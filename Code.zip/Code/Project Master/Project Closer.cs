﻿using System;
using System.Data;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using System.Collections.Generic;
using System.Text;
using Outlook = Microsoft.Office.Interop.Outlook;





namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class Project_Closer : Form
    {
        DataTable ProjectCloserSelectprojectCode = new DataTable();
        DataTable ProjectCloserSelectprojectCode1 = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        Timer marqueeTimer = new Timer();
        DataTable dtBOMlist = new DataTable();
        DataTable dtBOMstaus = new DataTable();
        frmForm2 frm = new frmForm2();
        Global GlobalClass = new Global();
        Login.frmLoginForm login = new Login.frmLoginForm();
        List<string> pdfFilePaths = new List<string>();
        public Project_Closer()
        {
            InitializeComponent();
            // Add title label
            AddTitleLabel();
            
            // Start marquee effect
            //StartMarquee();
            // Set the title of the form
            this.Text = "Project Closure";

            // Add event handler for project code selection change
            cmbProjectcode.SelectedIndexChanged += comselectedprojectcodeBom_SelectedIndexChanged;

            // Add event handler for checkbox changes
            dgBOMprojectstatusList.CellValueChanged += dgBOMprojectstatusList_CellValueChanged;
            dgBOMprojectstatusList.CurrentCellDirtyStateChanged += dgBOMprojectstatusList_CurrentCellDirtyStateChanged;

            // Add event handler for comselectdispatch dropdown change
            comselectdispatch.SelectedIndexChanged += comselectdispatch_SelectedIndexChanged;

            // Make comselectdispatch read-only
            comselectdispatch.DropDownStyle = ComboBoxStyle.DropDownList;
            comselectdispatch.Enabled = true;
        }

        private void AddTitleLabel()
        {
            Label labelProjectClosure = new Label();
            // Adjust the titleLabel position when the form resizes
            this.Resize += (sender, e) =>
            {
                labelProjectClosure.Location = new System.Drawing.Point((this.ClientSize.Width - labelProjectClosure.Width) / 2, 10);
            };
        }

        private void StartMarquee()
        {
            marqueeTimer.Interval = 100; // Adjust the interval as needed for the scrolling speed
            marqueeTimer.Tick += MarqueeTimer_Tick;
            marqueeTimer.Start();
        }

        private void MarqueeTimer_Tick(object sender, EventArgs e)
        {
            // Move the label horizontally
            // Uncomment and complete the code when titleLabel is properly initialized
            labelProjectClosure.Location = new System.Drawing.Point(labelProjectClosure.Location.X - 1, labelProjectClosure.Location.Y);

            // Reset the label position when it moves out of the form's bounds
             if (labelProjectClosure.Right < 0)
             {
                labelProjectClosure.Location = new System.Drawing.Point(this.ClientSize.Width, labelProjectClosure.Location.Y);
             }
        }

        private void Project_Closer_Load(object sender, EventArgs e)
        {
            LoadProjectCodes();
            //LoadProjectCodesinserted();
            DataGridViewCheckBoxColumn chkBoxColumn = new DataGridViewCheckBoxColumn();
            chkBoxColumn.Frozen = true; // Make the new column frozen
            dgBOMprojectstatusList.Columns.Insert(0, chkBoxColumn);
            ResetForm();
            
        }

        private void LoadProjectCodes()
        {
            ProjectCloserSelectprojectCode = DAL.Project_Closer_select_project_Code(0, null).Tables[0];

            if (ProjectCloserSelectprojectCode.Rows.Count > 0)
            {
                foreach (DataRow DR in ProjectCloserSelectprojectCode.Rows)
                {
                    if (!cmbProjectcode.Items.Contains(DR["ProjectCode"].ToString()))
                        cmbProjectcode.Items.Add(DR["ProjectCode"].ToString());
                }
            }
        }
        /*
        private void LoadProjectCodesinserted()
        {
            ProjectCloserSelectprojectCode = DAL.Project_Closer_select_project_Code(1,null).Tables[0];

            if (ProjectCloserSelectprojectCode.Rows.Count > 0)
            {
                foreach (DataRow DR in ProjectCloserSelectprojectCode.Rows)
                {
                    if (!comsectinsertedProjectcode.Items.Contains(DR["ProjectCode"].ToString()))
                        comsectinsertedProjectcode.Items.Add(DR["ProjectCode"].ToString());
                }
            }
        }
        */
        private void comselectedprojectcodeBom_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
            if (comselectedprojectcodeBom.SelectedItem != null)
            {
                string selectedProjectCode = comselectedprojectcodeBom.SelectedItem.ToString();
                LoadBOMData(selectedProjectCode);
            }
            */
        }

        private void LoadBOMDataShipped(string projectCode)
        {
            // Fetch data based on selected project code
            dtBOMlist = DAL.fnMpBOMlistPOOrderFilter(1, projectCode).Tables[0];

            // Ensure combinedData is populated with data from dtBOMlist
            DataTable combinedData = dtBOMlist.Copy();

            // Bind the combined data to the grid
            dgBOMprojectstatusList.DataSource = combinedData;

            // Make all cells read-only except the checkbox column
            foreach (DataGridViewColumn column in dgBOMprojectstatusList.Columns)
            {
                if (!(column is DataGridViewCheckBoxColumn))
                {
                    column.ReadOnly = true;
                }
            }

            // Hide the grid initially
            dgBOMprojectstatusList.Visible = false;
        }


        private void LoadBOMDataWIP(string projectCode)
        {
            // Fetch data based on selected project code
            dtBOMlist = DAL.fnMpBOMlistPOOrderFilter(0, projectCode).Tables[0];

            // Ensure combinedData is populated with data from dtBOMlist
            DataTable combinedData = dtBOMlist.Copy();

            // Bind the combined data to the grid
            dgBOMprojectstatusList.DataSource = combinedData;

            // Make all cells read-only except the checkbox column
            foreach (DataGridViewColumn column in dgBOMprojectstatusList.Columns)
            {
                if (!(column is DataGridViewCheckBoxColumn))
                {
                    column.ReadOnly = true;
                }
            }
            dgBOMprojectstatusList.Columns["projectstatus"].Visible = false;

            // Hide the grid initially
            dgBOMprojectstatusList.Visible = false;
        }

        private void dgBOMprojectstatusList_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgBOMprojectstatusList.IsCurrentCellDirty)
            {
                dgBOMprojectstatusList.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void dgBOMprojectstatusList_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0 && e.RowIndex >= 0)
            {
                DataGridViewCheckBoxCell chkCell = (DataGridViewCheckBoxCell)dgBOMprojectstatusList.Rows[e.RowIndex].Cells[0];
                bool isChecked = (bool)chkCell.Value;

                if (isChecked)
                {
                    // Fetch all data from the selected row
                    DataGridViewRow selectedRow = dgBOMprojectstatusList.Rows[e.RowIndex];
                    string projectStatus = selectedRow.Cells["projectstatus"].Value.ToString();
                    /*
                    if (projectStatus == "Shipped")
                    {
                        comselectdispatch.SelectedItem = "YES";
                        //comselectdispatch.SelectedItem = "NO";
                    }
                    else
                    {
                        comselectdispatch.SelectedItem = "NO";
                        //comselectdispatch.SelectedItem = "YES";
                    }
                    */
                    comselectdispatch.SelectedItem = "NO";
                    comselectdispatch.Enabled = true;
                }
                else
                {
                    comselectdispatch.SelectedIndex = -1;
                    comselectdispatch.Enabled = true;
                    HideDispatchDetails();
                }
            }
        }

        private void comselectdispatch_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comselectdispatch.SelectedItem != null)
            {
                if (comselectdispatch.SelectedItem.ToString() == "NO")
                {
                    ShowDispatchDetails();
                    string selectedProjectCode = cmbProjectcode.SelectedItem.ToString();
                    LoadBOMDataWIP(selectedProjectCode);
                    dgBOMprojectstatusList.Visible = true;
                }
                else if (comselectdispatch.SelectedItem.ToString() == "YES")
                {
                    HideDispatchDetails();
                    string selectedProjectCode = cmbProjectcode.SelectedItem.ToString();
                    //LoadBOMDataShipped(selectedProjectCode);
                    dgBOMprojectstatusList.Visible = true;
                }
            }
            
        }

        private void ShowDispatchDetails()
        {
            labelReason.Visible = true;
            textBoxReason.Visible = true;
            labelReadyDate.Visible = true;
            dateTimePickerReadyDate.Visible = true;
            labelInstallationImpact.Visible = true;
            textBoxInstallationImpact.Visible = true;
            labelPaymentIssue.Visible = true;
            textBoxPaymentIssue.Visible = true;
        }

        private void HideDispatchDetails()
        {
            labelReason.Visible = false;
            textBoxReason.Visible = false;
            labelReadyDate.Visible = false;
            dateTimePickerReadyDate.Visible = false;
            labelInstallationImpact.Visible = false;
            textBoxInstallationImpact.Visible = false;
            labelPaymentIssue.Visible = false;
            textBoxPaymentIssue.Visible = false;
        }

        private void comboBoxOpenPoints_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxOpenPoints.SelectedItem != null)
            {
                if (comboBoxOpenPoints.SelectedItem.ToString() == "YES")
                {
                    labelThereasonforopenpoints.Visible = true;
                    Thereasonforopenpoints.Visible = true;
                    textWhowilladdressatsitebyservice.Visible = true;
                    labelWhowilladdressatsitebyservice.Visible = true;
                }
                else if (comboBoxOpenPoints.SelectedItem.ToString() == "NO")
                {
                    labelThereasonforopenpoints.Visible = false;
                    Thereasonforopenpoints.Visible = false;
                    textWhowilladdressatsitebyservice.Visible = false;
                    labelWhowilladdressatsitebyservice.Visible = false;
                }
            }
        }

       


        private void comboBoxOpenPoints1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxOpenPoints1.SelectedItem != null)
            {
                if (comboBoxOpenPoints1.SelectedItem.ToString() == "YES")
                {
                    textThereasonforopenpoints1.Visible = true;
                    labelThereasonforopenpoints1.Visible = true;
                    textBoxWhyNotAddressed.Visible = true;
                    labelWhyNotAddressed.Visible = true;
                    dateTimePickerReadyToFix.Visible = true;
                    labelReadyToFix.Visible = true;
                    textWhowilladdressatsitebyservice1.Visible = true;
                    labelWhowilladdressatsitebyservice1.Visible = true;
                    textBoxInstallationImpact1.Visible = true;
                    labelInstallationImpact1.Visible = true;
                    textBoxPaymentIssue1.Visible = true;
                    labelPaymentIssue1.Visible = true;
                }
                else if (comboBoxOpenPoints1.SelectedItem.ToString() == "NO")
                {
                    textThereasonforopenpoints1.Visible = false;
                    labelThereasonforopenpoints1.Visible = false;
                    textBoxWhyNotAddressed.Visible = false;
                    labelWhyNotAddressed.Visible = false;
                    dateTimePickerReadyToFix.Visible = false;
                    labelReadyToFix.Visible = false;
                    textWhowilladdressatsitebyservice1.Visible = false;
                    labelWhowilladdressatsitebyservice1.Visible = false;
                    textBoxInstallationImpact1.Visible = false;
                    labelInstallationImpact1.Visible = false;
                    textBoxPaymentIssue1.Visible = false;
                    labelPaymentIssue1.Visible = false;
                }
            }
        }

        private void comcreticalinformation_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comcreticalinformation.SelectedItem != null)
            {
                if (comcreticalinformation.SelectedItem.ToString() == "YES")
                {
                    textBoxCompleteDetails.Visible = true;
                    labelBoxCompleteDetails.Visible = true;
                    labelSupportingDocuments.Visible = true;
                    textBoxSupportingDocuments.Visible = true;
                }
                else if (comcreticalinformation.SelectedItem.ToString() == "NO")
                {
                    textBoxCompleteDetails.Visible = false;
                    labelBoxCompleteDetails.Visible = false;
                    labelSupportingDocuments.Visible = false;
                    textBoxSupportingDocuments.Visible = false;
                }
            }
        }

        


      
        private void buttprojectclosersave_Click(object sender, EventArgs e)
        {
            //--------------------------------------------------------------------------------- first box validation start
            // Check if a project code is selected
            if (cmbProjectcode.SelectedItem == null || string.IsNullOrEmpty(cmbProjectcode.SelectedItem?.ToString()))
            {
                MessageBox.Show("Please select Project Code");
                return;
            }

            // Check if dispatch selection is made
            if (comselectdispatch.SelectedItem == null)
            {
                MessageBox.Show("Please select all items as per BOM ready to dispatch");
                return;
            }

            // Check if the date is selected in dateTimePickerReadyDate
            if (dateTimePickerReadyDate.Value.Date == DateTime.Today.Date && dateTimePickerReadyDate.Visible == true)
            {
                MessageBox.Show("Please select a valid Ready Date");
                return;
            }


            // Check if textBoxReason is empty
            if (string.IsNullOrWhiteSpace(textBoxReason.Text) && textBoxReason.Visible==true)
            {
                MessageBox.Show("Please enter The reason for delay, why not ready ?: ");
                textBoxReason.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textBoxReason.Focus();  // Set focus to textBoxReason
                return;
            }
            else
            {
                textBoxReason.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }

            // Check if textBoxInstallationImpact is empty
            if (string.IsNullOrWhiteSpace(textBoxInstallationImpact.Text) && textBoxInstallationImpact.Visible==true)
            {
                MessageBox.Show("Please enter How will it affect the installation");
                textBoxInstallationImpact.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textBoxInstallationImpact.Focus();  // Set focus to textBoxInstallationImpact
                return;
            }
            else
            {
                textBoxInstallationImpact.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }

            // Check if textBoxPaymentIssue is empty
            if (string.IsNullOrWhiteSpace(textBoxPaymentIssue.Text) && textBoxPaymentIssue.Visible==true)
            {
                MessageBox.Show("Please enter Any issue with payment realization");
                textBoxPaymentIssue.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textBoxPaymentIssue.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                textBoxPaymentIssue.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }
            //--------------------------------------------------------------- first box validation end

            //-------------------------------------------------------------------second box validation start

            // Check if open points to address at site (internal NC) are selected
            if (comboBoxOpenPoints.SelectedItem == null)
            {
                MessageBox.Show("Please select any open points to address at site as per internal NC");
                return;
            }
            // Check if Thereasonforopenpoints is empty
            if (string.IsNullOrWhiteSpace(Thereasonforopenpoints.Text) && Thereasonforopenpoints.Visible==true)
            {
                MessageBox.Show("Please enter The reason for openpoints");
                Thereasonforopenpoints.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                Thereasonforopenpoints.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                Thereasonforopenpoints.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }
            
            // Check if textWhowilladdressatsitebyservice is empty
            if (string.IsNullOrWhiteSpace(textWhowilladdressatsitebyservice.Text) && textWhowilladdressatsitebyservice.Visible==true)
            {
                MessageBox.Show("Please enter Who will address at site by service");
                textWhowilladdressatsitebyservice.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textWhowilladdressatsitebyservice.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                textWhowilladdressatsitebyservice.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }

            //---------------------------------------------------------------------second box validation end

            //---------------------------------------------------------------------3rd box validation

            // Check if open points to address at site (customer feedback during PDI) are selected
            if (comboBoxOpenPoints1.SelectedItem == null)
            {
                MessageBox.Show("Please select any open points to address at site, customer feedback during PDI");
                return;
            }

            // Check if the date is selected in dateTimePickerReadyToFix
            if (dateTimePickerReadyToFix.Value.Date == DateTime.Today.Date && dateTimePickerReadyToFix.Visible==true)
            {
                MessageBox.Show("Please select a valid Ready To Fix Date");
                return;
            }
            // Check if textThereasonforopenpoints1 is empty
            if (string.IsNullOrWhiteSpace(textThereasonforopenpoints1.Text) && textThereasonforopenpoints1.Visible==true)
            {
                MessageBox.Show("Please enter The reason for openpoints");
                textThereasonforopenpoints1.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textThereasonforopenpoints1.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                textThereasonforopenpoints1.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }

            // Check if textWhowilladdressatsitebyservice1 is empty
            if (string.IsNullOrWhiteSpace(textWhowilladdressatsitebyservice1.Text) && textWhowilladdressatsitebyservice1.Visible==true)
            {
                MessageBox.Show("Please enter Who will address at site by service");
                textWhowilladdressatsitebyservice1.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textWhowilladdressatsitebyservice1.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                textWhowilladdressatsitebyservice1.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }

            // Check if textBoxWhyNotAddressed is empty
            if (string.IsNullOrWhiteSpace(textBoxWhyNotAddressed.Text) && textBoxWhyNotAddressed.Visible==true)
            {
                MessageBox.Show("Please enter Why Not Addressed");
                textBoxWhyNotAddressed.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textBoxWhyNotAddressed.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                textBoxWhyNotAddressed.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }

            // Check if textBoxPaymentIssue1 is empty
            if (string.IsNullOrWhiteSpace(textBoxPaymentIssue1.Text) && textBoxPaymentIssue1.Visible==true)
            {
                MessageBox.Show("Please enter Payment Issue");
                textBoxPaymentIssue1.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textBoxPaymentIssue1.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                textBoxPaymentIssue1.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }


            // Check if textBoxInstallationImpact1 is empty
            if (string.IsNullOrWhiteSpace(textBoxInstallationImpact1.Text) && textBoxInstallationImpact1.Visible==true)
            {
                MessageBox.Show("Please enter Installation Impact");
                textBoxInstallationImpact1.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textBoxInstallationImpact1.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                textBoxInstallationImpact1.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }
            //---------------------------------------------------------------------3rd box validation end

            //---------------------------------------------------------------------4rd box validation start

            // Check if critical information is selected
            if (comcreticalinformation.SelectedItem == null)
            {
                MessageBox.Show("Please select critical information");
                return;
            }

            // Check if textBoxCompleteDetails is empty
            if (string.IsNullOrWhiteSpace(textBoxCompleteDetails.Text) && textBoxCompleteDetails.Visible==true)
            {
                MessageBox.Show("Please enter Complete Details");
                textBoxCompleteDetails.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textBoxCompleteDetails.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                textBoxCompleteDetails.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }

            // Check if textBoxSupportingDocuments is empty
            if (string.IsNullOrWhiteSpace(textBoxSupportingDocuments.Text) && textBoxSupportingDocuments.Visible==true)
            {
                MessageBox.Show("Please enter Supporting Documents");
                textBoxSupportingDocuments.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textBoxSupportingDocuments.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                textBoxSupportingDocuments.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }
            //---------------------------------------------------------------------4rd box validation end
            //------------------------------------------------------------------------------------5th box validation start

            // Check if Lesson Learnt is selected
            
            // Check if textMandatetoanswerthis is empty
            if (string.IsNullOrWhiteSpace(textMandatetoanswerthis.Text) && textMandatetoanswerthis.Visible==true)
            {
                MessageBox.Show("Please Enter Mandate to Answer this Question");
                textMandatetoanswerthis.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textMandatetoanswerthis.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                textMandatetoanswerthis.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }
            //----------------------------------------------------------------------------------5th box validation end

            // Check if at least one checkbox in the DataGridView is checked
            bool isCheckboxChecked = false;
            foreach (DataGridViewRow row in dgBOMprojectstatusList.Rows)
            {
                DataGridViewCheckBoxCell chkCell = (DataGridViewCheckBoxCell)row.Cells[0];
                if (chkCell.Value != null && (bool)chkCell.Value)
                {
                    isCheckboxChecked = true;
                    break;
                }
            }
           
            if (!isCheckboxChecked && dgBOMprojectstatusList.Visible==true)
            {
                MessageBox.Show("Please select at least one item from the BOM project status list.");
                return;
            }
            else
            {/*
                // Declare variables to store textbox values
                string projectCode = comselectedprojectcodeBom.SelectedItem?.ToString();
                string dispatchSelection = comselectdispatch.SelectedItem?.ToString();

                string ReadyDate = dateTimePickerReadyDate.Value.Date.ToString("dd-MM-yyyy");
                string reasonForDelay = textBoxReason.Text;
                string installationImpact = textBoxInstallationImpact.Text;
                string paymentIssue = textBoxPaymentIssue.Text;
                string openPointsAddressSite = comboBoxOpenPoints.SelectedItem?.ToString();
                string reasonForOpenPoints = Thereasonforopenpoints.Text;
                string whoAddressSiteService = textWhowilladdressatsitebyservice.Text;
                string openPointsAddressSiteFeedback = comboBoxOpenPoints1.SelectedItem?.ToString();
                string ReadyToFix = dateTimePickerReadyToFix.Value.Date.ToString("dd-MM-yyyy");
                string reasonForOpenPointsFeedback = textThereasonforopenpoints1.Text;
                string whoAddressSiteServiceFeedback = textWhowilladdressatsitebyservice1.Text;
                string whyNotAddressed = textBoxWhyNotAddressed.Text;
                string paymentIssueFeedback = textBoxPaymentIssue1.Text;
                string installationImpactFeedback = textBoxInstallationImpact1.Text;
                string criticalInformation = comcreticalinformation.SelectedItem?.ToString();
                string completeDetails = textBoxCompleteDetails.Text;
                string supportingDocuments = textBoxSupportingDocuments.Text;
                string lessonLearnt = comLessonLearnt.SelectedItem?.ToString();
                string mandateToAnswer = textMandatetoanswerthis.Text;

                // Concatenate all values into a single message
                string message = $"Project Code: {projectCode}\n" +
                                 $"Dispatch Selection: {dispatchSelection}\n" +
                                 $"ReadyDate:{ReadyDate}\n" +
                                 $"Reason for Delay: {reasonForDelay}\n" +
                                 $"Installation Impact: {installationImpact}\n" +
                                 $"Payment Issue: {paymentIssue}\n" +
                                 $"Open Points Address Site: {openPointsAddressSite}\n" +
                                 $"Reason for Open Points: {reasonForOpenPoints}\n" +
                                 $"Who Will Address Site by Service: {whoAddressSiteService}\n" +
                                 $"Open Points Address Site Feedback: {openPointsAddressSiteFeedback}\n" +
                                 $"ReadyToFix:{ReadyToFix}\n" +
                                 $"Reason for Open Points Feedback: {reasonForOpenPointsFeedback}\n" +
                                 $"Who Will Address Site by Service Feedback: {whoAddressSiteServiceFeedback}\n" +
                                 $"Why Not Addressed: {whyNotAddressed}\n" +
                                 $"Payment Issue Feedback: {paymentIssueFeedback}\n" +
                                 $"Installation Impact Feedback: {installationImpactFeedback}\n" +
                                 $"Critical Information: {criticalInformation}\n" +
                                 $"Complete Details: {completeDetails}\n" +
                                 $"Supporting Documents: {supportingDocuments}\n" +
                                 $"Lesson Learnt: {lessonLearnt}\n" +
                                 $"Mandate to Answer: {mandateToAnswer}";

                // Display all values in a message box
                MessageBox.Show(message);
                */
            }

            // Your logic here

            // Declare variables to store textbox values
            string projectCode = cmbProjectcode.SelectedItem?.ToString();
            string dispatchSelection = comselectdispatch.SelectedItem?.ToString();

            string ReadyDate = dateTimePickerReadyDate.Value.Date.ToString("dd-MM-yyyy");
            string reasonForDelay = textBoxReason.Text;
            string installationImpact = textBoxInstallationImpact.Text;
            string paymentIssue = textBoxPaymentIssue.Text;
            string openPointsAddressSite = comboBoxOpenPoints.SelectedItem?.ToString();
            string reasonForOpenPoints = Thereasonforopenpoints.Text;
            string whoAddressSiteService = textWhowilladdressatsitebyservice.Text;
            string openPointsAddressSiteFeedback = comboBoxOpenPoints1.SelectedItem?.ToString();
            string ReadyToFix = dateTimePickerReadyToFix.Value.Date.ToString("dd-MM-yyyy");
            string reasonForOpenPointsFeedback = textThereasonforopenpoints1.Text;
            string whoAddressSiteServiceFeedback = textWhowilladdressatsitebyservice1.Text;
            string whyNotAddressed = textBoxWhyNotAddressed.Text;
            string paymentIssueFeedback = textBoxPaymentIssue1.Text;
            string installationImpactFeedback = textBoxInstallationImpact1.Text;
            string criticalInformation = comcreticalinformation.SelectedItem?.ToString();
            string completeDetails = textBoxCompleteDetails.Text;
            string supportingDocuments = textBoxSupportingDocuments.Text;
            
            string mandateToAnswer = textMandatetoanswerthis.Text;

           

            // Iterate through the DataGridView rows
            foreach (DataGridViewRow row in dgBOMprojectstatusList.Rows)
            {
                // Check if the checkbox in the first column of the row is checked
                DataGridViewCheckBoxCell chkCell = (DataGridViewCheckBoxCell)row.Cells[0];
                if (chkCell.Value != null && (bool)chkCell.Value)
                {
                    // Fetch data from the row based on your requirements
                    //string SlNo = row.Cells["SlNo"].Value.ToString();
                    string ProductName = row.Cells["ProductName"].Value.ToString();
                    string Quantity = row.Cells["Quantity"].Value.ToString();
                    string ProductCode = row.Cells["ProductCode"].Value.ToString();
                    string selectedProjectCode = cmbProjectcode.SelectedItem.ToString();

                    // Insert logic to save data to your database or perform other actions
                    // For demonstration purposes, I'll just show a message box with the data
                    
                    // Concatenate all values into a single message
                    string message = $"Project Code: {selectedProjectCode}\n" +
                                     //$"Project SlNo: { SlNo}\n" +
                                     $"Project ProductName: {ProductName}\n" +
                                     $"Project Quantity: {Quantity}\n" +
                                     $"Project ProductCode: {ProductCode}\n" +
                                     $"All items as per BOM ready to dispatch: { dispatchSelection}\n" +
                                     $"When it will be ready to dispatch: { ReadyDate}\n" +
                                     $"The reason for delay, why not ready: { reasonForDelay}\n" +
                                     $"How will it affect the installation: { installationImpact}\n" +
                                     $"Any issue with payment realization: { paymentIssue}\n" +
                                     $"Any open points to address at site as per internal NC: {openPointsAddressSite}\n" +
                                     $"The reason for open points: {reasonForOpenPoints}\n" +
                                     $"Who will address at site by service engineer: { whoAddressSiteService}\n" +
                                     $"Any open points to address at site, customer feedback during PDI: { openPointsAddressSiteFeedback}\n" +
                                     $"When it will be ready to fix at site :{ ReadyToFix}\n" +
                                     $"Reason for Open Points Feedback: {reasonForOpenPointsFeedback}\n" +
                                     $"Who will address at site by service engineer: { whoAddressSiteServiceFeedback}\n" +
                                     $"Why not addressed before dispatch: { whyNotAddressed}\n" +
                                     $"Any issue with payment realization: { paymentIssueFeedback}\n" +
                                     $"How will it affect the installation: { installationImpactFeedback}\n" +
                                     $"Critical information to site/installation engineer and / or sales focal: { criticalInformation}\n" +
                                     $"information in the tab with complete details: { completeDetails}\n" +
                                     $"supporting documents: {supportingDocuments}\n" +
                                    
                                     $"Mandate to answer this question: { mandateToAnswer}";

                    // Display all values in a message box

                    DataTable isDuplicateKeyTableProjectcloserDeatis = DAL.CheckDuplicateKeyModel(3, ProductCode).Tables[0];
                    if (isDuplicateKeyTableProjectcloserDeatis.Rows.Count > 0)
                    {
                        //MessageBox.Show("already exists data {ProductCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        MessageBox.Show($"The product with code {ProductCode} already exists in the system.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        //textMaterialModelNO.Focus();
                        return;
                    }
                    // Get the current date
                    DateTime currentDate = DateTime.Now;
                    string currentDateString = currentDate.ToString("dd-MM-yyyy HH:mm:ss");
                    GlobalClass.iStatus = DAL.ProjectCloserDetails(0,
                        selectedProjectCode,
                        //SlNo,
                        ProductName,
                        Quantity,
                        ProductCode,
                        dispatchSelection,
                        ReadyDate,
                        reasonForDelay,
                        installationImpact,
                        paymentIssue,
                        openPointsAddressSite,
                        reasonForOpenPoints,
                        whoAddressSiteService,
                        openPointsAddressSiteFeedback,
                        ReadyToFix,
                        reasonForOpenPointsFeedback,
                        whoAddressSiteServiceFeedback,
                        whyNotAddressed,
                        paymentIssueFeedback,
                        installationImpactFeedback,
                        criticalInformation,
                        completeDetails,
                        supportingDocuments,
                        mandateToAnswer,
                        login.GetUserDetails[2],
                        currentDateString
                        );  
                }
               
            }

            
            MessageBox.Show("Project Closer Inserted", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Hide();
            // Display "I am a hero" message box after all validations and operations are successful
            Project_Closer Project_Closer = new Project_Closer();
            Project_Closer.Show();
            
            ResetForm();
        }


        private void ResetForm()
        {
            ResetControls(this.Controls);
        }

        private void ResetControls(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is ComboBox comboBox)
                {
                    comboBox.SelectedItem = null;
                }
                else if (control is TextBox textBox)
                {
                    textBox.Clear();
                }
                else if (control.HasChildren)
                {
                    ResetControls(control.Controls);
                }
            }

            // Clear specific labels by name or other identifier
            ClearSpecificTexts();
        }
      
      

        private void ClearSpecificTexts()
        {
            labelReason.Visible = false;
            textBoxReason.Visible = false;
            labelReadyDate.Visible = false;
            dateTimePickerReadyDate.Visible = false;
            labelInstallationImpact.Visible = false;
            textBoxInstallationImpact.Visible = false;
            labelPaymentIssue.Visible = false;
            textBoxPaymentIssue.Visible = false;

            labelThereasonforopenpoints.Visible = false;
            Thereasonforopenpoints.Visible = false;
            textWhowilladdressatsitebyservice.Visible = false;
            labelWhowilladdressatsitebyservice.Visible = false;

            textThereasonforopenpoints1.Visible = false;
            labelThereasonforopenpoints1.Visible = false;
            textBoxWhyNotAddressed.Visible = false;
            labelWhyNotAddressed.Visible = false;
            dateTimePickerReadyToFix.Visible = false;
            labelReadyToFix.Visible = false;
            textWhowilladdressatsitebyservice1.Visible = false;
            labelWhowilladdressatsitebyservice1.Visible = false;
            textBoxInstallationImpact1.Visible = false;
            labelInstallationImpact1.Visible = false;
            textBoxPaymentIssue1.Visible = false;
            labelPaymentIssue1.Visible = false;

            textBoxCompleteDetails.Visible = false;
            labelBoxCompleteDetails.Visible = false;
            labelSupportingDocuments.Visible = false;
            textBoxSupportingDocuments.Visible = false;
            dgBOMprojectstatusList.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void AllitemsasperBOMreadytodispatch_Click(object sender, EventArgs e)
        {

        }
       

        private string ReadSignature()
        {
            string appDataDir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Microsoft\\Signatures";
            string signature = string.Empty;
            DirectoryInfo diInfo = new DirectoryInfo(appDataDir);

            if (diInfo.Exists)
            {
                FileInfo[] fiSignature = diInfo.GetFiles("*.htm");

                if (fiSignature.Length > 0)
                {
                    StreamReader sr = new StreamReader(fiSignature[0].FullName, Encoding.Default);
                    signature = sr.ReadToEnd();

                    if (!string.IsNullOrEmpty(signature))
                    {
                        string fileName = fiSignature[0].Name.Replace(fiSignature[0].Extension, string.Empty);
                        signature = signature.Replace(fileName + "_files/", appDataDir + "/" + fileName + "_files/");
                    }
                }
            }
            return signature;
        }
        DataTable dtEMailID = new DataTable();
        bool bMail = false;
        
        public void fnApprovetMail(string sUser, string sRemarks, ListBox sCC, string attachmentFilename)
        {
            bMail = false;
            DataTable dtlogindetails = DAL.fnloginemail(sUser.Trim()).Tables[0];
            if (dtlogindetails.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                {
                    Outlook.Application oApp = new Outlook.Application();
                    Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                    // Add the attachment to the email
                    if (File.Exists(attachmentFilename))
                    {
                        oMsg.Attachments.Add(attachmentFilename);
                    }

                    // Set the recipient(s)
                    Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                    oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                    oRecips.ResolveAll();

                    // Add CC recipients
                    if (sCC.Items.Count > 0)
                    {
                        foreach (string ccEmail in sCC.Items)
                        {
                            if (!string.IsNullOrEmpty(ccEmail))
                            {
                                Outlook.Recipient oRecipCC = (Outlook.Recipient)oRecips.Add(ccEmail);
                                oRecipCC.Type = (int)Outlook.OlMailRecipientType.olCC;
                                oRecipCC.Resolve();
                            }
                        }
                    }

                    // Set the email properties
                    oMsg.Subject = "" + cmbProjectcode.Text + " sent for " + " approval";
                    oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Project Closer <font color='blue'>" + cmbProjectcode.Text + " </font> sent for " + " approval. <font color='red'> " + "<br /></font> Remarks : <br /> <br />";
                    oMsg.HTMLBody += "<br /><br /><br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /><br /><br /><br /><br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                    // Send the email
                    oMsg.Send();

                    // Release COM objects
                    oMsg = null;
                    oApp = null;
                }
            }
        }
        public class EmailApprovalContext
        {
            public string UserName { get; set; }
            public string Message { get; set; }
            public List<string> EmailAddresses { get; set; }
        }
        
        public void SendApprovalEmailWithAttachment(EmailApprovalContext approvalContext, string attachmentFilePath)

        {

            // Create a ListBox and populate it with email addresses

            ListBox emailListBox = new ListBox();

            emailListBox.Items.AddRange(approvalContext.EmailAddresses.ToArray());


            // Call the function to send the approval email with an attachment

            fnApprovetMailWithAttachment(approvalContext.UserName, approvalContext.Message, emailListBox, attachmentFilePath);


            // Clear the ListBox items (if needed)

            emailListBox.Items.Clear();

        }
    
        public void fnApprovetMailWithAttachment(string sUser, string sRemarks, ListBox sCC, string attachmentFilePath)
        {
            bMail = false;
            DataTable dtlogindetails = DAL.fnloginemail(sUser.Trim()).Tables[0];
            if (dtlogindetails.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                {
                    Outlook.Application oApp = new Outlook.Application();
                    Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                    // Add the attachment to the email
                    if (File.Exists(attachmentFilePath))
                    {
                        oMsg.Attachments.Add(attachmentFilePath);
                    }


                    foreach (string path in pdfFilePaths)
                    {
                        MessageBox.Show("PDF created at: " + path);
                        //Outlook.Attachment attachment1 = oMsg.Attachments.Add(@"C:\ERP v6.8 Released version\ERP v6.8\Erp Project With Buttons\Certificate of Compliance.pdf");
                        // Create an attachment for each file path and add it to the email
                        try
                        {
                            Outlook.Attachment attachment = oMsg.Attachments.Add(path, Outlook.OlAttachmentType.olByValue, Type.Missing, Type.Missing);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error attaching file: " + ex.Message);
                        }
                    }
                    //Outlook.Attachment attachment1 = oMsg.Attachments.Add(@"C:\ERP v6.8 Released version\ERP v6.8\Erp Project With Buttons\Certificate of Compliance.pdf");
                    //Outlook.Attachment attachment2 = oMsg.Attachments.Add(@"C:\ERP v6.8 Released version\ERP v6.8\Erp Project With Buttons\Letter of Origin.pdf");
                    //Outlook.Attachment attachment3 = oMsg.Attachments.Add(@"C:\ERP v6.8 Released version\ERP v6.8\Erp Project With Buttons\Letter of Quality.pdf");
                    // Set the recipient(s)
                    Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                    oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                    oRecips.ResolveAll();

                    // Set the email properties
                    oMsg.Subject = "Project Closure: " + "" + cmbProjectcode.Text + " sent for " + " shreeshail is Testing mail ignore this mail ";
                    oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> We are pleased to inform you that the <font color='blue'>" + cmbProjectcode.Text + " </font> has been completed successfully " + "  Please find attached file. <font color='red'> " + "<br /></font> Remarks : <br /> <br />";
                    oMsg.HTMLBody += "<br /><br /><br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /><br /><br /><br /><br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                    
                    if (sCC.Items.Count > 0)
                    {
                        Outlook.Recipient oRecip;
                        List<string> sCCRecipsList = new List<string>();

                        
                        foreach (string tempTO in sCC.Items)
                        {
                            if (tempTO != null)
                                sCCRecipsList.Add(tempTO);
                        }
                        foreach (string t in sCCRecipsList)
                        {
                            oRecip = (Outlook.Recipient)oRecips.Add(t);
                            oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                            oRecip.Resolve();
                        }
                        oMsg.Send();
                        oRecip = null;
                    }
                    else
                    {
                        oMsg.Send();
                        oRecips = null;
                    }
                    
                    bMail = true;
                    oMsg = null;
                    oApp = null;
                 
                }
            }
        }
        
        private void buttprint_Click(object sender, EventArgs e)
        {
            

            // Hide the TextBoxes
            //updateModelNumber.Visible = false;
            //cmbProjectcode.Visible = false;
            //labprojeccode1.Visible = true;
            //comsectinsertedProjectcode.Visible = true;

            if (string.IsNullOrEmpty(cmbProjectcode.Text))
            {
                // Show an error message to the user
                MessageBox.Show("Project code cannot be empty. Please enter a valid project code.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                // Optionally, set focus to the input field
                cmbProjectcode.Focus();

                // Return from the method to prevent further processing
                return;
            }
            // Querying the database to select project code information
            ProjectCloserSelectprojectCode = DAL.Project_Closer_select_project_Code(2, cmbProjectcode.Text).Tables[0];
           

            // Ensure there are rows in the DataTable
            if (ProjectCloserSelectprojectCode.Rows.Count > 0)
            {
                /*
                // Initialize a StringBuilder to collect all ProductCodeSerialNumber values
                StringBuilder allProductCodeSerialNumbers = new StringBuilder();

                // Loop through each row in the DataTable
                foreach (DataRow row in ProjectCloserSelectprojectCode.Rows)
                {
                    // Extracting ProductCodeSerialNumber from the current row
                    string ProductCodeSerialNumber = row["QRSlNo"].ToString();

                    // Append the ProductCodeSerialNumber to the StringBuilder, followed by a comma
                    allProductCodeSerialNumbers.Append(ProductCodeSerialNumber + ",");
                }

                // Remove the last comma if there is any content in the StringBuilder
                if (allProductCodeSerialNumbers.Length > 0)
                {
                    allProductCodeSerialNumbers.Length--; // This removes the last comma
                }

                // Display all collected ProductCodeSerialNumber values
                string SerialNumbers = allProductCodeSerialNumbers.ToString();
                MessageBox.Show(SerialNumbers, "Product Code Serial Numbers");
                */

                try
                {

                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    saveFileDialog.DefaultExt = "pdf";
                    saveFileDialog.Filter = "PDF files (*.pdf)|*.pdf";

                    // Create Certificate of Compliance PDF
                    saveFileDialog.FileName = "Certificate of Compliance.pdf";
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string fileName = saveFileDialog.FileName;
                        CreateCertificateOfCompliancePDF(fileName);//SerialNumbers
                        pdfFilePaths.Add(fileName);
                    }

                    // Create Letter of Origin PDF
                    saveFileDialog.FileName = "Letter of Origin.pdf";
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string fileName = saveFileDialog.FileName;
                        CreateLetterOfOriginPDF(fileName);//SerialNumbers
                        pdfFilePaths.Add(fileName);
                    }

                    // Create Letter of Quality PDF
                    saveFileDialog.FileName = "Letter of Quality.pdf";
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string fileName = saveFileDialog.FileName;
                        CreateLetterOfQualityPDF(fileName);//SerialNumbers
                        pdfFilePaths.Add(fileName);
                    }

                    MessageBox.Show("PDFs saved successfully!");
                    //VendorEMail(dtGetVendorDetails.Rows[0]["EmailAddress"].ToString(), FileFul);

                    // Fetch data from database

                    DataTable dtEMailID = DAL.PORemarksHistory(8, cmbProjectcode.Text).Tables[0];
                   
                    // Create an instance of EmailApprovalContext

                    EmailApprovalContext approvalContext = new EmailApprovalContext

                    {

                    EmailAddresses = new List<string>(),



                    UserName = "Thilak Kumar",//login.GetUserDetails[2],

                        Message = "has been successfully completed"

                    };

                    // Check if there are rows in the DataTable
                    if (dtEMailID.Rows.Count > 0)

                    {

                        // Loop through each row in the DataTable

                        for (int i = 0; i < dtEMailID.Rows.Count; i++)

                        {

                            // Retrieve the email ID and check if it's not empty

                            string emailId = dtEMailID.Rows[i]["Email"].ToString();

                            if (!string.IsNullOrEmpty(emailId))

                            {

                                // Add the email ID to the list

                                approvalContext.EmailAddresses.Add(emailId);

                            }
                        }
                       
                        SendApprovalEmailWithAttachment(approvalContext, "attachment.pdf");

                    }


                    ResetForm();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
        
        private void CreateCertificateOfCompliancePDF(string fileName)//string SerialNumbers
        {
            // Create a new PDF document
           
            // Create a new PDF document with increased left margin
            Document document = new Document(PageSize.A4, 50, 50, 40, 30);
            try
            {
                using (FileStream fs = new FileStream(fileName, FileMode.Create))
                {
                    PdfWriter writer = PdfWriter.GetInstance(document, fs);

                    // Assign the custom event handler for header and footer
                    PdfHeaderFooter pageEventHandler = new PdfHeaderFooter();
                    writer.PageEvent = pageEventHandler;

                    // Open the document for writing
                    document.Open();


                    // Calculate the position for drawing the line and adding text
                    float lineYPosition = document.TopMargin + 650; // Adjust the Y position as needed
                    float textLineYPosition = lineYPosition - 10; // Adjust for text line position

                    // Get the direct content for drawing
                    PdfContentByte cb = writer.DirectContent;
                    cb.SetColorStroke(BaseColor.BLACK); // Set line color

                    // Text to be added above the line
                    string text = "Certificate of Compliance";
                    BaseFont bfBold = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                    float textWidth = bfBold.GetWidthPoint(text, 12); // Calculate text width with font size 12

                    // Calculate the adjusted line margins
                    float lineStartX = (document.PageSize.Width - textWidth) / 2; // Center the text
                    float lineEndX = lineStartX + textWidth;

                    // Draw the straight line
                    cb.MoveTo(lineStartX, lineYPosition + 6); // Move to the adjusted starting point
                    cb.LineTo(lineEndX, lineYPosition + 6); // Draw a line to the adjusted ending point
                    cb.Stroke(); // Stroke the line

                    // Add text above the line
                    cb.BeginText();
                    cb.SetFontAndSize(bfBold, 12); // Use bold font
                    cb.ShowTextAligned(PdfContentByte.ALIGN_CENTER, text, document.PageSize.Width / 2, lineYPosition + 10, 0);
                    cb.EndText();


                    // Add a paragraph after the header
                    document.Add(new Paragraph(" "));

                    // Add certificate of compliance content
                    Paragraph complianceParagraph = new Paragraph();
                    complianceParagraph.Add(Chunk.NEWLINE); // Empty line
                    complianceParagraph.Add(Chunk.NEWLINE); // Empty line
                    complianceParagraph.Add(Chunk.NEWLINE); // Empty line
                    complianceParagraph.Add(Chunk.NEWLINE); // Empty line
                    complianceParagraph.Add(Chunk.NEWLINE); // Empty line
                    complianceParagraph.Add(Chunk.NEWLINE); // Empty line

                    Font contentFont = FontFactory.GetFont("Calibri", BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 12);
                    ProjectCloserSelectprojectCode1 = DAL.Project_Closer_select_project_Code(3, cmbProjectcode.Text).Tables[0];

                    string ModelNumber = ProjectCloserSelectprojectCode1.Rows[0]["MachineModelNumber"].ToString();
                    string SerialNumbers = ProjectCloserSelectprojectCode1.Rows[0]["QRSlNo"].ToString();
                    string contentString = $"This is to certify that the equipment bearing the model number {ModelNumber} and serial numbers {SerialNumbers} is an Indian Registry of approved product used in test & measurement systems and is as per requirement.";
                    complianceParagraph.Add(new Phrase(contentString, contentFont));
                    //complianceParagraph.Add(new Phrase("This is to certify that the equipment bearing the model number UT-04-0050 and serial numbers 113989-23070298, 113991-23070299, 114000-23070300, and 114001-23070301 is an Indian Registry of approved product used in test & measurement systems and is as per requirement.", contentFont)); // Content
                    complianceParagraph.Alignment = Element.ALIGN_JUSTIFIED;
                    complianceParagraph.SpacingBefore = 20f;
                    
                    document.Add(complianceParagraph);

                    // Add authorized signatory line aligned to the left
                    Paragraph signatoryParagraph = new Paragraph();
                    signatoryParagraph.Add(Chunk.NEWLINE); // Empty line
                    signatoryParagraph.Add(Chunk.NEWLINE); // Empty line
                    signatoryParagraph.Add(Chunk.NEWLINE); // Empty line
                    signatoryParagraph.Add(new Phrase("Authorised Signatory for ITW India Private Limited-BISS Division", contentFont));
                    signatoryParagraph.Alignment = Element.ALIGN_LEFT; // Align left
                    signatoryParagraph.SpacingBefore = 50f; // Increase spacing before to move it further down

                    document.Add(signatoryParagraph);

                    // Add signatory image
                    string signImagePath = @"C:\Databasepath\BissSealSign1.png"; // Replace with your image path
                    Image signImage = Image.GetInstance(signImagePath); // Get instance of signatory image
                    signImage.ScaleToFit(100f, 50f); // Adjust size as needed
                    signImage.Alignment = Element.ALIGN_LEFT; // Align image to the left
                    document.Add(signImage); // Add signatory image to the document
                                             // Add additional space (10% below signatory line)
                    float additionalSpaceY = signatoryParagraph.TotalLeading + signatoryParagraph.SpacingAfter;
                    document.Add(new Paragraph(additionalSpaceY, new Chunk("")));



                    // Add authorized signatory line aligned to the left
                    Paragraph signatoryParagraph1 = new Paragraph();
                    //signatoryParagraph1.Add(Chunk.NEWLINE); // Empty line
                    
                    signatoryParagraph1.Add(new Phrase("Authorised Signatory", contentFont));
                    signatoryParagraph1.Alignment = Element.ALIGN_LEFT; // Align left
                    signatoryParagraph1.SpacingBefore = 10f; // Increase spacing before to move it further down

                    document.Add(signatoryParagraph1);


                    // Add additional space (10% below signatory line)
                    float additionalSpaceY1 = signatoryParagraph.TotalLeading + signatoryParagraph.SpacingAfter;
                    document.Add(new Paragraph(additionalSpaceY1, new Chunk("")));
                    // Write header table
                    //headerTable.WriteSelectedRows(0, -1, document.LeftMargin, document.PageSize.Height - document.TopMargin + 10, writer.DirectContent);

                    // Create footer table with two columns
                    PdfPTable footerTable = new PdfPTable(2);
                    footerTable.TotalWidth = document.PageSize.Width - document.LeftMargin - document.RightMargin;
                    float[] footerWidths = new float[] { 50f, 50f };
                    footerTable.SetWidths(footerWidths);



                    // Assuming footerTable is your PdfPTable for the footer
                    PdfPCell footerSeparatorCell = new PdfPCell();
                    footerSeparatorCell.Colspan = 3; // Span across all three columns
                    footerSeparatorCell.Border = Rectangle.TOP_BORDER; // Use TOP_BORDER for the bottom separator line
                    footerSeparatorCell.BorderColorTop = BaseColor.RED; // Set border color to red
                    footerSeparatorCell.PaddingTop = 5f; // Adjust top padding to control line thickness

                    footerTable.AddCell(footerSeparatorCell); // Add the separator cell to the footer table
                                                                           
                    PdfContentByte cb1 = writer.DirectContent;
                    cb1.SetColorStroke(BaseColor.RED);
                    cb1.MoveTo(document.LeftMargin, document.PageSize.Height - document.TopMargin - 42);
                    cb1.LineTo(document.PageSize.Width - document.RightMargin, document.PageSize.Height - document.TopMargin - 42);
                    cb1.Stroke();
                    cb1.SetColorStroke(BaseColor.RED);
                    cb1.MoveTo(document.LeftMargin, document.BottomMargin - (-41));
                    cb1.LineTo(document.PageSize.Width - document.RightMargin, document.BottomMargin - (-41));
                    cb1.Stroke();
                    document.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error creating Certificate of Compliance PDF: " + ex.Message);
            }
        }

        



        private void CreateLetterOfOriginPDF(string fileName)//, string SerialNumbers
        {
            // Create a new PDF document with increased left margin
            Document document = new Document(PageSize.A4, 50, 50, 40, 30); // Changed left margin to 50

            try
            {
                using (FileStream fs = new FileStream(fileName, FileMode.Create))
                {
                    PdfWriter writer = PdfWriter.GetInstance(document, fs);

                    // Assign the custom event handler for header and footer
                    PdfHeaderFooter pageEventHandler = new PdfHeaderFooter();
                    writer.PageEvent = pageEventHandler;

                    // Open the document for writing
                    document.Open();

                    // Calculate the position for drawing the line and adding text
                    float lineYPosition = document.TopMargin + 650; // Adjust the Y position as needed
                    float textLineYPosition = lineYPosition - 10; // Adjust for text line position

                    // Get the direct content for drawing
                    PdfContentByte cb = writer.DirectContent;
                    cb.SetColorStroke(BaseColor.BLACK); // Set line color

                    // Text to be added above the line
                    string text = "Certificate of Origin";
                    BaseFont bfBold = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                    float textWidth = bfBold.GetWidthPoint(text, 12); // Calculate text width with font size 12

                    // Calculate the adjusted line margins
                    float lineStartX = (document.PageSize.Width - textWidth) / 2; // Center the text
                    float lineEndX = lineStartX + textWidth;

                    // Draw the straight line
                    cb.MoveTo(lineStartX, lineYPosition + 6); // Move to the adjusted starting point
                    cb.LineTo(lineEndX, lineYPosition + 6); // Draw a line to the adjusted ending point
                    cb.Stroke(); // Stroke the line

                    // Add text above the line
                    cb.BeginText();
                    cb.SetFontAndSize(bfBold, 12); // Use bold font
                    cb.ShowTextAligned(PdfContentByte.ALIGN_CENTER, text, document.PageSize.Width / 2, lineYPosition + 10, 0);
                    cb.EndText();

                    // Add a paragraph after the header
                    document.Add(new Paragraph(" "));

                    // Add Letter of Origin content
                    Paragraph originParagraph = new Paragraph();
                    originParagraph.Add(Chunk.NEWLINE); // Empty line
                    originParagraph.Add(Chunk.NEWLINE); // Empty line
                    originParagraph.Add(Chunk.NEWLINE); // Empty line
                    originParagraph.Add(Chunk.NEWLINE); // Empty line
                    originParagraph.Add(Chunk.NEWLINE); // Empty line
                    originParagraph.Add(Chunk.NEWLINE); // Empty line

                    Font contentFont = FontFactory.GetFont("Calibri", BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 12);
                    ProjectCloserSelectprojectCode1 = DAL.Project_Closer_select_project_Code(3, cmbProjectcode.Text).Tables[0];

                    string ModelNumber = ProjectCloserSelectprojectCode1.Rows[0]["MachineModelNumber"].ToString();
                    string SerialNumbers = ProjectCloserSelectprojectCode1.Rows[0]["QRSlNo"].ToString();
                    string contentString = $"This is to certify that the Equipment bearing model number {ModelNumber} Application with serial numbers {SerialNumbers} India. This is also to certify that the equipment meets or exceeds the performance requirments as per the requirement.";
                    originParagraph.Add(new Phrase(contentString, contentFont));
                    originParagraph.Alignment = Element.ALIGN_JUSTIFIED;
                    originParagraph.SpacingBefore = 20f;

                    document.Add(originParagraph);

                    // Add authorized signatory line aligned to the left
                    Paragraph signatoryParagraph = new Paragraph();
                    signatoryParagraph.Add(Chunk.NEWLINE); // Empty line
                    signatoryParagraph.Add(Chunk.NEWLINE); // Empty line
                    signatoryParagraph.Add(Chunk.NEWLINE); // Empty line
                    signatoryParagraph.Add(new Phrase("Authorised Signatory for ITW India Private Limited-BISS Division", contentFont));
                    signatoryParagraph.Alignment = Element.ALIGN_LEFT; // Align left
                    signatoryParagraph.SpacingBefore = 50f; // Increase spacing before to move it further down

                    document.Add(signatoryParagraph);

                    // Add signatory image
                    string signImagePath = @"C:\Databasepath\BissSealSign1.png"; // Replace with your image path
                    Image signImage = Image.GetInstance(signImagePath); // Get instance of signatory image
                    signImage.ScaleToFit(100f, 50f); // Adjust size as needed
                    signImage.Alignment = Element.ALIGN_LEFT; // Align image to the left
                    document.Add(signImage); // Add signatory image to the document
                    float additionalSpaceY = signatoryParagraph.TotalLeading + signatoryParagraph.SpacingAfter;
                    document.Add(new Paragraph(additionalSpaceY, new Chunk("")));

                    // Add authorized signatory line aligned to the left
                    Paragraph signatoryParagraph1 = new Paragraph();
                    signatoryParagraph1.Add(new Phrase("Authorised Signatory", contentFont));
                    signatoryParagraph1.Alignment = Element.ALIGN_LEFT; // Align left
                    signatoryParagraph1.SpacingBefore = 10f; // Increase spacing before to move it further down

                    document.Add(signatoryParagraph1);

                    // Add additional space (10% below signatory line)
                    float additionalSpaceY1 = signatoryParagraph.TotalLeading + signatoryParagraph.SpacingAfter;
                    document.Add(new Paragraph(additionalSpaceY1, new Chunk("")));

                    // Create footer table with two columns
                    PdfPTable footerTable = new PdfPTable(2);
                    footerTable.TotalWidth = document.PageSize.Width - document.LeftMargin - document.RightMargin;
                    float[] footerWidths = new float[] { 50f, 50f };
                    footerTable.SetWidths(footerWidths);

                    // Assuming footerTable is your PdfPTable for the footer
                    PdfPCell footerSeparatorCell = new PdfPCell();
                    footerSeparatorCell.Colspan = 3; // Span across all three columns
                    footerSeparatorCell.Border = Rectangle.TOP_BORDER; // Use TOP_BORDER for the bottom separator line
                    footerSeparatorCell.BorderColorTop = BaseColor.RED; // Set border color to red
                    footerSeparatorCell.PaddingTop = 5f; // Adjust top padding to control line thickness

                    footerTable.AddCell(footerSeparatorCell); // Add the separator cell to the footer table

                    PdfContentByte cb1 = writer.DirectContent;
                    cb1.SetColorStroke(BaseColor.RED);
                    cb1.MoveTo(document.LeftMargin, document.PageSize.Height - document.TopMargin - 42);
                    cb1.LineTo(document.PageSize.Width - document.RightMargin, document.PageSize.Height - document.TopMargin - 42);
                    cb1.Stroke();
                    cb1.SetColorStroke(BaseColor.RED);
                    cb1.MoveTo(document.LeftMargin, document.BottomMargin - (-41));
                    cb1.LineTo(document.PageSize.Width - document.RightMargin, document.BottomMargin - (-41));
                    cb1.Stroke();
                    document.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error creating Letter of Origin PDF: " + ex.Message);
            }
        }



        
        private void CreateLetterOfQualityPDF(string fileName)//, string SerialNumbers
        {
            // Create a new PDF document with increased left margin
            Document document = new Document(PageSize.A4, 50, 50, 40, 30);
                       

            try
            {
                using (FileStream fs = new FileStream(fileName, FileMode.Create))
                {
                    PdfWriter writer = PdfWriter.GetInstance(document, fs);

                    // Assign the custom event handler for header and footer
                    PdfHeaderFooter pageEventHandler = new PdfHeaderFooter();
                    writer.PageEvent = pageEventHandler;

                    // Open the document for writing
                    document.Open();
                    

                    // Calculate the position for drawing the line and adding text
                    float lineYPosition = document.TopMargin + 650; // Adjust the Y position as needed
                    float textLineYPosition = lineYPosition - 10; // Adjust for text line position

                    // Get the direct content for drawing
                    PdfContentByte cb = writer.DirectContent;
                    cb.SetColorStroke(BaseColor.BLACK); // Set line color

                    // Text to be added above the line
                    string text = "Certificate of Quality";
                    BaseFont bf = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                    float textWidth = bf.GetWidthPoint(text, 12); // Calculate text width with font size 12

                    // Calculate the adjusted line margins
                    float lineStartX = (document.PageSize.Width - textWidth) / 2; // Center the text
                    float lineEndX = lineStartX + textWidth;

                    // Draw the straight line
                    cb.MoveTo(lineStartX, lineYPosition + 6); // Move to the adjusted starting point
                    cb.LineTo(lineEndX, lineYPosition + 6); // Draw a line to the adjusted ending point
                    cb.Stroke(); // Stroke the line

                    // Add text above the line
                    cb.BeginText();
                    cb.SetFontAndSize(bf, 12);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_CENTER, text, document.PageSize.Width / 2, lineYPosition + 10, 0);
                    cb.EndText();

                    // Add a paragraph after the header
                    document.Add(new Paragraph(" "));
                    // Font for all paragraphs
                    Font contentFont = FontFactory.GetFont("Calibri", BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 12);
                   
                    // Add Letter of Quality content
                    Paragraph qualityParagraph = new Paragraph();
                    qualityParagraph.Add(Chunk.NEWLINE); // Empty line
                    qualityParagraph.Add(Chunk.NEWLINE); // Empty line
                    qualityParagraph.Add(Chunk.NEWLINE); // Empty line
                    qualityParagraph.Add(Chunk.NEWLINE); // Empty line
                    qualityParagraph.Add(Chunk.NEWLINE); // Empty line
                    qualityParagraph.Add(Chunk.NEWLINE); // Empty line

                    ProjectCloserSelectprojectCode1 = DAL.Project_Closer_select_project_Code(3, cmbProjectcode.Text).Tables[0];

                    string ModelNumber = ProjectCloserSelectprojectCode1.Rows[0]["MachineModelNumber"].ToString();
                    string SerialNumbers = ProjectCloserSelectprojectCode1.Rows[0]["QRSlNo"].ToString();
                    string contentString = $"This certificate confirms that the equipment bearing the model number {ModelNumber} and serial numbers {SerialNumbers} is free from any defective materials and workmanship. This is also to certify that the equipment meets or exceeds the performance as per the requirement.";
                    qualityParagraph.Add(new Phrase(contentString, contentFont));
                    
                    qualityParagraph.Alignment = Element.ALIGN_JUSTIFIED;
                    qualityParagraph.SpacingBefore = 20f;

                    document.Add(qualityParagraph);


                    // Add new paragraph about ISO 9001-2015 compliance
                    Paragraph isoParagraph = new Paragraph();
                    isoParagraph.Add(Chunk.NEWLINE); // Empty line
                    isoParagraph.Add(Chunk.NEWLINE); // Empty line
                    isoParagraph.Add(new Phrase("Assembly quality assurance process complies with ISO 9001-2015.", contentFont));
                    isoParagraph.Alignment = Element.ALIGN_JUSTIFIED;
                    isoParagraph.SpacingBefore = 20f; // Add spacing before the paragraph

                    document.Add(isoParagraph);

                    // Add authorized signatory line aligned to the left
                    Paragraph signatoryParagraph = new Paragraph();
                    signatoryParagraph.Add(Chunk.NEWLINE); // Empty line
                    signatoryParagraph.Add(Chunk.NEWLINE); // Empty line
                    signatoryParagraph.Add(Chunk.NEWLINE); // Empty line
                    signatoryParagraph.Add(new Phrase("Authorised Signatory for ITW India Private Limited-BISS Division", contentFont));
                    signatoryParagraph.Alignment = Element.ALIGN_LEFT; // Align left
                    signatoryParagraph.SpacingBefore = 50f; // Increase spacing before to move it further down

                    document.Add(signatoryParagraph);

                    // Add signatory image
                    string signImagePath = @"C:\Databasepath\BissSealSign1.png"; // Replace with your image path
                    Image signImage = Image.GetInstance(signImagePath); // Get instance of signatory image
                    signImage.ScaleToFit(100f, 50f); // Adjust size as needed
                    signImage.Alignment = Element.ALIGN_LEFT; // Align image to the left
                    document.Add(signImage); // Add signatory image to the document
                    float additionalSpaceY = signatoryParagraph.TotalLeading + signatoryParagraph.SpacingAfter;
                    document.Add(new Paragraph(additionalSpaceY, new Chunk("")));



                    // Add authorized signatory line aligned to the left
                    Paragraph signatoryParagraph1 = new Paragraph();
                    //signatoryParagraph1.Add(Chunk.NEWLINE); // Empty line
                    //signatoryParagraph1.Add(Chunk.NEWLINE); // Empty line
                    //signatoryParagraph1.Add(Chunk.NEWLINE); // Empty line
                    signatoryParagraph1.Add(new Phrase("Authorised Signatory", contentFont));
                    signatoryParagraph1.Alignment = Element.ALIGN_LEFT; // Align left
                    signatoryParagraph1.SpacingBefore = 10f; // Increase spacing before to move it further down

                    document.Add(signatoryParagraph1);


                    // Add additional space (10% below signatory line)
                    float additionalSpaceY1 = signatoryParagraph.TotalLeading + signatoryParagraph.SpacingAfter;
                    document.Add(new Paragraph(additionalSpaceY1, new Chunk("")));
                    // Write header table
                    //headerTable.WriteSelectedRows(0, -1, document.LeftMargin, document.PageSize.Height - document.TopMargin + 10, writer.DirectContent);

                    // Create footer table with two columns
                    PdfPTable footerTable = new PdfPTable(2);
                    footerTable.TotalWidth = document.PageSize.Width - document.LeftMargin - document.RightMargin;
                    float[] footerWidths = new float[] { 50f, 50f };
                    footerTable.SetWidths(footerWidths);

                    // Assuming footerTable is your PdfPTable for the footer
                    PdfPCell footerSeparatorCell = new PdfPCell();
                    footerSeparatorCell.Colspan = 3; // Span across all three columns
                    footerSeparatorCell.Border = Rectangle.TOP_BORDER; // Use TOP_BORDER for the bottom separator line
                    footerSeparatorCell.BorderColorTop = BaseColor.RED; // Set border color to red
                    footerSeparatorCell.PaddingTop = 5f; // Adjust top padding to control line thickness

                    footerTable.AddCell(footerSeparatorCell); // Add the separator cell to the footer table

                    PdfContentByte cb1 = writer.DirectContent;
                    cb1.SetColorStroke(BaseColor.RED);
                    cb1.MoveTo(document.LeftMargin, document.PageSize.Height - document.TopMargin - 42);
                    cb1.LineTo(document.PageSize.Width - document.RightMargin, document.PageSize.Height - document.TopMargin - 42);
                    cb1.Stroke();
                    cb1.SetColorStroke(BaseColor.RED);
                    cb1.MoveTo(document.LeftMargin, document.BottomMargin - (-41));
                    cb1.LineTo(document.PageSize.Width - document.RightMargin, document.BottomMargin - (-41));
                    cb1.Stroke();
                    document.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error creating Letter of Quality PDF: " + ex.Message);
            }
        }

      
      


        public class PdfHeaderFooter : PdfPageEventHelper
        {
            private Font headerFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 12, BaseColor.BLACK);
            private Font footerFont = FontFactory.GetFont(FontFactory.HELVETICA, 8, BaseColor.BLACK);
            private Font contentFont = FontFactory.GetFont("Calibri", BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 12);

            public object Font { get; private set; }

            public override void OnEndPage(PdfWriter writer, Document document)
            {
                //document.SetMargins(36, 72, 108, 180);
                // Create header table with three columns
                PdfPTable headerTable = new PdfPTable(3);
                headerTable.TotalWidth = document.PageSize.Width - document.LeftMargin - document.RightMargin;
                float[] headerWidths = new float[] { 20f, 60f, 20f };
                headerTable.SetWidths(headerWidths);

                // Add left image
                string imagePathLeft = @"C:\Databasepath\ITWLogo.jpg";
                Image leftImage = Image.GetInstance(imagePathLeft);
                leftImage.ScaleToFit(80f, 160f);
                PdfPCell leftImageCell = new PdfPCell(leftImage);
                leftImageCell.Border = Rectangle.NO_BORDER;
                leftImageCell.HorizontalAlignment = Element.ALIGN_LEFT;
                leftImageCell.PaddingLeft = 10f;
                headerTable.AddCell(leftImageCell);

                // Add header text
                PdfPCell headerCell = new PdfPCell(new Phrase(" ", headerFont));
                headerCell.Border = Rectangle.NO_BORDER;
                headerCell.HorizontalAlignment = Element.ALIGN_CENTER;
                headerTable.AddCell(headerCell);

                // Add right image
                string imagePathRight = @"C:\Databasepath\New_Biss_Logo.jpg";
                Image rightImage = Image.GetInstance(imagePathRight);
                rightImage.ScaleToFit(120f, 60f);
                PdfPCell rightImageCell = new PdfPCell(rightImage);
                rightImageCell.Border = Rectangle.NO_BORDER;
                rightImageCell.HorizontalAlignment = Element.ALIGN_RIGHT;
                rightImageCell.PaddingRight = 10f;
                headerTable.AddCell(rightImageCell);

                float textY = document.PageSize.Height - document.TopMargin - rightImage.ScaledHeight - 5;

                PdfContentByte cb2 = writer.DirectContent;
                cb2.BeginText();
                BaseFont bf = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                cb2.SetFontAndSize(bf, 10);
                cb2.SetColorFill(BaseColor.RED);
                cb2.SetTextMatrix(document.LeftMargin, textY);
                cb2.ShowText("High precision and performance – Delivered worldwide!");
                cb2.EndText();

                // Draw a red line below the header
                PdfContentByte cb = writer.DirectContent;
                cb.SetColorStroke(BaseColor.RED);
                cb.MoveTo(document.LeftMargin, document.PageSize.Height - document.TopMargin - 42);
                cb.LineTo(document.PageSize.Width - document.RightMargin, document.PageSize.Height - document.TopMargin - 42);
                cb.Stroke();

                // Add a separator line below the header images
                PdfPCell headerSeparatorCell = new PdfPCell(new Phrase(" "));
                headerSeparatorCell.Colspan = 3;
                headerSeparatorCell.Border = Rectangle.BOTTOM_BORDER;
                headerSeparatorCell.BorderColorBottom = BaseColor.RED;
                headerSeparatorCell.PaddingBottom = 5f;
                headerTable.AddCell(headerSeparatorCell);

                headerTable.WriteSelectedRows(0, -1, document.LeftMargin, document.PageSize.Height - document.TopMargin + 10, writer.DirectContent);

                // Create footer table with two columns
                PdfPTable footerTable = new PdfPTable(2);
                footerTable.TotalWidth = document.PageSize.Width - document.LeftMargin - document.RightMargin;
                float[] footerWidths = new float[] { 50f, 50f };
                footerTable.SetWidths(footerWidths);

                // Footer content
                string footerText = "ITW India Private Limited (BISS Division)\n" +
                                    "No. 497E, 14th Cross, 4th Phase, PIA, Bangalore – 560 058, India\n" +
                                    "Ph: +91 (80) 28360184, Fax: +91 (80) 28360047\n";

                // Create a phrase with red color for the last line
                Phrase footerPhrase = new Phrase();
                footerPhrase.Add(new Chunk(footerText, footerFont));
                footerPhrase.Add(new Chunk("www.biss.in  Email: sales@biss.in; info@biss.in", FontFactory.GetFont(FontFactory.HELVETICA, 8, BaseColor.RED)));

                string footerText1 = "Registered Office:\n" +
                                     "ITW India Private Limited.\n" +
                                     "Level 1, Lotus Plaza, 732/1, MG Road,\n" +
                                     "Sector 14, Gurgaon, Haryana 122001 – India\n" +
                                     "CIN No.-U32301HR1979PTC038643";

                PdfPCell leftCell = new PdfPCell(footerPhrase);
                leftCell.Border = Rectangle.NO_BORDER;
                leftCell.HorizontalAlignment = Element.ALIGN_LEFT;
                
                PdfPCell rightCell = new PdfPCell(new Phrase(footerText1, footerFont));
                rightCell.Border = Rectangle.NO_BORDER;
                rightCell.HorizontalAlignment = Element.ALIGN_LEFT;
                
                footerTable.AddCell(leftCell);
                footerTable.AddCell(rightCell);

                // Adjust the y-coordinate for the footer table
                float footerY = document.BottomMargin + 40;
                footerTable.WriteSelectedRows(0, -1, document.LeftMargin+50, footerY, writer.DirectContent);
            }
        }


        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        //private void comselectedprojectcodeBom_SelectedIndexChanged_1(object sender, EventArgs e)
        //{

        //}
        public int sProjectStatusInstallform = 0;
        DataTable dtProjectList = new DataTable();

        private static string sProjectCode;
        public string fnProject_Master_coser
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }
        private void btnProjectSearch_Click(object sender, EventArgs e)
        {
            sProjectStatusInstallform = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnProject_Master_coser = sProjectStatusInstallform.ToString();
            projectsearch.ShowDialog();
            if (fnProject_Master_coser != null)
            {
                cmbProjectcode.Text = sProjectCode;
            }
        }
        DataView dvProjectName = new DataView();

        private void cmbProjectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            //dvProjectName = new DataView(dtProjectList);
            //dvProjectName.RowFilter = "ProjectCode='" + cmbProjectcode.Text + "'";

            string originalString = cmbProjectcode.Text;
            //UpdateSecondDropdown(originalString);
            LoadProjectStatus(originalString);

        }

        // Method to load the status based on the selected project code
        private void LoadProjectStatus(string projectCode)
        {
            try
            {
                dtBOMstaus = DAL.fnMpBOMlistPOOrderFilter(3, projectCode).Tables[0];

                // Initialize status to an empty string
                string status = "";

                // Loop through each row in dtBOMstaus to check for WIP or Shipped status
                foreach (DataRow row in dtBOMstaus.Rows)
                {
                    //status = row["projectstatus"].ToString(); // Assuming the column name for status is "Status"
                    /*
                   if (status == "WIP")
                    {
                        // If status is WIP, set specific dropdowns to NO and others to YES
                        comselectdispatch.Items.Clear();
                        comselectdispatch.Items.Add("NO");
                        comselectdispatch.SelectedIndex = 0;

                        

                        comboBoxOpenPoints.Items.Clear();
                        comboBoxOpenPoints.Items.Add("NO");
                        comboBoxOpenPoints.SelectedIndex = 0;

                        comboBoxOpenPoints1.Items.Clear();
                        comboBoxOpenPoints1.Items.Add("NO");
                        comboBoxOpenPoints1.SelectedIndex = 0;

                        comcreticalinformation.Items.Clear();
                        comcreticalinformation.Items.Add("NO");
                        comcreticalinformation.SelectedIndex = 0;

                        

                        comboBoxOpenPoints.Items.Clear();
                        comboBoxOpenPoints.Items.Add("YES");
                        comboBoxOpenPoints.Items.Add("NO");
                        comboBoxOpenPoints.SelectedIndex = 1; // Default selection "NO"

                        comboBoxOpenPoints1.Items.Clear();
                        comboBoxOpenPoints1.Items.Add("YES");
                        comboBoxOpenPoints1.Items.Add("NO");
                        comboBoxOpenPoints1.SelectedIndex = 1; // Default selection "NO"

                        comcreticalinformation.Items.Clear();
                        comcreticalinformation.Items.Add("YES");
                        comcreticalinformation.Items.Add("NO");
                        comcreticalinformation.SelectedIndex = 1; // Default selection "NO"
                        buttprint.Enabled = false;
                        buttprojectclosersave.Enabled = true;
                        break; // Exit the loop once "WIP" is found
                    }
                    else if (status == "Shipped")
                    {
                        // If status is Shipped, dynamically allow both YES or NO for all fields
                        comselectdispatch.Items.Clear();
                        comselectdispatch.Items.Add("YES");
                        //comselectdispatch.Items.Add("NO");
                        comselectdispatch.SelectedIndex = 0; // Default selection "YES"

                        comselectdispatch.Items.Clear();
                        comselectdispatch.Items.Add("NO");
                        //comselectdispatch.Items.Add("NO");
                        comselectdispatch.SelectedIndex = 0; // Default selection "YES"

                        buttprint.Enabled=true;
                        buttprojectclosersave.Enabled = false;



                        break; // Exit the loop once "Shipped" is found
                    }
                    */
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching project status: " + ex.Message);
            }
        }

        private void comsectinsertedProjectcode_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}


