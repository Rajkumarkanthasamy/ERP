﻿namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmProjectUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectUpdate));
            this.pnitemadd = new System.Windows.Forms.Panel();
            this.chkShortshipment = new System.Windows.Forms.CheckBox();
            this.chkWarranty = new System.Windows.Forms.CheckBox();
            this.pnWarranty = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpCLosedate = new System.Windows.Forms.DateTimePicker();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.txtWarrantyMonths = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvProjHistory = new System.Windows.Forms.DataGridView();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateCreated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WarrantyStartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WarrantyCloseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnShortShipment = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.txtShortShipdays = new System.Windows.Forms.TextBox();
            this.dtpShortShipDate = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.dtpShortShipClose = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.txtWarrantyStartsFrom = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.txtPMProjectCode = new System.Windows.Forms.TextBox();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txtcuscode = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPMProjectDescription = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbPMProjectStatus = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtprojectname = new System.Windows.Forms.TextBox();
            this.chkProjectList = new System.Windows.Forms.CheckedListBox();
            this.dtpChangedate = new System.Windows.Forms.DateTimePicker();
            this.pnitemadd.SuspendLayout();
            this.pnWarranty.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProjHistory)).BeginInit();
            this.pnShortShipment.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnitemadd
            // 
            this.pnitemadd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnitemadd.Controls.Add(this.chkShortshipment);
            this.pnitemadd.Controls.Add(this.chkWarranty);
            this.pnitemadd.Controls.Add(this.pnWarranty);
            this.pnitemadd.Controls.Add(this.dgvProjHistory);
            this.pnitemadd.Controls.Add(this.pnShortShipment);
            this.pnitemadd.Controls.Add(this.txtWarrantyStartsFrom);
            this.pnitemadd.Controls.Add(this.label8);
            this.pnitemadd.Controls.Add(this.label12);
            this.pnitemadd.Controls.Add(this.label45);
            this.pnitemadd.Controls.Add(this.txtPMProjectCode);
            this.pnitemadd.Controls.Add(this.dtpDate);
            this.pnitemadd.Controls.Add(this.btnExit);
            this.pnitemadd.Controls.Add(this.btnSave);
            this.pnitemadd.Controls.Add(this.txtCustomerName);
            this.pnitemadd.Controls.Add(this.txtcuscode);
            this.pnitemadd.Controls.Add(this.label3);
            this.pnitemadd.Controls.Add(this.txtPMProjectDescription);
            this.pnitemadd.Controls.Add(this.label2);
            this.pnitemadd.Controls.Add(this.label4);
            this.pnitemadd.Controls.Add(this.cmbPMProjectStatus);
            this.pnitemadd.Controls.Add(this.label7);
            this.pnitemadd.Controls.Add(this.txtprojectname);
            this.pnitemadd.Controls.Add(this.chkProjectList);
            this.pnitemadd.Controls.Add(this.dtpChangedate);
            this.pnitemadd.Location = new System.Drawing.Point(3, 4);
            this.pnitemadd.Name = "pnitemadd";
            this.pnitemadd.Size = new System.Drawing.Size(1159, 622);
            this.pnitemadd.TabIndex = 125;
            // 
            // chkShortshipment
            // 
            this.chkShortshipment.AutoSize = true;
            this.chkShortshipment.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShortshipment.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkShortshipment.Location = new System.Drawing.Point(590, 397);
            this.chkShortshipment.Name = "chkShortshipment";
            this.chkShortshipment.Size = new System.Drawing.Size(253, 27);
            this.chkShortshipment.TabIndex = 234;
            this.chkShortshipment.Text = "Create Short Shipment Code";
            this.chkShortshipment.UseVisualStyleBackColor = true;
            this.chkShortshipment.CheckedChanged += new System.EventHandler(this.chkShortshipment_CheckedChanged);
            // 
            // chkWarranty
            // 
            this.chkWarranty.AutoSize = true;
            this.chkWarranty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWarranty.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkWarranty.Location = new System.Drawing.Point(590, 355);
            this.chkWarranty.Name = "chkWarranty";
            this.chkWarranty.Size = new System.Drawing.Size(204, 27);
            this.chkWarranty.TabIndex = 233;
            this.chkWarranty.Text = "Create Warranty Code";
            this.chkWarranty.UseVisualStyleBackColor = true;
            this.chkWarranty.CheckedChanged += new System.EventHandler(this.chkWarranty_CheckedChanged);
            // 
            // pnWarranty
            // 
            this.pnWarranty.Controls.Add(this.label6);
            this.pnWarranty.Controls.Add(this.label5);
            this.pnWarranty.Controls.Add(this.dtpCLosedate);
            this.pnWarranty.Controls.Add(this.dtpStartDate);
            this.pnWarranty.Controls.Add(this.txtWarrantyMonths);
            this.pnWarranty.Controls.Add(this.label1);
            this.pnWarranty.Location = new System.Drawing.Point(46, 445);
            this.pnWarranty.Name = "pnWarranty";
            this.pnWarranty.Size = new System.Drawing.Size(809, 49);
            this.pnWarranty.TabIndex = 232;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(12, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 38);
            this.label6.TabIndex = 171;
            this.label6.Text = "Warranty Period :\r\n     (In Months)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(562, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 19);
            this.label5.TabIndex = 170;
            this.label5.Text = "Warranty Close :";
            // 
            // dtpCLosedate
            // 
            this.dtpCLosedate.CustomFormat = "";
            this.dtpCLosedate.Enabled = false;
            this.dtpCLosedate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpCLosedate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCLosedate.Location = new System.Drawing.Point(689, 10);
            this.dtpCLosedate.Name = "dtpCLosedate";
            this.dtpCLosedate.Size = new System.Drawing.Size(111, 26);
            this.dtpCLosedate.TabIndex = 168;
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.CustomFormat = "";
            this.dtpStartDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpStartDate.Location = new System.Drawing.Point(441, 10);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(106, 26);
            this.dtpStartDate.TabIndex = 167;
            this.dtpStartDate.ValueChanged += new System.EventHandler(this.dtpStartDate_ValueChanged);
            // 
            // txtWarrantyMonths
            // 
            this.txtWarrantyMonths.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWarrantyMonths.Location = new System.Drawing.Point(148, 10);
            this.txtWarrantyMonths.Name = "txtWarrantyMonths";
            this.txtWarrantyMonths.ReadOnly = true;
            this.txtWarrantyMonths.Size = new System.Drawing.Size(149, 26);
            this.txtWarrantyMonths.TabIndex = 172;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(309, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 19);
            this.label1.TabIndex = 169;
            this.label1.Text = "warranty Start *:";
            // 
            // dgvProjHistory
            // 
            this.dgvProjHistory.AllowUserToAddRows = false;
            this.dgvProjHistory.AllowUserToDeleteRows = false;
            this.dgvProjHistory.AllowUserToResizeRows = false;
            this.dgvProjHistory.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvProjHistory.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvProjHistory.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProjHistory.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvProjHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProjHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProjectCode,
            this.Status,
            this.DateCreated,
            this.WarrantyStartDate,
            this.WarrantyCloseDate});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvProjHistory.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvProjHistory.Location = new System.Drawing.Point(159, 114);
            this.dgvProjHistory.MultiSelect = false;
            this.dgvProjHistory.Name = "dgvProjHistory";
            this.dgvProjHistory.ReadOnly = true;
            this.dgvProjHistory.RowHeadersVisible = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProjHistory.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvProjHistory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvProjHistory.Size = new System.Drawing.Size(948, 127);
            this.dgvProjHistory.TabIndex = 231;
            // 
            // ProjectCode
            // 
            this.ProjectCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProjectCode.DataPropertyName = "ProjectCode";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProjectCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProjectCode.HeaderText = "ProjectCode";
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Status
            // 
            this.Status.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Status.DataPropertyName = "Status";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.Status.DefaultCellStyle = dataGridViewCellStyle3;
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // DateCreated
            // 
            this.DateCreated.DataPropertyName = "DateCreated";
            this.DateCreated.HeaderText = "Project created on";
            this.DateCreated.Name = "DateCreated";
            this.DateCreated.ReadOnly = true;
            this.DateCreated.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // WarrantyStartDate
            // 
            this.WarrantyStartDate.DataPropertyName = "WarrantyStartDate";
            this.WarrantyStartDate.HeaderText = "Warranty Start Date";
            this.WarrantyStartDate.Name = "WarrantyStartDate";
            this.WarrantyStartDate.ReadOnly = true;
            this.WarrantyStartDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WarrantyStartDate.Width = 135;
            // 
            // WarrantyCloseDate
            // 
            this.WarrantyCloseDate.DataPropertyName = "WarrantyCloseDate";
            this.WarrantyCloseDate.HeaderText = "Warranty Close Date";
            this.WarrantyCloseDate.Name = "WarrantyCloseDate";
            this.WarrantyCloseDate.ReadOnly = true;
            this.WarrantyCloseDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WarrantyCloseDate.Width = 136;
            // 
            // pnShortShipment
            // 
            this.pnShortShipment.Controls.Add(this.label9);
            this.pnShortShipment.Controls.Add(this.txtShortShipdays);
            this.pnShortShipment.Controls.Add(this.dtpShortShipDate);
            this.pnShortShipment.Controls.Add(this.label10);
            this.pnShortShipment.Controls.Add(this.dtpShortShipClose);
            this.pnShortShipment.Controls.Add(this.label11);
            this.pnShortShipment.Location = new System.Drawing.Point(19, 501);
            this.pnShortShipment.Name = "pnShortShipment";
            this.pnShortShipment.Size = new System.Drawing.Size(851, 48);
            this.pnShortShipment.TabIndex = 179;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(403, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 19);
            this.label9.TabIndex = 175;
            this.label9.Text = "Start *:";
            // 
            // txtShortShipdays
            // 
            this.txtShortShipdays.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShortShipdays.Location = new System.Drawing.Point(175, 4);
            this.txtShortShipdays.Name = "txtShortShipdays";
            this.txtShortShipdays.Size = new System.Drawing.Size(128, 26);
            this.txtShortShipdays.TabIndex = 178;
            // 
            // dtpShortShipDate
            // 
            this.dtpShortShipDate.CustomFormat = "";
            this.dtpShortShipDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpShortShipDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpShortShipDate.Location = new System.Drawing.Point(468, 6);
            this.dtpShortShipDate.Name = "dtpShortShipDate";
            this.dtpShortShipDate.Size = new System.Drawing.Size(106, 26);
            this.dtpShortShipDate.TabIndex = 173;
            this.dtpShortShipDate.ValueChanged += new System.EventHandler(this.dtpShortShipDate_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(8, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(168, 38);
            this.label10.TabIndex = 177;
            this.label10.Text = "Shortshipment Period :\r\n     (In Days)";
            // 
            // dtpShortShipClose
            // 
            this.dtpShortShipClose.CustomFormat = "";
            this.dtpShortShipClose.Enabled = false;
            this.dtpShortShipClose.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpShortShipClose.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpShortShipClose.Location = new System.Drawing.Point(715, 6);
            this.dtpShortShipClose.Name = "dtpShortShipClose";
            this.dtpShortShipClose.Size = new System.Drawing.Size(109, 26);
            this.dtpShortShipClose.TabIndex = 174;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(657, 11);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 19);
            this.label11.TabIndex = 176;
            this.label11.Text = "Close :";
            // 
            // txtWarrantyStartsFrom
            // 
            this.txtWarrantyStartsFrom.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtWarrantyStartsFrom.Location = new System.Drawing.Point(194, 414);
            this.txtWarrantyStartsFrom.Name = "txtWarrantyStartsFrom";
            this.txtWarrantyStartsFrom.ReadOnly = true;
            this.txtWarrantyStartsFrom.Size = new System.Drawing.Size(291, 26);
            this.txtWarrantyStartsFrom.TabIndex = 178;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(40, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 19);
            this.label8.TabIndex = 177;
            this.label8.Text = "Select Project :\t";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(35, 10);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 19);
            this.label12.TabIndex = 176;
            this.label12.Text = "Search Project :\t";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.Black;
            this.label45.Location = new System.Drawing.Point(32, 416);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(157, 19);
            this.label45.TabIndex = 174;
            this.label45.Text = "Warranty Start from :";
            // 
            // txtPMProjectCode
            // 
            this.txtPMProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPMProjectCode.Location = new System.Drawing.Point(194, 265);
            this.txtPMProjectCode.Name = "txtPMProjectCode";
            this.txtPMProjectCode.ReadOnly = true;
            this.txtPMProjectCode.Size = new System.Drawing.Size(291, 26);
            this.txtPMProjectCode.TabIndex = 108;
            // 
            // dtpDate
            // 
            this.dtpDate.CustomFormat = "";
            this.dtpDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDate.Location = new System.Drawing.Point(341, 265);
            this.dtpDate.MaxDate = new System.DateTime(2028, 12, 31, 0, 0, 0, 0);
            this.dtpDate.MinDate = new System.DateTime(2017, 1, 1, 0, 0, 0, 0);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(102, 26);
            this.dtpDate.TabIndex = 145;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(794, 565);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(113, 42);
            this.btnExit.TabIndex = 116;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(646, 565);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(113, 42);
            this.btnSave.TabIndex = 115;
            this.btnSave.Text = "Update";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCustomerName.Location = new System.Drawing.Point(590, 268);
            this.txtCustomerName.Multiline = true;
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.ReadOnly = true;
            this.txtCustomerName.Size = new System.Drawing.Size(293, 55);
            this.txtCustomerName.TabIndex = 114;
            // 
            // txtcuscode
            // 
            this.txtcuscode.Enabled = false;
            this.txtcuscode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcuscode.Location = new System.Drawing.Point(794, 271);
            this.txtcuscode.Name = "txtcuscode";
            this.txtcuscode.ReadOnly = true;
            this.txtcuscode.Size = new System.Drawing.Size(76, 26);
            this.txtcuscode.TabIndex = 113;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(75, 317);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 19);
            this.label3.TabIndex = 107;
            this.label3.Text = "Project Name*:";
            // 
            // txtPMProjectDescription
            // 
            this.txtPMProjectDescription.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPMProjectDescription.Location = new System.Drawing.Point(194, 305);
            this.txtPMProjectDescription.Multiline = true;
            this.txtPMProjectDescription.Name = "txtPMProjectDescription";
            this.txtPMProjectDescription.ReadOnly = true;
            this.txtPMProjectDescription.Size = new System.Drawing.Size(291, 51);
            this.txtPMProjectDescription.TabIndex = 106;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(85, 265);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 19);
            this.label2.TabIndex = 105;
            this.label2.Text = "Projet Code*:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(498, 280);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 19);
            this.label4.TabIndex = 109;
            this.label4.Text = "Customer*:";
            // 
            // cmbPMProjectStatus
            // 
            this.cmbPMProjectStatus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPMProjectStatus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPMProjectStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPMProjectStatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPMProjectStatus.FormattingEnabled = true;
            this.cmbPMProjectStatus.Items.AddRange(new object[] {
            "Cancelled",
            "Installation Completed",
            "On Hold",
            "Shipped",
            "WIP"});
            this.cmbPMProjectStatus.Location = new System.Drawing.Point(194, 372);
            this.cmbPMProjectStatus.Name = "cmbPMProjectStatus";
            this.cmbPMProjectStatus.Size = new System.Drawing.Size(291, 26);
            this.cmbPMProjectStatus.TabIndex = 111;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(68, 377);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 19);
            this.label7.TabIndex = 110;
            this.label7.Text = "Project Status *:";
            // 
            // txtprojectname
            // 
            this.txtprojectname.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtprojectname.Location = new System.Drawing.Point(159, 9);
            this.txtprojectname.Name = "txtprojectname";
            this.txtprojectname.Size = new System.Drawing.Size(948, 26);
            this.txtprojectname.TabIndex = 100;
            this.txtprojectname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtprojectname_KeyPress);
            this.txtprojectname.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtprojectname_KeyUp);
            // 
            // chkProjectList
            // 
            this.chkProjectList.CheckOnClick = true;
            this.chkProjectList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkProjectList.FormattingEnabled = true;
            this.chkProjectList.Location = new System.Drawing.Point(159, 41);
            this.chkProjectList.Name = "chkProjectList";
            this.chkProjectList.Size = new System.Drawing.Size(948, 67);
            this.chkProjectList.TabIndex = 101;
            this.chkProjectList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chkProjectList_ItemCheck);
            // 
            // dtpChangedate
            // 
            this.dtpChangedate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpChangedate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpChangedate.Location = new System.Drawing.Point(348, 316);
            this.dtpChangedate.Name = "dtpChangedate";
            this.dtpChangedate.Size = new System.Drawing.Size(121, 26);
            this.dtpChangedate.TabIndex = 165;
            // 
            // frmProjectUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1166, 627);
            this.Controls.Add(this.pnitemadd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmProjectUpdate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Update";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectUpdate_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectUpdate_Load);
            this.pnitemadd.ResumeLayout(false);
            this.pnitemadd.PerformLayout();
            this.pnWarranty.ResumeLayout(false);
            this.pnWarranty.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProjHistory)).EndInit();
            this.pnShortShipment.ResumeLayout(false);
            this.pnShortShipment.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnitemadd;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.TextBox txtcuscode;
        private System.Windows.Forms.TextBox txtPMProjectCode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPMProjectDescription;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbPMProjectStatus;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtprojectname;
        private System.Windows.Forms.CheckedListBox chkProjectList;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.DateTimePicker dtpChangedate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpCLosedate;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.TextBox txtWarrantyMonths;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtWarrantyStartsFrom;
        private System.Windows.Forms.Panel pnShortShipment;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtShortShipdays;
        private System.Windows.Forms.DateTimePicker dtpShortShipDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtpShortShipClose;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dgvProjHistory;
        private System.Windows.Forms.Panel pnWarranty;
        private System.Windows.Forms.CheckBox chkShortshipment;
        private System.Windows.Forms.CheckBox chkWarranty;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateCreated;
        private System.Windows.Forms.DataGridViewTextBoxColumn WarrantyStartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn WarrantyCloseDate;
    }
}