﻿
namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmProjectClosure
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectClosure));
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtPMProjectDescription = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbProjectcode = new System.Windows.Forms.ComboBox();
            this.btnProjectSearch = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Enabled = false;
            this.txtCustomerName.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCustomerName.Location = new System.Drawing.Point(142, 121);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(280, 26);
            this.txtCustomerName.TabIndex = 205;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(23, 68);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(114, 19);
            this.label20.TabIndex = 203;
            this.label20.Text = "Project Name*:";
            // 
            // txtPMProjectDescription
            // 
            this.txtPMProjectDescription.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPMProjectDescription.Location = new System.Drawing.Point(142, 66);
            this.txtPMProjectDescription.Multiline = true;
            this.txtPMProjectDescription.Name = "txtPMProjectDescription";
            this.txtPMProjectDescription.ReadOnly = true;
            this.txtPMProjectDescription.Size = new System.Drawing.Size(280, 53);
            this.txtPMProjectDescription.TabIndex = 202;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(49, 121);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(86, 19);
            this.label21.TabIndex = 204;
            this.label21.Text = "Customer*:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(35, 40);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 19);
            this.label8.TabIndex = 199;
            this.label8.Text = "Project Code:";
            // 
            // cmbProjectcode
            // 
            this.cmbProjectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectcode.DropDownHeight = 130;
            this.cmbProjectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectcode.FormattingEnabled = true;
            this.cmbProjectcode.IntegralHeight = false;
            this.cmbProjectcode.Location = new System.Drawing.Point(142, 36);
            this.cmbProjectcode.Name = "cmbProjectcode";
            this.cmbProjectcode.Size = new System.Drawing.Size(280, 26);
            this.cmbProjectcode.TabIndex = 200;
            // 
            // btnProjectSearch
            // 
            this.btnProjectSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectSearch.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectSearch.Location = new System.Drawing.Point(428, 35);
            this.btnProjectSearch.Name = "btnProjectSearch";
            this.btnProjectSearch.Size = new System.Drawing.Size(23, 24);
            this.btnProjectSearch.TabIndex = 201;
            this.btnProjectSearch.Text = "....";
            this.btnProjectSearch.UseVisualStyleBackColor = false;
            // 
            // frmProjectClosure
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1241, 549);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtPMProjectDescription);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cmbProjectcode);
            this.Controls.Add(this.btnProjectSearch);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmProjectClosure";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Closure";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtPMProjectDescription;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbProjectcode;
        private System.Windows.Forms.Button btnProjectSearch;
    }
}