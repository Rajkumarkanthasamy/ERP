﻿namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmProjectShipmentStatusUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectShipmentStatusUpdate));
            this.label6 = new System.Windows.Forms.Label();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.cmbProjectcode = new System.Windows.Forms.ComboBox();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.dtpAssemblyDate = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.dtpInstallationDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpShipmentDate = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.llbProjectName = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(33, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 19);
            this.label6.TabIndex = 143;
            this.label6.Text = "Project Name :";
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(43, 39);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(100, 19);
            this.lblProjectCode.TabIndex = 140;
            this.lblProjectCode.Text = "Project Code:";
            // 
            // cmbProjectcode
            // 
            this.cmbProjectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectcode.DropDownHeight = 130;
            this.cmbProjectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectcode.FormattingEnabled = true;
            this.cmbProjectcode.IntegralHeight = false;
            this.cmbProjectcode.Location = new System.Drawing.Point(150, 37);
            this.cmbProjectcode.Name = "cmbProjectcode";
            this.cmbProjectcode.Size = new System.Drawing.Size(282, 26);
            this.cmbProjectcode.TabIndex = 141;
            this.cmbProjectcode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectcode_SelectedIndexChanged);
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectView.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectView.Location = new System.Drawing.Point(438, 39);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 24);
            this.btnProjectView.TabIndex = 142;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            this.btnProjectView.Click += new System.EventHandler(this.btnProjectView_Click);
            // 
            // dtpAssemblyDate
            // 
            this.dtpAssemblyDate.CustomFormat = "";
            this.dtpAssemblyDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpAssemblyDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpAssemblyDate.Location = new System.Drawing.Point(150, 143);
            this.dtpAssemblyDate.Name = "dtpAssemblyDate";
            this.dtpAssemblyDate.Size = new System.Drawing.Size(125, 26);
            this.dtpAssemblyDate.TabIndex = 170;
            this.dtpAssemblyDate.ValueChanged += new System.EventHandler(this.dtpAssemblyDate_ValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(22, 148);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(121, 19);
            this.label13.TabIndex = 169;
            this.label13.Text = "Assembly Date*:";
            // 
            // dtpInstallationDate
            // 
            this.dtpInstallationDate.CustomFormat = "";
            this.dtpInstallationDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpInstallationDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInstallationDate.Location = new System.Drawing.Point(150, 198);
            this.dtpInstallationDate.Name = "dtpInstallationDate";
            this.dtpInstallationDate.Size = new System.Drawing.Size(125, 26);
            this.dtpInstallationDate.TabIndex = 172;
            this.dtpInstallationDate.ValueChanged += new System.EventHandler(this.dtpInstallationDate_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(40, 198);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 19);
            this.label1.TabIndex = 171;
            this.label1.Text = "Critical Date*:";
            // 
            // dtpShipmentDate
            // 
            this.dtpShipmentDate.CustomFormat = "";
            this.dtpShipmentDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpShipmentDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpShipmentDate.Location = new System.Drawing.Point(150, 252);
            this.dtpShipmentDate.Name = "dtpShipmentDate";
            this.dtpShipmentDate.Size = new System.Drawing.Size(125, 26);
            this.dtpShipmentDate.TabIndex = 174;
            this.dtpShipmentDate.ValueChanged += new System.EventHandler(this.dtpShipmentDate_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(20, 257);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 19);
            this.label2.TabIndex = 173;
            this.label2.Text = "Shipment Date*:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(26, 440);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(913, 64);
            this.groupBox2.TabIndex = 175;
            this.groupBox2.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(659, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(99, 46);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(815, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(92, 46);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // llbProjectName
            // 
            this.llbProjectName.AutoSize = true;
            this.llbProjectName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbProjectName.ForeColor = System.Drawing.Color.Black;
            this.llbProjectName.Location = new System.Drawing.Point(149, 88);
            this.llbProjectName.Name = "llbProjectName";
            this.llbProjectName.Size = new System.Drawing.Size(17, 19);
            this.llbProjectName.TabIndex = 176;
            this.llbProjectName.Text = "*";
            // 
            // frmProjectShipmentStatusUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(951, 516);
            this.Controls.Add(this.llbProjectName);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dtpShipmentDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpInstallationDate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpAssemblyDate);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblProjectCode);
            this.Controls.Add(this.cmbProjectcode);
            this.Controls.Add(this.btnProjectView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmProjectShipmentStatusUpdate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Shipment Status Update";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectShipmentStatusUpdate_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectShipmentStatusUpdate_Load);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.ComboBox cmbProjectcode;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.DateTimePicker dtpAssemblyDate;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dtpInstallationDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpShipmentDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label llbProjectName;
    }
}