﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmProjectSearchForm : Form
    {
        private const uint uPROJECT_PROJECTCODE_SEARCH = 0;
        private const uint uPROJECT_CUSTOMER_SEARCH = 1;
        private const uint uPROJECT_TYPE_SEARCH = 2;
        private const uint uPROJECT_STATUS_SEARCH = 3;
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        frmProjectmaster form = new frmProjectmaster();
        DataTable dtProjectList = new DataTable();
        DataTable dtTableFilter = new DataTable();
        BindingSource bsProjectList = new BindingSource();
        DataView dvProjectList = new DataView();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();

        private void fnRowFilter(uint uSearchOption, string sRowFilter)
        {
            dvProjectList = new DataView(dtProjectList);
            switch (uSearchOption)
            {
                case uPROJECT_PROJECTCODE_SEARCH:
                    {
                        dvProjectList.RowFilter = "ProjectCode like '%" + sRowFilter + "%' or ProjectDescription like '%" + sRowFilter + "%' or Type like '%" + sRowFilter + "%' or Status like '%" + sRowFilter + "%' or CapexNumber like '%" + sRowFilter + "%'";
                       dgProjectList.DataSource = dvProjectList.ToTable();
                        break;
                    }
                //case uPROJECT_CUSTOMER_SEARCH:
                //    {
                //        dvProjectList.RowFilter = "ProjectDescription like '%" + sRowFilter + "%'";
                //        dgProjectList.DataSource = dvProjectList.ToTable();
                //        break;
                //    }
                //case uPROJECT_TYPE_SEARCH:
                //    {
                //        dvProjectList.RowFilter = "Type like '%" + sRowFilter + "%'";
                //        dgProjectList.DataSource = dvProjectList.ToTable();
                //        break;
                //    }
                //case uPROJECT_STATUS_SEARCH:
                //    {
                //        dvProjectList.RowFilter = "Status like '%" + sRowFilter + "%'";
                //        dgProjectList.DataSource = dvProjectList.ToTable();
                //        break;
                //    }
                //case 55:
                //    {
                //        dvProjectList.RowFilter = "CapexNumber like '%" + sRowFilter + "%'";
                //        dgProjectList.DataSource = dvProjectList.ToTable();
                //        break;
                //    }
            }
        }

        public frmProjectSearchForm()
        {
            InitializeComponent();
        }

        private void datagridviewcolor()
        {
            foreach (DataGridViewRow row in dgProjectList.Rows)
            {
                 switch (row.Cells["Status"].Value.ToString())
                {
                    case "WIP":
                        row.DefaultCellStyle.BackColor = Color.PaleGreen;
                        break;
                    case "Installation completed":
                        row.DefaultCellStyle.BackColor = Color.LightBlue;
                        break;
                    case "Shipped":
                        row.DefaultCellStyle.BackColor = Color.Moccasin;
                        break;
                    case "Transferred":
                        row.DefaultCellStyle.BackColor = Color.Salmon;
                        break;
                    case "Expensed":
                        row.DefaultCellStyle.BackColor = Color.Wheat;
                        break;
                    case "FG":
                        row.DefaultCellStyle.BackColor = Color.Chocolate;
                        break;
                    case "Cancelled":
                        row.DefaultCellStyle.BackColor = Color.Red;
                        break;
                    case "Converted to FG":
                        row.DefaultCellStyle.BackColor = Color.SteelBlue;
                        break;
                    case "Capitalized FA":
                        row.DefaultCellStyle.BackColor = Color.Silver;
                        break;
                    case "GM Approval":
                        row.DefaultCellStyle.BackColor = Color.Yellow;
                        break;
                }
            }
        }

        private void frmProjectSearchForm_Load(object sender, EventArgs e)
        {
            checkPSWarranty.Checked = false;
            dtProjectList = DAL.fnProjectListWithEndDate(2,null,null).Tables[0];  //get all project from database
            bsProjectList.DataSource = dtProjectList;
            dgProjectList.AutoGenerateColumns = false;
            dgProjectList.DataSource = bsProjectList;
            foreach (DataRow DR in dtProjectList.Rows)
            {
                if (!string.IsNullOrEmpty(DR["Type"].ToString()))
                {
                    if (!cmbPSProjectType.Items.Contains(DR["Type"].ToString()))    //dynamically add items to combobox cmbPSProjectType
                        cmbPSProjectType.Items.Add(DR["Type"].ToString());
                }
            }
            if (LoginForm.GetUserDetails[2].ToLower() == "ravi" || LoginForm.GetUserDetails[2].ToLower() == "vishal")
            {
                pnShortShipment.Visible = true;
            }
            else
            {
                pnShortShipment.Visible = false;
            }

            cmbPSProjectType.SelectedIndex = 0;
            datagridviewcolor();
           
        }

        private void chkPSWarranty_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPSWarranty.Checked == true)
                fnRowFilter(3, "Warranty");
            else
                dgProjectList.DataSource = bsProjectList;
            datagridviewcolor();
        }
        string sProjectcode;
        bool bProjectSSorWarranty;
        private void dgProjectList_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            bProjectSSorWarranty = false;
            sProjectcode=dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
            var result = sProjectcode.Substring(sProjectcode.Length - 1);
            if (result.ToString() == "S" || result.ToString() == "W" || result.ToString() == "P")
            {
                bProjectSSorWarranty = true;
            }
            else
            {
                bProjectSSorWarranty = false;
            }

            if (!bProjectSSorWarranty)
            {
                if (LoginForm.GetUserDetails[23] == "Accounts" || LoginForm.GetUserDetails[2].ToString().ToLower() == "biss" || LoginForm.GetUserDetails[2].ToString() == "Vivek G")
                {
                    form.fnGetProjectCode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    this.Hide();
                    pleasewaitform pleaseWait = new pleasewaitform();
                    pleaseWait.Show();
                    Application.DoEvents();
                    form.Show();
                    pleaseWait.Hide();
                }
                else if (string.IsNullOrEmpty(dgProjectList.CurrentRow.Cells["Status"].Value.ToString()) && LoginForm.GetUserDetails[2] == dgProjectList.CurrentRow.Cells["Createdby"].Value.ToString())
                {
                    form.fnGetProjectCode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    this.Hide();
                    pleasewaitform pleaseWait = new pleasewaitform();
                    pleaseWait.Show();
                    Application.DoEvents();
                    form.Show();
                    pleaseWait.Hide();
                }
                else
                {
                    MessageBox.Show("Only you can select the project codes created by you before code activated to WIP. \nFor other projects contact accounts or the project created person", "Error", 0, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Warranty, Short Shipment and Parts code cannot be edited", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void cmbPSProjectType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbPSProjectType.SelectedIndex != 0)
                fnRowFilter(0, cmbPSProjectType.Text);
            else
                dgProjectList.DataSource = bsProjectList;
            datagridviewcolor();
        }

        private void txtPSProjectCode_Enter(object sender, EventArgs e)
        {
            dgProjectList.DataSource = bsProjectList;
            datagridviewcolor();
        }

     

        private void txtPSProjectCode_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(0, txtPSProjectCode.Text);
            datagridviewcolor();
        }

        private void txtPSCustomer_KeyUp(object sender, KeyEventArgs e)
        {
        }

        private void frmProjectSearchForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            form.fnGetProjectCode = null;
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            // Display form modelessly
            pleaseWait.Show();
            //  ALlow main UI thread to properly display please wait form.
            Application.DoEvents();
            form.Show();
            pleaseWait.Hide();
        }


        private void btnUpdateShortShipment_Click(object sender, EventArgs e)
        {
            if (cmbShortShipment.SelectedIndex >= 0)
            {
                DialogResult DR = MessageBox.Show("Do you want to update the project code '" + dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString() + "' short shipment required with '" + cmbShortShipment.Text + "'. \n Click Yes to update", "info", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.Yes)
                {
                    if ((LoginForm.GetUserDetails[2].ToLower() == "ravi" || LoginForm.GetUserDetails[2].ToLower() == "vishal"))
                    {
                        GlobalClass.iStatus = DAL.fnAddShortShipment(Global.uUPDATE, LoginForm.GetUserDetails[2].ToLower(), bShortShipment, dtpPMCreatedDate.Text, dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString());

                        dtProjectList = DAL.fnProjectListWithEndDate(1,null,null).Tables[0];  //get all project from database
                        bsProjectList.DataSource = dtProjectList;
                        dgProjectList.AutoGenerateColumns = false;
                        dgProjectList.DataSource = bsProjectList;
                        datagridviewcolor();
                    }
                    if (GlobalClass.iStatus > 0)
                    {
                        MessageBox.Show("Selected project code short shipment required updated", "Success", 0, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Selected project code short shipment required not updated", "Error", 0, MessageBoxIcon.Hand);
                }

            }
            else
            {
                MessageBox.Show("Please select short shipment required with Yes or NO", "Error", 0, MessageBoxIcon.Error);
            }
        }
        bool bShortShipment = false;

        private void cmbShortShipment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbShortShipment.SelectedIndex == 0)
            {
                bShortShipment = true;
            }
            else if (cmbShortShipment.SelectedIndex == 1)
            {
                bShortShipment = false;
            }

        }

        private void txtCapexNumber_Enter(object sender, EventArgs e)
        {
            txtPSProjectCode.Text = string.Empty;
            txtPSProjectCode.Text = string.Empty;
            dgProjectList.DataSource = bsProjectList;
            datagridviewcolor();
        }

        private void txtCapexNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void txtCapexNumber_KeyUp(object sender, KeyEventArgs e)
        {
        }

        private void btnLoadProjects_Click(object sender, EventArgs e)
        {
            if (btnLoadProjects.Text == "Load All Projects")
            {
                dtProjectList = DAL.fnProjectListWithEndDate(1, null, null).Tables[0];  //get all project from database
                bsProjectList.DataSource = dtProjectList;
                dgProjectList.AutoGenerateColumns = false;
                dgProjectList.DataSource = bsProjectList;
                datagridviewcolor();
                btnLoadProjects.Text = "Load Active Projects";

            }
            else
            {
                btnLoadProjects.Text = "Load All Projects";               
                dtProjectList = DAL.fnProjectListWithEndDate(2, null, null).Tables[0];  //get all project from database
                bsProjectList.DataSource = dtProjectList;
                dgProjectList.AutoGenerateColumns = false;
                dgProjectList.DataSource = bsProjectList;
                datagridviewcolor();
            }
        }

        private void txtPSProjectCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%' || e.KeyChar == '['))
            {
                e.Handled = true;
            }
        }

        private void txtPSProjectCode_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
