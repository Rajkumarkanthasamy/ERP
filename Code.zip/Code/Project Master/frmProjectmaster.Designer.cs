﻿namespace Erp_Project_With_Buttons
{
    partial class frmProjectmaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectmaster));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dtpPMCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblReturnedby = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnExcel = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.cmbPenaltyClause = new System.Windows.Forms.ComboBox();
            this.cmbPreDispatchInspection = new System.Windows.Forms.ComboBox();
            this.cmbShippingMode = new System.Windows.Forms.ComboBox();
            this.cmbPaymentTerms = new System.Windows.Forms.ComboBox();
            this.cmbAgent = new System.Windows.Forms.ComboBox();
            this.cmbSecurityDeposit = new System.Windows.Forms.ComboBox();
            this.cmbBankGuarantee = new System.Windows.Forms.ComboBox();
            this.cmbPerformanceBankGuarantee = new System.Windows.Forms.ComboBox();
            this.cmbPreDesignPreview = new System.Windows.Forms.ComboBox();
            this.cmbContractualAcceptance = new System.Windows.Forms.ComboBox();
            this.cmbShippingTerms = new System.Windows.Forms.ComboBox();
            this.txtPMProjectDescription = new System.Windows.Forms.TextBox();
            this.cmbsystemsubtype = new System.Windows.Forms.ComboBox();
            this.txtPMProjectCode = new System.Windows.Forms.TextBox();
            this.cmbPMProductType = new System.Windows.Forms.ComboBox();
            this.txtPONo = new System.Windows.Forms.TextBox();
            this.CmbStandardCustom = new System.Windows.Forms.ComboBox();
            this.txtBilltoCustomer = new System.Windows.Forms.TextBox();
            this.txtShiptoCustomer = new System.Windows.Forms.TextBox();
            this.cmbModelNumber = new System.Windows.Forms.ComboBox();
            this.txtWarrantyClose = new System.Windows.Forms.TextBox();
            this.txtCapexNumber = new System.Windows.Forms.TextBox();
            this.txtCapexName = new System.Windows.Forms.TextBox();
            this.txtCapexRequester = new System.Windows.Forms.TextBox();
            this.txtCapexAmount = new System.Windows.Forms.TextBox();
            this.txtOverHead = new System.Windows.Forms.TextBox();
            this.pnBIM = new System.Windows.Forms.Panel();
            this.pnGMApproval = new System.Windows.Forms.Panel();
            this.cmbGMApproveList = new System.Windows.Forms.ComboBox();
            this.label66 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.llbUploadDocs = new System.Windows.Forms.LinkLabel();
            this.cmbDocType = new System.Windows.Forms.ComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.txtTargetValue = new System.Windows.Forms.TextBox();
            this.txtTargetMaterialmargin = new System.Windows.Forms.TextBox();
            this.txtEstimatedManufacturing = new System.Windows.Forms.TextBox();
            this.txtEstimatedDesign = new System.Windows.Forms.TextBox();
            this.txtEstimatedInsatllation = new System.Windows.Forms.TextBox();
            this.txtInstallationValueinUSD = new System.Windows.Forms.TextBox();
            this.txtInstallationValueinINR = new System.Windows.Forms.TextBox();
            this.txtOrderValueinUSD = new System.Windows.Forms.TextBox();
            this.txtOrderValueinINR = new System.Windows.Forms.TextBox();
            this.txtSaleseffort = new System.Windows.Forms.TextBox();
            this.txtQuotationEffort = new System.Windows.Forms.TextBox();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.txtProjectMargin = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.llbProjectDocuments = new System.Windows.Forms.LinkLabel();
            this.cmbProjectDocument = new System.Windows.Forms.ComboBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.pnLDClause = new System.Windows.Forms.Panel();
            this.dtpLDToDate = new System.Windows.Forms.DateTimePicker();
            this.txtLDBody = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.dtpLDFromDate = new System.Windows.Forms.DateTimePicker();
            this.label52 = new System.Windows.Forms.Label();
            this.pnLCClause = new System.Windows.Forms.Panel();
            this.dtpLCEndDate = new System.Windows.Forms.DateTimePicker();
            this.txtBody = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.label49 = new System.Windows.Forms.Label();
            this.chkLCClause = new System.Windows.Forms.CheckBox();
            this.label46 = new System.Windows.Forms.Label();
            this.chkLDClause = new System.Windows.Forms.CheckBox();
            this.btnBack1 = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.cmbLever = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.gbControlButtons = new System.Windows.Forms.GroupBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtCustomerRequirement = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.txtMoblieNo = new System.Windows.Forms.TextBox();
            this.txtContactPerson = new System.Windows.Forms.TextBox();
            this.txtContactAddress = new System.Windows.Forms.TextBox();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.txtOfficeNo = new System.Windows.Forms.TextBox();
            this.txtContactEmail = new System.Windows.Forms.TextBox();
            this.txtDeliveryPeriod = new System.Windows.Forms.TextBox();
            this.txtStandardDeliveryPeriod = new System.Windows.Forms.TextBox();
            this.txtAgentCommission = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.lblremarks = new System.Windows.Forms.Label();
            this.lblContactPerson = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.btnNext1 = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pnProjectMaster = new System.Windows.Forms.Panel();
            this.comboBoxProfitCentre = new System.Windows.Forms.ComboBox();
            this.label72 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.cmbProductionCompany = new System.Windows.Forms.ComboBox();
            this.comManufactureform = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pnCustomerlinkProject = new System.Windows.Forms.Panel();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.cmbStockProject = new System.Windows.Forms.ComboBox();
            this.label70 = new System.Windows.Forms.Label();
            this.cmbWarrantyStartsFrom = new System.Windows.Forms.ComboBox();
            this.lblWarrantyStartsfrom = new System.Windows.Forms.Label();
            this.panelCapex = new System.Windows.Forms.Panel();
            this.checkBoxdept = new System.Windows.Forms.CheckBox();
            this.cmbDepartment = new System.Windows.Forms.ComboBox();
            this.lblsearch = new System.Windows.Forms.Label();
            this.lstusers = new System.Windows.Forms.ListBox();
            this.label65 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.cmbCustomizationlevel = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbProject8020 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbEndUserCountry = new System.Windows.Forms.ComboBox();
            this.txtProjectFocal = new System.Windows.Forms.ComboBox();
            this.cmbRevisionNumber = new System.Windows.Forms.ComboBox();
            this.label55 = new System.Windows.Forms.Label();
            this.cmbOfferNumber = new System.Windows.Forms.ComboBox();
            this.dtpRecievedDate = new System.Windows.Forms.DateTimePicker();
            this.label54 = new System.Windows.Forms.Label();
            this.dtpPODate = new System.Windows.Forms.DateTimePicker();
            this.label53 = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.chkBOMProject = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblproductsubtype = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.cmbProjectType = new System.Windows.Forms.ComboBox();
            this.lblProjecttype = new System.Windows.Forms.Label();
            this.lblOrdervalidityinmonths = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtcuscode = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dgvRevenueRecognition = new System.Windows.Forms.DataGridView();
            this.RevenueRecognition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MainQuestion1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnnextqn = new System.Windows.Forms.Button();
            this.btnbackqn = new System.Windows.Forms.Button();
            this.pnBIM.SuspendLayout();
            this.pnGMApproval.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.pnLDClause.SuspendLayout();
            this.pnLCClause.SuspendLayout();
            this.gbControlButtons.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.pnProjectMaster.SuspendLayout();
            this.pnCustomerlinkProject.SuspendLayout();
            this.panelCapex.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRevenueRecognition)).BeginInit();
            this.SuspendLayout();
            // 
            // dtpPMCreatedDate
            // 
            this.dtpPMCreatedDate.CustomFormat = "";
            this.dtpPMCreatedDate.Enabled = false;
            this.dtpPMCreatedDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPMCreatedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPMCreatedDate.Location = new System.Drawing.Point(1136, 7);
            this.dtpPMCreatedDate.Name = "dtpPMCreatedDate";
            this.dtpPMCreatedDate.Size = new System.Drawing.Size(110, 26);
            this.dtpPMCreatedDate.TabIndex = 70;
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Black;
            this.lblWelcome.Location = new System.Drawing.Point(4, 9);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(98, 24);
            this.lblWelcome.TabIndex = 24;
            this.lblWelcome.Text = "Welcome :";
            // 
            // lblReturnedby
            // 
            this.lblReturnedby.AutoSize = true;
            this.lblReturnedby.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturnedby.ForeColor = System.Drawing.Color.Black;
            this.lblReturnedby.Location = new System.Drawing.Point(100, 9);
            this.lblReturnedby.Name = "lblReturnedby";
            this.lblReturnedby.Size = new System.Drawing.Size(0, 24);
            this.lblReturnedby.TabIndex = 23;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Add-icon.png");
            this.imageList1.Images.SetKeyName(1, "table-add-icon.png");
            this.imageList1.Images.SetKeyName(2, "order-history-icon.png");
            this.imageList1.Images.SetKeyName(3, "Package-Add-icon.png");
            this.imageList1.Images.SetKeyName(4, "Excel-icon.png");
            this.imageList1.Images.SetKeyName(5, "Actions-address-book-new-icon.png");
            this.imageList1.Images.SetKeyName(6, "invoice-icon.png");
            this.imageList1.Images.SetKeyName(7, "Apps-kspread-icon.png");
            this.imageList1.Images.SetKeyName(8, "Apps-klipper-icon.png");
            this.imageList1.Images.SetKeyName(9, "Upline-icon.png");
            this.imageList1.Images.SetKeyName(10, "reports-icon.png");
            this.imageList1.Images.SetKeyName(11, "Mimetypes-application-vnd-sun-xml-calc-template-icon.png");
            this.imageList1.Images.SetKeyName(12, "catalog-icon.png");
            this.imageList1.Images.SetKeyName(13, "Add-icon.png");
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSearch.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(1035, 3);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(84, 31);
            this.btnSearch.TabIndex = 8;
            this.btnSearch.Text = "Search";
            this.toolTip1.SetToolTip(this.btnSearch, "Click Here To Get the List of Items");
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnExcel
            // 
            this.btnExcel.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExcel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExcel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcel.Location = new System.Drawing.Point(596, 29);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(151, 42);
            this.btnExcel.TabIndex = 12;
            this.btnExcel.Text = "Order Entry Form";
            this.toolTip1.SetToolTip(this.btnExcel, "Click Here To Get the List of Items");
            this.btnExcel.UseVisualStyleBackColor = false;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(793, 29);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(113, 42);
            this.btnExit.TabIndex = 21;
            this.btnExit.Text = "Exit";
            this.toolTip1.SetToolTip(this.btnExit, "Click Here To Exit This Page");
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // cmbPenaltyClause
            // 
            this.cmbPenaltyClause.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPenaltyClause.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPenaltyClause.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPenaltyClause.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbPenaltyClause.FormattingEnabled = true;
            this.cmbPenaltyClause.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbPenaltyClause.Location = new System.Drawing.Point(846, 285);
            this.cmbPenaltyClause.Name = "cmbPenaltyClause";
            this.cmbPenaltyClause.Size = new System.Drawing.Size(308, 26);
            this.cmbPenaltyClause.TabIndex = 17;
            this.toolTip1.SetToolTip(this.cmbPenaltyClause, "Select Project Type");
            // 
            // cmbPreDispatchInspection
            // 
            this.cmbPreDispatchInspection.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPreDispatchInspection.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPreDispatchInspection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPreDispatchInspection.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbPreDispatchInspection.FormattingEnabled = true;
            this.cmbPreDispatchInspection.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbPreDispatchInspection.Location = new System.Drawing.Point(845, 369);
            this.cmbPreDispatchInspection.Name = "cmbPreDispatchInspection";
            this.cmbPreDispatchInspection.Size = new System.Drawing.Size(308, 26);
            this.cmbPreDispatchInspection.TabIndex = 19;
            this.toolTip1.SetToolTip(this.cmbPreDispatchInspection, "Select Project Type");
            // 
            // cmbShippingMode
            // 
            this.cmbShippingMode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbShippingMode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbShippingMode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbShippingMode.FormattingEnabled = true;
            this.cmbShippingMode.Location = new System.Drawing.Point(177, 326);
            this.cmbShippingMode.Name = "cmbShippingMode";
            this.cmbShippingMode.Size = new System.Drawing.Size(333, 26);
            this.cmbShippingMode.TabIndex = 7;
            this.toolTip1.SetToolTip(this.cmbShippingMode, "Select Project Type");
            // 
            // cmbPaymentTerms
            // 
            this.cmbPaymentTerms.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPaymentTerms.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPaymentTerms.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbPaymentTerms.FormattingEnabled = true;
            this.cmbPaymentTerms.Location = new System.Drawing.Point(177, 365);
            this.cmbPaymentTerms.Name = "cmbPaymentTerms";
            this.cmbPaymentTerms.Size = new System.Drawing.Size(333, 26);
            this.cmbPaymentTerms.TabIndex = 8;
            this.toolTip1.SetToolTip(this.cmbPaymentTerms, "Select Project Type");
            // 
            // cmbAgent
            // 
            this.cmbAgent.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbAgent.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAgent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAgent.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbAgent.FormattingEnabled = true;
            this.cmbAgent.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbAgent.Location = new System.Drawing.Point(177, 405);
            this.cmbAgent.Name = "cmbAgent";
            this.cmbAgent.Size = new System.Drawing.Size(333, 26);
            this.cmbAgent.TabIndex = 9;
            this.toolTip1.SetToolTip(this.cmbAgent, "Select Project Type");
            // 
            // cmbSecurityDeposit
            // 
            this.cmbSecurityDeposit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSecurityDeposit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSecurityDeposit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSecurityDeposit.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbSecurityDeposit.FormattingEnabled = true;
            this.cmbSecurityDeposit.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbSecurityDeposit.Location = new System.Drawing.Point(839, 21);
            this.cmbSecurityDeposit.Name = "cmbSecurityDeposit";
            this.cmbSecurityDeposit.Size = new System.Drawing.Size(308, 26);
            this.cmbSecurityDeposit.TabIndex = 11;
            this.toolTip1.SetToolTip(this.cmbSecurityDeposit, "Select Project Type");
            // 
            // cmbBankGuarantee
            // 
            this.cmbBankGuarantee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbBankGuarantee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBankGuarantee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBankGuarantee.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbBankGuarantee.FormattingEnabled = true;
            this.cmbBankGuarantee.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbBankGuarantee.Location = new System.Drawing.Point(842, 65);
            this.cmbBankGuarantee.Name = "cmbBankGuarantee";
            this.cmbBankGuarantee.Size = new System.Drawing.Size(308, 26);
            this.cmbBankGuarantee.TabIndex = 12;
            this.toolTip1.SetToolTip(this.cmbBankGuarantee, "Select Project Type");
            // 
            // cmbPerformanceBankGuarantee
            // 
            this.cmbPerformanceBankGuarantee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPerformanceBankGuarantee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPerformanceBankGuarantee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPerformanceBankGuarantee.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbPerformanceBankGuarantee.FormattingEnabled = true;
            this.cmbPerformanceBankGuarantee.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbPerformanceBankGuarantee.Location = new System.Drawing.Point(842, 111);
            this.cmbPerformanceBankGuarantee.Name = "cmbPerformanceBankGuarantee";
            this.cmbPerformanceBankGuarantee.Size = new System.Drawing.Size(308, 26);
            this.cmbPerformanceBankGuarantee.TabIndex = 13;
            this.toolTip1.SetToolTip(this.cmbPerformanceBankGuarantee, "Select Project Type");
            // 
            // cmbPreDesignPreview
            // 
            this.cmbPreDesignPreview.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPreDesignPreview.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPreDesignPreview.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPreDesignPreview.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbPreDesignPreview.FormattingEnabled = true;
            this.cmbPreDesignPreview.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbPreDesignPreview.Location = new System.Drawing.Point(845, 326);
            this.cmbPreDesignPreview.Name = "cmbPreDesignPreview";
            this.cmbPreDesignPreview.Size = new System.Drawing.Size(308, 26);
            this.cmbPreDesignPreview.TabIndex = 18;
            this.toolTip1.SetToolTip(this.cmbPreDesignPreview, "Select Project Type");
            // 
            // cmbContractualAcceptance
            // 
            this.cmbContractualAcceptance.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbContractualAcceptance.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbContractualAcceptance.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbContractualAcceptance.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbContractualAcceptance.FormattingEnabled = true;
            this.cmbContractualAcceptance.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbContractualAcceptance.Location = new System.Drawing.Point(846, 411);
            this.cmbContractualAcceptance.Name = "cmbContractualAcceptance";
            this.cmbContractualAcceptance.Size = new System.Drawing.Size(308, 26);
            this.cmbContractualAcceptance.TabIndex = 20;
            this.toolTip1.SetToolTip(this.cmbContractualAcceptance, "Select Project Type");
            this.cmbContractualAcceptance.SelectedIndexChanged += new System.EventHandler(this.cmbContractualAcceptance_SelectedIndexChanged);
            // 
            // cmbShippingTerms
            // 
            this.cmbShippingTerms.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbShippingTerms.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbShippingTerms.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbShippingTerms.FormattingEnabled = true;
            this.cmbShippingTerms.Location = new System.Drawing.Point(176, 289);
            this.cmbShippingTerms.Name = "cmbShippingTerms";
            this.cmbShippingTerms.Size = new System.Drawing.Size(334, 26);
            this.cmbShippingTerms.TabIndex = 6;
            this.toolTip1.SetToolTip(this.cmbShippingTerms, "Select Project Type");
            // 
            // txtPMProjectDescription
            // 
            this.txtPMProjectDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPMProjectDescription.Location = new System.Drawing.Point(166, 364);
            this.txtPMProjectDescription.Multiline = true;
            this.txtPMProjectDescription.Name = "txtPMProjectDescription";
            this.txtPMProjectDescription.Size = new System.Drawing.Size(295, 30);
            this.txtPMProjectDescription.TabIndex = 11;
            this.toolTip1.SetToolTip(this.txtPMProjectDescription, "Enter Project Description");
            // 
            // cmbsystemsubtype
            // 
            this.cmbsystemsubtype.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbsystemsubtype.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbsystemsubtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbsystemsubtype.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbsystemsubtype.FormattingEnabled = true;
            this.cmbsystemsubtype.Location = new System.Drawing.Point(166, 330);
            this.cmbsystemsubtype.Name = "cmbsystemsubtype";
            this.cmbsystemsubtype.Size = new System.Drawing.Size(295, 26);
            this.cmbsystemsubtype.TabIndex = 10;
            this.toolTip1.SetToolTip(this.cmbsystemsubtype, "Select Project Type");
            this.cmbsystemsubtype.SelectedIndexChanged += new System.EventHandler(this.cmbsystemsubtype_SelectedIndexChanged);
            // 
            // txtPMProjectCode
            // 
            this.txtPMProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPMProjectCode.Location = new System.Drawing.Point(777, 7);
            this.txtPMProjectCode.Name = "txtPMProjectCode";
            this.txtPMProjectCode.ReadOnly = true;
            this.txtPMProjectCode.Size = new System.Drawing.Size(311, 26);
            this.txtPMProjectCode.TabIndex = 64;
            this.toolTip1.SetToolTip(this.txtPMProjectCode, "Display Project Code");
            // 
            // cmbPMProductType
            // 
            this.cmbPMProductType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPMProductType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPMProductType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPMProductType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPMProductType.FormattingEnabled = true;
            this.cmbPMProductType.Location = new System.Drawing.Point(166, 262);
            this.cmbPMProductType.Name = "cmbPMProductType";
            this.cmbPMProductType.Size = new System.Drawing.Size(295, 26);
            this.cmbPMProductType.TabIndex = 8;
            this.toolTip1.SetToolTip(this.cmbPMProductType, "Select Project Type");
            this.cmbPMProductType.SelectedIndexChanged += new System.EventHandler(this.cmbPMProductType_SelectedIndexChanged);
            // 
            // txtPONo
            // 
            this.txtPONo.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPONo.Location = new System.Drawing.Point(166, 64);
            this.txtPONo.Name = "txtPONo";
            this.txtPONo.Size = new System.Drawing.Size(295, 26);
            this.txtPONo.TabIndex = 0;
            this.toolTip1.SetToolTip(this.txtPONo, "Display Project Code");
            // 
            // CmbStandardCustom
            // 
            this.CmbStandardCustom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.CmbStandardCustom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbStandardCustom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbStandardCustom.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.CmbStandardCustom.FormattingEnabled = true;
            this.CmbStandardCustom.Items.AddRange(new object[] {
            "Standard",
            "Custom"});
            this.CmbStandardCustom.Location = new System.Drawing.Point(166, 230);
            this.CmbStandardCustom.Name = "CmbStandardCustom";
            this.CmbStandardCustom.Size = new System.Drawing.Size(295, 26);
            this.CmbStandardCustom.TabIndex = 7;
            this.toolTip1.SetToolTip(this.CmbStandardCustom, "Select Project Type");
            // 
            // txtBilltoCustomer
            // 
            this.txtBilltoCustomer.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtBilltoCustomer.Location = new System.Drawing.Point(777, 185);
            this.txtBilltoCustomer.Multiline = true;
            this.txtBilltoCustomer.Name = "txtBilltoCustomer";
            this.txtBilltoCustomer.Size = new System.Drawing.Size(314, 71);
            this.txtBilltoCustomer.TabIndex = 15;
            this.toolTip1.SetToolTip(this.txtBilltoCustomer, "Display Project Code");
            // 
            // txtShiptoCustomer
            // 
            this.txtShiptoCustomer.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtShiptoCustomer.Location = new System.Drawing.Point(777, 268);
            this.txtShiptoCustomer.Multiline = true;
            this.txtShiptoCustomer.Name = "txtShiptoCustomer";
            this.txtShiptoCustomer.Size = new System.Drawing.Size(314, 69);
            this.txtShiptoCustomer.TabIndex = 16;
            this.toolTip1.SetToolTip(this.txtShiptoCustomer, "Display Project Code");
            // 
            // cmbModelNumber
            // 
            this.cmbModelNumber.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbModelNumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbModelNumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbModelNumber.FormattingEnabled = true;
            this.cmbModelNumber.Location = new System.Drawing.Point(166, 295);
            this.cmbModelNumber.Name = "cmbModelNumber";
            this.cmbModelNumber.Size = new System.Drawing.Size(295, 26);
            this.cmbModelNumber.TabIndex = 9;
            this.toolTip1.SetToolTip(this.cmbModelNumber, "Select Project Type");
            // 
            // txtWarrantyClose
            // 
            this.txtWarrantyClose.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtWarrantyClose.Location = new System.Drawing.Point(777, 114);
            this.txtWarrantyClose.MaxLength = 2;
            this.txtWarrantyClose.Name = "txtWarrantyClose";
            this.txtWarrantyClose.Size = new System.Drawing.Size(311, 26);
            this.txtWarrantyClose.TabIndex = 13;
            this.txtWarrantyClose.Text = "0";
            this.toolTip1.SetToolTip(this.txtWarrantyClose, "Display Project Code");
            this.txtWarrantyClose.TextChanged += new System.EventHandler(this.txtWarrantyClose_TextChanged);
            this.txtWarrantyClose.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWarrantyClose_KeyPress);
            // 
            // txtCapexNumber
            // 
            this.txtCapexNumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCapexNumber.Location = new System.Drawing.Point(142, 9);
            this.txtCapexNumber.Name = "txtCapexNumber";
            this.txtCapexNumber.Size = new System.Drawing.Size(294, 26);
            this.txtCapexNumber.TabIndex = 64;
            this.toolTip1.SetToolTip(this.txtCapexNumber, "Enter Project Description");
            // 
            // txtCapexName
            // 
            this.txtCapexName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCapexName.Location = new System.Drawing.Point(142, 49);
            this.txtCapexName.Name = "txtCapexName";
            this.txtCapexName.Size = new System.Drawing.Size(294, 26);
            this.txtCapexName.TabIndex = 66;
            this.toolTip1.SetToolTip(this.txtCapexName, "Enter Project Description");
            // 
            // txtCapexRequester
            // 
            this.txtCapexRequester.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCapexRequester.Location = new System.Drawing.Point(142, 88);
            this.txtCapexRequester.Name = "txtCapexRequester";
            this.txtCapexRequester.Size = new System.Drawing.Size(294, 26);
            this.txtCapexRequester.TabIndex = 68;
            this.toolTip1.SetToolTip(this.txtCapexRequester, "Enter Project Description");
            // 
            // txtCapexAmount
            // 
            this.txtCapexAmount.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCapexAmount.Location = new System.Drawing.Point(607, 13);
            this.txtCapexAmount.MaxLength = 20;
            this.txtCapexAmount.Name = "txtCapexAmount";
            this.txtCapexAmount.Size = new System.Drawing.Size(182, 26);
            this.txtCapexAmount.TabIndex = 74;
            this.toolTip1.SetToolTip(this.txtCapexAmount, "Display Project Code");
            this.txtCapexAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCapexAmount_KeyPress);
            // 
            // txtOverHead
            // 
            this.txtOverHead.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtOverHead.Location = new System.Drawing.Point(607, 49);
            this.txtOverHead.MaxLength = 20;
            this.txtOverHead.Name = "txtOverHead";
            this.txtOverHead.Size = new System.Drawing.Size(182, 26);
            this.txtOverHead.TabIndex = 76;
            this.toolTip1.SetToolTip(this.txtOverHead, "Display Project Code");
            this.txtOverHead.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOverHead_KeyPress);
            // 
            // pnBIM
            // 
            this.pnBIM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnBIM.Controls.Add(this.pnGMApproval);
            this.pnBIM.Controls.Add(this.lblWelcome);
            this.pnBIM.Controls.Add(this.lblReturnedby);
            this.pnBIM.Controls.Add(this.btnSearch);
            this.pnBIM.Controls.Add(this.dtpPMCreatedDate);
            this.pnBIM.Location = new System.Drawing.Point(6, 7);
            this.pnBIM.Name = "pnBIM";
            this.pnBIM.Size = new System.Drawing.Size(1293, 45);
            this.pnBIM.TabIndex = 11;
            // 
            // pnGMApproval
            // 
            this.pnGMApproval.Controls.Add(this.cmbGMApproveList);
            this.pnGMApproval.Controls.Add(this.label66);
            this.pnGMApproval.Location = new System.Drawing.Point(561, 3);
            this.pnGMApproval.Name = "pnGMApproval";
            this.pnGMApproval.Size = new System.Drawing.Size(422, 35);
            this.pnGMApproval.TabIndex = 71;
            this.pnGMApproval.Visible = false;
            // 
            // cmbGMApproveList
            // 
            this.cmbGMApproveList.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbGMApproveList.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGMApproveList.DropDownHeight = 130;
            this.cmbGMApproveList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGMApproveList.DropDownWidth = 279;
            this.cmbGMApproveList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGMApproveList.FormattingEnabled = true;
            this.cmbGMApproveList.IntegralHeight = false;
            this.cmbGMApproveList.Location = new System.Drawing.Point(115, 4);
            this.cmbGMApproveList.Name = "cmbGMApproveList";
            this.cmbGMApproveList.Size = new System.Drawing.Size(294, 26);
            this.cmbGMApproveList.TabIndex = 117;
            this.cmbGMApproveList.SelectedIndexChanged += new System.EventHandler(this.cmbGMApproveList_SelectedIndexChanged);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.Color.Black;
            this.label66.Location = new System.Drawing.Point(12, 7);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(104, 19);
            this.label66.TabIndex = 118;
            this.label66.Text = "Project Code :";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Silver;
            this.tabPage3.Controls.Add(this.llbUploadDocs);
            this.tabPage3.Controls.Add(this.cmbDocType);
            this.tabPage3.Controls.Add(this.label69);
            this.tabPage3.Controls.Add(this.listBox1);
            this.tabPage3.Controls.Add(this.txtTargetValue);
            this.tabPage3.Controls.Add(this.txtTargetMaterialmargin);
            this.tabPage3.Controls.Add(this.txtEstimatedManufacturing);
            this.tabPage3.Controls.Add(this.txtEstimatedDesign);
            this.tabPage3.Controls.Add(this.txtEstimatedInsatllation);
            this.tabPage3.Controls.Add(this.txtInstallationValueinUSD);
            this.tabPage3.Controls.Add(this.txtInstallationValueinINR);
            this.tabPage3.Controls.Add(this.txtOrderValueinUSD);
            this.tabPage3.Controls.Add(this.txtOrderValueinINR);
            this.tabPage3.Controls.Add(this.txtSaleseffort);
            this.tabPage3.Controls.Add(this.txtQuotationEffort);
            this.tabPage3.Controls.Add(this.txtDiscount);
            this.tabPage3.Controls.Add(this.txtProjectMargin);
            this.tabPage3.Controls.Add(this.label68);
            this.tabPage3.Controls.Add(this.label67);
            this.tabPage3.Controls.Add(this.llbProjectDocuments);
            this.tabPage3.Controls.Add(this.cmbProjectDocument);
            this.tabPage3.Controls.Add(this.label60);
            this.tabPage3.Controls.Add(this.label37);
            this.tabPage3.Controls.Add(this.label36);
            this.tabPage3.Controls.Add(this.label25);
            this.tabPage3.Controls.Add(this.label64);
            this.tabPage3.Controls.Add(this.label61);
            this.tabPage3.Controls.Add(this.label62);
            this.tabPage3.Controls.Add(this.label63);
            this.tabPage3.Controls.Add(this.pnLDClause);
            this.tabPage3.Controls.Add(this.pnLCClause);
            this.tabPage3.Controls.Add(this.chkLCClause);
            this.tabPage3.Controls.Add(this.label46);
            this.tabPage3.Controls.Add(this.chkLDClause);
            this.tabPage3.Controls.Add(this.btnBack1);
            this.tabPage3.Controls.Add(this.label43);
            this.tabPage3.Controls.Add(this.label44);
            this.tabPage3.Controls.Add(this.label39);
            this.tabPage3.Controls.Add(this.label40);
            this.tabPage3.Controls.Add(this.cmbLever);
            this.tabPage3.Controls.Add(this.label38);
            this.tabPage3.Controls.Add(this.gbControlButtons);
            this.tabPage3.Location = new System.Drawing.Point(4, 5);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1285, 610);
            this.tabPage3.TabIndex = 2;
            // 
            // llbUploadDocs
            // 
            this.llbUploadDocs.AutoSize = true;
            this.llbUploadDocs.Location = new System.Drawing.Point(949, 353);
            this.llbUploadDocs.Name = "llbUploadDocs";
            this.llbUploadDocs.Size = new System.Drawing.Size(192, 19);
            this.llbUploadDocs.TabIndex = 175;
            this.llbUploadDocs.TabStop = true;
            this.llbUploadDocs.Text = "Project Documents Upload";
            this.llbUploadDocs.Visible = false;
            this.llbUploadDocs.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbUploadDocs_LinkClicked);
            // 
            // cmbDocType
            // 
            this.cmbDocType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbDocType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDocType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDocType.FormattingEnabled = true;
            this.cmbDocType.Location = new System.Drawing.Point(868, 281);
            this.cmbDocType.Name = "cmbDocType";
            this.cmbDocType.Size = new System.Drawing.Size(376, 26);
            this.cmbDocType.TabIndex = 173;
            this.cmbDocType.TextChanged += new System.EventHandler(this.cmbDocType_TextChanged);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label69.ForeColor = System.Drawing.Color.Black;
            this.label69.Location = new System.Drawing.Point(731, 283);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(129, 19);
            this.label69.TabIndex = 174;
            this.label69.Text = "Document Type*:";
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 19;
            this.listBox1.Location = new System.Drawing.Point(374, 429);
            this.listBox1.Name = "listBox1";
            this.listBox1.ScrollAlwaysVisible = true;
            this.listBox1.Size = new System.Drawing.Size(143, 42);
            this.listBox1.TabIndex = 171;
            this.listBox1.Visible = false;
            // 
            // txtTargetValue
            // 
            this.txtTargetValue.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtTargetValue.Location = new System.Drawing.Point(222, 161);
            this.txtTargetValue.MaxLength = 15;
            this.txtTargetValue.Name = "txtTargetValue";
            this.txtTargetValue.ReadOnly = true;
            this.txtTargetValue.Size = new System.Drawing.Size(235, 26);
            this.txtTargetValue.TabIndex = 169;
            // 
            // txtTargetMaterialmargin
            // 
            this.txtTargetMaterialmargin.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtTargetMaterialmargin.Location = new System.Drawing.Point(222, 125);
            this.txtTargetMaterialmargin.MaxLength = 4;
            this.txtTargetMaterialmargin.Name = "txtTargetMaterialmargin";
            this.txtTargetMaterialmargin.Size = new System.Drawing.Size(235, 26);
            this.txtTargetMaterialmargin.TabIndex = 167;
            this.txtTargetMaterialmargin.TextChanged += new System.EventHandler(this.txtTargetMaterialmargin_TextChanged);
            this.txtTargetMaterialmargin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTargetMaterialmargin_KeyPress);
            // 
            // txtEstimatedManufacturing
            // 
            this.txtEstimatedManufacturing.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtEstimatedManufacturing.Location = new System.Drawing.Point(868, 161);
            this.txtEstimatedManufacturing.MaxLength = 4;
            this.txtEstimatedManufacturing.Name = "txtEstimatedManufacturing";
            this.txtEstimatedManufacturing.Size = new System.Drawing.Size(234, 26);
            this.txtEstimatedManufacturing.TabIndex = 10;
            this.txtEstimatedManufacturing.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEstimatedManufacturing_KeyPress);
            // 
            // txtEstimatedDesign
            // 
            this.txtEstimatedDesign.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtEstimatedDesign.Location = new System.Drawing.Point(868, 124);
            this.txtEstimatedDesign.MaxLength = 4;
            this.txtEstimatedDesign.Name = "txtEstimatedDesign";
            this.txtEstimatedDesign.Size = new System.Drawing.Size(234, 26);
            this.txtEstimatedDesign.TabIndex = 9;
            this.txtEstimatedDesign.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEstimatedDesign_KeyPress);
            // 
            // txtEstimatedInsatllation
            // 
            this.txtEstimatedInsatllation.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtEstimatedInsatllation.Location = new System.Drawing.Point(868, 198);
            this.txtEstimatedInsatllation.MaxLength = 4;
            this.txtEstimatedInsatllation.Name = "txtEstimatedInsatllation";
            this.txtEstimatedInsatllation.Size = new System.Drawing.Size(234, 26);
            this.txtEstimatedInsatllation.TabIndex = 11;
            this.txtEstimatedInsatllation.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEstimatedInsatllation_KeyPress);
            // 
            // txtInstallationValueinUSD
            // 
            this.txtInstallationValueinUSD.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtInstallationValueinUSD.Location = new System.Drawing.Point(222, 269);
            this.txtInstallationValueinUSD.MaxLength = 15;
            this.txtInstallationValueinUSD.Name = "txtInstallationValueinUSD";
            this.txtInstallationValueinUSD.Size = new System.Drawing.Size(235, 26);
            this.txtInstallationValueinUSD.TabIndex = 5;
            this.txtInstallationValueinUSD.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtinstallationvalueinUSD_keydown);
            this.txtInstallationValueinUSD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInstallationValueinUSD_KeyPress);
            // 
            // txtInstallationValueinINR
            // 
            this.txtInstallationValueinINR.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtInstallationValueinINR.Location = new System.Drawing.Point(222, 228);
            this.txtInstallationValueinINR.MaxLength = 15;
            this.txtInstallationValueinINR.Name = "txtInstallationValueinINR";
            this.txtInstallationValueinINR.Size = new System.Drawing.Size(235, 26);
            this.txtInstallationValueinINR.TabIndex = 4;
            this.txtInstallationValueinINR.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtinstallationvalueinINR_keydown);
            this.txtInstallationValueinINR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInstallationValueinINR_KeyPress);
            // 
            // txtOrderValueinUSD
            // 
            this.txtOrderValueinUSD.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtOrderValueinUSD.Location = new System.Drawing.Point(222, 88);
            this.txtOrderValueinUSD.MaxLength = 15;
            this.txtOrderValueinUSD.Name = "txtOrderValueinUSD";
            this.txtOrderValueinUSD.Size = new System.Drawing.Size(235, 26);
            this.txtOrderValueinUSD.TabIndex = 3;
            this.txtOrderValueinUSD.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtOrderValueUSD_keydown);
            this.txtOrderValueinUSD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrderValueinUSD_KeyPress);
            // 
            // txtOrderValueinINR
            // 
            this.txtOrderValueinINR.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtOrderValueinINR.Location = new System.Drawing.Point(222, 54);
            this.txtOrderValueinINR.MaxLength = 15;
            this.txtOrderValueinINR.Name = "txtOrderValueinINR";
            this.txtOrderValueinINR.Size = new System.Drawing.Size(235, 26);
            this.txtOrderValueinINR.TabIndex = 2;
            this.txtOrderValueinINR.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtOrderValueinINR_keydown);
            this.txtOrderValueinINR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrderValueinINR_KeyPress);
            // 
            // txtSaleseffort
            // 
            this.txtSaleseffort.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtSaleseffort.Location = new System.Drawing.Point(867, 86);
            this.txtSaleseffort.MaxLength = 4;
            this.txtSaleseffort.Name = "txtSaleseffort";
            this.txtSaleseffort.Size = new System.Drawing.Size(235, 26);
            this.txtSaleseffort.TabIndex = 8;
            this.txtSaleseffort.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSaleseffort_KeyPress);
            // 
            // txtQuotationEffort
            // 
            this.txtQuotationEffort.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtQuotationEffort.Location = new System.Drawing.Point(867, 47);
            this.txtQuotationEffort.MaxLength = 4;
            this.txtQuotationEffort.Name = "txtQuotationEffort";
            this.txtQuotationEffort.Size = new System.Drawing.Size(235, 26);
            this.txtQuotationEffort.TabIndex = 7;
            this.txtQuotationEffort.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuotationEffort_KeyPress);
            // 
            // txtDiscount
            // 
            this.txtDiscount.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtDiscount.Location = new System.Drawing.Point(222, 193);
            this.txtDiscount.MaxLength = 3;
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.Size = new System.Drawing.Size(235, 26);
            this.txtDiscount.TabIndex = 1;
            this.txtDiscount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDiscount_KeyPress);
            // 
            // txtProjectMargin
            // 
            this.txtProjectMargin.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtProjectMargin.Location = new System.Drawing.Point(222, 18);
            this.txtProjectMargin.MaxLength = 4;
            this.txtProjectMargin.Name = "txtProjectMargin";
            this.txtProjectMargin.Size = new System.Drawing.Size(235, 26);
            this.txtProjectMargin.TabIndex = 0;
            this.txtProjectMargin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProjectMargin_KeyPress);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label68.Location = new System.Drawing.Point(69, 163);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(150, 19);
            this.label68.TabIndex = 170;
            this.label68.Text = "Target Value in INR : ";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label67.Location = new System.Drawing.Point(15, 125);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(201, 19);
            this.label67.TabIndex = 168;
            this.label67.Text = "Target Material Margin (%) :";
            // 
            // llbProjectDocuments
            // 
            this.llbProjectDocuments.AutoSize = true;
            this.llbProjectDocuments.Location = new System.Drawing.Point(740, 325);
            this.llbProjectDocuments.Name = "llbProjectDocuments";
            this.llbProjectDocuments.Size = new System.Drawing.Size(0, 19);
            this.llbProjectDocuments.TabIndex = 166;
            this.llbProjectDocuments.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbProjectDocuments_LinkClicked);
            // 
            // cmbProjectDocument
            // 
            this.cmbProjectDocument.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbProjectDocument.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectDocument.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectDocument.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectDocument.FormattingEnabled = true;
            this.cmbProjectDocument.Items.AddRange(new object[] {
            "Finance Documents",
            "Project Documents"});
            this.cmbProjectDocument.Location = new System.Drawing.Point(867, 239);
            this.cmbProjectDocument.Name = "cmbProjectDocument";
            this.cmbProjectDocument.Size = new System.Drawing.Size(377, 26);
            this.cmbProjectDocument.TabIndex = 164;
            this.cmbProjectDocument.SelectedIndexChanged += new System.EventHandler(this.cmbProjectDocument_SelectedIndexChanged);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.Black;
            this.label60.Location = new System.Drawing.Point(716, 241);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(145, 19);
            this.label60.TabIndex = 165;
            this.label60.Text = "Project Document*:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label37.Location = new System.Drawing.Point(631, 166);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(230, 19);
            this.label37.TabIndex = 163;
            this.label37.Text = "Estimated Manufacturing (Hrs)*:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label36.Location = new System.Drawing.Point(684, 127);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(177, 19);
            this.label36.TabIndex = 161;
            this.label36.Text = "Estimated Design (Hrs) *:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label25.Location = new System.Drawing.Point(653, 200);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(208, 19);
            this.label25.TabIndex = 159;
            this.label25.Text = "Estimated Installation (Hrs)* :\t\t";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label64.Location = new System.Drawing.Point(41, 271);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(175, 19);
            this.label64.TabIndex = 157;
            this.label64.Text = "Installtion Value in USD :";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label61.Location = new System.Drawing.Point(45, 230);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(171, 19);
            this.label61.TabIndex = 155;
            this.label61.Text = "Installtion Value in INR :";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label62.Location = new System.Drawing.Point(69, 90);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(147, 19);
            this.label62.TabIndex = 153;
            this.label62.Text = "Order Value in USD :";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label63.Location = new System.Drawing.Point(69, 56);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(147, 19);
            this.label63.TabIndex = 151;
            this.label63.Text = "Order Value in INR : ";
            // 
            // pnLDClause
            // 
            this.pnLDClause.Controls.Add(this.dtpLDToDate);
            this.pnLDClause.Controls.Add(this.txtLDBody);
            this.pnLDClause.Controls.Add(this.label47);
            this.pnLDClause.Controls.Add(this.label51);
            this.pnLDClause.Controls.Add(this.dtpLDFromDate);
            this.pnLDClause.Controls.Add(this.label52);
            this.pnLDClause.Location = new System.Drawing.Point(18, 386);
            this.pnLDClause.Name = "pnLDClause";
            this.pnLDClause.Size = new System.Drawing.Size(350, 117);
            this.pnLDClause.TabIndex = 150;
            this.pnLDClause.Visible = false;
            // 
            // dtpLDToDate
            // 
            this.dtpLDToDate.CustomFormat = "";
            this.dtpLDToDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpLDToDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpLDToDate.Location = new System.Drawing.Point(233, 3);
            this.dtpLDToDate.MaxDate = new System.DateTime(2028, 12, 31, 0, 0, 0, 0);
            this.dtpLDToDate.MinDate = new System.DateTime(2017, 1, 1, 0, 0, 0, 0);
            this.dtpLDToDate.Name = "dtpLDToDate";
            this.dtpLDToDate.Size = new System.Drawing.Size(103, 26);
            this.dtpLDToDate.TabIndex = 14;
            // 
            // txtLDBody
            // 
            this.txtLDBody.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtLDBody.Location = new System.Drawing.Point(59, 40);
            this.txtLDBody.Multiline = true;
            this.txtLDBody.Name = "txtLDBody";
            this.txtLDBody.Size = new System.Drawing.Size(277, 67);
            this.txtLDBody.TabIndex = 15;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.Black;
            this.label47.Location = new System.Drawing.Point(14, 9);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(44, 18);
            this.label47.TabIndex = 143;
            this.label47.Text = "Start :";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label51.ForeColor = System.Drawing.Color.Black;
            this.label51.Location = new System.Drawing.Point(7, 43);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(46, 18);
            this.label51.TabIndex = 147;
            this.label51.Text = "Body :";
            // 
            // dtpLDFromDate
            // 
            this.dtpLDFromDate.CustomFormat = "";
            this.dtpLDFromDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpLDFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpLDFromDate.Location = new System.Drawing.Point(59, 3);
            this.dtpLDFromDate.MaxDate = new System.DateTime(2028, 12, 31, 0, 0, 0, 0);
            this.dtpLDFromDate.MinDate = new System.DateTime(2017, 1, 1, 0, 0, 0, 0);
            this.dtpLDFromDate.Name = "dtpLDFromDate";
            this.dtpLDFromDate.Size = new System.Drawing.Size(124, 26);
            this.dtpLDFromDate.TabIndex = 13;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.ForeColor = System.Drawing.Color.Black;
            this.label52.Location = new System.Drawing.Point(189, 9);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(38, 18);
            this.label52.TabIndex = 145;
            this.label52.Text = "End :";
            // 
            // pnLCClause
            // 
            this.pnLCClause.Controls.Add(this.dtpLCEndDate);
            this.pnLCClause.Controls.Add(this.txtBody);
            this.pnLCClause.Controls.Add(this.label48);
            this.pnLCClause.Controls.Add(this.label50);
            this.pnLCClause.Controls.Add(this.dtpFromDate);
            this.pnLCClause.Controls.Add(this.label49);
            this.pnLCClause.Location = new System.Drawing.Point(710, 386);
            this.pnLCClause.Name = "pnLCClause";
            this.pnLCClause.Size = new System.Drawing.Size(350, 117);
            this.pnLCClause.TabIndex = 149;
            this.pnLCClause.Visible = false;
            // 
            // dtpLCEndDate
            // 
            this.dtpLCEndDate.CustomFormat = "";
            this.dtpLCEndDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpLCEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpLCEndDate.Location = new System.Drawing.Point(233, 3);
            this.dtpLCEndDate.MaxDate = new System.DateTime(2028, 12, 31, 0, 0, 0, 0);
            this.dtpLCEndDate.MinDate = new System.DateTime(2017, 1, 1, 0, 0, 0, 0);
            this.dtpLCEndDate.Name = "dtpLCEndDate";
            this.dtpLCEndDate.Size = new System.Drawing.Size(103, 26);
            this.dtpLCEndDate.TabIndex = 18;
            // 
            // txtBody
            // 
            this.txtBody.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtBody.Location = new System.Drawing.Point(59, 40);
            this.txtBody.Multiline = true;
            this.txtBody.Name = "txtBody";
            this.txtBody.Size = new System.Drawing.Size(277, 67);
            this.txtBody.TabIndex = 19;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.Black;
            this.label48.Location = new System.Drawing.Point(14, 9);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(44, 18);
            this.label48.TabIndex = 143;
            this.label48.Text = "Start :";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label50.ForeColor = System.Drawing.Color.Black;
            this.label50.Location = new System.Drawing.Point(7, 43);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(46, 18);
            this.label50.TabIndex = 147;
            this.label50.Text = "Body :";
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.CustomFormat = "";
            this.dtpFromDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(59, 3);
            this.dtpFromDate.MaxDate = new System.DateTime(2028, 12, 31, 0, 0, 0, 0);
            this.dtpFromDate.MinDate = new System.DateTime(2017, 1, 1, 0, 0, 0, 0);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(124, 26);
            this.dtpFromDate.TabIndex = 17;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.Black;
            this.label49.Location = new System.Drawing.Point(189, 9);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(38, 18);
            this.label49.TabIndex = 145;
            this.label49.Text = "End :";
            // 
            // chkLCClause
            // 
            this.chkLCClause.AutoSize = true;
            this.chkLCClause.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLCClause.ForeColor = System.Drawing.Color.Black;
            this.chkLCClause.Location = new System.Drawing.Point(710, 353);
            this.chkLCClause.Name = "chkLCClause";
            this.chkLCClause.Size = new System.Drawing.Size(103, 27);
            this.chkLCClause.TabIndex = 16;
            this.chkLCClause.Text = "LC Clause";
            this.chkLCClause.UseVisualStyleBackColor = true;
            this.chkLCClause.CheckedChanged += new System.EventHandler(this.chkLCClause_CheckedChanged);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label46.Location = new System.Drawing.Point(14, 331);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(105, 19);
            this.label46.TabIndex = 141;
            this.label46.Text = "Set Reminder ";
            // 
            // chkLDClause
            // 
            this.chkLDClause.AutoSize = true;
            this.chkLDClause.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLDClause.ForeColor = System.Drawing.Color.Black;
            this.chkLDClause.Location = new System.Drawing.Point(18, 353);
            this.chkLDClause.Name = "chkLDClause";
            this.chkLDClause.Size = new System.Drawing.Size(105, 27);
            this.chkLDClause.TabIndex = 12;
            this.chkLDClause.Text = "LD Clause";
            this.chkLDClause.UseVisualStyleBackColor = true;
            this.chkLDClause.CheckedChanged += new System.EventHandler(this.chkLDClause_CheckedChanged);
            // 
            // btnBack1
            // 
            this.btnBack1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBack1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBack1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack1.Location = new System.Drawing.Point(31, 526);
            this.btnBack1.Name = "btnBack1";
            this.btnBack1.Size = new System.Drawing.Size(113, 42);
            this.btnBack1.TabIndex = 22;
            this.btnBack1.Text = "Back";
            this.btnBack1.UseVisualStyleBackColor = false;
            this.btnBack1.Click += new System.EventHandler(this.btnBack1_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label43.Location = new System.Drawing.Point(722, 88);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(138, 19);
            this.label43.TabIndex = 135;
            this.label43.Text = "Sales Effort (Hrs) *:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label44.Location = new System.Drawing.Point(721, 49);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(139, 19);
            this.label44.TabIndex = 133;
            this.label44.Text = "Offer Effort (Hrs)* :";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label39.Location = new System.Drawing.Point(117, 195);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(99, 19);
            this.label39.TabIndex = 129;
            this.label39.Text = "Discount(%) :";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label40.Location = new System.Drawing.Point(6, 20);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(210, 19);
            this.label40.TabIndex = 127;
            this.label40.Text = "Quoted Material Margin (%) :";
            // 
            // cmbLever
            // 
            this.cmbLever.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbLever.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLever.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLever.FormattingEnabled = true;
            this.cmbLever.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.cmbLever.Location = new System.Drawing.Point(867, 12);
            this.cmbLever.Name = "cmbLever";
            this.cmbLever.Size = new System.Drawing.Size(235, 27);
            this.cmbLever.TabIndex = 6;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label38.Location = new System.Drawing.Point(807, 15);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(54, 19);
            this.label38.TabIndex = 112;
            this.label38.Text = "Lever :";
            // 
            // gbControlButtons
            // 
            this.gbControlButtons.Controls.Add(this.btnExit);
            this.gbControlButtons.Controls.Add(this.btnExcel);
            this.gbControlButtons.Controls.Add(this.btnSave);
            this.gbControlButtons.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.gbControlButtons.Location = new System.Drawing.Point(271, 500);
            this.gbControlButtons.Name = "gbControlButtons";
            this.gbControlButtons.Size = new System.Drawing.Size(960, 87);
            this.gbControlButtons.TabIndex = 60;
            this.gbControlButtons.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(449, 29);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(113, 42);
            this.btnSave.TabIndex = 20;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Controls.Add(this.txtCustomerRequirement);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.cmbShippingTerms);
            this.tabPage2.Controls.Add(this.txtDepartment);
            this.tabPage2.Controls.Add(this.txtMoblieNo);
            this.tabPage2.Controls.Add(this.txtContactPerson);
            this.tabPage2.Controls.Add(this.txtContactAddress);
            this.tabPage2.Controls.Add(this.txtRemarks);
            this.tabPage2.Controls.Add(this.txtOfficeNo);
            this.tabPage2.Controls.Add(this.txtContactEmail);
            this.tabPage2.Controls.Add(this.txtDeliveryPeriod);
            this.tabPage2.Controls.Add(this.txtStandardDeliveryPeriod);
            this.tabPage2.Controls.Add(this.txtAgentCommission);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.lblremarks);
            this.tabPage2.Controls.Add(this.lblContactPerson);
            this.tabPage2.Controls.Add(this.cmbContractualAcceptance);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.cmbPreDesignPreview);
            this.tabPage2.Controls.Add(this.label59);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.label58);
            this.tabPage2.Controls.Add(this.cmbPerformanceBankGuarantee);
            this.tabPage2.Controls.Add(this.cmbBankGuarantee);
            this.tabPage2.Controls.Add(this.cmbSecurityDeposit);
            this.tabPage2.Controls.Add(this.cmbAgent);
            this.tabPage2.Controls.Add(this.label57);
            this.tabPage2.Controls.Add(this.cmbPaymentTerms);
            this.tabPage2.Controls.Add(this.cmbShippingMode);
            this.tabPage2.Controls.Add(this.label56);
            this.tabPage2.Controls.Add(this.btnNext1);
            this.tabPage2.Controls.Add(this.btnBack);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.cmbPreDispatchInspection);
            this.tabPage2.Controls.Add(this.cmbPenaltyClause);
            this.tabPage2.Controls.Add(this.label32);
            this.tabPage2.Controls.Add(this.label34);
            this.tabPage2.Controls.Add(this.label35);
            this.tabPage2.Controls.Add(this.label31);
            this.tabPage2.Controls.Add(this.label30);
            this.tabPage2.Controls.Add(this.label29);
            this.tabPage2.Controls.Add(this.label28);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Location = new System.Drawing.Point(4, 5);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1285, 610);
            this.tabPage2.TabIndex = 1;
            // 
            // txtCustomerRequirement
            // 
            this.txtCustomerRequirement.CustomFormat = "";
            this.txtCustomerRequirement.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerRequirement.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtCustomerRequirement.Location = new System.Drawing.Point(846, 241);
            this.txtCustomerRequirement.Name = "txtCustomerRequirement";
            this.txtCustomerRequirement.Size = new System.Drawing.Size(307, 26);
            this.txtCustomerRequirement.TabIndex = 147;
            this.txtCustomerRequirement.ValueChanged += new System.EventHandler(this.txtCustomerRequirement_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(78, 252);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 19);
            this.label7.TabIndex = 97;
            this.label7.Text = "Mobile No :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(67, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 19);
            this.label6.TabIndex = 95;
            this.label6.Text = "Department :";
            // 
            // txtDepartment
            // 
            this.txtDepartment.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtDepartment.Location = new System.Drawing.Point(176, 59);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(334, 26);
            this.txtDepartment.TabIndex = 1;
            // 
            // txtMoblieNo
            // 
            this.txtMoblieNo.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtMoblieNo.Location = new System.Drawing.Point(177, 250);
            this.txtMoblieNo.Name = "txtMoblieNo";
            this.txtMoblieNo.Size = new System.Drawing.Size(333, 26);
            this.txtMoblieNo.TabIndex = 5;
            // 
            // txtContactPerson
            // 
            this.txtContactPerson.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtContactPerson.Location = new System.Drawing.Point(176, 23);
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Size = new System.Drawing.Size(334, 26);
            this.txtContactPerson.TabIndex = 0;
            // 
            // txtContactAddress
            // 
            this.txtContactAddress.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtContactAddress.Location = new System.Drawing.Point(176, 96);
            this.txtContactAddress.Multiline = true;
            this.txtContactAddress.Name = "txtContactAddress";
            this.txtContactAddress.Size = new System.Drawing.Size(334, 69);
            this.txtContactAddress.TabIndex = 2;
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(846, 463);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(308, 48);
            this.txtRemarks.TabIndex = 21;
            this.txtRemarks.Visible = false;
            // 
            // txtOfficeNo
            // 
            this.txtOfficeNo.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtOfficeNo.Location = new System.Drawing.Point(176, 213);
            this.txtOfficeNo.Name = "txtOfficeNo";
            this.txtOfficeNo.Size = new System.Drawing.Size(334, 26);
            this.txtOfficeNo.TabIndex = 4;
            // 
            // txtContactEmail
            // 
            this.txtContactEmail.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtContactEmail.Location = new System.Drawing.Point(176, 176);
            this.txtContactEmail.Name = "txtContactEmail";
            this.txtContactEmail.Size = new System.Drawing.Size(334, 26);
            this.txtContactEmail.TabIndex = 3;
            // 
            // txtDeliveryPeriod
            // 
            this.txtDeliveryPeriod.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtDeliveryPeriod.Location = new System.Drawing.Point(846, 156);
            this.txtDeliveryPeriod.Name = "txtDeliveryPeriod";
            this.txtDeliveryPeriod.Size = new System.Drawing.Size(306, 26);
            this.txtDeliveryPeriod.TabIndex = 14;
            // 
            // txtStandardDeliveryPeriod
            // 
            this.txtStandardDeliveryPeriod.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtStandardDeliveryPeriod.Location = new System.Drawing.Point(846, 200);
            this.txtStandardDeliveryPeriod.Name = "txtStandardDeliveryPeriod";
            this.txtStandardDeliveryPeriod.Size = new System.Drawing.Size(308, 26);
            this.txtStandardDeliveryPeriod.TabIndex = 15;
            // 
            // txtAgentCommission
            // 
            this.txtAgentCommission.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtAgentCommission.Location = new System.Drawing.Point(177, 442);
            this.txtAgentCommission.Name = "txtAgentCommission";
            this.txtAgentCommission.Size = new System.Drawing.Size(333, 26);
            this.txtAgentCommission.TabIndex = 10;
            this.txtAgentCommission.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAgentCommission_KeyPress);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label23.Location = new System.Drawing.Point(96, 103);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(71, 19);
            this.label23.TabIndex = 87;
            this.label23.Text = "Address :";
            // 
            // lblremarks
            // 
            this.lblremarks.AutoSize = true;
            this.lblremarks.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblremarks.ForeColor = System.Drawing.Color.Black;
            this.lblremarks.Location = new System.Drawing.Point(762, 465);
            this.lblremarks.Name = "lblremarks";
            this.lblremarks.Size = new System.Drawing.Size(71, 19);
            this.lblremarks.TabIndex = 146;
            this.lblremarks.Text = "Remarks:";
            this.lblremarks.Visible = false;
            // 
            // lblContactPerson
            // 
            this.lblContactPerson.AutoSize = true;
            this.lblContactPerson.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactPerson.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblContactPerson.Location = new System.Drawing.Point(79, 25);
            this.lblContactPerson.Name = "lblContactPerson";
            this.lblContactPerson.Size = new System.Drawing.Size(91, 19);
            this.lblContactPerson.TabIndex = 88;
            this.lblContactPerson.Text = "User Name :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label21.Location = new System.Drawing.Point(86, 216);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(80, 19);
            this.label21.TabIndex = 90;
            this.label21.Text = "Office No :";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label59.Location = new System.Drawing.Point(695, 200);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(140, 19);
            this.label59.TabIndex = 142;
            this.label59.Text = "Standard Delivery :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label22.Location = new System.Drawing.Point(114, 178);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(56, 19);
            this.label22.TabIndex = 89;
            this.label22.Text = "E-Mail:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label58.Location = new System.Drawing.Point(669, 158);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(165, 19);
            this.label58.TabIndex = 141;
            this.label58.Text = "Delivery Period in P.O :";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label57.Location = new System.Drawing.Point(104, 407);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(62, 19);
            this.label57.TabIndex = 136;
            this.label57.Text = "Agent*:\t";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label56.Location = new System.Drawing.Point(50, 328);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(121, 19);
            this.label56.TabIndex = 133;
            this.label56.Text = "Shipping Mode :\t";
            // 
            // btnNext1
            // 
            this.btnNext1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnNext1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNext1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext1.Location = new System.Drawing.Point(1114, 538);
            this.btnNext1.Name = "btnNext1";
            this.btnNext1.Size = new System.Drawing.Size(113, 42);
            this.btnNext1.TabIndex = 22;
            this.btnNext1.Text = "Next";
            this.btnNext1.UseVisualStyleBackColor = false;
            this.btnNext1.Click += new System.EventHandler(this.btnNext1_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBack.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(17, 538);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(113, 42);
            this.btnBack.TabIndex = 23;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label24.Location = new System.Drawing.Point(49, 372);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(122, 19);
            this.label24.TabIndex = 129;
            this.label24.Text = "Payment Terms :\t";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(50, 289);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 19);
            this.label1.TabIndex = 127;
            this.label1.Text = "Shipping Terms :\t";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label32.Location = new System.Drawing.Point(663, 369);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(177, 19);
            this.label32.TabIndex = 116;
            this.label32.Text = "Pre-dispatch Inspection :";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label34.Location = new System.Drawing.Point(699, 328);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(142, 19);
            this.label34.TabIndex = 112;
            this.label34.Text = "Pre-design Review :";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label35.Location = new System.Drawing.Point(645, 413);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(183, 38);
            this.label35.TabIndex = 110;
            this.label35.Text = "Contractual Acceptance /\r\nAcceptance Criteria :";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label31.Location = new System.Drawing.Point(718, 288);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(116, 19);
            this.label31.TabIndex = 108;
            this.label31.Text = "Penalty Clause :\t\t\r\n";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label30.Location = new System.Drawing.Point(648, 246);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(187, 19);
            this.label30.TabIndex = 106;
            this.label30.Text = "Customer Requirement * :\t\t\t\r\n";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label29.Location = new System.Drawing.Point(606, 118);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(227, 19);
            this.label29.TabIndex = 104;
            this.label29.Text = "Performance Bank Guarantee *:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label28.Location = new System.Drawing.Point(699, 72);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(135, 19);
            this.label28.TabIndex = 102;
            this.label28.Text = "Bank Guarantee* :";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label27.Location = new System.Drawing.Point(695, 28);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(137, 19);
            this.label27.TabIndex = 100;
            this.label27.Text = "Security Deposit* :";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label26.Location = new System.Drawing.Point(28, 444);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(143, 19);
            this.label26.TabIndex = 98;
            this.label26.Text = "Agent Commission :";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Silver;
            this.tabPage1.Controls.Add(this.pnProjectMaster);
            this.tabPage1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1285, 610);
            this.tabPage1.TabIndex = 0;
            // 
            // pnProjectMaster
            // 
            this.pnProjectMaster.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnProjectMaster.Controls.Add(this.comboBoxProfitCentre);
            this.pnProjectMaster.Controls.Add(this.label72);
            this.pnProjectMaster.Controls.Add(this.label45);
            this.pnProjectMaster.Controls.Add(this.cmbProductionCompany);
            this.pnProjectMaster.Controls.Add(this.comManufactureform);
            this.pnProjectMaster.Controls.Add(this.label8);
            this.pnProjectMaster.Controls.Add(this.pnCustomerlinkProject);
            this.pnProjectMaster.Controls.Add(this.cmbWarrantyStartsFrom);
            this.pnProjectMaster.Controls.Add(this.lblWarrantyStartsfrom);
            this.pnProjectMaster.Controls.Add(this.panelCapex);
            this.pnProjectMaster.Controls.Add(this.cmbCustomizationlevel);
            this.pnProjectMaster.Controls.Add(this.label13);
            this.pnProjectMaster.Controls.Add(this.cmbProject8020);
            this.pnProjectMaster.Controls.Add(this.label9);
            this.pnProjectMaster.Controls.Add(this.cmbEndUserCountry);
            this.pnProjectMaster.Controls.Add(this.txtProjectFocal);
            this.pnProjectMaster.Controls.Add(this.txtWarrantyClose);
            this.pnProjectMaster.Controls.Add(this.cmbModelNumber);
            this.pnProjectMaster.Controls.Add(this.cmbRevisionNumber);
            this.pnProjectMaster.Controls.Add(this.label55);
            this.pnProjectMaster.Controls.Add(this.cmbOfferNumber);
            this.pnProjectMaster.Controls.Add(this.dtpRecievedDate);
            this.pnProjectMaster.Controls.Add(this.label54);
            this.pnProjectMaster.Controls.Add(this.dtpPODate);
            this.pnProjectMaster.Controls.Add(this.label53);
            this.pnProjectMaster.Controls.Add(this.btnNext);
            this.pnProjectMaster.Controls.Add(this.txtShiptoCustomer);
            this.pnProjectMaster.Controls.Add(this.label20);
            this.pnProjectMaster.Controls.Add(this.txtBilltoCustomer);
            this.pnProjectMaster.Controls.Add(this.label19);
            this.pnProjectMaster.Controls.Add(this.label18);
            this.pnProjectMaster.Controls.Add(this.label16);
            this.pnProjectMaster.Controls.Add(this.label15);
            this.pnProjectMaster.Controls.Add(this.CmbStandardCustom);
            this.pnProjectMaster.Controls.Add(this.label12);
            this.pnProjectMaster.Controls.Add(this.label11);
            this.pnProjectMaster.Controls.Add(this.txtPONo);
            this.pnProjectMaster.Controls.Add(this.label10);
            this.pnProjectMaster.Controls.Add(this.chkBOMProject);
            this.pnProjectMaster.Controls.Add(this.cmbPMProductType);
            this.pnProjectMaster.Controls.Add(this.label5);
            this.pnProjectMaster.Controls.Add(this.txtPMProjectCode);
            this.pnProjectMaster.Controls.Add(this.cmbsystemsubtype);
            this.pnProjectMaster.Controls.Add(this.label3);
            this.pnProjectMaster.Controls.Add(this.txtPMProjectDescription);
            this.pnProjectMaster.Controls.Add(this.lblproductsubtype);
            this.pnProjectMaster.Controls.Add(this.label2);
            this.pnProjectMaster.Controls.Add(this.cmbCustomer);
            this.pnProjectMaster.Controls.Add(this.cmbProjectType);
            this.pnProjectMaster.Controls.Add(this.lblProjecttype);
            this.pnProjectMaster.Controls.Add(this.lblOrdervalidityinmonths);
            this.pnProjectMaster.Controls.Add(this.label4);
            this.pnProjectMaster.Controls.Add(this.txtcuscode);
            this.pnProjectMaster.Location = new System.Drawing.Point(10, 9);
            this.pnProjectMaster.Name = "pnProjectMaster";
            this.pnProjectMaster.Size = new System.Drawing.Size(1263, 581);
            this.pnProjectMaster.TabIndex = 13;
            // 
            // comboBoxProfitCentre
            // 
            this.comboBoxProfitCentre.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.comboBoxProfitCentre.FormattingEnabled = true;
            this.comboBoxProfitCentre.IntegralHeight = false;
            this.comboBoxProfitCentre.Items.AddRange(new object[] {
            "Product - BISS",
            "Product- BISS OTC",
            "Service-BISS Product",
            "Service- IMT",
            "Service- Testing",
            "IMT-EM-Static HFA",
            "IMT-EM-Static LFA",
            "IMT-EM-OTC",
            "IMT-Dynamic LFA",
            "IMT-Dynamic HFA",
            "IMT-Dynamic-OTC",
            "IMT-Ceast Drop Towers",
            "IMT-Ceast PTI",
            "IMT-Ceast -OTC",
            "IST",
            "Others"});
            this.comboBoxProfitCentre.Location = new System.Drawing.Point(164, 34);
            this.comboBoxProfitCentre.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxProfitCentre.Name = "comboBoxProfitCentre";
            this.comboBoxProfitCentre.Size = new System.Drawing.Size(295, 26);
            this.comboBoxProfitCentre.TabIndex = 208;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label72.Location = new System.Drawing.Point(53, 33);
            this.label72.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(109, 19);
            this.label72.TabIndex = 209;
            this.label72.Text = "Profit Centre*:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.Black;
            this.label45.Location = new System.Drawing.Point(658, 52);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(118, 19);
            this.label45.TabIndex = 207;
            this.label45.Text = "Product Make*:";
            // 
            // cmbProductionCompany
            // 
            this.cmbProductionCompany.DropDownHeight = 60;
            this.cmbProductionCompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProductionCompany.DropDownWidth = 150;
            this.cmbProductionCompany.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProductionCompany.FormattingEnabled = true;
            this.cmbProductionCompany.IntegralHeight = false;
            this.cmbProductionCompany.ItemHeight = 18;
            this.cmbProductionCompany.Items.AddRange(new object[] {
            "BiSS-ITW",
            "INSTRON"});
            this.cmbProductionCompany.Location = new System.Drawing.Point(777, 45);
            this.cmbProductionCompany.Name = "cmbProductionCompany";
            this.cmbProductionCompany.Size = new System.Drawing.Size(234, 26);
            this.cmbProductionCompany.TabIndex = 206;
            // 
            // comManufactureform
            // 
            this.comManufactureform.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comManufactureform.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comManufactureform.DropDownHeight = 130;
            this.comManufactureform.DropDownWidth = 279;
            this.comManufactureform.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comManufactureform.FormattingEnabled = true;
            this.comManufactureform.IntegralHeight = false;
            this.comManufactureform.Location = new System.Drawing.Point(166, 404);
            this.comManufactureform.Name = "comManufactureform";
            this.comManufactureform.Size = new System.Drawing.Size(295, 26);
            this.comManufactureform.TabIndex = 131;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(17, 404);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(149, 19);
            this.label8.TabIndex = 132;
            this.label8.Text = "Manufacture From*:";
            // 
            // pnCustomerlinkProject
            // 
            this.pnCustomerlinkProject.Controls.Add(this.lblProjectName);
            this.pnCustomerlinkProject.Controls.Add(this.label71);
            this.pnCustomerlinkProject.Controls.Add(this.cmbStockProject);
            this.pnCustomerlinkProject.Controls.Add(this.label70);
            this.pnCustomerlinkProject.Location = new System.Drawing.Point(5, 432);
            this.pnCustomerlinkProject.Name = "pnCustomerlinkProject";
            this.pnCustomerlinkProject.Size = new System.Drawing.Size(466, 139);
            this.pnCustomerlinkProject.TabIndex = 130;
            this.pnCustomerlinkProject.Visible = false;
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.Color.Black;
            this.lblProjectName.Location = new System.Drawing.Point(162, 82);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(17, 19);
            this.lblProjectName.TabIndex = 122;
            this.lblProjectName.Text = "*";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.ForeColor = System.Drawing.Color.Black;
            this.label71.Location = new System.Drawing.Point(46, 82);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(110, 19);
            this.label71.TabIndex = 121;
            this.label71.Text = "Project Name :";
            // 
            // cmbStockProject
            // 
            this.cmbStockProject.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbStockProject.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbStockProject.DropDownHeight = 130;
            this.cmbStockProject.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStockProject.DropDownWidth = 279;
            this.cmbStockProject.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbStockProject.FormattingEnabled = true;
            this.cmbStockProject.IntegralHeight = false;
            this.cmbStockProject.Location = new System.Drawing.Point(162, 47);
            this.cmbStockProject.Name = "cmbStockProject";
            this.cmbStockProject.Size = new System.Drawing.Size(294, 26);
            this.cmbStockProject.TabIndex = 119;
            this.cmbStockProject.SelectedIndexChanged += new System.EventHandler(this.cmbStockProject_SelectedIndexChanged);
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.ForeColor = System.Drawing.Color.Black;
            this.label70.Location = new System.Drawing.Point(10, 49);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(146, 19);
            this.label70.TabIndex = 120;
            this.label70.Text = "Stock Project Code :";
            // 
            // cmbWarrantyStartsFrom
            // 
            this.cmbWarrantyStartsFrom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbWarrantyStartsFrom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbWarrantyStartsFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWarrantyStartsFrom.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWarrantyStartsFrom.FormattingEnabled = true;
            this.cmbWarrantyStartsFrom.Items.AddRange(new object[] {
            "Starts from Invoice Date",
            "Starts from Installation Date",
            "Warranty NA"});
            this.cmbWarrantyStartsFrom.Location = new System.Drawing.Point(777, 82);
            this.cmbWarrantyStartsFrom.Name = "cmbWarrantyStartsFrom";
            this.cmbWarrantyStartsFrom.Size = new System.Drawing.Size(314, 26);
            this.cmbWarrantyStartsFrom.TabIndex = 129;
            this.cmbWarrantyStartsFrom.SelectedIndexChanged += new System.EventHandler(this.cmbWarrantyStartsFrom_SelectedIndexChanged);
            // 
            // lblWarrantyStartsfrom
            // 
            this.lblWarrantyStartsfrom.AutoSize = true;
            this.lblWarrantyStartsfrom.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWarrantyStartsfrom.ForeColor = System.Drawing.Color.Black;
            this.lblWarrantyStartsfrom.Location = new System.Drawing.Point(600, 84);
            this.lblWarrantyStartsfrom.Name = "lblWarrantyStartsfrom";
            this.lblWarrantyStartsfrom.Size = new System.Drawing.Size(171, 19);
            this.lblWarrantyStartsfrom.TabIndex = 128;
            this.lblWarrantyStartsfrom.Text = "Warranty Starts from *:";
            this.lblWarrantyStartsfrom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panelCapex
            // 
            this.panelCapex.Controls.Add(this.checkBoxdept);
            this.panelCapex.Controls.Add(this.cmbDepartment);
            this.panelCapex.Controls.Add(this.lblsearch);
            this.panelCapex.Controls.Add(this.lstusers);
            this.panelCapex.Controls.Add(this.txtOverHead);
            this.panelCapex.Controls.Add(this.label65);
            this.panelCapex.Controls.Add(this.label42);
            this.panelCapex.Controls.Add(this.txtCapexAmount);
            this.panelCapex.Controls.Add(this.label41);
            this.panelCapex.Controls.Add(this.label33);
            this.panelCapex.Controls.Add(this.txtCapexRequester);
            this.panelCapex.Controls.Add(this.label17);
            this.panelCapex.Controls.Add(this.txtCapexName);
            this.panelCapex.Controls.Add(this.label14);
            this.panelCapex.Controls.Add(this.txtCapexNumber);
            this.panelCapex.Location = new System.Drawing.Point(4, 436);
            this.panelCapex.Name = "panelCapex";
            this.panelCapex.Size = new System.Drawing.Size(1107, 130);
            this.panelCapex.TabIndex = 127;
            this.panelCapex.Visible = false;
            // 
            // checkBoxdept
            // 
            this.checkBoxdept.AutoSize = true;
            this.checkBoxdept.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxdept.ForeColor = System.Drawing.Color.Black;
            this.checkBoxdept.Location = new System.Drawing.Point(795, 84);
            this.checkBoxdept.Name = "checkBoxdept";
            this.checkBoxdept.Size = new System.Drawing.Size(55, 27);
            this.checkBoxdept.TabIndex = 214;
            this.checkBoxdept.Text = "All ";
            this.checkBoxdept.UseVisualStyleBackColor = true;
            this.checkBoxdept.CheckedChanged += new System.EventHandler(this.checkBoxdept_CheckedChanged);
            // 
            // cmbDepartment
            // 
            this.cmbDepartment.DropDownHeight = 80;
            this.cmbDepartment.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDepartment.FormattingEnabled = true;
            this.cmbDepartment.IntegralHeight = false;
            this.cmbDepartment.ItemHeight = 19;
            this.cmbDepartment.Location = new System.Drawing.Point(608, 85);
            this.cmbDepartment.MaxDropDownItems = 4;
            this.cmbDepartment.Name = "cmbDepartment";
            this.cmbDepartment.Size = new System.Drawing.Size(181, 27);
            this.cmbDepartment.TabIndex = 212;
            this.cmbDepartment.SelectedIndexChanged += new System.EventHandler(this.cmbDepartment_SelectedIndexChanged);
            // 
            // lblsearch
            // 
            this.lblsearch.AutoSize = true;
            this.lblsearch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsearch.ForeColor = System.Drawing.Color.Black;
            this.lblsearch.Location = new System.Drawing.Point(457, 85);
            this.lblsearch.Name = "lblsearch";
            this.lblsearch.Size = new System.Drawing.Size(145, 19);
            this.lblsearch.TabIndex = 211;
            this.lblsearch.Text = "Select Department :";
            // 
            // lstusers
            // 
            this.lstusers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstusers.FormattingEnabled = true;
            this.lstusers.ItemHeight = 19;
            this.lstusers.Location = new System.Drawing.Point(957, 7);
            this.lstusers.Name = "lstusers";
            this.lstusers.ScrollAlwaysVisible = true;
            this.lstusers.Size = new System.Drawing.Size(139, 99);
            this.lstusers.TabIndex = 213;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.ForeColor = System.Drawing.Color.Black;
            this.label65.Location = new System.Drawing.Point(804, 15);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(155, 19);
            this.label65.TabIndex = 210;
            this.label65.Text = "Added Departments :";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Black;
            this.label42.Location = new System.Drawing.Point(442, 51);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(166, 19);
            this.label42.TabIndex = 77;
            this.label42.Text = "Capex Amount in USD :";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.Black;
            this.label41.Location = new System.Drawing.Point(446, 13);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(162, 19);
            this.label41.TabIndex = 75;
            this.label41.Text = "Capex Amount in INR :";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Black;
            this.label33.Location = new System.Drawing.Point(6, 88);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(134, 19);
            this.label33.TabIndex = 69;
            this.label33.Text = "Capex Requester*:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(30, 51);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(105, 19);
            this.label17.TabIndex = 67;
            this.label17.Text = "Capex Name*:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(19, 13);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(121, 19);
            this.label14.TabIndex = 65;
            this.label14.Text = "Capex Number*:";
            // 
            // cmbCustomizationlevel
            // 
            this.cmbCustomizationlevel.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCustomizationlevel.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCustomizationlevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCustomizationlevel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomizationlevel.FormattingEnabled = true;
            this.cmbCustomizationlevel.Location = new System.Drawing.Point(1022, 389);
            this.cmbCustomizationlevel.Name = "cmbCustomizationlevel";
            this.cmbCustomizationlevel.Size = new System.Drawing.Size(62, 26);
            this.cmbCustomizationlevel.TabIndex = 120;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(862, 391);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(157, 19);
            this.label13.TabIndex = 119;
            this.label13.Text = "Customization level *:";
            // 
            // cmbProject8020
            // 
            this.cmbProject8020.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbProject8020.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProject8020.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProject8020.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProject8020.FormattingEnabled = true;
            this.cmbProject8020.Items.AddRange(new object[] {
            "80",
            "20"});
            this.cmbProject8020.Location = new System.Drawing.Point(777, 384);
            this.cmbProject8020.Name = "cmbProject8020";
            this.cmbProject8020.Size = new System.Drawing.Size(62, 26);
            this.cmbProject8020.TabIndex = 118;
            this.cmbProject8020.SelectedIndexChanged += new System.EventHandler(this.cmbProject8020_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(654, 389);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(117, 19);
            this.label9.TabIndex = 117;
            this.label9.Text = "Project 80/20* :\t";
            // 
            // cmbEndUserCountry
            // 
            this.cmbEndUserCountry.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbEndUserCountry.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEndUserCountry.DropDownHeight = 120;
            this.cmbEndUserCountry.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEndUserCountry.FormattingEnabled = true;
            this.cmbEndUserCountry.IntegralHeight = false;
            this.cmbEndUserCountry.Location = new System.Drawing.Point(777, 146);
            this.cmbEndUserCountry.Name = "cmbEndUserCountry";
            this.cmbEndUserCountry.Size = new System.Drawing.Size(311, 26);
            this.cmbEndUserCountry.TabIndex = 14;
            // 
            // txtProjectFocal
            // 
            this.txtProjectFocal.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtProjectFocal.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtProjectFocal.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectFocal.FormattingEnabled = true;
            this.txtProjectFocal.Location = new System.Drawing.Point(777, 348);
            this.txtProjectFocal.Name = "txtProjectFocal";
            this.txtProjectFocal.Size = new System.Drawing.Size(314, 26);
            this.txtProjectFocal.TabIndex = 17;
            // 
            // cmbRevisionNumber
            // 
            this.cmbRevisionNumber.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbRevisionNumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRevisionNumber.DropDownHeight = 130;
            this.cmbRevisionNumber.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRevisionNumber.DropDownWidth = 279;
            this.cmbRevisionNumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRevisionNumber.FormattingEnabled = true;
            this.cmbRevisionNumber.IntegralHeight = false;
            this.cmbRevisionNumber.Location = new System.Drawing.Point(166, 163);
            this.cmbRevisionNumber.Name = "cmbRevisionNumber";
            this.cmbRevisionNumber.Size = new System.Drawing.Size(295, 26);
            this.cmbRevisionNumber.TabIndex = 5;
            this.cmbRevisionNumber.SelectedIndexChanged += new System.EventHandler(this.cmbRevisionNumber_SelectedIndexChanged);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.Black;
            this.label55.Location = new System.Drawing.Point(84, 165);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(74, 19);
            this.label55.TabIndex = 116;
            this.label55.Text = "Revision :";
            // 
            // cmbOfferNumber
            // 
            this.cmbOfferNumber.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbOfferNumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbOfferNumber.DropDownHeight = 130;
            this.cmbOfferNumber.DropDownWidth = 279;
            this.cmbOfferNumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOfferNumber.FormattingEnabled = true;
            this.cmbOfferNumber.IntegralHeight = false;
            this.cmbOfferNumber.Location = new System.Drawing.Point(166, 129);
            this.cmbOfferNumber.Name = "cmbOfferNumber";
            this.cmbOfferNumber.Size = new System.Drawing.Size(295, 26);
            this.cmbOfferNumber.TabIndex = 4;
            this.cmbOfferNumber.SelectedIndexChanged += new System.EventHandler(this.cmbOfferNumber_SelectedIndexChanged);
            // 
            // dtpRecievedDate
            // 
            this.dtpRecievedDate.CustomFormat = "";
            this.dtpRecievedDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpRecievedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpRecievedDate.Location = new System.Drawing.Point(375, 94);
            this.dtpRecievedDate.Name = "dtpRecievedDate";
            this.dtpRecievedDate.Size = new System.Drawing.Size(86, 26);
            this.dtpRecievedDate.TabIndex = 3;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.ForeColor = System.Drawing.Color.Black;
            this.label54.Location = new System.Drawing.Point(255, 99);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(114, 19);
            this.label54.TabIndex = 113;
            this.label54.Text = "Received Date :";
            // 
            // dtpPODate
            // 
            this.dtpPODate.CustomFormat = "";
            this.dtpPODate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPODate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPODate.Location = new System.Drawing.Point(166, 92);
            this.dtpPODate.Name = "dtpPODate";
            this.dtpPODate.Size = new System.Drawing.Size(88, 26);
            this.dtpPODate.TabIndex = 2;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.ForeColor = System.Drawing.Color.Black;
            this.label53.Location = new System.Drawing.Point(85, 99);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(73, 19);
            this.label53.TabIndex = 111;
            this.label53.Text = "PO Date :";
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNext.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(1143, 532);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(113, 42);
            this.btnNext.TabIndex = 19;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(605, 268);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(169, 38);
            this.label20.TabIndex = 108;
            this.label20.Text = "Ship-to Name, Address \r\nand Phone :";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(607, 185);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(167, 38);
            this.label19.TabIndex = 106;
            this.label19.Text = "Bill-to Customer Name \r\nand Address :";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(669, 350);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(105, 19);
            this.label18.TabIndex = 104;
            this.label18.Text = "Project Focal :\t";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(638, 148);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(136, 19);
            this.label16.TabIndex = 101;
            this.label16.Text = "End User Country :\t";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(37, 302);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(121, 19);
            this.label15.TabIndex = 99;
            this.label15.Text = "Model Number :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(16, 232);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(142, 19);
            this.label12.TabIndex = 92;
            this.label12.Text = "Standard/Custom*:\t";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(82, 129);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 19);
            this.label11.TabIndex = 90;
            this.label11.Text = "Offer No :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(53, 62);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 19);
            this.label10.TabIndex = 88;
            this.label10.Text = "PO Number* :";
            // 
            // chkBOMProject
            // 
            this.chkBOMProject.AutoSize = true;
            this.chkBOMProject.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBOMProject.ForeColor = System.Drawing.Color.Black;
            this.chkBOMProject.Location = new System.Drawing.Point(1122, 385);
            this.chkBOMProject.Name = "chkBOMProject";
            this.chkBOMProject.Size = new System.Drawing.Size(131, 27);
            this.chkBOMProject.TabIndex = 18;
            this.chkBOMProject.Text = "BOM Project";
            this.chkBOMProject.UseVisualStyleBackColor = true;
            this.chkBOMProject.CheckedChanged += new System.EventHandler(this.chkBOMProject_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(45, 264);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 19);
            this.label5.TabIndex = 67;
            this.label5.Text = "Product Type*:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(44, 375);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 19);
            this.label3.TabIndex = 63;
            this.label3.Text = "Project Name*:";
            // 
            // lblproductsubtype
            // 
            this.lblproductsubtype.AutoSize = true;
            this.lblproductsubtype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblproductsubtype.ForeColor = System.Drawing.Color.Black;
            this.lblproductsubtype.Location = new System.Drawing.Point(21, 337);
            this.lblproductsubtype.Name = "lblproductsubtype";
            this.lblproductsubtype.Size = new System.Drawing.Size(137, 19);
            this.lblproductsubtype.TabIndex = 84;
            this.lblproductsubtype.Text = "System Sub Type*:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(669, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 19);
            this.label2.TabIndex = 61;
            this.label2.Text = "Projet Code*:";
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCustomer.DropDownHeight = 130;
            this.cmbCustomer.DropDownWidth = 279;
            this.cmbCustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomer.FormattingEnabled = true;
            this.cmbCustomer.IntegralHeight = false;
            this.cmbCustomer.Location = new System.Drawing.Point(166, 194);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new System.Drawing.Size(295, 26);
            this.cmbCustomer.TabIndex = 6;
            this.cmbCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbCustomer_SelectedIndexChanged_1);
            // 
            // cmbProjectType
            // 
            this.cmbProjectType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbProjectType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectType.FormattingEnabled = true;
            this.cmbProjectType.Items.AddRange(new object[] {
            "Accessories (OTC)",
            "Annual Maintenance Service (AMC)",
            "Calibration (CAL)",
            "Contract Testing Service (CTS)",
            "Customer (CUS)",
            "Expenses (EXP)",
            "Fixed Asset (CIP)",
            "Parts (PRT)",
            "Product Service (PRS)",
            "PurchaseStock(PST)",
            "R&D (RND)",
            "Repair/Breakdown (RBR)",
            "Stock (STO)",
            "TestingLab (TEL)",
            "Testing for Sales and Marketing (SAL)",
            "INSTRON(INS)",
            "BATCH ORDER FOR PROJECTS (BOP)"});
            this.cmbProjectType.Location = new System.Drawing.Point(165, 6);
            this.cmbProjectType.Name = "cmbProjectType";
            this.cmbProjectType.Size = new System.Drawing.Size(295, 26);
            this.cmbProjectType.TabIndex = 12;
            this.cmbProjectType.SelectedIndexChanged += new System.EventHandler(this.cmbProjectType_SelectedIndexChanged);
            // 
            // lblProjecttype
            // 
            this.lblProjecttype.AutoSize = true;
            this.lblProjecttype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjecttype.ForeColor = System.Drawing.Color.Black;
            this.lblProjecttype.Location = new System.Drawing.Point(53, 7);
            this.lblProjecttype.Name = "lblProjecttype";
            this.lblProjecttype.Size = new System.Drawing.Size(107, 19);
            this.lblProjecttype.TabIndex = 77;
            this.lblProjecttype.Text = "Project Type*:";
            // 
            // lblOrdervalidityinmonths
            // 
            this.lblOrdervalidityinmonths.AutoSize = true;
            this.lblOrdervalidityinmonths.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrdervalidityinmonths.ForeColor = System.Drawing.Color.Black;
            this.lblOrdervalidityinmonths.Location = new System.Drawing.Point(548, 114);
            this.lblOrdervalidityinmonths.Name = "lblOrdervalidityinmonths";
            this.lblOrdervalidityinmonths.Size = new System.Drawing.Size(223, 19);
            this.lblOrdervalidityinmonths.TabIndex = 73;
            this.lblOrdervalidityinmonths.Text = "Warranty Period (In Months) *:";
            this.lblOrdervalidityinmonths.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(72, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 19);
            this.label4.TabIndex = 65;
            this.label4.Text = "Customer*:";
            // 
            // txtcuscode
            // 
            this.txtcuscode.Enabled = false;
            this.txtcuscode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcuscode.Location = new System.Drawing.Point(401, 194);
            this.txtcuscode.Name = "txtcuscode";
            this.txtcuscode.ReadOnly = true;
            this.txtcuscode.Size = new System.Drawing.Size(39, 26);
            this.txtcuscode.TabIndex = 86;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(22, 1);
            this.tabControl1.Location = new System.Drawing.Point(6, 58);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1293, 619);
            this.tabControl1.TabIndex = 12;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Silver;
            this.tabPage4.Controls.Add(this.dgvRevenueRecognition);
            this.tabPage4.Controls.Add(this.btnnextqn);
            this.tabPage4.Controls.Add(this.btnbackqn);
            this.tabPage4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabPage4.Location = new System.Drawing.Point(4, 5);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1285, 610);
            this.tabPage4.TabIndex = 3;
            // 
            // dgvRevenueRecognition
            // 
            this.dgvRevenueRecognition.AllowUserToAddRows = false;
            this.dgvRevenueRecognition.AllowUserToDeleteRows = false;
            this.dgvRevenueRecognition.AllowUserToResizeRows = false;
            this.dgvRevenueRecognition.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvRevenueRecognition.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvRevenueRecognition.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRevenueRecognition.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvRevenueRecognition.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRevenueRecognition.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RevenueRecognition,
            this.MainQuestion1});
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRevenueRecognition.DefaultCellStyle = dataGridViewCellStyle9;
            this.dgvRevenueRecognition.Location = new System.Drawing.Point(6, 6);
            this.dgvRevenueRecognition.MultiSelect = false;
            this.dgvRevenueRecognition.Name = "dgvRevenueRecognition";
            this.dgvRevenueRecognition.ReadOnly = true;
            this.dgvRevenueRecognition.RowHeadersVisible = false;
            this.dgvRevenueRecognition.RowHeadersWidth = 62;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRevenueRecognition.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvRevenueRecognition.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvRevenueRecognition.Size = new System.Drawing.Size(744, 288);
            this.dgvRevenueRecognition.TabIndex = 230;
            this.dgvRevenueRecognition.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRevenueRecognition_CellDoubleClick);
            // 
            // RevenueRecognition
            // 
            this.RevenueRecognition.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.RevenueRecognition.DataPropertyName = "RevenueRecognition";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.RevenueRecognition.DefaultCellStyle = dataGridViewCellStyle7;
            this.RevenueRecognition.HeaderText = "Revenue Assessment";
            this.RevenueRecognition.MinimumWidth = 8;
            this.RevenueRecognition.Name = "RevenueRecognition";
            this.RevenueRecognition.ReadOnly = true;
            this.RevenueRecognition.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // MainQuestion1
            // 
            this.MainQuestion1.DataPropertyName = "MainQuestion1";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            this.MainQuestion1.DefaultCellStyle = dataGridViewCellStyle8;
            this.MainQuestion1.HeaderText = "Yes/No";
            this.MainQuestion1.MinimumWidth = 8;
            this.MainQuestion1.Name = "MainQuestion1";
            this.MainQuestion1.ReadOnly = true;
            this.MainQuestion1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.MainQuestion1.Width = 63;
            // 
            // btnnextqn
            // 
            this.btnnextqn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnextqn.Location = new System.Drawing.Point(1114, 538);
            this.btnnextqn.Name = "btnnextqn";
            this.btnnextqn.Size = new System.Drawing.Size(110, 44);
            this.btnnextqn.TabIndex = 37;
            this.btnnextqn.Text = "Next";
            this.btnnextqn.UseVisualStyleBackColor = true;
            this.btnnextqn.Click += new System.EventHandler(this.btnnextqn_Click);
            // 
            // btnbackqn
            // 
            this.btnbackqn.CausesValidation = false;
            this.btnbackqn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnbackqn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbackqn.Location = new System.Drawing.Point(18, 538);
            this.btnbackqn.Name = "btnbackqn";
            this.btnbackqn.Size = new System.Drawing.Size(113, 42);
            this.btnbackqn.TabIndex = 36;
            this.btnbackqn.Text = "Back";
            this.btnbackqn.UseVisualStyleBackColor = true;
            this.btnbackqn.Click += new System.EventHandler(this.btnbackqn_Click);
            // 
            // frmProjectmaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.pnBIM);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmProjectmaster";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Master";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectmaster_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectmaster_Load);
            this.pnBIM.ResumeLayout(false);
            this.pnBIM.PerformLayout();
            this.pnGMApproval.ResumeLayout(false);
            this.pnGMApproval.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.pnLDClause.ResumeLayout(false);
            this.pnLDClause.PerformLayout();
            this.pnLCClause.ResumeLayout(false);
            this.pnLCClause.PerformLayout();
            this.gbControlButtons.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.pnProjectMaster.ResumeLayout(false);
            this.pnProjectMaster.PerformLayout();
            this.pnCustomerlinkProject.ResumeLayout(false);
            this.pnCustomerlinkProject.PerformLayout();
            this.panelCapex.ResumeLayout(false);
            this.panelCapex.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRevenueRecognition)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dtpPMCreatedDate;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblReturnedby;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Panel pnBIM;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel pnGMApproval;
        private System.Windows.Forms.ComboBox cmbGMApproveList;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.LinkLabel llbUploadDocs;
        private System.Windows.Forms.ComboBox cmbDocType;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox txtTargetValue;
        private System.Windows.Forms.TextBox txtTargetMaterialmargin;
        private System.Windows.Forms.TextBox txtEstimatedManufacturing;
        private System.Windows.Forms.TextBox txtEstimatedDesign;
        private System.Windows.Forms.TextBox txtEstimatedInsatllation;
        private System.Windows.Forms.TextBox txtInstallationValueinUSD;
        private System.Windows.Forms.TextBox txtInstallationValueinINR;
        private System.Windows.Forms.TextBox txtOrderValueinUSD;
        private System.Windows.Forms.TextBox txtOrderValueinINR;
        private System.Windows.Forms.TextBox txtSaleseffort;
        private System.Windows.Forms.TextBox txtQuotationEffort;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.TextBox txtProjectMargin;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.LinkLabel llbProjectDocuments;
        private System.Windows.Forms.ComboBox cmbProjectDocument;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Panel pnLDClause;
        private System.Windows.Forms.DateTimePicker dtpLDToDate;
        private System.Windows.Forms.TextBox txtLDBody;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.DateTimePicker dtpLDFromDate;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Panel pnLCClause;
        private System.Windows.Forms.DateTimePicker dtpLCEndDate;
        private System.Windows.Forms.TextBox txtBody;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.CheckBox chkLCClause;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.CheckBox chkLDClause;
        private System.Windows.Forms.Button btnBack1;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ComboBox cmbLever;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.GroupBox gbControlButtons;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnExcel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DateTimePicker txtCustomerRequirement;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbShippingTerms;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.TextBox txtMoblieNo;
        private System.Windows.Forms.TextBox txtContactPerson;
        private System.Windows.Forms.TextBox txtContactAddress;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.TextBox txtOfficeNo;
        private System.Windows.Forms.TextBox txtContactEmail;
        private System.Windows.Forms.TextBox txtDeliveryPeriod;
        private System.Windows.Forms.TextBox txtStandardDeliveryPeriod;
        private System.Windows.Forms.TextBox txtAgentCommission;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lblremarks;
        private System.Windows.Forms.Label lblContactPerson;
        private System.Windows.Forms.ComboBox cmbContractualAcceptance;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cmbPreDesignPreview;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.ComboBox cmbPerformanceBankGuarantee;
        private System.Windows.Forms.ComboBox cmbBankGuarantee;
        private System.Windows.Forms.ComboBox cmbSecurityDeposit;
        private System.Windows.Forms.ComboBox cmbAgent;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.ComboBox cmbPaymentTerms;
        private System.Windows.Forms.ComboBox cmbShippingMode;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button btnNext1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbPreDispatchInspection;
        private System.Windows.Forms.ComboBox cmbPenaltyClause;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel pnProjectMaster;
        private System.Windows.Forms.ComboBox cmbWarrantyStartsFrom;
        private System.Windows.Forms.Label lblWarrantyStartsfrom;
        private System.Windows.Forms.Panel panelCapex;
        private System.Windows.Forms.ComboBox cmbDepartment;
        private System.Windows.Forms.Label lblsearch;
        private System.Windows.Forms.ListBox lstusers;
        private System.Windows.Forms.TextBox txtOverHead;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtCapexAmount;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtCapexRequester;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtCapexName;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCapexNumber;
        private System.Windows.Forms.ComboBox cmbCustomizationlevel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmbProject8020;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbEndUserCountry;
        private System.Windows.Forms.ComboBox txtProjectFocal;
        private System.Windows.Forms.TextBox txtWarrantyClose;
        private System.Windows.Forms.ComboBox cmbModelNumber;
        private System.Windows.Forms.ComboBox cmbRevisionNumber;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.ComboBox cmbOfferNumber;
        private System.Windows.Forms.DateTimePicker dtpRecievedDate;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.DateTimePicker dtpPODate;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.TextBox txtShiptoCustomer;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtBilltoCustomer;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox CmbStandardCustom;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtPONo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox chkBOMProject;
        private System.Windows.Forms.ComboBox cmbPMProductType;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPMProjectCode;
        private System.Windows.Forms.ComboBox cmbsystemsubtype;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPMProjectDescription;
        private System.Windows.Forms.Label lblproductsubtype;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.ComboBox cmbProjectType;
        private System.Windows.Forms.Label lblProjecttype;
        private System.Windows.Forms.Label lblOrdervalidityinmonths;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtcuscode;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Panel pnCustomerlinkProject;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.ComboBox cmbStockProject;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.DataGridView dgvRevenueRecognition;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnnextqn;
        private System.Windows.Forms.Button btnbackqn;
        private System.Windows.Forms.DataGridViewTextBoxColumn RevenueRecognition;
        private System.Windows.Forms.DataGridViewTextBoxColumn MainQuestion1;
        private System.Windows.Forms.ComboBox comManufactureform;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox checkBoxdept;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox cmbProductionCompany;
        private System.Windows.Forms.ComboBox comboBoxProfitCentre;
        private System.Windows.Forms.Label label72;
    }
}
