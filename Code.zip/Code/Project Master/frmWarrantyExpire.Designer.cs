﻿namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmWarrantyExpire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmWarrantyExpire));
            this.dgProjectList = new System.Windows.Forms.DataGridView();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WarrantyStartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WarrantyCloseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Noofdaysdelayed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.dtpInstallationDate = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.chkExceluploadclose = new System.Windows.Forms.CheckBox();
            this.dgvExcelUpload = new System.Windows.Forms.DataGridView();
            this.ProjectCode1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.ProjectStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgProjectList)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExcelUpload)).BeginInit();
            this.SuspendLayout();
            // 
            // dgProjectList
            // 
            this.dgProjectList.AllowUserToAddRows = false;
            this.dgProjectList.AllowUserToDeleteRows = false;
            this.dgProjectList.AllowUserToResizeRows = false;
            this.dgProjectList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgProjectList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgProjectList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgProjectList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgProjectList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgProjectList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProjectCode,
            this.ProjectDescription,
            this.Customer,
            this.Status,
            this.WarrantyStartDate,
            this.WarrantyCloseDate,
            this.Noofdaysdelayed});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgProjectList.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgProjectList.EnableHeadersVisualStyles = false;
            this.dgProjectList.Location = new System.Drawing.Point(3, 33);
            this.dgProjectList.MultiSelect = false;
            this.dgProjectList.Name = "dgProjectList";
            this.dgProjectList.ReadOnly = true;
            this.dgProjectList.RowHeadersVisible = false;
            this.dgProjectList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgProjectList.Size = new System.Drawing.Size(1185, 454);
            this.dgProjectList.TabIndex = 10;
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.HeaderText = "Project Code";
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 105;
            // 
            // ProjectDescription
            // 
            this.ProjectDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProjectDescription.DataPropertyName = "ProjectDescription";
            this.ProjectDescription.HeaderText = "Name";
            this.ProjectDescription.Name = "ProjectDescription";
            this.ProjectDescription.ReadOnly = true;
            this.ProjectDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectDescription.Width = 112;
            // 
            // Customer
            // 
            this.Customer.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Customer.DataPropertyName = "Customer";
            this.Customer.HeaderText = "Customer";
            this.Customer.Name = "Customer";
            this.Customer.ReadOnly = true;
            this.Customer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Customer.Width = 93;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Status.Width = 66;
            // 
            // WarrantyStartDate
            // 
            this.WarrantyStartDate.DataPropertyName = "WarrantyStartDate";
            this.WarrantyStartDate.HeaderText = "Warranty Start";
            this.WarrantyStartDate.Name = "WarrantyStartDate";
            this.WarrantyStartDate.ReadOnly = true;
            this.WarrantyStartDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WarrantyStartDate.Width = 120;
            // 
            // WarrantyCloseDate
            // 
            this.WarrantyCloseDate.DataPropertyName = "WarrantyCloseDate";
            this.WarrantyCloseDate.HeaderText = "Warranty Close";
            this.WarrantyCloseDate.Name = "WarrantyCloseDate";
            this.WarrantyCloseDate.ReadOnly = true;
            this.WarrantyCloseDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WarrantyCloseDate.Width = 123;
            // 
            // Noofdaysdelayed
            // 
            this.Noofdaysdelayed.DataPropertyName = "No of days delayed";
            this.Noofdaysdelayed.HeaderText = "No of days delayed";
            this.Noofdaysdelayed.Name = "Noofdaysdelayed";
            this.Noofdaysdelayed.ReadOnly = true;
            this.Noofdaysdelayed.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Noofdaysdelayed.Width = 149;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(519, 493);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(669, 63);
            this.groupBox2.TabIndex = 174;
            this.groupBox2.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(400, 18);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 39);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Update";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(541, 18);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 39);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // dtpInstallationDate
            // 
            this.dtpInstallationDate.CustomFormat = "";
            this.dtpInstallationDate.Enabled = false;
            this.dtpInstallationDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpInstallationDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInstallationDate.Location = new System.Drawing.Point(1041, 6);
            this.dtpInstallationDate.Name = "dtpInstallationDate";
            this.dtpInstallationDate.Size = new System.Drawing.Size(125, 26);
            this.dtpInstallationDate.TabIndex = 176;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(986, 11);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 19);
            this.label13.TabIndex = 175;
            this.label13.Text = "Date :";
            // 
            // chkExceluploadclose
            // 
            this.chkExceluploadclose.AutoSize = true;
            this.chkExceluploadclose.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkExceluploadclose.ForeColor = System.Drawing.Color.Blue;
            this.chkExceluploadclose.Location = new System.Drawing.Point(519, 5);
            this.chkExceluploadclose.Name = "chkExceluploadclose";
            this.chkExceluploadclose.Size = new System.Drawing.Size(114, 22);
            this.chkExceluploadclose.TabIndex = 177;
            this.chkExceluploadclose.Text = "Close Projects";
            this.chkExceluploadclose.UseVisualStyleBackColor = true;
            this.chkExceluploadclose.CheckedChanged += new System.EventHandler(this.chkExceluploadclose_CheckedChanged);
            // 
            // dgvExcelUpload
            // 
            this.dgvExcelUpload.AllowUserToAddRows = false;
            this.dgvExcelUpload.AllowUserToDeleteRows = false;
            this.dgvExcelUpload.AllowUserToResizeRows = false;
            this.dgvExcelUpload.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvExcelUpload.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvExcelUpload.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvExcelUpload.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvExcelUpload.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvExcelUpload.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProjectCode1,
            this.ProjectStatus});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvExcelUpload.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvExcelUpload.EnableHeadersVisualStyles = false;
            this.dgvExcelUpload.Location = new System.Drawing.Point(3, 38);
            this.dgvExcelUpload.MultiSelect = false;
            this.dgvExcelUpload.Name = "dgvExcelUpload";
            this.dgvExcelUpload.ReadOnly = false;
            this.dgvExcelUpload.RowHeadersVisible = false;
            this.dgvExcelUpload.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvExcelUpload.Size = new System.Drawing.Size(1185, 431);
            this.dgvExcelUpload.TabIndex = 178;
            this.dgvExcelUpload.Visible = false;
            // 
            // ProjectCode1
            // 
            this.ProjectCode1.DataPropertyName = "ProjectCode";
            this.ProjectCode1.HeaderText = "Project Code";
            this.ProjectCode1.Name = "ProjectCode1";
            this.ProjectCode1.ReadOnly = true;
            this.ProjectCode1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode1.Width = 117;

            // 
            // ProjectStatus
            // 
            this.ProjectStatus.DataPropertyName = "ProjectStatus";
            this.ProjectStatus.HeaderText = "ProjectStatus";
            this.ProjectStatus.Name = "ProjectStatus";
            //this.ProjectStatus.ReadOnly = false;
            this.ProjectStatus.Width = 85;
            this.ProjectStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBrowse.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBrowse.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.Location = new System.Drawing.Point(639, 5);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(114, 24);
            this.btnBrowse.TabIndex = 232;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = false;
            this.btnBrowse.Visible = false;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
           
            // 
            // frmWarrantyExpire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1194, 559);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.dgvExcelUpload);
            this.Controls.Add(this.chkExceluploadclose);
            this.Controls.Add(this.dtpInstallationDate);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dgProjectList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmWarrantyExpire";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Warranty Expire";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmWarrantyExpire_FormClosing);
            this.Load += new System.EventHandler(this.frmWarrantyExpire_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgProjectList)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvExcelUpload)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgProjectList;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.DateTimePicker dtpInstallationDate;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn WarrantyStartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn WarrantyCloseDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Noofdaysdelayed;
        private System.Windows.Forms.CheckBox chkExceluploadclose;
        private System.Windows.Forms.DataGridView dgvExcelUpload;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectStatus;
    }
}