﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmProjectApprove : Form
    {
        public frmProjectApprove()
        {
            InitializeComponent();
        }
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        frmForm2 frm = new frmForm2();
        //  frmProjectmaster form = new frmProjectmaster();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtProjectList = new DataTable();
        DataTable dtDepartment = new DataTable();
        public int ProjectApprove = 0;
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }
        DataTable DepartmentList = new DataTable();
        private void cmbProjectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProjectcode.SelectedIndex >= 0)
            {
                lstusers.Items.Clear();
                DataView dvProjectBOMList = new DataView(dtProjectList);
                dvProjectBOMList.RowFilter = "ProjectCode='" + cmbProjectcode.Text + "'";
                if (dvProjectBOMList.ToTable().Rows.Count > 0)
                {
                    txtProjectDescription.Text = dvProjectBOMList.ToTable().Rows[0]["ProjectDescription"].ToString();
                    txtCustomerName.Text = dvProjectBOMList.ToTable().Rows[0]["Customer"].ToString();
                }
                else
                {
                    txtProjectDescription.ResetText();
                    txtCustomerName.ResetText();
                }

                DepartmentList = DAL.fnDepartmentList(2, cmbProjectcode.Text, null).Tables[0];
                
                foreach (DataRow DR in DepartmentList.Rows)
                {
                    if (!lstusers.Items.Contains(DR[0].ToString()))
                    {
                        lstusers.Items.Add(DR[0].ToString());
                    }
                }
                btnSave.Enabled = true;
            }
            else
            {
                txtProjectDescription.ResetText();
                txtCustomerName.ResetText();
            }
        }

        private void btnProjectSearch_Click(object sender, EventArgs e)
        {
            ProjectApprove = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnProjectApprove = ProjectApprove.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectcode.SelectedItem = sProjectCode;
            }
        }

        private void frmProjectApprove_Load(object sender, EventArgs e)
        {
            dtProjectList = DAL.fnCapexProjectList(null).Tables[0];
            dtDepartment = DAL.fnDepartmentList(0, null, null).Tables[0];
            foreach (DataRow DR in dtProjectList.Rows)
            {
                if (!cmbProjectcode.Items.Contains(DR["ProjectCode"].ToString()))
                    cmbProjectcode.Items.Add(DR["ProjectCode"].ToString());
            }

            foreach (DataRow DR in dtDepartment.Rows)
            {
                if (!cmbDepartment.Items.Contains(DR[0].ToString()))
                    cmbDepartment.Items.Add(DR[0].ToString());
            }
        }

        private void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!lstusers.Items.Contains(cmbDepartment.Text))
            {
                lstusers.Items.Add(cmbDepartment.Text);
            }
        }

        private void lstusers_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                GlobalClass.iSuccess = DAL.fnAddProjectDepartment(2, cmbProjectcode.Text, lstusers.SelectedItem.ToString(), login.GetUserDetails[2], dtpIndentDate.Text);
                lstusers.Items.Remove(lstusers.SelectedItem);
                MessageBox.Show("Assigned department deleted to the project", "Success", 0, MessageBoxIcon.Warning);
            }
        }

        private void frmProjectApprove_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnClose();
        }

        private void fnClose()
        {
            this.Hide();
            frm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnClose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (lstusers.Items.Count > 0 && cmbProjectcode.SelectedIndex >= 0)
            {
                foreach (var listBoxItem in lstusers.Items)
                {
                    GlobalClass.iSuccess = DAL.fnAddProjectDepartment(2, cmbProjectcode.Text, listBoxItem.ToString(), login.GetUserDetails[2], dtpIndentDate.Text);
                    GlobalClass.iSuccess = DAL.fnAddProjectDepartment(1, cmbProjectcode.Text, listBoxItem.ToString(), login.GetUserDetails[2], dtpIndentDate.Text);
                }

                MessageBox.Show("Departments assigned to the project", "Success", 0, MessageBoxIcon.Information);
                btnSave.Enabled = false;
            }
            else
            {
                if (lstusers.Items.Count == 0)
                {
                    MessageBox.Show("Select the departments to assign the project", "Error", 0, MessageBoxIcon.Error);
                    cmbDepartment.DroppedDown = true;
                }
                else if (cmbProjectcode.SelectedIndex < 0)
                {
                    MessageBox.Show("Select the project", "Error", 0, MessageBoxIcon.Error);
                    cmbProjectcode.DroppedDown = true;
                }
            }
        }
    }
}
