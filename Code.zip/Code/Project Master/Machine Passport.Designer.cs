﻿
namespace Erp_Project_With_Buttons.Project_Master
{
    partial class Machine_Passport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Machine_Passport));
            this.label66 = new System.Windows.Forms.Label();
            this.cmbProductCategory = new System.Windows.Forms.ComboBox();
            this.textCustName = new System.Windows.Forms.TextBox();
            this.txtMpMachineModelNumber = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textPoNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgupdate = new System.Windows.Forms.DataGridView();
            this.dgItemOrProductList = new System.Windows.Forms.DataGridView();
            this.txtLFRemarks = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.buttAdd = new System.Windows.Forms.Button();
            this.textMaterialModelNO = new System.Windows.Forms.TextBox();
            this.labMaterialModelNo = new System.Windows.Forms.Label();
            this.AllTypes = new System.Windows.Forms.Label();
            this.AllType = new System.Windows.Forms.ComboBox();
            this.textMpMachineSerialNo = new System.Windows.Forms.TextBox();
            this.MachineSerialNo = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.butAccept = new System.Windows.Forms.Button();
            this.btnprintgin = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.MPSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbProjectcode = new System.Windows.Forms.ComboBox();
            this.btnProjectSearch = new System.Windows.Forms.Button();
            this.textPODate = new System.Windows.Forms.TextBox();
            this.labPODate = new System.Windows.Forms.Label();
            this.labprintprojectcode = new System.Windows.Forms.Label();
            this.comselectedprojectcode = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkUpdatePO = new System.Windows.Forms.CheckBox();
            this.ApproveList = new System.Windows.Forms.Label();
            this.comApproveList = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comspecification = new System.Windows.Forms.TextBox();
            this.txtMpProjectDedscription = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgupdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.Color.Black;
            this.label66.Location = new System.Drawing.Point(50, 88);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(121, 18);
            this.label66.TabIndex = 463;
            this.label66.Text = "Product Category :";
            this.label66.Click += new System.EventHandler(this.label66_Click);
            // 
            // cmbProductCategory
            // 
            this.cmbProductCategory.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbProductCategory.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProductCategory.DropDownHeight = 180;
            this.cmbProductCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProductCategory.DropDownWidth = 150;
            this.cmbProductCategory.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProductCategory.FormattingEnabled = true;
            this.cmbProductCategory.IntegralHeight = false;
            this.cmbProductCategory.Location = new System.Drawing.Point(176, 83);
            this.cmbProductCategory.Name = "cmbProductCategory";
            this.cmbProductCategory.Size = new System.Drawing.Size(214, 26);
            this.cmbProductCategory.TabIndex = 464;
            this.cmbProductCategory.SelectedIndexChanged += new System.EventHandler(this.cmbProductCategory_SelectedIndexChanged);
            // 
            // textCustName
            // 
            this.textCustName.BackColor = System.Drawing.SystemColors.Control;
            this.textCustName.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textCustName.Location = new System.Drawing.Point(945, 88);
            this.textCustName.MaxLength = 80;
            this.textCustName.Name = "textCustName";
            this.textCustName.ReadOnly = true;
            this.textCustName.Size = new System.Drawing.Size(214, 26);
            this.textCustName.TabIndex = 460;
            // 
            // txtMpMachineModelNumber
            // 
            this.txtMpMachineModelNumber.BackColor = System.Drawing.SystemColors.Control;
            this.txtMpMachineModelNumber.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtMpMachineModelNumber.Location = new System.Drawing.Point(586, 83);
            this.txtMpMachineModelNumber.MaxLength = 80;
            this.txtMpMachineModelNumber.Name = "txtMpMachineModelNumber";
            this.txtMpMachineModelNumber.ReadOnly = true;
            this.txtMpMachineModelNumber.Size = new System.Drawing.Size(214, 26);
            this.txtMpMachineModelNumber.TabIndex = 456;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(449, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 18);
            this.label3.TabIndex = 457;
            this.label3.Text = "Machine Model No:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(821, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 18);
            this.label4.TabIndex = 455;
            this.label4.Text = "Customer Name :";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Checked = false;
            this.dateTimePicker1.Enabled = false;
            this.dateTimePicker1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(1165, 77);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(83, 26);
            this.dateTimePicker1.TabIndex = 450;
            // 
            // textPoNo
            // 
            this.textPoNo.BackColor = System.Drawing.SystemColors.Control;
            this.textPoNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPoNo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textPoNo.Location = new System.Drawing.Point(945, 129);
            this.textPoNo.Name = "textPoNo";
            this.textPoNo.ReadOnly = true;
            this.textPoNo.Size = new System.Drawing.Size(214, 26);
            this.textPoNo.TabIndex = 459;
            this.textPoNo.TextChanged += new System.EventHandler(this.textPoNo_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label1.Location = new System.Drawing.Point(885, 129);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 18);
            this.label1.TabIndex = 458;
            this.label1.Text = "PO No:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.BackColor = System.Drawing.SystemColors.Window;
            this.groupBox3.Controls.Add(this.dgupdate);
            this.groupBox3.Controls.Add(this.dgItemOrProductList);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.Window;
            this.groupBox3.Location = new System.Drawing.Point(23, 336);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1244, 379);
            this.groupBox3.TabIndex = 468;
            this.groupBox3.TabStop = false;
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // dgupdate
            // 
            this.dgupdate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgupdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgupdate.Location = new System.Drawing.Point(3, 16);
            this.dgupdate.Name = "dgupdate";
            this.dgupdate.Size = new System.Drawing.Size(1238, 360);
            this.dgupdate.TabIndex = 500;
            this.dgupdate.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgupdate_CellContentClick);
            // 
            // dgItemOrProductList
            // 
            this.dgItemOrProductList.AllowUserToAddRows = false;
            this.dgItemOrProductList.AllowUserToResizeRows = false;
            this.dgItemOrProductList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgItemOrProductList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgItemOrProductList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgItemOrProductList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgItemOrProductList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgItemOrProductList.EnableHeadersVisualStyles = false;
            this.dgItemOrProductList.Location = new System.Drawing.Point(3, 16);
            this.dgItemOrProductList.MultiSelect = false;
            this.dgItemOrProductList.Name = "dgItemOrProductList";
            this.dgItemOrProductList.RowHeadersVisible = false;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgItemOrProductList.Size = new System.Drawing.Size(1238, 360);
            this.dgItemOrProductList.TabIndex = 448;
            this.dgItemOrProductList.Visible = false;
            this.dgItemOrProductList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemOrProductList_CellContentClick);
            // 
            // txtLFRemarks
            // 
            this.txtLFRemarks.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtLFRemarks.Location = new System.Drawing.Point(97, 718);
            this.txtLFRemarks.MaxLength = 1000;
            this.txtLFRemarks.Multiline = true;
            this.txtLFRemarks.Name = "txtLFRemarks";
            this.txtLFRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLFRemarks.Size = new System.Drawing.Size(625, 44);
            this.txtLFRemarks.TabIndex = 447;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(23, 732);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 18);
            this.label9.TabIndex = 446;
            this.label9.Text = "Remarks :\t";
            // 
            // buttAdd
            // 
            this.buttAdd.BackColor = System.Drawing.SystemColors.ControlLight;
            this.buttAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAdd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttAdd.Location = new System.Drawing.Point(1181, 277);
            this.buttAdd.Name = "buttAdd";
            this.buttAdd.Size = new System.Drawing.Size(86, 43);
            this.buttAdd.TabIndex = 499;
            this.buttAdd.Text = "Add Items";
            this.buttAdd.UseVisualStyleBackColor = false;
            this.buttAdd.Click += new System.EventHandler(this.buttAdd_Click);
            // 
            // textMaterialModelNO
            // 
            this.textMaterialModelNO.BackColor = System.Drawing.SystemColors.Control;
            this.textMaterialModelNO.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textMaterialModelNO.Location = new System.Drawing.Point(176, 147);
            this.textMaterialModelNO.MaxLength = 80;
            this.textMaterialModelNO.Name = "textMaterialModelNO";
            this.textMaterialModelNO.ReadOnly = true;
            this.textMaterialModelNO.Size = new System.Drawing.Size(214, 26);
            this.textMaterialModelNO.TabIndex = 497;
            this.textMaterialModelNO.TextChanged += new System.EventHandler(this.textMaterialModelNO_TextChanged);
            // 
            // labMaterialModelNo
            // 
            this.labMaterialModelNo.AutoSize = true;
            this.labMaterialModelNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labMaterialModelNo.ForeColor = System.Drawing.Color.Black;
            this.labMaterialModelNo.Location = new System.Drawing.Point(76, 150);
            this.labMaterialModelNo.Name = "labMaterialModelNo";
            this.labMaterialModelNo.Size = new System.Drawing.Size(95, 18);
            this.labMaterialModelNo.TabIndex = 498;
            this.labMaterialModelNo.Text = "Product Code:";
            // 
            // AllTypes
            // 
            this.AllTypes.AutoSize = true;
            this.AllTypes.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllTypes.ForeColor = System.Drawing.Color.Black;
            this.AllTypes.Location = new System.Drawing.Point(122, 115);
            this.AllTypes.Name = "AllTypes";
            this.AllTypes.Size = new System.Drawing.Size(48, 18);
            this.AllTypes.TabIndex = 457;
            this.AllTypes.Text = "Types:";
            // 
            // AllType
            // 
            this.AllType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.AllType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.AllType.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.AllType.DropDownHeight = 180;
            this.AllType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AllType.DropDownWidth = 150;
            this.AllType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllType.FormattingEnabled = true;
            this.AllType.IntegralHeight = false;
            this.AllType.Location = new System.Drawing.Point(177, 115);
            this.AllType.Name = "AllType";
            this.AllType.Size = new System.Drawing.Size(214, 26);
            this.AllType.TabIndex = 458;
            this.AllType.SelectedIndexChanged += new System.EventHandler(this.AllType_SelectedIndexChanged);
            // 
            // textMpMachineSerialNo
            // 
            this.textMpMachineSerialNo.BackColor = System.Drawing.SystemColors.Control;
            this.textMpMachineSerialNo.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textMpMachineSerialNo.Location = new System.Drawing.Point(587, 115);
            this.textMpMachineSerialNo.MaxLength = 80;
            this.textMpMachineSerialNo.Name = "textMpMachineSerialNo";
            this.textMpMachineSerialNo.ReadOnly = true;
            this.textMpMachineSerialNo.Size = new System.Drawing.Size(214, 26);
            this.textMpMachineSerialNo.TabIndex = 356;
            // 
            // MachineSerialNo
            // 
            this.MachineSerialNo.AutoSize = true;
            this.MachineSerialNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MachineSerialNo.ForeColor = System.Drawing.Color.Black;
            this.MachineSerialNo.Location = new System.Drawing.Point(455, 115);
            this.MachineSerialNo.Name = "MachineSerialNo";
            this.MachineSerialNo.Size = new System.Drawing.Size(125, 18);
            this.MachineSerialNo.TabIndex = 357;
            this.MachineSerialNo.Text = "Machine Serial No:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.butAccept);
            this.groupBox2.Controls.Add(this.btnprintgin);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.MPSave);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(195, 768);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(802, 46);
            this.groupBox2.TabIndex = 469;
            this.groupBox2.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(410, 8);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(116, 33);
            this.button2.TabIndex = 488;
            this.button2.Text = "View Status";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // butAccept
            // 
            this.butAccept.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.butAccept.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.butAccept.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butAccept.Location = new System.Drawing.Point(544, 9);
            this.butAccept.Name = "butAccept";
            this.butAccept.Size = new System.Drawing.Size(116, 33);
            this.butAccept.TabIndex = 487;
            this.butAccept.Text = "Approve ";
            this.butAccept.UseVisualStyleBackColor = false;
            this.butAccept.Click += new System.EventHandler(this.butAccept_Click);
            // 
            // btnprintgin
            // 
            this.btnprintgin.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnprintgin.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnprintgin.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprintgin.Location = new System.Drawing.Point(276, 8);
            this.btnprintgin.Name = "btnprintgin";
            this.btnprintgin.Size = new System.Drawing.Size(116, 33);
            this.btnprintgin.TabIndex = 486;
            this.btnprintgin.Text = "Print";
            this.btnprintgin.UseVisualStyleBackColor = false;
            this.btnprintgin.Click += new System.EventHandler(this.btnprintgin_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button1.Enabled = false;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(143, 8);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(116, 33);
            this.button1.TabIndex = 340;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MPSave
            // 
            this.MPSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.MPSave.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.MPSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.MPSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.MPSave.Location = new System.Drawing.Point(6, 8);
            this.MPSave.Name = "MPSave";
            this.MPSave.Size = new System.Drawing.Size(116, 33);
            this.MPSave.TabIndex = 339;
            this.MPSave.Text = "Save";
            this.MPSave.UseVisualStyleBackColor = false;
            this.MPSave.Click += new System.EventHandler(this.MPSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnExit.Location = new System.Drawing.Point(678, 9);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(116, 33);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(38, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 19);
            this.label2.TabIndex = 341;
            this.label2.Text = "Project Code:";
            // 
            // cmbProjectcode
            // 
            this.cmbProjectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectcode.DropDownHeight = 130;
            this.cmbProjectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectcode.FormattingEnabled = true;
            this.cmbProjectcode.IntegralHeight = false;
            this.cmbProjectcode.Location = new System.Drawing.Point(144, 14);
            this.cmbProjectcode.Name = "cmbProjectcode";
            this.cmbProjectcode.Size = new System.Drawing.Size(214, 26);
            this.cmbProjectcode.TabIndex = 342;
            this.cmbProjectcode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectcode_SelectedIndexChanged_1);
            // 
            // btnProjectSearch
            // 
            this.btnProjectSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectSearch.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectSearch.Location = new System.Drawing.Point(364, 14);
            this.btnProjectSearch.Name = "btnProjectSearch";
            this.btnProjectSearch.Size = new System.Drawing.Size(39, 24);
            this.btnProjectSearch.TabIndex = 343;
            this.btnProjectSearch.Text = "....";
            this.btnProjectSearch.UseVisualStyleBackColor = false;
            this.btnProjectSearch.Click += new System.EventHandler(this.btnProjectSearch_Click);
            // 
            // textPODate
            // 
            this.textPODate.BackColor = System.Drawing.SystemColors.Control;
            this.textPODate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPODate.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textPODate.Location = new System.Drawing.Point(587, 147);
            this.textPODate.Name = "textPODate";
            this.textPODate.ReadOnly = true;
            this.textPODate.Size = new System.Drawing.Size(214, 26);
            this.textPODate.TabIndex = 484;
            // 
            // labPODate
            // 
            this.labPODate.AutoSize = true;
            this.labPODate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labPODate.ForeColor = System.Drawing.SystemColors.WindowText;
            this.labPODate.Location = new System.Drawing.Point(518, 147);
            this.labPODate.Name = "labPODate";
            this.labPODate.Size = new System.Drawing.Size(62, 18);
            this.labPODate.TabIndex = 483;
            this.labPODate.Text = "PO Date:";
            // 
            // labprintprojectcode
            // 
            this.labprintprojectcode.AutoSize = true;
            this.labprintprojectcode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labprintprojectcode.ForeColor = System.Drawing.Color.Black;
            this.labprintprojectcode.Location = new System.Drawing.Point(738, 16);
            this.labprintprojectcode.Name = "labprintprojectcode";
            this.labprintprojectcode.Size = new System.Drawing.Size(138, 19);
            this.labprintprojectcode.TabIndex = 486;
            this.labprintprojectcode.Text = "Print Project Code:";
            this.labprintprojectcode.Visible = false;
            // 
            // comselectedprojectcode
            // 
            this.comselectedprojectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comselectedprojectcode.DropDownHeight = 130;
            this.comselectedprojectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comselectedprojectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comselectedprojectcode.FormattingEnabled = true;
            this.comselectedprojectcode.IntegralHeight = false;
            this.comselectedprojectcode.Location = new System.Drawing.Point(873, 14);
            this.comselectedprojectcode.Name = "comselectedprojectcode";
            this.comselectedprojectcode.Size = new System.Drawing.Size(254, 26);
            this.comselectedprojectcode.TabIndex = 487;
            this.comselectedprojectcode.Visible = false;
            this.comselectedprojectcode.SelectedIndexChanged += new System.EventHandler(this.comselectedprojectcode_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.groupBox1.Controls.Add(this.comselectedprojectcode);
            this.groupBox1.Controls.Add(this.chkUpdatePO);
            this.groupBox1.Controls.Add(this.ApproveList);
            this.groupBox1.Controls.Add(this.comApproveList);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.labprintprojectcode);
            this.groupBox1.Controls.Add(this.cmbProjectcode);
            this.groupBox1.Controls.Add(this.btnProjectSearch);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Location = new System.Drawing.Point(32, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1235, 51);
            this.groupBox1.TabIndex = 488;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // chkUpdatePO
            // 
            this.chkUpdatePO.AutoSize = true;
            this.chkUpdatePO.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkUpdatePO.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.chkUpdatePO.Location = new System.Drawing.Point(1133, 16);
            this.chkUpdatePO.Name = "chkUpdatePO";
            this.chkUpdatePO.Size = new System.Drawing.Size(97, 22);
            this.chkUpdatePO.TabIndex = 490;
            this.chkUpdatePO.Text = "Update MP";
            this.chkUpdatePO.UseVisualStyleBackColor = true;
            this.chkUpdatePO.CheckedChanged += new System.EventHandler(this.chkUpdatePO_CheckedChanged);
            // 
            // ApproveList
            // 
            this.ApproveList.AutoSize = true;
            this.ApproveList.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ApproveList.ForeColor = System.Drawing.Color.Black;
            this.ApproveList.Location = new System.Drawing.Point(425, 16);
            this.ApproveList.Name = "ApproveList";
            this.ApproveList.Size = new System.Drawing.Size(123, 19);
            this.ApproveList.TabIndex = 488;
            this.ApproveList.Text = "Approval PCode:";
            this.ApproveList.Visible = false;
            // 
            // comApproveList
            // 
            this.comApproveList.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comApproveList.DropDownHeight = 130;
            this.comApproveList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comApproveList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comApproveList.FormattingEnabled = true;
            this.comApproveList.IntegralHeight = false;
            this.comApproveList.Location = new System.Drawing.Point(554, 14);
            this.comApproveList.Name = "comApproveList";
            this.comApproveList.Size = new System.Drawing.Size(178, 26);
            this.comApproveList.TabIndex = 489;
            this.comApproveList.Visible = false;
            this.comApproveList.SelectedIndexChanged += new System.EventHandler(this.comApproveList_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(69, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 18);
            this.label5.TabIndex = 500;
            this.label5.Text = "Specification:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // comspecification
            // 
            this.comspecification.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.comspecification.Location = new System.Drawing.Point(172, 191);
            this.comspecification.MaxLength = 1000;
            this.comspecification.Multiline = true;
            this.comspecification.Name = "comspecification";
            this.comspecification.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.comspecification.Size = new System.Drawing.Size(487, 129);
            this.comspecification.TabIndex = 551;
            // 
            // txtMpProjectDedscription
            // 
            this.txtMpProjectDedscription.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtMpProjectDedscription.Location = new System.Drawing.Point(833, 194);
            this.txtMpProjectDedscription.MaxLength = 1000;
            this.txtMpProjectDedscription.Multiline = true;
            this.txtMpProjectDedscription.Name = "txtMpProjectDedscription";
            this.txtMpProjectDedscription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMpProjectDedscription.Size = new System.Drawing.Size(326, 126);
            this.txtMpProjectDedscription.TabIndex = 552;
            this.txtMpProjectDedscription.TextChanged += new System.EventHandler(this.txtMpProjectDedscription_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(697, 191);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(130, 18);
            this.label6.TabIndex = 553;
            this.label6.Text = "Project Description:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // Machine_Passport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1299, 818);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtLFRemarks);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.buttAdd);
            this.Controls.Add(this.txtMpProjectDedscription);
            this.Controls.Add(this.comspecification);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textMaterialModelNO);
            this.Controls.Add(this.labMaterialModelNo);
            this.Controls.Add(this.textPODate);
            this.Controls.Add(this.labPODate);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.cmbProductCategory);
            this.Controls.Add(this.textCustName);
            this.Controls.Add(this.txtMpMachineModelNumber);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textPoNo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textMpMachineSerialNo);
            this.Controls.Add(this.MachineSerialNo);
            this.Controls.Add(this.AllTypes);
            this.Controls.Add(this.AllType);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Machine_Passport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Machine_Passport";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectmaster_FormClosing);
            this.Load += new System.EventHandler(this.Machine_Passport_Load);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgupdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.ComboBox cmbProductCategory;
        private System.Windows.Forms.TextBox textCustName;
        private System.Windows.Forms.TextBox txtMpMachineModelNumber;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textPoNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label AllTypes;
        private System.Windows.Forms.ComboBox AllType;
        private System.Windows.Forms.TextBox textMpMachineSerialNo;
        private System.Windows.Forms.TextBox txtLFRemarks;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label MachineSerialNo;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button MPSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbProjectcode;
        private System.Windows.Forms.Button btnProjectSearch;
        private System.Windows.Forms.TextBox textMaterialModelNO;
        private System.Windows.Forms.Label labMaterialModelNo;
        private System.Windows.Forms.TextBox textPODate;
        private System.Windows.Forms.Label labPODate;
        private System.Windows.Forms.Button btnprintgin;
        private System.Windows.Forms.Label labprintprojectcode;
        private System.Windows.Forms.ComboBox comselectedprojectcode;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label ApproveList;
        private System.Windows.Forms.ComboBox comApproveList;
        private System.Windows.Forms.Button butAccept;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dgItemOrProductList;
        private System.Windows.Forms.Button buttAdd;
        private System.Windows.Forms.CheckBox chkUpdatePO;
        private System.Windows.Forms.DataGridView dgupdate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox comspecification;
        private System.Windows.Forms.TextBox txtMpProjectDedscription;
        private System.Windows.Forms.Label label6;
    }
}