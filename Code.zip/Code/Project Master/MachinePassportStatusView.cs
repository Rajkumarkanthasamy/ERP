﻿
using System;
using System.Data;
using System.Windows.Forms;
using System.Drawing;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class MachinePassportStatusView : Form
    {
        private DataTable dtProjectList = new DataTable();
        private DataTable dtOrderentry = new DataTable();
        private DataAccessLayer DAL = new DataAccessLayer();
        public int sProjectStatusInstallform = 0;
        private string _projectCode;
        Machine_Passport frm = new Machine_Passport();


        public MachinePassportStatusView(string projectCode)
        {
            InitializeComponent();
            _projectCode = projectCode;
        }
       
        private void MachinePassportStatusView_Load(object sender, EventArgs e)
        {
          
        }

        

        private void btnLoadProjects_Click(object sender, EventArgs e)
        {
            LoadProjectData();
        }

        private void LoadProjectData()
        {
            DataTable dataTable;

            if (btnLoadProjects.Text == "Load Projects Details")
            {
                dataTable = DAL.fnProjectBom(_projectCode, 4).Tables[0];
            }
            else
            {
                dataTable = DAL.mpApprovelProjectList(1, null).Tables[0];
            }

            dgMachineClosingList.DataSource = dataTable;
            dgMachineClosingList.DataBindingComplete += dgMachineClosingList_DataBindingComplete;
        }

        private void dgMachineClosingList_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewRow row in dgMachineClosingList.Rows)
            {
                ApplyRowColoring(row);
            }
        }

        private void ApplyRowColoring(DataGridViewRow row)
        {
            string status = row.Cells["Status"].Value?.ToString();

            // Apply color based on status
            if (string.IsNullOrEmpty(status))
            {
                row.DefaultCellStyle.BackColor = Color.Yellow;
            }
            else if (status == "WIP")
            {
                row.DefaultCellStyle.BackColor = Color.White;
            }
            else if (status == "MHApproval")
            {
                row.DefaultCellStyle.BackColor = Color.Green;
            }
            else if (status == "Reject")
            {
                row.DefaultCellStyle.BackColor = Color.Red;
            }

            // Check and apply color based on Quantity column
            if (dgMachineClosingList.Columns.Contains("Quantity"))
            {
                if (row.Cells["Quantity"].Value != null && int.TryParse(row.Cells["Quantity"].Value.ToString(), out int quantity))
                {
                    if (quantity == 0)
                    {
                        row.DefaultCellStyle.BackColor = Color.BurlyWood;
                    }
                }
            }

            // Check and apply color based on ProductCode column
            if (dgMachineClosingList.Columns.Contains("ProductCode"))
            {
                var cellValue = row.Cells["ProductCode"].Value;

                // Check if ProductCode cell is empty or null
                if (cellValue == null || string.IsNullOrWhiteSpace(cellValue.ToString()))
                {
                    row.DefaultCellStyle.BackColor = Color.BurlyWood;
                }
                else
                {
                    // Check if ProductCode is zero
                    if (int.TryParse(cellValue.ToString(), out int productCode) && productCode == 0)
                    {
                        row.DefaultCellStyle.BackColor = Color.BurlyWood;
                    }
                }
            }
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void dgMachineClosingList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

