﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmProjectTransferRequest : Form
    {
        public frmProjectTransferRequest()
        {
            InitializeComponent();
        }
        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        frmForm2 frm = new frmForm2();
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        DataTable dtProjectTransferCheck = new DataTable();

        private void btnSave_Click(object sender, EventArgs e)
        {

            if (cmbProjectCode.SelectedIndex >= 0 && cmbMainProjectcode.SelectedIndex >= 0)
            {
                dtProjectTransferCheck = DAL.fnTransferProjectNo(1, cmbProjectCode.Text).Tables[0];

                if (dtProjectTransferCheck.Rows.Count == 0)
                {

                    GlobalClass.iSuccess = DAL.fnAddProject(5, cmbMainProjectcode.Text, cmbProjectCode.Text,"","", "",
                                          "", "", "", "", "", "", Loginfrm.GetUserDetails[2], "", "", true, "", "", "", "", "", "");
                    MessageBox.Show("Project code transfer requested", "Success", 0, MessageBoxIcon.Information);
                    btnSave.Enabled = false;
                }
                else
                { 
                    MessageBox.Show("Selected project has Project BOM, Project transfer not accepeted \n\n Delete the project BOM to transfer the project", "Error", 0, MessageBoxIcon.Error);
                }
            }
            else
            {
                if (cmbMainProjectcode.SelectedIndex < 0)
                {
                    MessageBox.Show("Select project code", "Error", 0, MessageBoxIcon.Error);
                    cmbMainProjectcode.DroppedDown = true;
                }
                else if (cmbProjectCode.SelectedIndex < 0)
                {
                    MessageBox.Show("Select project code", "Error", 0, MessageBoxIcon.Error);
                    cmbProjectCode.DroppedDown = true;
                }
            }
        }
        DataTable dtTransferProject = new DataTable();
        DataTable dtMainProjects = new DataTable();
        private void frmProjectTransferRequest_Load(object sender, EventArgs e)
        {
            dtTransferProject = DAL.fnCustomerWIPProjectList(null).Tables[0];

            dtMainProjects = DAL.fnWIPProjectList(null).Tables[0];
            foreach (DataRow DR in dtTransferProject.Rows)
            {
                if (!cmbProjectCode.Items.Contains(DR["ProjectCode"].ToString()))
                    cmbProjectCode.Items.Add(DR["ProjectCode"].ToString());
            }

            foreach (DataRow DR in dtMainProjects.Rows)
            {
                if (!cmbMainProjectcode.Items.Contains(DR["ProjectCode"].ToString()))
                    cmbMainProjectcode.Items.Add(DR["ProjectCode"].ToString());
            }
        }

        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProjectCode.SelectedIndex >= 0)
            {
                DataView dvProjectBOMList = new DataView(dtTransferProject);
                dvProjectBOMList.RowFilter = "ProjectCode='" + cmbProjectCode.Text + "'";
                if (dvProjectBOMList.ToTable().Rows.Count > 0)
                {
                    txtProjectName.Text = dvProjectBOMList.ToTable().Rows[0]["ProjectDescription"].ToString();
                }
                else
                {
                    txtProjectName.ResetText();
                }
            }
            else
            {
                txtProjectName.ResetText();
            }
        }
        public int sProjectTransfrerRequest = 0;
        private void btnProjectView_Click(object sender, EventArgs e)
        {
            sProjectTransfrerRequest = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnPTRform = sProjectTransfrerRequest.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbMainProjectcode.Text = sProjectCode;
            }
        }

        private void btnSelectProjectCode_Click(object sender, EventArgs e)
        {
            sProjectTransfrerRequest = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnPTRform = sProjectTransfrerRequest.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectCode.Text = sProjectCode;
            }

        }

        private void cmbMainProjectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMainProjectcode.SelectedIndex >= 0)
            {
                DataView dvProjectBOMList = new DataView(dtMainProjects);
                dvProjectBOMList.RowFilter = "ProjectCode='" + cmbMainProjectcode.Text + "'";
                if (dvProjectBOMList.ToTable().Rows.Count > 0)
                {
                    lblMainProjectName.Text = dvProjectBOMList.ToTable().Rows[0]["ProjectDescription"].ToString();
                }
                else
                {
                    lblMainProjectName.ResetText();
                }
            }
            else
            {
                lblMainProjectName.ResetText();
            }
        }
        private void fnClose()
        {
            this.Hide();
            frm.Show();
        }
        private void frmProjectTransferRequest_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnClose();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnClose();
        }
    }
}
