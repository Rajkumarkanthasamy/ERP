﻿namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmProjectApproveGM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectApproveGM));
            this.txtTargetValue = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.txtTargetMaterialmargin = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.txtOrderValueinINR = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.txtProjectMargin = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.cmbCustomizationlevel = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbProject8020 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtPaymenttrerms = new System.Windows.Forms.TextBox();
            this.dgItemOrProductList = new System.Windows.Forms.DataGridView();
            this.SLNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Version = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinishDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmbGMApproveList = new System.Windows.Forms.ComboBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPMProjectDescription = new System.Windows.Forms.TextBox();
            this.txtCustomer = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.txtBOMCost = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.dtpPMCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.txtAssembleDate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnReview = new System.Windows.Forms.Button();
            this.lstusers = new System.Windows.Forms.ListBox();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.chkloadOldProjects = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).BeginInit();
            this.SuspendLayout();
            // 
            // txtTargetValue
            // 
            this.txtTargetValue.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtTargetValue.Location = new System.Drawing.Point(778, 129);
            this.txtTargetValue.MaxLength = 15;
            this.txtTargetValue.Name = "txtTargetValue";
            this.txtTargetValue.ReadOnly = true;
            this.txtTargetValue.Size = new System.Drawing.Size(294, 26);
            this.txtTargetValue.TabIndex = 177;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label68.Location = new System.Drawing.Point(625, 131);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(150, 19);
            this.label68.TabIndex = 178;
            this.label68.Text = "Target Value in INR : ";
            // 
            // txtTargetMaterialmargin
            // 
            this.txtTargetMaterialmargin.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtTargetMaterialmargin.Location = new System.Drawing.Point(778, 88);
            this.txtTargetMaterialmargin.MaxLength = 4;
            this.txtTargetMaterialmargin.Name = "txtTargetMaterialmargin";
            this.txtTargetMaterialmargin.ReadOnly = true;
            this.txtTargetMaterialmargin.Size = new System.Drawing.Size(293, 26);
            this.txtTargetMaterialmargin.TabIndex = 175;
            this.txtTargetMaterialmargin.TextChanged += new System.EventHandler(this.txtTargetMaterialmargin_TextChanged);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label67.Location = new System.Drawing.Point(571, 90);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(201, 19);
            this.label67.TabIndex = 176;
            this.label67.Text = "Target Material Margin (%) :";
            // 
            // txtOrderValueinINR
            // 
            this.txtOrderValueinINR.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtOrderValueinINR.Location = new System.Drawing.Point(778, 47);
            this.txtOrderValueinINR.MaxLength = 15;
            this.txtOrderValueinINR.Name = "txtOrderValueinINR";
            this.txtOrderValueinINR.ReadOnly = true;
            this.txtOrderValueinINR.Size = new System.Drawing.Size(294, 26);
            this.txtOrderValueinINR.TabIndex = 172;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label63.Location = new System.Drawing.Point(625, 49);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(147, 19);
            this.label63.TabIndex = 174;
            this.label63.Text = "Order Value in INR : ";
            // 
            // txtProjectMargin
            // 
            this.txtProjectMargin.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtProjectMargin.Location = new System.Drawing.Point(778, 6);
            this.txtProjectMargin.MaxLength = 4;
            this.txtProjectMargin.Name = "txtProjectMargin";
            this.txtProjectMargin.ReadOnly = true;
            this.txtProjectMargin.Size = new System.Drawing.Size(293, 26);
            this.txtProjectMargin.TabIndex = 171;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label40.Location = new System.Drawing.Point(562, 8);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(210, 19);
            this.label40.TabIndex = 173;
            this.label40.Text = "Quoted Material Margin (%) :";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label24.Location = new System.Drawing.Point(40, 158);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(122, 19);
            this.label24.TabIndex = 180;
            this.label24.Text = "Payment Terms :\t";
            // 
            // cmbCustomizationlevel
            // 
            this.cmbCustomizationlevel.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCustomizationlevel.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCustomizationlevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCustomizationlevel.Enabled = false;
            this.cmbCustomizationlevel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomizationlevel.FormattingEnabled = true;
            this.cmbCustomizationlevel.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.cmbCustomizationlevel.Location = new System.Drawing.Point(398, 238);
            this.cmbCustomizationlevel.Name = "cmbCustomizationlevel";
            this.cmbCustomizationlevel.Size = new System.Drawing.Size(62, 26);
            this.cmbCustomizationlevel.TabIndex = 184;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(243, 240);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(149, 19);
            this.label13.TabIndex = 183;
            this.label13.Text = "Customization level :";
            // 
            // cmbProject8020
            // 
            this.cmbProject8020.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbProject8020.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProject8020.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProject8020.Enabled = false;
            this.cmbProject8020.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProject8020.FormattingEnabled = true;
            this.cmbProject8020.Items.AddRange(new object[] {
            "80",
            "20"});
            this.cmbProject8020.Location = new System.Drawing.Point(166, 238);
            this.cmbProject8020.Name = "cmbProject8020";
            this.cmbProject8020.Size = new System.Drawing.Size(62, 26);
            this.cmbProject8020.TabIndex = 182;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(52, 240);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 19);
            this.label9.TabIndex = 181;
            this.label9.Text = "Project 80/20 :\t";
            // 
            // txtPaymenttrerms
            // 
            this.txtPaymenttrerms.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPaymenttrerms.Location = new System.Drawing.Point(166, 158);
            this.txtPaymenttrerms.MaxLength = 4;
            this.txtPaymenttrerms.Multiline = true;
            this.txtPaymenttrerms.Name = "txtPaymenttrerms";
            this.txtPaymenttrerms.ReadOnly = true;
            this.txtPaymenttrerms.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPaymenttrerms.Size = new System.Drawing.Size(382, 69);
            this.txtPaymenttrerms.TabIndex = 185;
            // 
            // dgItemOrProductList
            // 
            this.dgItemOrProductList.AllowUserToAddRows = false;
            this.dgItemOrProductList.AllowUserToDeleteRows = false;
            this.dgItemOrProductList.AllowUserToResizeRows = false;
            this.dgItemOrProductList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgItemOrProductList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgItemOrProductList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgItemOrProductList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgItemOrProductList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SLNO,
            this.PProductCode,
            this.ProductName,
            this.Version,
            this.ProductType,
            this.Quantity,
            this.UnitCost,
            this.StartDate,
            this.FinishDate});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgItemOrProductList.EnableHeadersVisualStyles = false;
            this.dgItemOrProductList.Location = new System.Drawing.Point(12, 280);
            this.dgItemOrProductList.MultiSelect = false;
            this.dgItemOrProductList.Name = "dgItemOrProductList";
            this.dgItemOrProductList.RowHeadersVisible = false;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dgItemOrProductList.Size = new System.Drawing.Size(1128, 304);
            this.dgItemOrProductList.TabIndex = 186;
            this.dgItemOrProductList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemOrProductList_CellClick);
            // 
            // SLNO
            // 
            this.SLNO.DataPropertyName = "SlNo";
            this.SLNO.HeaderText = "SlNo";
            this.SLNO.Name = "SLNO";
            this.SLNO.ReadOnly = true;
            this.SLNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SLNO.Width = 47;
            // 
            // PProductCode
            // 
            this.PProductCode.DataPropertyName = "ProductCode";
            this.PProductCode.HeaderText = "ProductCode";
            this.PProductCode.Name = "PProductCode";
            this.PProductCode.ReadOnly = true;
            this.PProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PProductCode.Width = 104;
            // 
            // ProductName
            // 
            this.ProductName.DataPropertyName = "ProductName";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProductName.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProductName.HeaderText = "Product Name";
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductName.Width = 114;
            // 
            // Version
            // 
            this.Version.DataPropertyName = "Version";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Version.DefaultCellStyle = dataGridViewCellStyle3;
            this.Version.HeaderText = "Version";
            this.Version.Name = "Version";
            this.Version.ReadOnly = true;
            this.Version.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Version.Width = 65;
            // 
            // ProductType
            // 
            this.ProductType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProductType.DataPropertyName = "ProductType";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProductType.DefaultCellStyle = dataGridViewCellStyle4;
            this.ProductType.HeaderText = "Product Type";
            this.ProductType.Name = "ProductType";
            this.ProductType.ReadOnly = true;
            this.ProductType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductType.Visible = false;
            this.ProductType.Width = 107;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle5;
            this.Quantity.HeaderText = "Qty";
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 40;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.NullValue = null;
            this.UnitCost.DefaultCellStyle = dataGridViewCellStyle6;
            this.UnitCost.HeaderText = "Amount";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 71;
            // 
            // StartDate
            // 
            this.StartDate.DataPropertyName = "StartDate";
            this.StartDate.HeaderText = "Start Date";
            this.StartDate.Name = "StartDate";
            this.StartDate.ReadOnly = true;
            this.StartDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.StartDate.Width = 85;
            // 
            // FinishDate
            // 
            this.FinishDate.DataPropertyName = "FinishDate";
            this.FinishDate.HeaderText = "Finish Date";
            this.FinishDate.Name = "FinishDate";
            this.FinishDate.ReadOnly = true;
            this.FinishDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FinishDate.Width = 90;
            // 
            // cmbGMApproveList
            // 
            this.cmbGMApproveList.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbGMApproveList.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGMApproveList.DropDownHeight = 130;
            this.cmbGMApproveList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGMApproveList.DropDownWidth = 279;
            this.cmbGMApproveList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGMApproveList.FormattingEnabled = true;
            this.cmbGMApproveList.IntegralHeight = false;
            this.cmbGMApproveList.Location = new System.Drawing.Point(167, 28);
            this.cmbGMApproveList.Name = "cmbGMApproveList";
            this.cmbGMApproveList.Size = new System.Drawing.Size(381, 26);
            this.cmbGMApproveList.TabIndex = 117;
            this.cmbGMApproveList.SelectedIndexChanged += new System.EventHandler(this.cmbGMApproveList_SelectedIndexChanged);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.Color.Black;
            this.label66.Location = new System.Drawing.Point(58, 30);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(104, 19);
            this.label66.TabIndex = 118;
            this.label66.Text = "Project Code :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(52, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 19);
            this.label3.TabIndex = 188;
            this.label3.Text = "Project Name :";
            // 
            // txtPMProjectDescription
            // 
            this.txtPMProjectDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPMProjectDescription.Location = new System.Drawing.Point(167, 63);
            this.txtPMProjectDescription.Multiline = true;
            this.txtPMProjectDescription.Name = "txtPMProjectDescription";
            this.txtPMProjectDescription.ReadOnly = true;
            this.txtPMProjectDescription.Size = new System.Drawing.Size(381, 52);
            this.txtPMProjectDescription.TabIndex = 187;
            // 
            // txtCustomer
            // 
            this.txtCustomer.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCustomer.Location = new System.Drawing.Point(166, 123);
            this.txtCustomer.MaxLength = 15;
            this.txtCustomer.Name = "txtCustomer";
            this.txtCustomer.ReadOnly = true;
            this.txtCustomer.Size = new System.Drawing.Size(381, 26);
            this.txtCustomer.TabIndex = 189;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(80, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 19);
            this.label1.TabIndex = 190;
            this.label1.Text = "Customer :";
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblTotalCost.ForeColor = System.Drawing.Color.Black;
            this.lblTotalCost.Location = new System.Drawing.Point(635, 218);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(137, 19);
            this.lblTotalCost.TabIndex = 192;
            this.lblTotalCost.Text = "Project BOM Cost :";
            // 
            // txtBOMCost
            // 
            this.txtBOMCost.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtBOMCost.Location = new System.Drawing.Point(778, 216);
            this.txtBOMCost.MaxLength = 15;
            this.txtBOMCost.Name = "txtBOMCost";
            this.txtBOMCost.ReadOnly = true;
            this.txtBOMCost.Size = new System.Drawing.Size(294, 26);
            this.txtBOMCost.TabIndex = 193;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(953, 590);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(113, 42);
            this.btnExit.TabIndex = 195;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(615, 590);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(113, 42);
            this.btnSave.TabIndex = 194;
            this.btnSave.Text = "Approve";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dtpPMCreatedDate
            // 
            this.dtpPMCreatedDate.CustomFormat = "";
            this.dtpPMCreatedDate.Enabled = false;
            this.dtpPMCreatedDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPMCreatedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPMCreatedDate.Location = new System.Drawing.Point(398, 172);
            this.dtpPMCreatedDate.Name = "dtpPMCreatedDate";
            this.dtpPMCreatedDate.Size = new System.Drawing.Size(131, 26);
            this.dtpPMCreatedDate.TabIndex = 196;
            // 
            // txtAssembleDate
            // 
            this.txtAssembleDate.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtAssembleDate.Location = new System.Drawing.Point(778, 170);
            this.txtAssembleDate.MaxLength = 15;
            this.txtAssembleDate.Name = "txtAssembleDate";
            this.txtAssembleDate.ReadOnly = true;
            this.txtAssembleDate.Size = new System.Drawing.Size(294, 26);
            this.txtAssembleDate.TabIndex = 198;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(602, 172);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(170, 19);
            this.label2.TabIndex = 197;
            this.label2.Text = "Project Assemble Date :";
            // 
            // btnReview
            // 
            this.btnReview.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnReview.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnReview.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReview.Location = new System.Drawing.Point(789, 590);
            this.btnReview.Name = "btnReview";
            this.btnReview.Size = new System.Drawing.Size(113, 42);
            this.btnReview.TabIndex = 199;
            this.btnReview.Text = "Review";
            this.btnReview.UseVisualStyleBackColor = false;
            this.btnReview.Click += new System.EventHandler(this.btnReview_Click);
            // 
            // lstusers
            // 
            this.lstusers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstusers.FormattingEnabled = true;
            this.lstusers.ItemHeight = 19;
            this.lstusers.Location = new System.Drawing.Point(521, 308);
            this.lstusers.Name = "lstusers";
            this.lstusers.ScrollAlwaysVisible = true;
            this.lstusers.Size = new System.Drawing.Size(110, 61);
            this.lstusers.TabIndex = 200;
            this.lstusers.Visible = false;
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtRemarks.Location = new System.Drawing.Point(159, 588);
            this.txtRemarks.MaxLength = 1000;
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(382, 44);
            this.txtRemarks.TabIndex = 202;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(78, 590);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 19);
            this.label4.TabIndex = 201;
            this.label4.Text = "Remarks :\t";
            // 
            // chkloadOldProjects
            // 
            this.chkloadOldProjects.AutoSize = true;
            this.chkloadOldProjects.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkloadOldProjects.ForeColor = System.Drawing.Color.Black;
            this.chkloadOldProjects.Location = new System.Drawing.Point(171, 2);
            this.chkloadOldProjects.Name = "chkloadOldProjects";
            this.chkloadOldProjects.Size = new System.Drawing.Size(148, 23);
            this.chkloadOldProjects.TabIndex = 214;
            this.chkloadOldProjects.Text = "Load Old Projects";
            this.chkloadOldProjects.UseVisualStyleBackColor = true;
            this.chkloadOldProjects.CheckedChanged += new System.EventHandler(this.chkloadOldProjects_CheckedChanged);
            // 
            // frmProjectApproveGM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1152, 638);
            this.Controls.Add(this.chkloadOldProjects);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnReview);
            this.Controls.Add(this.txtAssembleDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtBOMCost);
            this.Controls.Add(this.lblTotalCost);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCustomer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPMProjectDescription);
            this.Controls.Add(this.cmbGMApproveList);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.dgItemOrProductList);
            this.Controls.Add(this.txtPaymenttrerms);
            this.Controls.Add(this.cmbCustomizationlevel);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.cmbProject8020);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.txtTargetValue);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.txtTargetMaterialmargin);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.txtOrderValueinINR);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.txtProjectMargin);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.dtpPMCreatedDate);
            this.Controls.Add(this.lstusers);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "frmProjectApproveGM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Approve";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectApproveGM_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectApproveGM_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTargetValue;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox txtTargetMaterialmargin;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox txtOrderValueinINR;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox txtProjectMargin;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cmbCustomizationlevel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmbProject8020;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtPaymenttrerms;
        private System.Windows.Forms.DataGridView dgItemOrProductList;
        private System.Windows.Forms.ComboBox cmbGMApproveList;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPMProjectDescription;
        private System.Windows.Forms.TextBox txtCustomer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.TextBox txtBOMCost;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DateTimePicker dtpPMCreatedDate;
        private System.Windows.Forms.TextBox txtAssembleDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn SLNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn PProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinishDate;
        private System.Windows.Forms.Button btnReview;
        private System.Windows.Forms.ListBox lstusers;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkloadOldProjects;
    }
}