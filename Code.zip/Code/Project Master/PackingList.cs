﻿using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class PackingList : Form
    {
        public PackingList()
        {
            InitializeComponent();
        }
    }
}
