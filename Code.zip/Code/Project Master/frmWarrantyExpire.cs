﻿using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmWarrantyExpire : Form
    {
        public frmWarrantyExpire()
        {
            InitializeComponent();
        }
        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        DataTable dtProjectList = new DataTable();
        frmForm2 frm = new frmForm2();
        private void frmWarrantyExpire_Load(object sender, EventArgs e)
        {
            dtpInstallationDate.Format = DateTimePickerFormat.Custom;
            dtpInstallationDate.CustomFormat = "yyyy-MM-dd";
            dtProjectList = DAL.fnInstallProjectList(1, dtpInstallationDate.Text).Tables[0];
            dtpInstallationDate.Format = DateTimePickerFormat.Custom;
            dtpInstallationDate.CustomFormat = "dd-MM-yyyy";
            dgProjectList.AutoGenerateColumns = false;
            dgProjectList.DataSource = dtProjectList;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (chkExceluploadclose.Checked)
            {
                foreach (DataGridViewRow row in dgvExcelUpload.Rows)
                {
                    GlobalClass.iStatus = DAL.fnAddProjectUpdate(5, row.Cells["ProjectCode1"].Value.ToString(), "", row.Cells["ProjectStatus"].Value.ToString(), "");
                    GlobalClass.iStatus = DAL.fnAddProjectStatus(0, row.Cells["ProjectCode1"].Value.ToString(), "", Loginfrm.GetUserDetails[2], row.Cells["ProjectStatus"].Value.ToString(), dtpInstallationDate.Text);
                }
                MessageBox.Show("Project status updated", "Success", 0, MessageBoxIcon.Information);
                fnClose();
            }
            else
            {
                foreach (DataGridViewRow row in dgProjectList.Rows)
                {
                    GlobalClass.iStatus = DAL.fnAddProjectUpdate(5, row.Cells["ProjectCode"].Value.ToString(), "", "Warranty Expired", "");
                    GlobalClass.iStatus = DAL.fnAddProjectStatus(0, row.Cells["ProjectCode"].Value.ToString(), row.Cells["ProjectDescription"].Value.ToString(), Loginfrm.GetUserDetails[2], "Warranty Expired", dtpInstallationDate.Text);
                }
                MessageBox.Show("Warranty Expired status updated for the projects", "Success", 0, MessageBoxIcon.Information);
                fnClose();
            }
        }

        private void frmWarrantyExpire_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnClose();
        }
        private void fnClose()
        {
            this.Hide();
            frm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnClose();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Excel Files (*.xls)|*.xls";
            openFileDialog1.InitialDirectory = @"c:\";
            openFileDialog1.FileName = "Select File";
            openFileDialog1.Title = "Select excel file..";
            openFileDialog1.ShowDialog();
        }

        DataTable dtExcelImport = new DataTable();
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
                string smessageItemCode = string.Empty;
                string str = string.Empty;
                string sheetname = "";
                string constr = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source=" + openFileDialog1.FileName + ";Extended Properties= \"Excel 8.0;HDR=YES;\";";
                OleDbConnection con = new OleDbConnection(constr);
                con.Open();
                DataTable Sheets = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                foreach (DataRow dr in Sheets.Rows)
                {
                    sheetname = dr[2].ToString().Replace("'", "");
                    break;
                }
                if (!string.IsNullOrEmpty(sheetname))
                {
                    OleDbDataAdapter sda = new OleDbDataAdapter("select * from [" + sheetname + "]", con);
                    sda.Fill(dtExcelImport);
                }
                con.Close();

                /*
                if (dtExcelImport.Rows.Count > 0 && dtExcelImport.Columns.Count == 1 )
                {
                    for (int i = 0; i < dtExcelImport.Columns.Count; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                str = "ProjectCode";
                                break;
                        }
                        dtExcelImport.Columns[i].ColumnName = str;
                    }

                    for (int i = dtExcelImport.Rows.Count - 1; i >= 0; i--)
                    {
                        if (dtExcelImport.Rows[i][0] == DBNull.Value)
                            dtExcelImport.Rows[i].Delete();
                    }
                    dtExcelImport.AcceptChanges();

                    if (dtExcelImport.Rows.Count > 0)
                    {
                        dgvExcelUpload.AutoGenerateColumns = false;
                        dgvExcelUpload.DataSource = dtExcelImport;

                    }
                    else
                    {
                        MessageBox.Show("Uploaded Excel file not contains any valid details matching with the project master requirements. \n\n Please note these columns are mandatory to fill. \n Projectcode", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Uploaded Excel file is not in expected format.\n 1) Excel file should contain 1 column with name on the first Row \n 2) project code details to be start from the second Row ", "Error", 0, MessageBoxIcon.Error);
                }*/

                // --- after you normalized column names and removed empty rows ---
                if (dtExcelImport.Rows.Count > 0)
                {
                    // Make sure expected columns exist in the DataTable
                    if (!dtExcelImport.Columns.Contains("ProjectCode"))
                        throw new InvalidOperationException("DataTable must contain 'ProjectCode' column.");
                    if (!dtExcelImport.Columns.Contains("ProjectStatus"))
                        dtExcelImport.Columns.Add("ProjectStatus", typeof(string)); // optional

                    // Ensure grid is visible
                    dgvExcelUpload.Visible = true;

                    // We control columns explicitly
                    dgvExcelUpload.AutoGenerateColumns = false;

                    // Ensure grid columns exist and bind them
                    if (!dgvExcelUpload.Columns.Contains("ProjectCode1"))
                    {
                        var c = new DataGridViewTextBoxColumn
                        {
                            Name = "ProjectCode1",
                            HeaderText = "Project Code",
                            DataPropertyName = "ProjectCode",
                            ReadOnly = true,
                            SortMode = DataGridViewColumnSortMode.NotSortable,
                            AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                        };
                        dgvExcelUpload.Columns.Add(c);
                    }
                    else
                    {
                        dgvExcelUpload.Columns["ProjectCode1"].DataPropertyName = "ProjectCode";
                    }

                    if (!dgvExcelUpload.Columns.Contains("ProjectStatus"))
                    {
                        var c = new DataGridViewTextBoxColumn
                        {
                            Name = "ProjectStatus",
                            HeaderText = "Project Status",
                            DataPropertyName = "ProjectStatus",
                            ReadOnly = false,
                            SortMode = DataGridViewColumnSortMode.NotSortable,
                            AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                        };
                        dgvExcelUpload.Columns.Add(c);
                    }
                    else
                    {
                        dgvExcelUpload.Columns["ProjectStatus"].DataPropertyName = "ProjectStatus";
                    }

                    // Clean rebind
                    dgvExcelUpload.DataSource = null;
                    dgvExcelUpload.DataSource = dtExcelImport;

                    // Optional polish
                    dgvExcelUpload.AutoResizeColumns();
                    dgvExcelUpload.ClearSelection();
                }
                else
                {
                    MessageBox.Show(
                        "Uploaded Excel file does not contain any valid rows.\n\n" +
                        "Mandatory:\n - ProjectCode\nOptional:\n - ProjectStatus",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("btnUpload_Click" + ex.Message);
            }
        }

        private void chkExceluploadclose_CheckedChanged(object sender, EventArgs e)
        {
            if (chkExceluploadclose.Checked)
            {
                btnBrowse.Visible = true;
                dgvExcelUpload.Visible = true;
                dgProjectList.Visible = false;
            }
            else
            {
                btnBrowse.Visible = false;
                dgvExcelUpload.Visible = false;
                dgProjectList.Visible = true;
            }
        }
    }
}
