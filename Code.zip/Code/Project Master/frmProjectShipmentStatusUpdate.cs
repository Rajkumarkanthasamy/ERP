﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmProjectShipmentStatusUpdate : Form
    {
        public frmProjectShipmentStatusUpdate()
        {
            InitializeComponent();
        }
        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        frmForm2 frm = new frmForm2();
        Global GlobalClass = new Global();
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        public int sProjectShipmentStatusform = 0;
        DataTable dtProjctList = new DataTable();
        private void frmProjectShipmentStatusUpdate_Load(object sender, EventArgs e)
        {
            dtProjctList = DAL.fnAllProjectList(null).Tables[0];

            foreach (DataRow DR in dtProjctList.Rows)
            {
                if (!cmbProjectcode.Items.Contains(DR["ProjectCode"].ToString()))
                    cmbProjectcode.Items.Add(DR["ProjectCode"].ToString());
            }
        }

        private void btnProjectView_Click(object sender, EventArgs e)
        {
            sProjectShipmentStatusform = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnProjectShipStatusInstallform = sProjectShipmentStatusform.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectcode.SelectedItem = sProjectCode;
            }
        }

        DataTable dtProjectDates = new DataTable();
        private void cmbProjectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProjectcode.SelectedIndex >= 0)
            {
                btnSave.Enabled = true;
                dtProjectDates = DAL.fnAllProjectList(cmbProjectcode.Text).Tables[0];
                DataView dvProjectBOMList = new DataView(dtProjctList);
                dvProjectBOMList.RowFilter = "ProjectCode='" + cmbProjectcode.Text + "'";
                if (dvProjectBOMList.ToTable().Rows.Count > 0)
                {
                    llbProjectName.Text = dvProjectBOMList.ToTable().Rows[0]["ProjectDescription"].ToString();
                }
                else
                {
                    llbProjectName.ResetText();
                }

                if (dtProjectDates.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtProjectDates.Rows[0]["AssembleDate"].ToString()))
                    {
                        dtpAssemblyDate.Value = Convert.ToDateTime(dtProjectDates.Rows[0]["AssembleDate"]);
                        dtpInstallationDate.Value = Convert.ToDateTime(dtProjectDates.Rows[0]["CriticalDate"]);
                        dtpShipmentDate.Value = Convert.ToDateTime(dtProjectDates.Rows[0]["ShipmentDate"]);
                    }
                    else
                    {
                        dtpAssemblyDate.Value = DateTime.Now;
                        dtpInstallationDate.Value = DateTime.Now;
                        dtpShipmentDate.Value = DateTime.Now; 
                    }
                }
            }
            else
            {
                llbProjectName.ResetText();
            }
        }
        bool bAssemblyDate = false;
        bool bInstallationDate = false;
        bool bShipmentDate = false;
        private void dtpAssemblyDate_ValueChanged(object sender, EventArgs e)
        {
            bAssemblyDate = true;
        }

        private void dtpInstallationDate_ValueChanged(object sender, EventArgs e)
        {
            bInstallationDate = true;
        }

        private void dtpShipmentDate_ValueChanged(object sender, EventArgs e)
        {
            bShipmentDate = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (bAssemblyDate && bInstallationDate && bShipmentDate && cmbProjectcode.SelectedIndex >= 0)
            {

                GlobalClass.iStatus = DAL.fnAddProjectUpdate(7, cmbProjectcode.Text, dtpAssemblyDate.Text, dtpInstallationDate.Text, dtpShipmentDate.Text);

                MessageBox.Show("Dates updated to the project '" + llbProjectName.Text + "'", "Success", 0, MessageBoxIcon.Information);
                btnSave.Enabled = false;
                bAssemblyDate = false;
                bInstallationDate = false;
                bShipmentDate = false;
            }
            else
            {
                if (cmbProjectcode.SelectedIndex < 0)
                {
                    cmbProjectcode.DroppedDown = true;
                    MessageBox.Show("Select the project code", "Error", 0, MessageBoxIcon.Error);
                }
                else if (!bAssemblyDate)
                {
                    MessageBox.Show("Select the project assembly date", "Error", 0, MessageBoxIcon.Error);
                }
                else if (!bInstallationDate)
                {
                    MessageBox.Show("Select the project installation date", "Error", 0, MessageBoxIcon.Error);
                }
                else if (!bShipmentDate)
                {
                    MessageBox.Show("Select the project shipment date", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }

        private void frmProjectShipmentStatusUpdate_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }
    }
}
