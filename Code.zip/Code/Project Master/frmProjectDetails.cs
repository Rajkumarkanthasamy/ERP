﻿using System;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmProjectDetails : Form
    {
        public frmProjectDetails()
        {
            InitializeComponent();
        }

        private void frmProjectDetails_Load(object sender, EventArgs e)
        {

        }
    }
}
