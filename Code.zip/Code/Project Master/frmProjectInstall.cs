﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmProjectInstall : Form
    {
        public frmProjectInstall()
        {
            InitializeComponent();
        }
        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        frmForm2 frm = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        public int sProjectStatusInstallform = 0;
        DataTable dtProjectList = new DataTable();

        private void frmProjectInstall_Load(object sender, EventArgs e)
        {
            dtProjectList = DAL.fnInstallProjectList(0,null).Tables[0];

            foreach (DataRow DR in dtProjectList.Rows)
            {
                if (!cmbProjectcode.Items.Contains(DR["ProjectCode"].ToString()))
                    cmbProjectcode.Items.Add(DR["ProjectCode"].ToString());
            }
        }

        private void btnProjectSearch_Click(object sender, EventArgs e)
        {
            sProjectStatusInstallform = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnProjectStatusInstallform = sProjectStatusInstallform.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectcode.Text = sProjectCode;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (dvProjectName.ToTable().Rows.Count > 0)
            {
                if (cmbProjectcode.SelectedIndex >= 0 && cmbProjectStatus.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtInstallationformno.Text)
                    && bInstallationDate && bWarrantyenddate)
                {
                    GlobalClass.iStatus = DAL.fnAddProjectUpdate(6, cmbProjectcode.Text, "", cmbProjectStatus.Text, "");
                    GlobalClass.iStatus = DAL.fnAddProjectStatus(0, cmbProjectcode.Text, dvProjectName.ToTable().Rows[0]["ProjectDescription"].ToString(), Loginfrm.GetUserDetails[2], cmbProjectStatus.Text, dtpInstallationDate.Text);


                    GlobalClass.iStatus = DAL.fnAddProject(Global.uINSERT, cmbProjectcode.Text + " -W", dvProjectName.ToTable().Rows[0]["ProjectDescription"].ToString() + " -Warranty","","", dtpStartDate.Text,
                                                              dvProjectName.ToTable().Rows[0]["Customer"].ToString(), "", "WIP", "", "", "", Loginfrm.GetUserDetails[2], "", dvProjectName.ToTable().Rows[0]["CustomerCode"].ToString(), false, "", "", "", "", "", "");

                    GlobalClass.iStatus = DAL.fnAddShortShipment(44, dtpCLosedate.Text, false, dtpStartDate.Text, cmbProjectcode.Text + " -W");

                    GlobalClass.iStatus = DAL.fnAddProjectStatus(0, cmbProjectcode.Text + " -W", dvProjectName.ToTable().Rows[0]["ProjectDescription"].ToString() + " -Warranty", Loginfrm.GetUserDetails[2], "WIP", dtpInstallationDate.Text);

                    GlobalClass.iStatus = DAL.fnAddProjectInstallationStatusUpdate(1, cmbProjectcode.Text, cmbProjectStatus.Text, txtInstallationformno.Text, dtpInstallationDate.Text,
                        txtPersonSigned.Text, txtDesignationofSigned.Text, txtAssetSerialNo.Text, txtRemarks.Text, Loginfrm.GetUserDetails[2],
                        cmbMarketingInteractions.Text, txtMarketingInteractions.Text, cmbQualityofbissproducts.Text, txtQualityofbissproducts.Text, cmbQualityofbissreports.Text, txtQualityofbissreports.Text,
                        cmbqualityofinteractions.Text, txtqualityofinteractions.Text, cmbequipementpackingquality.Text, txtequipementpackingquality.Text, cmbMachineUserfriendly.Text, txtMachineUserfriendly.Text,
                        cmbApplicationuserfriendly.Text, txtApplicationuserfriendly.Text);

                    MessageBox.Show("Installation Status Updated", "Success", 0, MessageBoxIcon.Information);
                    this.Hide();
                    frmProjectInstall Install = new frmProjectInstall();
                    Install.Show();
                }
                else
                {
                    if (cmbProjectcode.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select project code", "Error", 0, MessageBoxIcon.Error);
                        cmbProjectcode.DroppedDown = true;
                    }
                    else if (cmbProjectStatus.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select project status", "Error", 0, MessageBoxIcon.Error);
                        cmbProjectStatus.DroppedDown = true;
                    }
                    else if (string.IsNullOrEmpty(txtInstallationformno.Text))
                    {
                        MessageBox.Show("Enter Installation form number", "Error", 0, MessageBoxIcon.Error);
                        txtInstallationformno.Focus();
                    }
                    else if (!bInstallationDate)
                    {
                        MessageBox.Show("Select the Installation date", "Error", 0, MessageBoxIcon.Error);
                        dtpInstallationDate.Enabled = true;
                    }
                    else if (!bWarrantyenddate)
                    {
                        MessageBox.Show("Please update the order entry form with warranty in months", "Error", 0, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void frmProjectInstall_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnClose();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnClose();
        }

        private void fnClose()
        {
            this.Hide();
            frm.Show();
        }
        bool bInstallationDate = false;
        private void dtpInstallationDate_ValueChanged(object sender, EventArgs e)
        {
            dtpStartDate.Value = Convert.ToDateTime(dtpInstallationDate.Text);
            bInstallationDate = true;
        }
        DataView dvProjectName = new DataView();
        private void cmbProjectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            dvProjectName = new DataView(dtProjectList);
            dvProjectName.RowFilter = "ProjectCode='" + cmbProjectcode.Text + "'";
            if (dvProjectName.ToTable().Rows.Count > 0)
            {
                txtPMProjectDescription.Text = dvProjectName.ToTable().Rows[0]["ProjectDescription"].ToString();
                txtCustomerName.Text = dvProjectName.ToTable().Rows[0]["Customer"].ToString();

                DataTable dtOrderentry = DAL.fnProjectOrderEntry(cmbProjectcode.Text, 1).Tables[0];
                if (dtOrderentry.Rows.Count > 0)
                {
                    txtWarrantyMonths.Text = dtOrderentry.Rows[0]["WarrantyPeriod"].ToString();
                }
                else
                {
                    txtWarrantyMonths.Enabled = true;
                    txtWarrantyMonths.ReadOnly = false;
                }

            }
        }

        bool bWarrantyenddate = false;

        private void dtpStartDate_ValueChanged(object sender, EventArgs e)
        {
            bWarrantyenddate = false;
            if (!string.IsNullOrEmpty(txtWarrantyMonths.Text))
            {
                dtpCLosedate.Value = Convert.ToDateTime(dtpStartDate.Text).AddMonths(Convert.ToInt32(txtWarrantyMonths.Text)).AddDays(-1);
                bWarrantyenddate = true;
            }
            else
            {
                bWarrantyenddate = false;
                MessageBox.Show("Please update the order entry form with warranty in months", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
