﻿namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmProjectSearchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectSearchForm));
            this.dgProjectList = new System.Windows.Forms.DataGridView();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Createdby = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateCreated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WarrantyCloseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CapexNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.btnLoadProjects = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.pnShortShipment = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.btnUpdateShortShipment = new System.Windows.Forms.Button();
            this.cmbShortShipment = new System.Windows.Forms.ComboBox();
            this.dtpPMCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.checkPSWarranty = new System.Windows.Forms.CheckBox();
            this.cmbPSProjectType = new System.Windows.Forms.ComboBox();
            this.lblIteType = new System.Windows.Forms.Label();
            this.txtPSProjectCode = new System.Windows.Forms.TextBox();
            this.lblItemCode = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgProjectList)).BeginInit();
            this.gbSearchOptions.SuspendLayout();
            this.pnShortShipment.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgProjectList
            // 
            this.dgProjectList.AllowUserToAddRows = false;
            this.dgProjectList.AllowUserToDeleteRows = false;
            this.dgProjectList.AllowUserToResizeRows = false;
            this.dgProjectList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgProjectList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgProjectList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgProjectList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgProjectList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgProjectList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProjectCode,
            this.ProjectDescription,
            this.Customer,
            this.Type,
            this.Createdby,
            this.DateCreated,
            this.WarrantyCloseDate,
            this.Status,
            this.CapexNumber});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgProjectList.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgProjectList.EnableHeadersVisualStyles = false;
            this.dgProjectList.Location = new System.Drawing.Point(5, 109);
            this.dgProjectList.Name = "dgProjectList";
            this.dgProjectList.ReadOnly = true;
            this.dgProjectList.RowHeadersVisible = false;
            this.dgProjectList.RowHeadersWidth = 51;
            this.dgProjectList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgProjectList.Size = new System.Drawing.Size(1299, 579);
            this.dgProjectList.TabIndex = 8;
            this.dgProjectList.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgProjectList_CellMouseDoubleClick);
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.HeaderText = "ProjectCode";
            this.ProjectCode.MinimumWidth = 6;
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 102;
            // 
            // ProjectDescription
            // 
            this.ProjectDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProjectDescription.DataPropertyName = "ProjectDescription";
            this.ProjectDescription.HeaderText = "Project Name";
            this.ProjectDescription.MinimumWidth = 6;
            this.ProjectDescription.Name = "ProjectDescription";
            this.ProjectDescription.ReadOnly = true;
            this.ProjectDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectDescription.Width = 235;
            // 
            // Customer
            // 
            this.Customer.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Customer.DataPropertyName = "Customer";
            this.Customer.HeaderText = "Customer";
            this.Customer.MinimumWidth = 6;
            this.Customer.Name = "Customer";
            this.Customer.ReadOnly = true;
            this.Customer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Customer.Width = 234;
            // 
            // Type
            // 
            this.Type.DataPropertyName = "Type";
            this.Type.HeaderText = "Type";
            this.Type.MinimumWidth = 6;
            this.Type.Name = "Type";
            this.Type.ReadOnly = true;
            this.Type.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Type.Width = 49;
            // 
            // Createdby
            // 
            this.Createdby.DataPropertyName = "CreatedBy";
            this.Createdby.HeaderText = "Created By";
            this.Createdby.MinimumWidth = 6;
            this.Createdby.Name = "Createdby";
            this.Createdby.ReadOnly = true;
            this.Createdby.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Createdby.Width = 94;
            // 
            // DateCreated
            // 
            this.DateCreated.DataPropertyName = "DateCreated";
            this.DateCreated.HeaderText = "Created On";
            this.DateCreated.MinimumWidth = 6;
            this.DateCreated.Name = "DateCreated";
            this.DateCreated.ReadOnly = true;
            this.DateCreated.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DateCreated.Width = 97;
            // 
            // WarrantyCloseDate
            // 
            this.WarrantyCloseDate.DataPropertyName = "CustomerRequirement";
            this.WarrantyCloseDate.HeaderText = "Delivery Date";
            this.WarrantyCloseDate.MinimumWidth = 6;
            this.WarrantyCloseDate.Name = "WarrantyCloseDate";
            this.WarrantyCloseDate.ReadOnly = true;
            this.WarrantyCloseDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WarrantyCloseDate.Width = 113;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.MinimumWidth = 6;
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Status.Width = 60;
            // 
            // CapexNumber
            // 
            this.CapexNumber.DataPropertyName = "CapexNumber";
            this.CapexNumber.HeaderText = "Capex No";
            this.CapexNumber.MinimumWidth = 6;
            this.CapexNumber.Name = "CapexNumber";
            this.CapexNumber.ReadOnly = true;
            this.CapexNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CapexNumber.Width = 83;
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.btnLoadProjects);
            this.gbSearchOptions.Controls.Add(this.label5);
            this.gbSearchOptions.Controls.Add(this.pnShortShipment);
            this.gbSearchOptions.Controls.Add(this.dtpPMCreatedDate);
            this.gbSearchOptions.Controls.Add(this.checkPSWarranty);
            this.gbSearchOptions.Controls.Add(this.cmbPSProjectType);
            this.gbSearchOptions.Controls.Add(this.lblIteType);
            this.gbSearchOptions.Controls.Add(this.txtPSProjectCode);
            this.gbSearchOptions.Controls.Add(this.lblItemCode);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(5, 4);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(1297, 99);
            this.gbSearchOptions.TabIndex = 7;
            this.gbSearchOptions.TabStop = false;
            // 
            // btnLoadProjects
            // 
            this.btnLoadProjects.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnLoadProjects.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnLoadProjects.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadProjects.Location = new System.Drawing.Point(647, 14);
            this.btnLoadProjects.Name = "btnLoadProjects";
            this.btnLoadProjects.Size = new System.Drawing.Size(163, 32);
            this.btnLoadProjects.TabIndex = 209;
            this.btnLoadProjects.Text = "Load All Projects";
            this.btnLoadProjects.UseVisualStyleBackColor = false;
            this.btnLoadProjects.Click += new System.EventHandler(this.btnLoadProjects_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(96, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(452, 19);
            this.label5.TabIndex = 72;
            this.label5.Text = "Search results include project code, project name, capex number";
            // 
            // pnShortShipment
            // 
            this.pnShortShipment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnShortShipment.Controls.Add(this.label4);
            this.pnShortShipment.Controls.Add(this.btnUpdateShortShipment);
            this.pnShortShipment.Controls.Add(this.cmbShortShipment);
            this.pnShortShipment.Location = new System.Drawing.Point(844, 42);
            this.pnShortShipment.Name = "pnShortShipment";
            this.pnShortShipment.Size = new System.Drawing.Size(425, 43);
            this.pnShortShipment.TabIndex = 9;
            this.pnShortShipment.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 19);
            this.label4.TabIndex = 78;
            this.label4.Text = "Short Shipment:";
            // 
            // btnUpdateShortShipment
            // 
            this.btnUpdateShortShipment.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateShortShipment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnUpdateShortShipment.Location = new System.Drawing.Point(215, 2);
            this.btnUpdateShortShipment.Name = "btnUpdateShortShipment";
            this.btnUpdateShortShipment.Size = new System.Drawing.Size(203, 36);
            this.btnUpdateShortShipment.TabIndex = 76;
            this.btnUpdateShortShipment.Text = "Raise Short Shipment Request";
            this.btnUpdateShortShipment.UseVisualStyleBackColor = true;
            this.btnUpdateShortShipment.Click += new System.EventHandler(this.btnUpdateShortShipment_Click);
            // 
            // cmbShortShipment
            // 
            this.cmbShortShipment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbShortShipment.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbShortShipment.FormattingEnabled = true;
            this.cmbShortShipment.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbShortShipment.Location = new System.Drawing.Point(125, 9);
            this.cmbShortShipment.Name = "cmbShortShipment";
            this.cmbShortShipment.Size = new System.Drawing.Size(79, 26);
            this.cmbShortShipment.TabIndex = 77;
            this.toolTip1.SetToolTip(this.cmbShortShipment, "Select a Project Type to Search");
            this.cmbShortShipment.SelectedIndexChanged += new System.EventHandler(this.cmbShortShipment_SelectedIndexChanged);
            // 
            // dtpPMCreatedDate
            // 
            this.dtpPMCreatedDate.CustomFormat = "";
            this.dtpPMCreatedDate.Enabled = false;
            this.dtpPMCreatedDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPMCreatedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPMCreatedDate.Location = new System.Drawing.Point(679, 55);
            this.dtpPMCreatedDate.Name = "dtpPMCreatedDate";
            this.dtpPMCreatedDate.Size = new System.Drawing.Size(131, 26);
            this.dtpPMCreatedDate.TabIndex = 71;
            // 
            // checkPSWarranty
            // 
            this.checkPSWarranty.AutoSize = true;
            this.checkPSWarranty.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkPSWarranty.Location = new System.Drawing.Point(1119, 18);
            this.checkPSWarranty.Name = "checkPSWarranty";
            this.checkPSWarranty.Size = new System.Drawing.Size(135, 23);
            this.checkPSWarranty.TabIndex = 5;
            this.checkPSWarranty.Text = "Show Warranty";
            this.checkPSWarranty.UseVisualStyleBackColor = true;
            this.checkPSWarranty.Visible = false;
            this.checkPSWarranty.CheckedChanged += new System.EventHandler(this.chkPSWarranty_CheckedChanged);
            // 
            // cmbPSProjectType
            // 
            this.cmbPSProjectType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPSProjectType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPSProjectType.FormattingEnabled = true;
            this.cmbPSProjectType.Items.AddRange(new object[] {
            "None"});
            this.cmbPSProjectType.Location = new System.Drawing.Point(918, 14);
            this.cmbPSProjectType.Name = "cmbPSProjectType";
            this.cmbPSProjectType.Size = new System.Drawing.Size(176, 26);
            this.cmbPSProjectType.TabIndex = 4;
            this.toolTip1.SetToolTip(this.cmbPSProjectType, "Select a Project Type to Search");
            this.cmbPSProjectType.SelectedIndexChanged += new System.EventHandler(this.cmbPSProjectType_SelectedIndexChanged);
            // 
            // lblIteType
            // 
            this.lblIteType.AutoSize = true;
            this.lblIteType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIteType.Location = new System.Drawing.Point(819, 17);
            this.lblIteType.Name = "lblIteType";
            this.lblIteType.Size = new System.Drawing.Size(95, 19);
            this.lblIteType.TabIndex = 1;
            this.lblIteType.Text = "ProjectType:";
            // 
            // txtPSProjectCode
            // 
            this.txtPSProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPSProjectCode.Location = new System.Drawing.Point(90, 15);
            this.txtPSProjectCode.Multiline = true;
            this.txtPSProjectCode.Name = "txtPSProjectCode";
            this.txtPSProjectCode.Size = new System.Drawing.Size(458, 41);
            this.txtPSProjectCode.TabIndex = 1;
            this.toolTip1.SetToolTip(this.txtPSProjectCode, "Enter Text to Search  by Project Code");
            this.txtPSProjectCode.Enter += new System.EventHandler(this.txtPSProjectCode_Enter);
            this.txtPSProjectCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPSProjectCode_KeyPress);
            this.txtPSProjectCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPSProjectCode_KeyUp);
            // 
            // lblItemCode
            // 
            this.lblItemCode.AutoSize = true;
            this.lblItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemCode.Location = new System.Drawing.Point(21, 19);
            this.lblItemCode.Name = "lblItemCode";
            this.lblItemCode.Size = new System.Drawing.Size(63, 19);
            this.lblItemCode.TabIndex = 0;
            this.lblItemCode.Text = "Search :";
            // 
            // frmProjectSearchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1307, 704);
            this.Controls.Add(this.dgProjectList);
            this.Controls.Add(this.gbSearchOptions);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmProjectSearchForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Search";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectSearchForm_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectSearchForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgProjectList)).EndInit();
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            this.pnShortShipment.ResumeLayout(false);
            this.pnShortShipment.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgProjectList;
        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.CheckBox checkPSWarranty;
        private System.Windows.Forms.ComboBox cmbPSProjectType;
        private System.Windows.Forms.Label lblIteType;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btnUpdateShortShipment;
        private System.Windows.Forms.ComboBox cmbShortShipment;
        private System.Windows.Forms.Panel pnShortShipment;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpPMCreatedDate;
        private System.Windows.Forms.Button btnLoadProjects;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn Createdby;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateCreated;
        private System.Windows.Forms.DataGridViewTextBoxColumn WarrantyCloseDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn CapexNumber;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPSProjectCode;
        private System.Windows.Forms.Label lblItemCode;
    }
}