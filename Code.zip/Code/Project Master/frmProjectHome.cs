﻿using System;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmProjectHome : Form
    {
        public frmProjectHome()
        {
            InitializeComponent();
        }
        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        frmForm2 frm = new frmForm2();
        private void frmProjectHome_Load(object sender, EventArgs e)
        {
            if (Login.frmLoginForm.sUserDetails[48] != "True")
            {
                btnProjectMaster.Enabled = false;
                llProjectMaster.Enabled = false;
            }
            else
            {
                btnProjectMaster.Enabled = true;
                llProjectMaster.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[33] != "True")
            {
                btnProjectTransfer.Enabled = false;
                llbProjectTransfer.Enabled = false;
            }
            else
            {
                btnProjectTransfer.Enabled = true;
                llbProjectTransfer.Enabled = true;
            }
            if (Login.frmLoginForm.sUserDetails[34] != "True")
            {
                btnProjectDocuments.Enabled = false;
                llbProjectDocs.Enabled = false;
            }
            else
            {
                btnProjectDocuments.Enabled = true;
                llbProjectDocs.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[37] != "True")
            {
                btnWarrantyShortShipment.Enabled = false;
                llbWarrantyShortShipment.Enabled = false;
            }
            else
            {
                btnWarrantyShortShipment.Enabled = true;
                llbWarrantyShortShipment.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[38] != "True")
            {
                btnProjectStatus.Enabled = false;
                llProjectStatus.Enabled = false;
            }
            else
            {
                btnProjectStatus.Enabled = true;
                llProjectStatus.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[39] != "True")
            {
                btnProjectInstallation.Enabled = false;
                llProjectInstallation.Enabled = false;
            }
            else
            {
                btnProjectInstallation.Enabled = true;
                llProjectInstallation.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[40] != "True")
            {
                btnProjectTransferRequest.Enabled = false;
                llbProjectTransferRequest.Enabled = false;
            }
            else
            {
                btnProjectTransferRequest.Enabled = true;
                llbProjectTransferRequest.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[49] != "True")
            {
                btnProjectStatusupdate.Enabled = false;
                llbProjectStatusUpdate.Enabled = false;
            }
            else
            {
                btnProjectStatusupdate.Enabled = true;
                llbProjectStatusUpdate.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[69] != "True")
            {
                btnProjectApprove.Enabled = false;
                lblProjectApprove.Enabled = false;
            }
            else
            {
                btnProjectApprove.Enabled = true;
                lblProjectApprove.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[74] != "True")
            {
                btnGMApprove.Enabled = false;
                llbGMApprove.Enabled = false;
            }
            else
            {
                btnGMApprove.Enabled = true;
                llbGMApprove.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[76] != "True")
            {
                btnAssetMaster.Enabled = false;
                lblAssetMaster.Enabled = false;
            }
            else
            {
                btnAssetMaster.Enabled = true;
                lblAssetMaster.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[83] != "True")
            {
                btnProjectBarcode.Enabled = false;
                llbProjectBarcode.Enabled = false;
            }
            else
            {
                btnProjectBarcode.Enabled = true;
                llbProjectBarcode.Enabled = true;
            }
        }

        private void frmProjectHome_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void btnProjectMaster_Click(object sender, EventArgs e)
        {
            frmProjectmaster frmprojectmaster = new frmProjectmaster();
            fnFormShow(frmprojectmaster);
        }

        #region Function to Show Please wait form & Switch to Selected From
        private void fnFormShow(Form Frm)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            Frm.Show();
            pleaseWait.Hide();
        }
        #endregion

        private void btnProjectStatus_Click(object sender, EventArgs e)
        {
            frmProjectStatusUpdate frmProjectStatusUpdate = new frmProjectStatusUpdate();
            fnFormShow(frmProjectStatusUpdate);
        }

        private void llProjectMaster_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnProjectMaster_Click(sender, e);
        }

        private void llProjectStatus_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnProjectStatus_Click(sender, e);
        }

        private void btnWarrantyShortShipment_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectUpdate PUpdate = new Project_Master.frmProjectUpdate();
            fnFormShow(PUpdate);
        }

        private void llbWarrantyShortShipment_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnWarrantyShortShipment_Click(sender, e);
        }

        private void btnProjectInstallation_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectInstall PInstall = new Project_Master.frmProjectInstall();
            fnFormShow(PInstall);
        }

        private void llProjectInstallation_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnProjectInstallation_Click(sender, e);
        }

        private void btnProjectTransfer_Click(object sender, EventArgs e)
        {
            Item_Return_Adjust_Stock.frmTranferForm TransferForm = new Item_Return_Adjust_Stock.frmTranferForm();
            fnFormShow(TransferForm);
        }

        private void llbProjectTransfer_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnProjectTransfer_Click(sender, e);
        }

        private void btnProjectDocuments_Click(object sender, EventArgs e)
        {
            Project_Documents.frmProjectDocs PDC = new Project_Documents.frmProjectDocs();
            fnFormShow(PDC);
        }

        private void llbProjectDocs_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnProjectDocuments_Click(sender, e);
        }

        private void llbProjectStatusUpdate_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnProjectStatusupdate_Click(sender, e);
        }

        private void btnProjectStatusupdate_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectShipmentStatusUpdate PrSU = new frmProjectShipmentStatusUpdate();
            fnFormShow(PrSU);
        }

        private void llbProjectTransferRequest_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnProjectTransferRequest_Click(sender, e);
        }

        private void btnProjectTransferRequest_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectTransferRequest TRE = new frmProjectTransferRequest();
            fnFormShow(TRE);
        }

        private void btnProjectApprove_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectApprove PApprove = new frmProjectApprove();
            fnFormShow(PApprove);
        }

        private void lblProjectApprove_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnProjectApprove_Click(sender, e);
        }

        private void btnGMApprove_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectApproveGM GM = new frmProjectApproveGM();
            fnFormShow(GM);
        }

        private void llbGMApprove_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnGMApprove_Click(sender, e);
        }

        private void btnAssetMaster_Click(object sender, EventArgs e)
        {
            AssetMaster.frmAssetmaster frmAssetmaster = new AssetMaster.frmAssetmaster();
            fnFormShow(frmAssetmaster);
        }

        private void lblAssetMaster_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnAssetMaster_Click(sender, e);
        }

        private void LblProjectTracker_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Project_Master.frmProjectTracker frmprotacker = new Project_Master.frmProjectTracker();
            fnFormShow(frmprotacker);
        }

        private void btnProjectBarcode_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectBarcode frmProjectBarcode = new frmProjectBarcode();
            fnFormShow(frmProjectBarcode);
        }

        private void llbProjectBarcode_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnProjectBarcode_Click(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
