﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Collections;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmProjectApproveGM : Form
    {
        public frmProjectApproveGM()
        {
            InitializeComponent();
        }
        frmForm2 frm = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtProjectList = new DataTable();
        DataTable dtProjectOrderEntry = new DataTable();
        DataTable dtApproveProject = new DataTable();
        DataTable dtDGDatatable = new DataTable();
        private void frmProjectApproveGM_Load(object sender, EventArgs e)
        {
            if (login.GetUserDetails[2].ToLower() == "vivek g")
            {
                dtApproveProject = DAL.fnGMProjectList(null).Tables[0];
                foreach (DataRow DR in dtApproveProject.Rows)
                {
                    if (!cmbGMApproveList.Items.Contains(DR["ProjectCode"].ToString()))
                        cmbGMApproveList.Items.Add(DR["ProjectCode"].ToString());
                }
                if (cmbGMApproveList.Items.Count > 0)
                {
                    cmbGMApproveList.DroppedDown = true;
                }
                chkloadOldProjects.Visible = false;
            }
            else if (login.GetUserDetails[2].ToLower() == "hebbarrk")
            {
                dtApproveProject = DAL.fnGMProjectList1(0,null).Tables[0];
                foreach (DataRow DR in dtApproveProject.Rows)
                {
                    if (!cmbGMApproveList.Items.Contains(DR["ProjectCode"].ToString()))
                        cmbGMApproveList.Items.Add(DR["ProjectCode"].ToString());
                }
                if (cmbGMApproveList.Items.Count > 0)
                {
                    cmbGMApproveList.DroppedDown = true;
                }
                chkloadOldProjects.Visible = true;
            }
        }

        private void cmbGMApproveList_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtProjectList = DAL.fnProjectList(cmbGMApproveList.Text).Tables[0]; //get selected project from projectMaster database
            if (dtProjectList.Rows.Count > 0)
            {
                txtPMProjectDescription.Text = dtProjectList.Rows[0]["ProjectDescription"].ToString();
                txtCustomer.Text = dtProjectList.Rows[0]["Customer"].ToString();
                cmbProject8020.SelectedItem = dtProjectList.Rows[0]["project8020"].ToString();
                cmbCustomizationlevel.SelectedItem = dtProjectList.Rows[0]["customizationlevel"].ToString();
                txtAssembleDate.Text = dtProjectList.Rows[0]["AssembleDate"].ToString();
            }
            else
            {
                txtPMProjectDescription.ResetText();
                txtCustomer.ResetText();
                txtAssembleDate.ResetText();
                cmbProject8020.SelectedIndex = -1;
                cmbCustomizationlevel.SelectedIndex = -1;
            }

            dtProjectOrderEntry = DAL.fnProjectOrderEntry(cmbGMApproveList.Text, 1).Tables[0];
            if (dtProjectOrderEntry.Rows.Count > 0)
            {
                txtPaymenttrerms.Text = dtProjectOrderEntry.Rows[0]["PaymentTerms"].ToString();
                txtProjectMargin.Text = dtProjectOrderEntry.Rows[0]["ProjectMargin"].ToString();
                txtOrderValueinINR.Text = dtProjectOrderEntry.Rows[0]["OrderValueinINR"].ToString();
                txtTargetMaterialmargin.Text = dtProjectOrderEntry.Rows[0]["TargetMargin"].ToString();
            }
            else
            {
                txtPaymenttrerms.ResetText();
                txtProjectMargin.ResetText();
                txtOrderValueinINR.ResetText();
                txtTargetMaterialmargin.ResetText();
            }

            dtDGDatatable = DAL.fnDirectProjectBOMList(cmbGMApproveList.Text).Tables[0];
            double totalamount = 0;
            if (dtDGDatatable.Rows.Count > 0)
            {
                //  dgItemOrProductList.AutoGenerateColumns = false;
                // dgItemOrProductList.DataSource = dtDGDatatable;



                // Datagridviewcolor("PProductCode", dgItemOrProductList);
                fnTotalCalucalation();
                lstusers.Items.Clear();
                foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                {
                    if (!string.IsNullOrEmpty(dgvr.Cells["PProductCode"].Value.ToString()))
                    {
                        totalamount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                    }
                }
                //foreach (DataRow dr in dtDGDatatable.Rows)
                //{
                //    if (!string.IsNullOrEmpty(dr["CreatedBy"].ToString()))
                //    {
                //        DataTable dtlogindetails = DAL.fnloginemail(dtDGDatatable.Rows[0]["CreatedBy"].ToString()).Tables[0];
                //        if (!lstusers.Items.Contains(dtlogindetails.Rows[0]["emailid"].ToString()))
                //        {
                //            lstusers.Items.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                //        }
                //    }
                //}

                lstusers.Items.Add("ravi@biss.in");
                lstusers.Items.Add("chandru@biss.in");
            }
            else
            {
                dgItemOrProductList.AutoGenerateColumns = false;
                dgItemOrProductList.DataSource = null;
            }
            txtBOMCost.Text = Math.Round(totalamount).ToString();

        }


        private void fnTotalCalucalation()
        {
            DataView view = dtDGDatatable.DefaultView;
            view.Sort = "SLNO ASC";
            dtDGDatatable = view.ToTable();
            DataTable dtExcelImport = new DataTable();
            dtExcelImport = dtDGDatatable.Copy();
            double sQty;
            if (dtExcelImport.Rows.Count > 0)
            {
                Dictionary<string, double> dicSum = new Dictionary<string, double>();
                foreach (DataRow row in dtExcelImport.Rows)
                {
                    // if (!string.IsNullOrEmpty(row[3].ToString()))
                    {
                        string group = row["ProductType"].ToString();
                        double rate = Convert.ToDouble(row["Quantity"]) * Convert.ToDouble(row["UnitCost"]);
                        if (dicSum.ContainsKey(group))
                            dicSum[group] += rate;
                        else
                            dicSum.Add(group, rate);
                    }
                }
                DataTable UniqueRecords = RemoveDuplicateRows(dtExcelImport, "ProductType");

                foreach (var group in dicSum)
                {
                    foreach (DataRow FinalItems in dtExcelImport.Rows)
                    {
                        if (FinalItems["ProductType"].ToString() == group.Key.ToString())
                        {
                            sQty = group.Value;
                            FinalItems["UnitCost"] = sQty;

                            break;
                        }
                    }
                }
            }

            foreach (DataRow row in dtDGDatatable.Rows)
            {
                if (string.IsNullOrEmpty(row["ProductCode"].ToString()))
                {
                    foreach (DataRow FinalItems in dtExcelImport.Rows)
                    {
                        if (row["ProductType"].ToString() == FinalItems["ProductType"].ToString())
                        {
                            row["UnitCost"] = FinalItems["UnitCost"].ToString();
                            //row["BreakupTotal"] = FinalItems["BreakupTotal"].ToString();
                            break;
                        }
                    }
                }
            }

            dgItemOrProductList.AutoGenerateColumns = false;
            dgItemOrProductList.DataSource = dtDGDatatable;
            Datagridviewcolor("PProductCode", dgItemOrProductList);

        }


        public DataTable RemoveDuplicateRows(DataTable table, string DistinctColumn)
        {
            try
            {
                ArrayList UniqueRecords = new ArrayList();
                ArrayList DuplicateRecords = new ArrayList();

                foreach (DataRow dRow in table.Rows)
                {
                    if (UniqueRecords.Contains(dRow[DistinctColumn]))
                        DuplicateRecords.Add(dRow);
                    else
                        UniqueRecords.Add(dRow[DistinctColumn]);

                }
                if (DuplicateRecords.Count > 0)
                {
                    foreach (DataRow dRow in DuplicateRecords)
                    {
                        table.Rows.Remove(dRow);
                    }
                }
                return table;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;

            }
        }

        private void Datagridviewcolor(string ColumnName, DataGridView dgDataGridView)
        {
            int iRow = 0;
            foreach (DataGridViewRow dgr in dgDataGridView.Rows)
            {

                if ((dgr.Cells[ColumnName].Value.ToString()) == "")
                {
                    dgr.DefaultCellStyle.BackColor = Color.BurlyWood;
                }
                else
                {
                    dgItemOrProductList.Rows[iRow].Visible = false;
                }
                iRow++;
            }
        }

        private void txtTargetMaterialmargin_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtTargetMaterialmargin.Text))
            {
                txtTargetValue.Text = Math.Round((1 - (Convert.ToDouble(txtTargetMaterialmargin.Text) / 100)) * Convert.ToDouble(txtOrderValueinINR.Text)).ToString();
            }
        }

        private void fnExit()
        {
            this.Hide();
            frm.Show();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }

        private void frmProjectApproveGM_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (dgItemOrProductList.Rows.Count == 0)
            {
                DialogResult DR = MessageBox.Show("Do you want to approve a Project without Project BOM? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.Yes)
                {
                    fnApproveProject();
                }

            }
            else
            {
                fnApproveProject();
            }
        }

        private void fnApproveProject()
        {
            if (login.GetUserDetails[2] == "Vivek G")
            {
                GlobalClass.iSuccess = DAL.fnAddProject(61, cmbGMApproveList.Text, txtPMProjectDescription.Text,"","", dtpPMCreatedDate.Text,
                          "", "", "WIP", "", "", "", login.GetUserDetails[2], "", "", false, cmbProject8020.Text, cmbCustomizationlevel.Text, "", "", "", "");

                //fnAlertMail("Vivek G", lstusers);
                fnAlertMail1("Hebbarrk", lstusers);
                MessageBox.Show(" Project " + txtPMProjectDescription.Text + " approved.", "Success", 0, MessageBoxIcon.Information);
                this.Hide();
                frmProjectApproveGM GM = new frmProjectApproveGM();
                GM.Show();
            }
            else if (login.GetUserDetails[2] == "Hebbarrk")
            {
                GlobalClass.iSuccess = DAL.fnAddProject(6, cmbGMApproveList.Text, txtPMProjectDescription.Text,"","", dtpPMCreatedDate.Text,
                          "", "", "WIP", "", "", "", login.GetUserDetails[2], "", "", false, cmbProject8020.Text, cmbCustomizationlevel.Text, "", "", "", "");

                fnAlertMail("Vivek G", lstusers);

                MessageBox.Show(" Project " + txtPMProjectDescription.Text + " approved.", "Success", 0, MessageBoxIcon.Information);
                this.Hide();
                frmProjectApproveGM GM = new frmProjectApproveGM();
                GM.Show();
            }
        }

        public void fnAlertMail(string sUser, ListBox sCC)
        {
            try
            {
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0];
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);


                        oMsg.Subject = "Project " + txtPMProjectDescription.Text + " approved";
                        oMsg.HTMLBody = "Dear " + sUser.ToUpper() + ", <br /><br /> Project BOM <font color='blue'>" + cmbGMApproveList.Text + "  " + txtPMProjectDescription.Text + " </font> approved. <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();


                        if (sCC.Items.Count > 0)
                        {
                            Outlook.Recipient oRecip;
                            List<string> sCCRecipsList = new List<string>();
                            foreach (string tempTO in sCC.Items)
                            {
                                if (tempTO != null)
                                    sCCRecipsList.Add(tempTO);
                            }
                            foreach (string t in sCCRecipsList)
                            {

                                oRecip = (Outlook.Recipient)oRecips.Add(t);
                                oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                                oRecip.Resolve();
                            }
                            oMsg.Send();
                            oRecip = null;
                        }
                        else
                        {
                            // Send.
                            oMsg.Send();
                            // Clean up.
                            oRecips = null;
                        }


                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        public void fnAlertMail1(string sUser, ListBox sCC)
        {
            try
            {
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0];
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);


                        oMsg.Subject = "Project " + txtPMProjectDescription.Text + " approved";
                        oMsg.HTMLBody = "Dear " + sUser.ToUpper() + ", <br /><br /> Project BOM <font color='blue'>" + cmbGMApproveList.Text + "  " + txtPMProjectDescription.Text + " </font> sent for approval. <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();


                        if (sCC.Items.Count > 0)
                        {
                            Outlook.Recipient oRecip;
                            List<string> sCCRecipsList = new List<string>();
                            foreach (string tempTO in sCC.Items)
                            {
                                if (tempTO != null)
                                    sCCRecipsList.Add(tempTO);
                            }
                            foreach (string t in sCCRecipsList)
                            {

                                oRecip = (Outlook.Recipient)oRecips.Add(t);
                                oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                                oRecip.Resolve();
                            }
                            oMsg.Send();
                            oRecip = null;
                        }
                        else
                        {
                            // Send.
                            oMsg.Send();
                            // Clean up.
                            oRecips = null;
                        }


                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void dgItemOrProductList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (string.IsNullOrEmpty(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString()))
            {
                int iRow = 0;
                int i = Convert.ToInt32(dgItemOrProductList.CurrentRow.Cells["SLNO"].Value);
                foreach (DataGridViewRow dgr in dgItemOrProductList.Rows)
                {
                    if (dgr.Cells["PProductCode"].Value.ToString() == "" || (Convert.ToDouble(dgr.Cells["SLNO"].Value.ToString()) > i && Convert.ToDouble(dgr.Cells["SLNO"].Value.ToString()) < (i + 1)))
                    {
                        dgItemOrProductList.Rows[iRow].Visible = true;
                    }
                    else
                    {
                        dgItemOrProductList.Rows[iRow].Visible = false;
                    }

                    iRow++;
                }
            }
        }

        private void btnReview_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtRemarks.Text))
            {

                if (login.GetUserDetails[2] == "Vivek G")
                {
                    GlobalClass.iSuccess = DAL.fnAddProject(62, cmbGMApproveList.Text, txtPMProjectDescription.Text,"","", dtpPMCreatedDate.Text,
                           "", "", "WIP", "", "", "", login.GetUserDetails[2], "", "", false, cmbProject8020.Text, cmbCustomizationlevel.Text, "", "", "", "");
                    fnRejectMail("Vishal", lstusers);

                    MessageBox.Show("Project " + txtPMProjectDescription.Text + " sent for review.", "Success", 0, MessageBoxIcon.Information);
                    this.Hide();
                    frmProjectApproveGM GM = new frmProjectApproveGM();
                    GM.Show();
                }
                else if (login.GetUserDetails[2] == "Hebbarrk")
                {
                    GlobalClass.iSuccess = DAL.fnAddProject(62, cmbGMApproveList.Text, txtPMProjectDescription.Text,"","", dtpPMCreatedDate.Text,
                              "", "", "WIP", "", "", "", login.GetUserDetails[2], "", "", false, cmbProject8020.Text, cmbCustomizationlevel.Text, "", "", "", "");
                    fnRejectMail("Vishal", lstusers);

                    MessageBox.Show("Project " + txtPMProjectDescription.Text + " sent for review.", "Success", 0, MessageBoxIcon.Information);
                    this.Hide();
                    frmProjectApproveGM GM = new frmProjectApproveGM();
                    GM.Show();
                }
            }
            else
            {
                MessageBox.Show("Add remarks to review project.", "Error", 0, MessageBoxIcon.Error);
                txtRemarks.Focus();
            }
        }

        public void fnRejectMail(string sUser, ListBox sCC)
        {
            try
            {
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);


                        oMsg.Subject = "BOM of Project " + txtPMProjectDescription.Text + " sent for review";
                        oMsg.HTMLBody = "Dear " + sUser.ToUpper() + ", <br /><br /> Project BOM <font color='red'>" + cmbGMApproveList.Text + "  " + txtPMProjectDescription.Text + " </font> sent for review. <br /><br /> Remarks : '" + txtRemarks.Text + "' <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();


                        if (sCC.Items.Count > 0)
                        {
                            Outlook.Recipient oRecip;
                            List<string> sCCRecipsList = new List<string>();
                            foreach (string tempTO in sCC.Items)
                            {
                                if (tempTO != null)
                                    sCCRecipsList.Add(tempTO);
                            }
                            foreach (string t in sCCRecipsList)
                            {

                                oRecip = (Outlook.Recipient)oRecips.Add(t);
                                oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                                oRecip.Resolve();
                            }
                            oMsg.Send();
                            oRecip = null;
                        }
                        else
                        {
                            // Send.
                            oMsg.Send();
                            // Clean up.
                            oRecips = null;
                        }


                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void chkloadOldProjects_CheckedChanged(object sender, EventArgs e)
        {
            if (chkloadOldProjects.Checked)
            {
                btnSave.Enabled = false;
                btnReview.Enabled = false;
                dtApproveProject = DAL.fnGMProjectList1(1, null).Tables[0];
                foreach (DataRow DR in dtApproveProject.Rows)
                {
                    if (!cmbGMApproveList.Items.Contains(DR["ProjectCode"].ToString()))
                        cmbGMApproveList.Items.Add(DR["ProjectCode"].ToString());
                }
                //if (cmbGMApproveList.Items.Count > 0)
                //{
                //    cmbGMApproveList.DroppedDown = true;
                //}
            }
            else {
                frmProjectApproveGM frmProjectApproveGM = new frmProjectApproveGM();
                frmProjectApproveGM.Show();
                this.Hide();
                btnSave.Enabled = true;
                btnReview.Enabled = true;
            }

        }
    }
}
