﻿
namespace Erp_Project_With_Buttons.Project_Master
{
    partial class MachinePassportUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MachinePassportUpdate));
            this.comselectedprojectcode = new System.Windows.Forms.ComboBox();
            this.updateModelNumber = new System.Windows.Forms.Label();
            this.comDeviation = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.butAccept = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // comselectedprojectcode
            // 
            this.comselectedprojectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comselectedprojectcode.DropDownHeight = 130;
            this.comselectedprojectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comselectedprojectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comselectedprojectcode.FormattingEnabled = true;
            this.comselectedprojectcode.IntegralHeight = false;
            this.comselectedprojectcode.Location = new System.Drawing.Point(120, 12);
            this.comselectedprojectcode.Name = "comselectedprojectcode";
            this.comselectedprojectcode.Size = new System.Drawing.Size(214, 26);
            this.comselectedprojectcode.TabIndex = 488;
            this.comselectedprojectcode.SelectedIndexChanged += new System.EventHandler(this.comselectedprojectcode_SelectedIndexChanged);
            // 
            // updateModelNumber
            // 
            this.updateModelNumber.AutoSize = true;
            this.updateModelNumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateModelNumber.Location = new System.Drawing.Point(19, 15);
            this.updateModelNumber.Name = "updateModelNumber";
            this.updateModelNumber.Size = new System.Drawing.Size(95, 18);
            this.updateModelNumber.TabIndex = 489;
            this.updateModelNumber.Text = "Product Code:";
            // 
            // comDeviation
            // 
            this.comDeviation.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.comDeviation.Location = new System.Drawing.Point(120, 112);
            this.comDeviation.MaxLength = 1000;
            this.comDeviation.Multiline = true;
            this.comDeviation.Name = "comDeviation";
            this.comDeviation.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.comDeviation.Size = new System.Drawing.Size(624, 44);
            this.comDeviation.TabIndex = 496;
            this.comDeviation.TextChanged += new System.EventHandler(this.comDeviation_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 18);
            this.label1.TabIndex = 497;
            this.label1.Text = "Deviation:";
            // 
            // butAccept
            // 
            this.butAccept.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.butAccept.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.butAccept.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butAccept.Location = new System.Drawing.Point(56, 19);
            this.butAccept.Name = "butAccept";
            this.butAccept.Size = new System.Drawing.Size(100, 33);
            this.butAccept.TabIndex = 498;
            this.butAccept.Text = "Save";
            this.butAccept.UseVisualStyleBackColor = false;
            this.butAccept.Click += new System.EventHandler(this.butAccept_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.butAccept);
            this.groupBox1.Location = new System.Drawing.Point(120, 277);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(624, 71);
            this.groupBox1.TabIndex = 500;
            this.groupBox1.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(455, 19);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 33);
            this.button2.TabIndex = 500;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // MachinePassportUpdate
            // 
            this.ClientSize = new System.Drawing.Size(824, 372);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comDeviation);
            this.Controls.Add(this.updateModelNumber);
            this.Controls.Add(this.comselectedprojectcode);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MachinePassportUpdate";
            this.Load += new System.EventHandler(this.MachinePassportUpdate_Load_1);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button MPSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtLFRemarks;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comselectedprojectcode;
        private System.Windows.Forms.Label updateModelNumber;
        private System.Windows.Forms.TextBox comDeviation;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button butAccept;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
    }
}