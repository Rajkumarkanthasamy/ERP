﻿// ============================================================================
//  ProjectPackingList.cs
//  Namespace : Erp_Project_With_Buttons.Project_Master
//  Framework : .NET 4.5  /  Windows Forms
//
//  NuGet required:
//      Install-Package iTextSharp
//
//  DB Tables auto-created on first run:
//      ProjectPackingListHeader
//      ProjectPackingListDetail
// ============================================================================

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Font = iTextSharp.text.Font;
using Font2 = System.Drawing.Font;
using Image = iTextSharp.text.Image;
using Rectangle = iTextSharp.text.Rectangle;

namespace Erp_Project_With_Buttons.Project_Master
{
    // =========================================================================
    //  Models
    // =========================================================================

    [Serializable]
    public class BomItem
    {
        public int ID { get; set; }
        public string ProjectCode { get; set; }
        public string ProductNo { get; set; }
        public string ProductName { get; set; }
        public string ProductCode { get; set; }
        public string ProductType { get; set; }
        public decimal Quantity { get; set; }
        public string UOM { get; set; }

        public override string ToString() =>
            $"[{ProductCode}]  {ProductName}  x{Quantity} x{ProductType}";//{UOM}
    }

    public class PackingBox
    {
        public int BoxNumber { get; set; }
        public string BoxLabel { get; set; }
        public decimal GrossWeight { get; set; }
        public decimal NetWeight { get; set; }
        public string Length { get; set; }
        public string Width { get; set; }
        public string Height { get; set; }
        public string Dimensions =>
            (!string.IsNullOrWhiteSpace(Length) || !string.IsNullOrWhiteSpace(Width) || !string.IsNullOrWhiteSpace(Height))
                ? $"L{Length} x W{Width} x H{Height}"
                : "";
        public List<BomItem> Items { get; set; } = new List<BomItem>();

        public override string ToString() => BoxLabel;
    }

    [Serializable]
    public class DragPayload
    {
        public string Source { get; }
        public List<BomItem> Items { get; }
        public DragPayload(string source, List<BomItem> items) { Source = source; Items = items; }
    }

    //public string Length { get; set; }
    //public string Width { get; set; }
    //public string Height { get; set; }

    // =========================================================================
    //  Form
    // =========================================================================

    public partial class ProjectPackingList : Form
    {
        // ── Update this connection string ─────────────────────────────────────
        private const string ConnStr =
            @"Data Source=.\SQLEXPRESS;Initial Catalog=ERP_Database;Integrated Security=True";

        // ── State ─────────────────────────────────────────────────────────────
        private List<BomItem> _bom = new List<BomItem>();
        private List<PackingBox> _boxes = new List<PackingBox>();
        private List<BomItem> _nonBox = new List<BomItem>();
        private int _boxCtr = 0;
        private bool _loading = false;   // suppress SelectedIndexChanged during refresh
        private string _projectCode = "";
        DataAccessLayer DAL = new DataAccessLayer();
        frmForm2 Home = new frmForm2();
        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataTable ProjectPackingListHeaderList = new DataTable();

        // =========================================================================
        //  INIT
        // =========================================================================

        public ProjectPackingList()
        {
            InitializeComponent();

        }

        private void ProjectPackingList_Load(object sender, EventArgs e)
        {
            //EnsureTablesExist();
            LoadProjectCombo();
            GeneratePackingNo();
            SetBoxDetailEnabled(false);
            SetStatus("Ready. Select a project and click Load BOM.");
        }

        // =========================================================================
        //  PROJECT COMBO / LOAD BOM
        // =========================================================================

        private void LoadProjectCombo()
        {
            try
            {
                cmbProject.Items.Clear();
                //   cmbProject.Items.Add("");
                DataTable ProjectList = DAL.fnProjectBOMList(null).Tables[0];
                foreach (DataRow dr in ProjectList.Rows)
                {
                    if (!cmbProject.Items.Contains(dr["ProjectCode"].ToString()))
                        cmbProject.Items.Add(dr["ProjectCode"].ToString());
                }

                //fnAllProjectList_
                //mpProjectOrderEntry

                //getProjectDetailsPacking

                




            }
            catch (Exception ex) { Err("LoadProjectCombo", ex); }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            btnViewPrint.Enabled = true;
            PackingVersion.Text = "-";
            if (cmbProject.SelectedIndex <= 0)
            { Warn("Please select a project."); return; }

            _projectCode = cmbProject.SelectedItem.ToString();
            ClearAll();
            LoadBom();
        }

        private void RebuildBomBalance()
        {
            // Collect all items already used in Box + NonBox
            HashSet<int> usedItemIds = new HashSet<int>();

            foreach (var box in _boxes)
                foreach (var item in box.Items)
                    usedItemIds.Add(item.ID);

            foreach (var item in _nonBox)
                usedItemIds.Add(item.ID);

            // Remove duplicates from _bom
            _bom = _bom
                .Where(i => !usedItemIds.Contains(i.ID))
                .GroupBy(i => i.ID)
                .Select(g => g.First())
                .ToList();
        }

        private void ParseDimensions(string dbValue, out string length, out string width, out string height)
        {
            length = width = height = "";

            if (string.IsNullOrWhiteSpace(dbValue))
                return;

            // Expected format: L23 x W213 x H4
            var parts = dbValue.Split('x');

            foreach (var part in parts)
            {
                var p = part.Trim();

                if (p.StartsWith("L", StringComparison.OrdinalIgnoreCase))
                    length = p.Substring(1).Trim();
                else if (p.StartsWith("W", StringComparison.OrdinalIgnoreCase))
                    width = p.Substring(1).Trim();
                else if (p.StartsWith("H", StringComparison.OrdinalIgnoreCase))
                    height = p.Substring(1).Trim();
            }
        }


        private void LoadPackingListData_FromDAL(string packingNo, int version)
        {
            _bom.Clear();
            _boxes.Clear();
            _nonBox.Clear();

            DataTable dt =
                DAL.fnGetProjectPackingListHeader(null, packingNo).Tables[0];
           // MessageBox.Show(dt.Rows.Count.ToString());

            foreach (DataRow dr in dt.Rows)
            {
                BomItem item = new BomItem
                {
                    ID = Convert.ToInt32(dr["BomID"]),
                    ProductNo = dr["ProductNo"].ToString(),
                    ProductName = dr["ProductName"].ToString(),
                    ProductCode = dr["ProductCode"].ToString(),
                    Quantity = Convert.ToDecimal(dr["Quantity"]),
                    ProductType = dr["ProductType"].ToString(),
                    UOM ="UOM"
                };

                if (dr["ItemType"].ToString() == "BOX")
                {
                    int boxNumber = Convert.ToInt32(dr["BoxNumber"]);
                    PackingBox box = _boxes.FirstOrDefault(b => b.BoxNumber == boxNumber);

                    string length, width, height;
                    ParseDimensions(dr["BoxDimensions"].ToString(), out length, out width, out height);

                    if (box == null)
                    {

                        box = new PackingBox
                        {
                            BoxNumber = boxNumber,
                            BoxLabel = dr["BoxLabel"].ToString(),
                            GrossWeight = Convert.ToDecimal(dr["GrossWeight"]),
                            NetWeight = Convert.ToDecimal(dr["NetWeight"]),
                            Length = length,
                            Width = width,
                            Height = height

                        };
                        _boxes.Add(box);
                    }

                    box.Items.Add(item);
                }
                else
                {
                    _nonBox.Add(item);
                }

                _bom.Add(item);
            }
            RebuildBomBalance();
            RefreshBom();
            RefreshBoxList();
            RefreshNonBox();
        }


        private void LoadBom()
        {
            ProjectPackingListHeaderList.Clear();
            ProjectPackingListHeaderList = DAL.fnGetProjectPackingListHeader(_projectCode, null).Tables[0];

            if (ProjectPackingListHeaderList.Rows.Count > 0)
            {
                PackingVersion.Text = ProjectPackingListHeaderList.Rows[0]["version"].ToString();
                LoadPackingListData_FromDAL(ProjectPackingListHeaderList.Rows[0]["PackingNo"].ToString(),int.Parse(ProjectPackingListHeaderList.Rows[0]["version"].ToString()) );
                DataTable fnProjectBOMDetails = DAL.fnProjectBOMList(_projectCode).Tables[0];
                _bom.Clear();
                //MessageBox.Show(fnProjectBOMDetails.Rows.Count.ToString());
                foreach (DataRow rdr in fnProjectBOMDetails.Rows)
                {
                    _bom.Add(new BomItem
                    {
                        ID = Convert.ToInt32(rdr["ID"]),
                        ProjectCode = rdr["ProjectCode"].ToString(),
                        ProductNo = rdr["ProductNo"].ToString(),
                        ProductName = rdr["ProductName"].ToString(),
                        ProductCode = rdr["ProductCode"].ToString(),
                        ProductType = rdr["ProductType"].ToString(),
                        Quantity = Convert.ToDecimal(rdr["Quantity"]),
                        UOM = rdr["UOM"].ToString()
                    });
                }
                RebuildBomBalance();
                RefreshBom();
                btnSave.Enabled = false;
            }
            else
            {
                btnSave.Enabled = true;
                try
                {

                    DataTable fnProjectBOMDetails = DAL.fnProjectBOMList(_projectCode).Tables[0];
                    _bom.Clear();
                    foreach (DataRow rdr in fnProjectBOMDetails.Rows)
                    {
                        _bom.Add(new BomItem
                        {
                            ID = Convert.ToInt32(rdr["ID"]),
                            ProjectCode = rdr["ProjectCode"].ToString(),
                            ProductNo = rdr["ProductNo"].ToString(),
                            ProductName = rdr["ProductName"].ToString(),
                            ProductCode = rdr["ProductCode"].ToString(),
                            ProductType = rdr["ProductType"].ToString(),
                            Quantity = Convert.ToDecimal(rdr["Quantity"]),
                            UOM = rdr["UOM"].ToString()
                        });
                    }


                    RefreshBom();
                    SetStatus($"Loaded {_bom.Count} BOM items for [{_projectCode}].");



                    // DataTable ProjectDetails = DAL.getProjectDetailsPacking(_projectCode).Tables[0];
                }
                catch (Exception ex) { Err("LoadBom", ex); }
            }
        }

        // =========================================================================
        //  BOX MANAGEMENT
        // =========================================================================

        private void btnAddBox_Click(object sender, EventArgs e)
        {
            _boxCtr++;
            var box = new PackingBox { BoxNumber = _boxCtr, BoxLabel = $"Box {_boxCtr}" };
            _boxes.Add(box);
            RefreshBoxList();
            lstBoxes.SelectedItem = box;
            SetStatus($"Added {box.BoxLabel}.");
        }

        private void btnRemoveBox_Click(object sender, EventArgs e)
        {
            if (!(lstBoxes.SelectedItem is PackingBox box)) return;

            if (box.Items.Count > 0 &&
                MessageBox.Show($"'{box.BoxLabel}' has {box.Items.Count} item(s). Return them to BOM list?",
                    "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                _bom.AddRange(box.Items);

            _boxes.Remove(box);
            RefreshBom();
            RefreshBoxList();
            SetBoxDetailEnabled(false);
            SetStatus($"Removed {box.BoxLabel}.");
        }

        // ── Apply box detail fields ────────────────────────────────────────────

        private void btnApplyBoxInfo_Click(object sender, EventArgs e)
        {
            btnViewPrint.Enabled = false;
            btnSave.Enabled = true;
            if (!(lstBoxes.SelectedItem is PackingBox box)) return;

            box.BoxLabel = txtBoxLabel.Text.Trim();
            decimal gw; decimal.TryParse(txtGW.Text, out gw); box.GrossWeight = gw;
            decimal nw; decimal.TryParse(txtNW.Text, out nw); box.NetWeight = nw;
            box.Length = txtLength.Text.Trim();
            box.Width = txtWidth.Text.Trim();
            box.Height = txtHeight.Text.Trim();

            if (string.IsNullOrWhiteSpace(box.BoxLabel)) box.BoxLabel = $"Box {box.BoxNumber}";

            RefreshBoxList();
            lstBoxes.SelectedItem = box;
            RefreshBoxItems();
            SetStatus($"{box.BoxLabel} updated — GW:{box.GrossWeight} kg  NW:{box.NetWeight} kg  {box.Dimensions}");
        }

        // ── Context menu: rename ──────────────────────────────────────────────

        private void mnuRenameBox_Click(object sender, EventArgs e)
        {
            if (!(lstBoxes.SelectedItem is PackingBox box)) return;
            string n = SimplePrompt("Rename Box", "Label:", box.BoxLabel);
            if (!string.IsNullOrWhiteSpace(n)) { box.BoxLabel = n; txtBoxLabel.Text = n; RefreshBoxList(); }
        }

        private void mnuDeleteBox_Click(object sender, EventArgs e) => btnRemoveBox_Click(sender, e);

        // =========================================================================
        //  BOX SELECTION → populate detail fields
        // =========================================================================

        private void lstBoxes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_loading) return;
            if (lstBoxes.SelectedItem is PackingBox box)
            {
                SetBoxDetailEnabled(true);
                txtBoxLabel.Text = box.BoxLabel;
                txtGW.Text = box.GrossWeight > 0 ? box.GrossWeight.ToString("G29") : "";
                txtNW.Text = box.NetWeight > 0 ? box.NetWeight.ToString("G29") : "";
                txtLength.Text = box.Length ?? "";
                txtWidth.Text = box.Width ?? "";
                txtHeight.Text = box.Height ?? "";
            }
            else
            {
                SetBoxDetailEnabled(false);
                ClearBoxDetailFields();
            }
            RefreshBoxItems();
        }

        private void SetBoxDetailEnabled(bool on)
        {
            grpBoxInfo.Enabled = on;
            if (!on) ClearBoxDetailFields();
        }

        private void ClearBoxDetailFields()
        {
            txtBoxLabel.Text = "";
            txtGW.Text = "";
            txtNW.Text = "";
            txtLength.Text = "";
            txtWidth.Text = "";
            txtHeight.Text = "";
        }

        // =========================================================================
        //  BUTTON MOVES
        // =========================================================================

        private void btnMoveToBox_Click(object sender, EventArgs e)
        {
            if (!(lstBoxes.SelectedItem is PackingBox box))
            { Warn("Select a box first."); return; }

            var sel = lstBOM.SelectedItems.Cast<BomItem>().ToList();
            if (!sel.Any()) { Warn("Select BOM item(s) to move."); return; }

            foreach (var item in sel) { box.Items.Add(item); _bom.Remove(item); }
            RefreshBom();
            RefreshBoxItems();
        }

        private void btnMoveToList_Click(object sender, EventArgs e)
        {
            // from box items → bom
            var selBox = lstBoxItems.SelectedItems.Cast<BomItem>().ToList();
            if (selBox.Any() && lstBoxes.SelectedItem is PackingBox box)
            { foreach (var i in selBox) { _bom.Add(i); box.Items.Remove(i); } RefreshBom(); RefreshBoxItems(); return; }

            // from non-box → bom
            var selNon = lstNonBox.SelectedItems.Cast<BomItem>().ToList();
            foreach (var i in selNon) { _bom.Add(i); _nonBox.Remove(i); }
            RefreshBom(); RefreshNonBox();
        }

        private void btnMarkNonBox_Click(object sender, EventArgs e)
        {
            var sel = lstBOM.SelectedItems.Cast<BomItem>().ToList();
            if (!sel.Any()) return;
            foreach (var i in sel) { _nonBox.Add(i); _bom.Remove(i); }
            RefreshBom(); RefreshNonBox();
        }

        // =========================================================================
        //  DRAG & DROP
        // =========================================================================

        // ── BOM list ─────────────────────────────────────────────────────────

        private void lstBOM_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left || lstBOM.SelectedItems.Count == 0) return;
            lstBOM.DoDragDrop(new DragPayload("BOM", lstBOM.SelectedItems.Cast<BomItem>().ToList()), DragDropEffects.Move);
        }

        private void lstBOM_DragOver(object sender, DragEventArgs e)
        { e.Effect = e.Data.GetDataPresent(typeof(DragPayload)) ? DragDropEffects.Move : DragDropEffects.None; }

        private void lstBOM_DragDrop(object sender, DragEventArgs e)
        {
            btnViewPrint.Enabled = false;
            btnSave.Enabled = true;
            var p = e.Data.GetData(typeof(DragPayload)) as DragPayload; if (p == null) return;
            if (p.Source == "BOX" && lstBoxes.SelectedItem is PackingBox sb)
            { foreach (var i in p.Items) { sb.Items.Remove(i); _bom.Add(i); } RefreshBom(); RefreshBoxItems(); }
            else if (p.Source == "NONBOX")
            { foreach (var i in p.Items) { _nonBox.Remove(i); _bom.Add(i); } RefreshBom(); RefreshNonBox(); }
        }

        // ── Box item list ──────────────────────────────────────────────────────

        private void lstBoxItems_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left || lstBoxItems.SelectedItems.Count == 0) return;
            lstBoxItems.DoDragDrop(new DragPayload("BOX", lstBoxItems.SelectedItems.Cast<BomItem>().ToList()), DragDropEffects.Move);
        }

        private void lstBoxItems_DragOver(object sender, DragEventArgs e)
        { e.Effect = e.Data.GetDataPresent(typeof(DragPayload)) ? DragDropEffects.Move : DragDropEffects.None; }

        private void lstBoxItems_DragDrop(object sender, DragEventArgs e)
        {
            btnViewPrint.Enabled = false;
            btnSave.Enabled = true;
            //MessageBox.Show("happing...!");
            var p = e.Data.GetData(typeof(DragPayload)) as DragPayload; if (p == null) return;
            if (!(lstBoxes.SelectedItem is PackingBox dest)) return;

            if (p.Source == "BOM")
            { foreach (var i in p.Items) { _bom.Remove(i); dest.Items.Add(i); } RefreshBom(); }
            else if (p.Source == "BOX")
            { foreach (var b in _boxes) foreach (var i in p.Items) if (b.Items.Contains(i)) { b.Items.Remove(i); dest.Items.Add(i); } }
            else if (p.Source == "NONBOX")
            { foreach (var i in p.Items) { _nonBox.Remove(i); dest.Items.Add(i); } RefreshNonBox(); }

            RefreshBoxItems();
        }

        // ── Box selector (drag items onto a box) ──────────────────────────────

        private void lstBoxes_MouseDown(object sender, MouseEventArgs e) { }

        private void lstBoxes_DragOver(object sender, DragEventArgs e)
        {
            int idx = lstBoxes.IndexFromPoint(lstBoxes.PointToClient(new Point(e.X, e.Y)));
            if (idx >= 0) lstBoxes.SelectedIndex = idx;
            e.Effect = e.Data.GetDataPresent(typeof(DragPayload)) ? DragDropEffects.Move : DragDropEffects.None;
        }

        private void lstBoxes_DragDrop(object sender, DragEventArgs e) => lstBoxItems_DragDrop(sender, e);

        // ── Non-box list ──────────────────────────────────────────────────────

        private void lstNonBox_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left || lstNonBox.SelectedItems.Count == 0) return;
            lstNonBox.DoDragDrop(new DragPayload("NONBOX", lstNonBox.SelectedItems.Cast<BomItem>().ToList()), DragDropEffects.Move);
        }

        private void lstNonBox_DragOver(object sender, DragEventArgs e)
        { e.Effect = e.Data.GetDataPresent(typeof(DragPayload)) ? DragDropEffects.Move : DragDropEffects.None; }

        private void lstNonBox_DragDrop(object sender, DragEventArgs e)
        {
            btnViewPrint.Enabled = false;
            btnSave.Enabled = true;
            var p = e.Data.GetData(typeof(DragPayload)) as DragPayload; if (p == null) return;
            if (p.Source == "BOM")
            { foreach (var i in p.Items) { _bom.Remove(i); _nonBox.Add(i); } RefreshBom(); RefreshNonBox(); }
        }

        // =========================================================================
        //  REFRESH HELPERS
        // =========================================================================

        private void RefreshBom()
        {
            lstBOM.BeginUpdate();
            lstBOM.Items.Clear();
            foreach (var i in _bom) lstBOM.Items.Add(i);
            lstBOM.EndUpdate();
            lblBOMCount.Text = $"{_bom.Count} item(s)";
        }

        private void RefreshBoxList()
        {
            _boxCtr = _boxes.Count();
            _loading = true;
            var sel = lstBoxes.SelectedItem as PackingBox;
            lstBoxes.BeginUpdate();
            lstBoxes.Items.Clear();
            _boxes.Sort((a, b) => a.BoxNumber.CompareTo(b.BoxNumber));
            foreach (var b in _boxes) lstBoxes.Items.Add(b);
            lstBoxes.EndUpdate();
            if (sel != null && _boxes.Contains(sel)) lstBoxes.SelectedItem = sel;
            else if (_boxes.Count > 0) lstBoxes.SelectedIndex = _boxes.Count - 1;
            _loading = false;
            RefreshBoxItems();

        }

        private void RefreshBoxItems()
        {
            lstBoxItems.BeginUpdate();
            lstBoxItems.Items.Clear();
            if (lstBoxes.SelectedItem is PackingBox box)
            { foreach (var i in box.Items) lstBoxItems.Items.Add(i); lblBoxItemCount.Text = $"{box.Items.Count} item(s) in {box.BoxLabel}"; }
            else
            { lblBoxItemCount.Text = ""; }
            lstBoxItems.EndUpdate();
        }

        private void RefreshNonBox()
        {
            lstNonBox.BeginUpdate();
            lstNonBox.Items.Clear();
            foreach (var i in _nonBox) lstNonBox.Items.Add(i);
            lstNonBox.EndUpdate();
        }

        // =========================================================================
        //  SAVE
        // =========================================================================




        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_projectCode)) { Warn("Load a project first."); return; }
            if (string.IsNullOrWhiteSpace(txtPackingNo.Text)) { Warn("Packing No is required."); return; }

            // Auto-apply box info if a box is selected and user forgot to click Apply
            if (lstBoxes.SelectedItem is PackingBox cur)
                btnApplyBoxInfo_Click(null, null);

            try
            {

                //fnProjectPackingListDetail
                // using (var cn = Open())
                //using (var tx = cn.BeginTransaction())
                // {

                void PrintPackingListLines()
                {
                    int currentRow = 0;

                    // Build data table
                    DataTable dt = new DataTable();
                    dt.Columns.Add("Sl", typeof(int));
                    dt.Columns.Add("Box");
                    dt.Columns.Add("Product");
                    dt.Columns.Add("Code");
                    dt.Columns.Add("Qty");
                    dt.Columns.Add("UOM");

                    int sl = 1;

                    foreach (var box in _boxes)
                    {
                        foreach (var item in box.Items)
                        {
                            dt.Rows.Add(
                                sl++,
                                box.BoxLabel,
                                item.ProductName,
                                item.ProductCode,
                                item.Quantity,
                                item.UOM
                            );
                        }
                    }

                    foreach (var item in _nonBox)
                    {
                        dt.Rows.Add(
                            sl++,
                            "Non-Box",
                            item.ProductName,
                            item.ProductCode,
                            item.Quantity,
                            item.UOM
                        );
                    }

                    System.Drawing.Printing.PrintDocument pd = new System.Drawing.Printing.PrintDocument();

                    pd.PrintPage += (s, ll) =>
                    {
                        int left = 40;
                        int top = 40;
                        int rowHeight = 22;

                        Font2 headerFont = new Font2("Segoe UI", 10, FontStyle.Bold);
                        Font2 rowFont = new Font2("Segoe UI", 9);

                        // Title
                        ll.Graphics.DrawString("Packing List Details", headerFont, Brushes.Black, left, top);
                        top += 30;

                        // Headers
                        ll.Graphics.DrawString("Sl", headerFont, Brushes.Black, left, top);
                        ll.Graphics.DrawString("Box", headerFont, Brushes.Black, left + 40, top);
                        ll.Graphics.DrawString("Product", headerFont, Brushes.Black, left + 140, top);
                        ll.Graphics.DrawString("Code", headerFont, Brushes.Black, left + 360, top);
                        ll.Graphics.DrawString("Qty", headerFont, Brushes.Black, left + 470, top);
                        ll.Graphics.DrawString("UOM", headerFont, Brushes.Black, left + 520, top);

                        top += 20;
                        ll.Graphics.DrawLine(Pens.Black, left, top, ll.PageBounds.Width - 40, top);
                        top += 10;

                        // Rows
                        while (currentRow < dt.Rows.Count)
                        {
                            if (top + rowHeight > ll.MarginBounds.Bottom)
                            {
                                ll.HasMorePages = true;
                                return;
                            }

                            DataRow r = dt.Rows[currentRow];

                            ll.Graphics.DrawString(r["Sl"].ToString(), rowFont, Brushes.Black, left, top);
                            ll.Graphics.DrawString(r["Box"].ToString(), rowFont, Brushes.Black, left + 40, top);
                            ll.Graphics.DrawString(r["Product"].ToString(), rowFont, Brushes.Black, left + 140, top);
                            ll.Graphics.DrawString(r["Code"].ToString(), rowFont, Brushes.Black, left + 360, top);
                            ll.Graphics.DrawString(r["Qty"].ToString(), rowFont, Brushes.Black, left + 470, top);
                            ll.Graphics.DrawString(r["UOM"].ToString(), rowFont, Brushes.Black, left + 520, top);

                            top += rowHeight;
                            currentRow++;
                        }

                        ll.HasMorePages = false;
                    };

                    PrintPreviewDialog preview = new PrintPreviewDialog();
                    preview.Document = pd;
                    preview.ShowDialog();
                }
               // PrintPackingListLines();


                try
                    {
                        string pn = txtPackingNo.Text.Trim();

                    int version = 1;

                    if(ProjectPackingListHeaderList.Rows.Count > 0)
                    {
                        int temVersion = int.Parse(ProjectPackingListHeaderList.Rows[0]["version"].ToString());
                        version = temVersion + 1;
                    }

                        //Exec(cn, tx, "DELETE FROM ProjectPackingListDetail WHERE PackingNo=@p", P("@p", pn));
                       // Exec(cn, tx, "DELETE FROM ProjectPackingListHeader WHERE PackingNo=@p", P("@p", pn));

                        // Exec(cn, tx, @"INSERT INTO ProjectPackingListHeader
                        //  (PackingNo,ProjectCode,PackingDate,TotalBoxes,CreatedDate,CreatedBy,Remarks)
                        //  VALUES(@pn,@pc,@pd,@tb,GETDATE(),@cb,'')",
                        // P("@pn", pn), P("@pc", _projectCode),
                        ////  P("@pd", dtpDate.Value.Date),
                        // P("@tb", _boxes.Count), P("@cb", Environment.UserName));
                        
                        int fnProjectPackingListHeaderStatus = DAL.fnProjectPackingListHeader(
                                                                    0,
                                                                    pn,
                                                                    _projectCode,
                                                                    dtpDate.Value.Date.ToString("yyyy-MM-dd"),
                                                                    _boxes.Count.ToString(),
                                                                    Loginfrm.GetUserDetails[2].ToString(),
                                                                    "",
                                                                    version
                                                                );


                    //Console.WriteLine("hello, world....!");
                  

                        int sl = 1;

                        if (fnProjectPackingListHeaderStatus == 1 )
                        {
                        // 3. INSERT BOX ITEMS using function
                       
                            foreach (var box in _boxes)
                            {
                                foreach (var item in box.Items)
                                {
                              
                                int fnProjectPackingListDetailStatus = DAL.fnProjectPackingListDetail(
                                         0,
                                         pn,
                                         sl.ToString(),
                                         box.BoxNumber.ToString(),
                                         box.BoxLabel,
                                         box.Dimensions,
                                         box.GrossWeight.ToString(),
                                         box.NetWeight.ToString(),
                                         item.ID.ToString(),
                                         item.ProductNo,
                                         item.ProductName,
                                         item.ProductCode,
                                         item.Quantity.ToString(),
                                         
                                         "BOX",
                                         version,
                                         item.ProductType
                                     );

                                    sl++;
                                }
                            }

                            // 4. INSERT NON-BOX ITEMS using function
                            foreach (var item in _nonBox)
                            {
                                int fnProjectPackingListDetailNONBOXStatus = DAL.fnProjectPackingListDetail(
                                    0,
                                    pn,
                                    sl.ToString(),
                                    "0",
                                    "Non-Box",
                                    "",
                                    "0",
                                    "0",
                                    item.ID.ToString(),
                                    item.ProductNo,
                                    item.ProductName,
                                    item.ProductCode,
                                    item.Quantity.ToString(),
                                    "NONBOX",
                                    1,
                                    item.ProductType
                                );

                                sl++;
                            }
                        }

                        //  foreach (var box in _boxes)
                        // foreach (var item in box.Items)
                        // {
                        //  Exec(cn, tx, @"INSERT INTO ProjectPackingListDetail
                        //    (PackingNo,SlNo,BoxNumber,BoxLabel,BoxDimensions,GrossWeight,NetWeight,
                        //    BomID,ProductNo,ProductName,ProductCode,Quantity,UOM,ItemType)
                        ////   VALUES(@pn,@sl,@bn,@bl,@bd,@gw,@nw,@bi,@pno,@pna,@pc,@qty,@uom,'BOX')",
                        //  P("@pn", pn), P("@sl", sl++),   
                        ///  P("@bn", box.BoxNumber), P("@bl", box.BoxLabel),
                        // P("@bd", box.Dimensions), P("@gw", box.GrossWeight),
                        //  P("@nw", box.NetWeight), P("@bi", item.ID),
                        //  P("@pno", item.ProductNo), P("@pna", item.ProductName),
                        //  P("@pc", item.ProductCode), P("@qty", item.Quantity),
                        //  P("@uom", item.UOM));
                        //}

                        // foreach (var item in _nonBox)
                        //  Exec(cn, tx, @"INSERT INTO ProjectPackingListDetail
                        // (PackingNo,SlNo,BoxNumber,BoxLabel,BoxDimensions,GrossWeight,NetWeight,
                        //   BomID,ProductNo,ProductName,ProductCode,Quantity,UOM,ItemType)
                        //  VALUES(@pn,@sl,0,'Non-Box','',0,0,@bi,@pno,@pna,@pc,@qty,@uom,'NONBOX')",
                        //// P("@pn", pn), P("@sl", sl++),
                        // P("@bi", item.ID), P("@pno", item.ProductNo),
                        // P("@pna", item.ProductName), P("@pc", item.ProductCode),
                        // P("@qty", item.Quantity), P("@uom", item.UOM));

                       // tx.Commit();
                        SetStatus($"Packing list [{pn}] saved — {_boxes.Count} box(es), {_nonBox.Count} non-box item(s).");
                        MessageBox.Show("Saved successfully!", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        btnViewPrint.Enabled = true;
                    btnSave.Enabled = false;
                    GeneratePackingNo();
                    }
                    catch(Exception ERROR) { MessageBox.Show(ERROR.ToString()); }
               // }
            }
            catch (Exception ex) { Err("Save", ex); }
        }

        // =========================================================================
        //  PDF PRINT
        // =========================================================================

        private void btnViewPrint_Click(object sender, EventArgs e)
        {
            if (_boxes.Count == 0 && _nonBox.Count == 0)
            { Warn("Nothing to print yet."); return; }

            // Auto-apply box info
            if (lstBoxes.SelectedItem is PackingBox)
                btnApplyBoxInfo_Click(null, null);

            string path = Path.Combine("C:\\Users\\Kanthara095\\OneDrive - Illinois Tool Works, Inc\\Documents\\",
                $"PackingList_{txtPackingNo.Text}_{DateTime.Now:yyyyMMddHHmmss}.pdf");
            try
            {
                BuildPdf(path);
                System.Diagnostics.Process.Start(path);
                SetStatus($"PDF opened: {path}");
            }
            catch (Exception ex) { Err("PDF", ex); }
        }

        private void BuildPdf(string path)
        {
            // Define content area height (e.g., 650 points = ~230mm)
            // A4 height = 842 points, so 842 - 100(header) - 92(footer) = 650 content
            float contentHeight = 650f;
            float headerHeight = 100f;
            float footerHeight = 92f;
            float pageWidth = PageSize.A4.Width;  // 595 points
            float pageHeight = contentHeight + headerHeight + footerHeight; // 842 points (A4)

            // Create custom page size with calculated height
            var customPage = new Rectangle(pageWidth, pageHeight);

            // Set margins: Left, Right, Top (header space), Bottom (footer space)
            var doc = new Document(customPage, 36, 36, headerHeight, footerHeight);
            var writer = PdfWriter.GetInstance(doc, new FileStream(path, FileMode.Create));

            // Pass heights to page event
            writer.PageEvent = new InstronHeaderFooter(headerHeight, footerHeight);
            doc.Open();

            // ... rest of your content code remains the same ...

            // FONTS
            var fTitle = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 10, BaseColor.BLACK);
            var fHead = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.WHITE);
            var fCell = FontFactory.GetFont(FontFactory.HELVETICA, 8, BaseColor.BLACK);
            var fBold = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.BLACK);
            var fMeta = FontFactory.GetFont(FontFactory.HELVETICA, 7, BaseColor.DARK_GRAY);

            var blue = new BaseColor(30, 80, 160);
            var grey = new BaseColor(90, 90, 90);

            DataTable ProjectDetails = DAL.getProjectDetailsPacking(_projectCode).Tables[0];

            // TITLE

            doc.Add(new Paragraph($"PACKING LIST - {ProjectDetails.Rows[0]["customer"]}", fTitle) { Alignment = Element.ALIGN_CENTER });
          
            doc.Add(new Paragraph($"Kind Attention -{ProjectDetails.Rows[0]["ContactPerson"]}", fBold) { SpacingBefore = 10, Alignment = Element.ALIGN_LEFT });
            doc.Add(new Paragraph($"Ship to - {ProjectDetails.Rows[0]["customer"]}", fBold) { SpacingBefore = 3, Alignment = Element.ALIGN_LEFT });
            doc.Add(new Paragraph($"{ProjectDetails.Rows[0]["ShiptoCustomer"]}", fBold) { SpacingBefore = 3, Alignment = Element.ALIGN_LEFT });
            doc.Add(new Paragraph($"PO ref - {ProjectDetails.Rows[0]["PONo"]} Date:{ProjectDetails.Rows[0]["PODate"]}", fBold) { SpacingBefore = 3, SpacingAfter = 10, Alignment = Element.ALIGN_LEFT });
            

            //  doc.Add(new Paragraph(
            //    $"Project: {_projectCode}   |   Packing No: {txtPackingNo.Text}   |   Date: {dtpDate.Value:dd-MM-yyyy}",
            //    fMeta)
            //{ Alignment = Element.ALIGN_CENTER, SpacingAfter = 10 });

            // BOXES
            foreach (var box in _boxes)
            {
                if (box.Items.Count == 0) continue;

                var bt = new PdfPTable(1) { WidthPercentage = 100, SpacingBefore = 10 };
                string hdr = $"  {box.BoxLabel.ToUpper()}";
                if (!string.IsNullOrWhiteSpace(box.Dimensions)) hdr += $"   ({box.Dimensions})";
                if (box.GrossWeight > 0) hdr += $"   GW: {box.GrossWeight} kg   NW: {box.NetWeight} kg";
                bt.AddCell(new PdfPCell(new Phrase(hdr, fHead)) { BackgroundColor = blue, Padding = 5 });
                doc.Add(bt);

                var t = new PdfPTable(new float[] { 5, 22, 38, 8, 20 }) { WidthPercentage = 100 };
                foreach (var h in new[] { "S/N", "Product Code", "Product Name", "Qty",  "Type" })
                    t.AddCell(new PdfPCell(new Phrase(h, fHead))
                    { BackgroundColor = blue, Padding = 3, HorizontalAlignment = Element.ALIGN_CENTER });

                int sn = 1;
                foreach (var item in box.Items)
                {
                    var bg = sn % 2 == 0 ? new BaseColor(236, 244, 255) : BaseColor.WHITE;
                    t.AddCell(new PdfPCell(new Phrase(sn++.ToString(), fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.ProductCode, fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.ProductName, fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.Quantity.ToString("G29"), fCell)) { BackgroundColor = bg, Padding = 3 });
                   // t.AddCell(new PdfPCell(new Phrase(item.UOM, fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.ProductType, fCell)) { BackgroundColor = bg, Padding = 3 });
                }
                doc.Add(t);
            }

            // NON-BOX
            if (_nonBox.Count > 0)
            {
                var nbt = new PdfPTable(1) { WidthPercentage = 100, SpacingBefore = 14 };
                nbt.AddCell(new PdfPCell(new Phrase("  NON-BOX ITEMS  (SHIP LOOSE)", fHead))
                { BackgroundColor = grey, Padding = 5 });
                doc.Add(nbt);

                var t = new PdfPTable(new float[] { 5, 22, 44, 8, 14 }) { WidthPercentage = 100 };
                foreach (var h in new[] { "S/N", "Product No", "Product Name", "Qty",  "Type" })
                    t.AddCell(new PdfPCell(new Phrase(h, fHead))
                    { BackgroundColor = grey, Padding = 3, HorizontalAlignment = Element.ALIGN_CENTER });

                int sn = 1;
                foreach (var item in _nonBox)
                {
                    var bg = sn % 2 == 0 ? new BaseColor(248, 248, 248) : BaseColor.WHITE;
                    t.AddCell(new PdfPCell(new Phrase(sn++.ToString(), fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.ProductCode, fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.ProductName, fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.Quantity.ToString("G29"), fCell)) { BackgroundColor = bg, Padding = 3 });
                    //t.AddCell(new PdfPCell(new Phrase(item.UOM, fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.ProductType, fCell)) { BackgroundColor = bg, Padding = 3 });
                }
                doc.Add(t);
            }

            // SUMMARY
            int totalBoxItems = _boxes.Sum(b => b.Items.Count);
            doc.Add(new Paragraph(
                $"\nTotal Boxes: {_boxes.Count}   |   Box Items: {totalBoxItems}" +
                $"   |   Non-Box Items: {_nonBox.Count}   |   Grand Total: {totalBoxItems + _nonBox.Count}",
                fBold)
            { SpacingBefore = 10, Alignment = Element.ALIGN_RIGHT });

            doc.Add(new Paragraph(
                $"\nGenerated: {DateTime.Now:dd-MMM-yyyy HH:mm}   |   By: {Environment.UserName}", fMeta)
            { Alignment = Element.ALIGN_RIGHT });

            doc.Close();
        }

        // Page event class with configurable heights
        public class InstronHeaderFooter : PdfPageEventHelper
        {
            private Image _instronLogo;
            private Image _itwLogo;
            private readonly BaseColor _redLine = new BaseColor(180, 20, 60);
            private readonly Font _fFooter = FontFactory.GetFont(FontFactory.HELVETICA, 7, BaseColor.DARK_GRAY);
            private readonly float _headerHeight;
            private readonly float _footerHeight;
            private bool _imagesLoaded = false;

            public InstronHeaderFooter(float headerHeight, float footerHeight)
            {
                _headerHeight = headerHeight;
                _footerHeight = footerHeight;
            }

            private void LoadImages()
            {
                if (_imagesLoaded) return;

                try
                {
                    string instronPath = @"C:\Databasepath\InstronLogo3.jpg";
                    string itwPath = @"C:\Databasepath\ITWLogo.jpg";

                    if (File.Exists(instronPath))
                    {
                        _instronLogo = Image.GetInstance(instronPath);
                        _instronLogo.ScalePercent(40);
                    }
                    if (File.Exists(itwPath))
                    {
                        _itwLogo = Image.GetInstance(itwPath);
                        _itwLogo.ScalePercent(40);
                    }
                }
                catch { }
                _imagesLoaded = true;
            }

            public override void OnStartPage(PdfWriter writer, Document document)
            {
                base.OnStartPage(writer, document);
                LoadImages();

                var cb = writer.DirectContent;
                var pageHeight = document.PageSize.Height;

                // Header positioned at very top
                var headerTable = new PdfPTable(2) { WidthPercentage = 100 };
                headerTable.SetWidths(new float[] { 70, 30 });
                headerTable.TotalWidth = document.PageSize.Width - document.LeftMargin - document.RightMargin;

                var instronCell = new PdfPCell() { Border = Rectangle.NO_BORDER, VerticalAlignment = Element.ALIGN_BOTTOM };
                if (_instronLogo != null) instronCell.AddElement(_instronLogo);
                headerTable.AddCell(instronCell);

                var itwCell = new PdfPCell() { Border = Rectangle.NO_BORDER, VerticalAlignment = Element.ALIGN_BOTTOM, HorizontalAlignment = Element.ALIGN_RIGHT };
                if (_itwLogo != null) itwCell.AddElement(_itwLogo);
                headerTable.AddCell(itwCell);

                // Write header starting 10 points from top
                headerTable.WriteSelectedRows(0, -1, document.LeftMargin, pageHeight - 10, cb);

                // Red line at bottom of header area
                cb.SetColorStroke(_redLine);
                cb.SetLineWidth(2f);
                float lineY = pageHeight - _headerHeight + 10; // 10 points above content area
                cb.MoveTo(document.LeftMargin, lineY);
                cb.LineTo(document.PageSize.Width - document.RightMargin, lineY);
                cb.Stroke();
            }

            public override void OnEndPage(PdfWriter writer, Document document)
            {
                base.OnEndPage(writer, document);

                var cb = writer.DirectContent;

                // Red line at top of footer area
                cb.SetColorStroke(_redLine);
                cb.SetLineWidth(1f);
                float lineY = _footerHeight - 5; // 5 points above footer text
                cb.MoveTo(document.LeftMargin, lineY);
                cb.LineTo(document.PageSize.Width - document.RightMargin, lineY);
                cb.Stroke();

                // Footer table
                var footerTable = new PdfPTable(2) { WidthPercentage = 100 };
                footerTable.SetWidths(new float[] { 60, 40 });
                footerTable.TotalWidth = document.PageSize.Width - document.LeftMargin - document.RightMargin;

                var leftCell = new PdfPCell() { Border = Rectangle.NO_BORDER };
                leftCell.AddElement(new Paragraph("ITW India Private Limited (Instron Division)",
                    FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.BLACK)));
                leftCell.AddElement(new Paragraph("No. 497E, 14th Cross, 4th Phase, PIA, Bangalore – 560 058, India", _fFooter));
                leftCell.AddElement(new Paragraph("Ph: +91 (80) 28360184, Fax: +91 (80) 28360047", _fFooter));

                var webEmail = new Paragraph();
                webEmail.Add(new Chunk("www.instron.com ", FontFactory.GetFont(FontFactory.HELVETICA, 7, BaseColor.BLUE)));
                webEmail.Add(new Chunk("Email: sales.india@instron.com", _fFooter));
                leftCell.AddElement(webEmail);
                footerTable.AddCell(leftCell);

                var rightCell = new PdfPCell() { Border = Rectangle.NO_BORDER };
                rightCell.AddElement(new Paragraph("Registered Office:",
                    FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.BLACK)));
                rightCell.AddElement(new Paragraph("ITW India Private Limited.", _fFooter));
                rightCell.AddElement(new Paragraph("Plot Nos. 50-59, Sector-25, Faridabad, Ballabgarh,", _fFooter));
                rightCell.AddElement(new Paragraph("Haryana, India- 121004", _fFooter));
                rightCell.AddElement(new Paragraph("CIN No.- U32301HR1979PTC038643", _fFooter));
                footerTable.AddCell(rightCell);

                // Write footer at bottom of page
                footerTable.WriteSelectedRows(0, -1, document.LeftMargin, _footerHeight - 10, cb);
            }
        }

        private void BuildPdfv2(string path)
        {
            // Page event helper class for repeating header/footer
            var pageEventHelper = new InstronHeaderFooterv2();

            var doc = new Document(PageSize.A4, 36, 36, 90, 90);
            var writer = PdfWriter.GetInstance(doc, new FileStream(path, FileMode.Create));
            writer.PageEvent = pageEventHelper;
            doc.Open();

            // Fonts
            var fTitle = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14, BaseColor.BLACK);
            var fHead = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.WHITE);
            var fCell = FontFactory.GetFont(FontFactory.HELVETICA, 8, BaseColor.BLACK);
            var fBold = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.BLACK);
            var fMeta = FontFactory.GetFont(FontFactory.HELVETICA, 7, BaseColor.DARK_GRAY);

            var blue = new BaseColor(30, 80, 160);
            var grey = new BaseColor(90, 90, 90);

            // ── TITLE ──────────────────────────────────────────────────────────
            doc.Add(new Paragraph("PACKING LIST", fTitle) { Alignment = Element.ALIGN_CENTER });
            doc.Add(new Paragraph(
                $"Project: {_projectCode}   |   Packing No: {txtPackingNo.Text}   |   Date: {dtpDate.Value:dd-MM-yyyy}",
                fMeta)
            { Alignment = Element.ALIGN_CENTER, SpacingAfter = 10  });
            
            // ── BOXES ─────────────────────────────────────────────────────────
            foreach (var box in _boxes)
            {
                if (box.Items.Count == 0) continue;
                MessageBox.Show(doc.PageSize.Height.ToString());
                var bt = new PdfPTable(1) { WidthPercentage = 100, SpacingBefore = 10 };
                string hdr = $"  {box.BoxLabel.ToUpper()}";
                if (!string.IsNullOrWhiteSpace(box.Dimensions)) hdr += $"   ({box.Dimensions})";
                if (box.GrossWeight > 0) hdr += $"   GW: {box.GrossWeight} kg   NW: {box.NetWeight} kg";
                bt.AddCell(new PdfPCell(new Phrase(hdr, fHead)) { BackgroundColor = blue, Padding = 5 });
                doc.Add(bt);

                var t = new PdfPTable(new float[] { 5, 22, 38, 8, 7, 20 }) { WidthPercentage = 100 };
                foreach (var h in new[] { "S/N", "Product No", "Product Name", "Qty", "UOM", "Type" })
                    t.AddCell(new PdfPCell(new Phrase(h, fHead))
                    { BackgroundColor = blue, Padding = 3, HorizontalAlignment = Element.ALIGN_CENTER });

                int sn = 1;
                foreach (var item in box.Items)
                {
                    var bg = sn % 2 == 0 ? new BaseColor(236, 244, 255) : BaseColor.WHITE;
                    t.AddCell(new PdfPCell(new Phrase(sn++.ToString(), fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.ProductCode, fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.ProductName, fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.Quantity.ToString("G29"), fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.UOM, fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.ProductType, fCell)) { BackgroundColor = bg, Padding = 3 });
                }
                doc.Add(t);
            }

            // ── NON-BOX ───────────────────────────────────────────────────────
            if (_nonBox.Count > 0)
            {
                var nbt = new PdfPTable(1) { WidthPercentage = 100, SpacingBefore = 14 };
                nbt.AddCell(new PdfPCell(new Phrase("  NON-BOX ITEMS  (SHIP LOOSE)", fHead))
                { BackgroundColor = grey, Padding = 5 });
                doc.Add(nbt);

                var t = new PdfPTable(new float[] { 5, 22, 44, 8, 7, 14 }) { WidthPercentage = 100 };
                foreach (var h in new[] { "S/N", "Product No", "Product Name", "Qty", "UOM", "Type" })
                    t.AddCell(new PdfPCell(new Phrase(h, fHead))
                    { BackgroundColor = grey, Padding = 3, HorizontalAlignment = Element.ALIGN_CENTER });

                int sn = 1;
                foreach (var item in _nonBox)
                {
                    var bg = sn % 2 == 0 ? new BaseColor(248, 248, 248) : BaseColor.WHITE;
                    t.AddCell(new PdfPCell(new Phrase(sn++.ToString(), fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.ProductCode, fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.ProductName, fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.Quantity.ToString("G29"), fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.UOM, fCell)) { BackgroundColor = bg, Padding = 3 });
                    t.AddCell(new PdfPCell(new Phrase(item.ProductType, fCell)) { BackgroundColor = bg, Padding = 3 });
                }
                doc.Add(t);
            }

            // ── SUMMARY ───────────────────────────────────────────────────────
            int totalBoxItems = _boxes.Sum(b => b.Items.Count);
            doc.Add(new Paragraph(
                $"\nTotal Boxes: {_boxes.Count}   |   Box Items: {totalBoxItems}" +
                $"   |   Non-Box Items: {_nonBox.Count}   |   Grand Total: {totalBoxItems + _nonBox.Count}",
                fBold)
            { SpacingBefore = 10, Alignment = Element.ALIGN_RIGHT });

            doc.Add(new Paragraph(
                $"\nGenerated: {DateTime.Now:dd-MMM-yyyy HH:mm}   |   By: {Environment.UserName}", fMeta)
            { Alignment = Element.ALIGN_RIGHT });

            doc.Close();
        }

        // Separate page event class - add this outside your method in the same class/file
        public class InstronHeaderFooterv2 : PdfPageEventHelper
        {
            private Image _instronLogo;
            private Image _itwLogo;
            private readonly BaseColor _redLine = new BaseColor(180, 20, 60);
            private readonly Font _fFooter = FontFactory.GetFont(FontFactory.HELVETICA, 7, BaseColor.DARK_GRAY);
            private bool _imagesLoaded = false;

            private void LoadImages()
            {
                if (_imagesLoaded) return;

                try
                {
                    if (File.Exists(@"C:\Databasepath\InstronLogo3.jpg"))
                    {
                        _instronLogo = Image.GetInstance(@"C:\Databasepath\InstronLogo3.jpg");
                        _instronLogo.ScalePercent(50);
                    }
                    if (File.Exists(@"C:\Databasepath\ITWLogo.jpg"))
                    {
                        _itwLogo = Image.GetInstance(@"C:\Databasepath\ITWLogo.jpg");
                        _itwLogo.ScalePercent(50);
                    }
                }
                catch { }
                _imagesLoaded = true;
            }

            public override void OnStartPage(PdfWriter writer, Document document)
            {
                base.OnStartPage(writer, document);
                LoadImages();

                var cb = writer.DirectContent;
                var headerTable = new PdfPTable(2) { WidthPercentage = 100 };
                headerTable.SetWidths(new float[] { 70, 30 });
                headerTable.TotalWidth = document.PageSize.Width - document.LeftMargin - document.RightMargin;

                var instronCell = new PdfPCell() { Border = Rectangle.NO_BORDER, VerticalAlignment = Element.ALIGN_BOTTOM };
                if (_instronLogo != null) instronCell.AddElement(_instronLogo);
                headerTable.AddCell(instronCell);

                var itwCell = new PdfPCell() { Border = Rectangle.NO_BORDER, VerticalAlignment = Element.ALIGN_BOTTOM };
                if (_itwLogo != null) itwCell.AddElement(_itwLogo);
                headerTable.AddCell(itwCell);

                headerTable.WriteSelectedRows(0, -1, document.LeftMargin, document.PageSize.Height - 20, cb);

                cb.SetColorStroke(_redLine);
                cb.SetLineWidth(2f);
                cb.MoveTo(document.LeftMargin, document.PageSize.Height - 35);
                cb.LineTo(document.PageSize.Width - document.RightMargin, document.PageSize.Height - 35);
                cb.Stroke();
            }

            public override void OnEndPage(PdfWriter writer, Document document)
            {
                base.OnEndPage(writer, document);

                var cb = writer.DirectContent;

                cb.SetColorStroke(_redLine);
                cb.SetLineWidth(1f);
                cb.MoveTo(document.LeftMargin, document.BottomMargin + 60);
                cb.LineTo(document.PageSize.Width - document.RightMargin, document.BottomMargin + 60);
                cb.Stroke();

                var footerTable = new PdfPTable(2) { WidthPercentage = 100 };
                footerTable.SetWidths(new float[] { 60, 40 });
                footerTable.TotalWidth = document.PageSize.Width - document.LeftMargin - document.RightMargin;
                footerTable.DefaultCell.Border = Rectangle.NO_BORDER;

                var leftCell = new PdfPCell() { Border = Rectangle.NO_BORDER };
                leftCell.AddElement(new Paragraph("ITW India Private Limited (Instron Division)",
                    FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.BLACK)));
                leftCell.AddElement(new Paragraph("No. 497E, 14th Cross, 4th Phase, PIA, Bangalore – 560 058, India", _fFooter));
                leftCell.AddElement(new Paragraph("Ph: +91 (80) 28360184, Fax: +91 (80) 28360047", _fFooter));

                var webEmail = new Paragraph();
                webEmail.Add(new Chunk("www.instron.com ", FontFactory.GetFont(FontFactory.HELVETICA, 7, BaseColor.BLUE)));
                webEmail.Add(new Chunk("Email: sales.india@instron.com", _fFooter));
                leftCell.AddElement(webEmail);
                footerTable.AddCell(leftCell);

                var rightCell = new PdfPCell() { Border = Rectangle.NO_BORDER };
                rightCell.AddElement(new Paragraph("Registered Office:",
                    FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.BLACK)));
                rightCell.AddElement(new Paragraph("ITW India Private Limited.", _fFooter));
                rightCell.AddElement(new Paragraph("Plot Nos. 50-59, Sector-25, Faridabad, Ballabgarh,", _fFooter));
                rightCell.AddElement(new Paragraph("Haryana, India- 121004", _fFooter));
                rightCell.AddElement(new Paragraph("CIN No.- U32301HR1979PTC038643", _fFooter));
                footerTable.AddCell(rightCell);

                footerTable.WriteSelectedRows(0, -1, document.LeftMargin, document.BottomMargin + 55, cb);
            }
        }

        private void BuildPdfv1(string path)
        {
            var doc = new Document(PageSize.A4, 36, 36, 20, 20); // Increased margins for header/footer
            var writer = PdfWriter.GetInstance(doc, new FileStream(path, FileMode.Create));
            doc.Open();

            // Fonts
            var fTitle = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14, BaseColor.BLACK);
            var fHead = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.WHITE);
            var fCell = FontFactory.GetFont(FontFactory.HELVETICA, 8, BaseColor.BLACK);
            var fBold = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.BLACK);
            var fMeta = FontFactory.GetFont(FontFactory.HELVETICA, 7, BaseColor.DARK_GRAY);
            var fFooter = FontFactory.GetFont(FontFactory.HELVETICA, 7, BaseColor.DARK_GRAY);

            var blue = new BaseColor(30, 80, 160);
            var grey = new BaseColor(90, 90, 90);
            var redLine = new BaseColor(180, 20, 60); // Instron red color

            // ── HEADER ─────────────────────────────────────────────────────────
            // Add header table with logo area
            var headerTable = new PdfPTable(1) { WidthPercentage = 100 };
            headerTable.DefaultCell.Border = Rectangle.NO_BORDER;

            // Logo row - Left: Instron logo, Right: TW logo
            var logoTable = new PdfPTable(2) { WidthPercentage = 100 };
            logoTable.DefaultCell.Border = Rectangle.NO_BORDER;
            logoTable.SetWidths(new float[] { 70, 30 });
            //logoTable.DefaultCell.Border = Rectangle.NO_BORDER;

            // Left cell - Instron logo placeholder (replace with actual image)
            var instronCell = new PdfPCell() {  VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            // Uncomment to add actual logo image:
             var instronLogo = Image.GetInstance("C:\\Databasepath\\InstronLogo3.jpg");
             instronLogo.ScalePercent(50);
             instronCell.AddElement(instronLogo);
             logoTable.AddCell(instronCell);
            // var instronText = new Paragraph("INSTRON®", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 16, redLine));
            //instronCell.AddElement(instronText);
            //logoTable.AddCell(instronCell);

            // Right cell - TW logo placeholder
            // var twCell = new PdfPCell() { HorizontalAlignment = Element.ALIGN_RIGHT , Border = Rectangle.NO_BORDER };
            // var twText = new Paragraph("//TW", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK));
            //twText.Alignment = Element.ALIGN_RIGHT;
            //twCell.AddElement(twText);
            var ITWCell = new PdfPCell() { VerticalAlignment = Element.ALIGN_RIGHT, Border = Rectangle.NO_BORDER };

            var ITWLogo = Image.GetInstance("C:\\Databasepath\\ITWLogo.jpg");
            ITWLogo.ScalePercent(50);
            ITWCell.AddElement(ITWLogo);

            logoTable.AddCell(ITWCell);

            headerTable.AddCell(logoTable);

            // Red separator line
            var lineCell = new PdfPCell() {  PaddingTop = 5, PaddingBottom = 5, Border = Rectangle.NO_BORDER };
            var line = new Paragraph(new Chunk(new iTextSharp.text.pdf.draw.LineSeparator(2f, 100f, redLine, Element.ALIGN_CENTER, 0)));
            lineCell.AddElement(line);
            headerTable.AddCell(lineCell);

            doc.Add(headerTable);

            // ── TITLE ──────────────────────────────────────────────────────────
            doc.Add(new Paragraph("PACKING LIST", fTitle) { Alignment = Element.ALIGN_CENTER });
            doc.Add(new Paragraph(
                $"Project: {_projectCode}   |   Packing No: {txtPackingNo.Text}   |   Date: {dtpDate.Value:dd-MM-yyyy}",
                fMeta)
            { Alignment = Element.ALIGN_CENTER, SpacingAfter = 10 });

            // ── BOXES ─────────────────────────────────────────────────────────
            foreach (var box in _boxes)
            {
                if (box.Items.Count == 0) continue;

                // Box header row
                var bt = new PdfPTable(1) { WidthPercentage = 100, SpacingBefore = 10 };
                string hdr = $"  {box.BoxLabel.ToUpper()}";
                if (!string.IsNullOrWhiteSpace(box.Dimensions)) hdr += $"   ({box.Dimensions})";
                if (box.GrossWeight > 0) hdr += $"   GW: {box.GrossWeight} kg   NW: {box.NetWeight} kg";
                bt.AddCell(new PdfPCell(new Phrase(hdr, fHead))
                { BackgroundColor = blue, Padding = 5 });
                doc.Add(bt);

                var t = new PdfPTable(new float[] { 5, 22, 38, 8, 7, 20 }) { WidthPercentage = 100 };
                foreach (var h in new[] { "S/N", "Product No", "Product Name", "Qty", "UOM", "Type" })
                    t.AddCell(new PdfPCell(new Phrase(h, fHead))
                    { BackgroundColor = blue, Padding = 3, HorizontalAlignment = Element.ALIGN_CENTER });

                int sn = 1;
                foreach (var item in box.Items)
                {
                    var bg = sn % 2 == 0 ? new BaseColor(236, 244, 255) : BaseColor.WHITE;
                    t.AddCell(Cell(sn++.ToString(), fCell, bg));
                    t.AddCell(Cell(item.ProductCode, fCell, bg));
                    t.AddCell(Cell(item.ProductName, fCell, bg));
                    t.AddCell(Cell(item.Quantity.ToString("G29"), fCell, bg));
                    t.AddCell(Cell(item.UOM, fCell, bg));
                    t.AddCell(Cell(item.ProductType, fCell, bg));
                }
                doc.Add(t);
            }

            // ── NON-BOX ───────────────────────────────────────────────────────
            if (_nonBox.Count > 0)
            {
                var nbt = new PdfPTable(1) { WidthPercentage = 100, SpacingBefore = 14 };
                nbt.AddCell(new PdfPCell(new Phrase("  NON-BOX ITEMS  (SHIP LOOSE)", fHead))
                { BackgroundColor = grey, Padding = 5 });
                doc.Add(nbt);

                var t = new PdfPTable(new float[] { 5, 22, 44, 8, 7, 14 }) { WidthPercentage = 100 };
                foreach (var h in new[] { "S/N", "Product No", "Product Name", "Qty", "UOM", "Type" })
                    t.AddCell(new PdfPCell(new Phrase(h, fHead))
                    { BackgroundColor = grey, Padding = 3, HorizontalAlignment = Element.ALIGN_CENTER });

                int sn = 1;
                foreach (var item in _nonBox)
                {
                    var bg = sn % 2 == 0 ? new BaseColor(248, 248, 248) : BaseColor.WHITE;
                    t.AddCell(Cell(sn++.ToString(), fCell, bg));
                    t.AddCell(Cell(item.ProductCode, fCell, bg));
                    t.AddCell(Cell(item.ProductName, fCell, bg));
                    t.AddCell(Cell(item.Quantity.ToString("G29"), fCell, bg));
                    t.AddCell(Cell(item.UOM, fCell, bg));
                    t.AddCell(Cell(item.ProductType, fCell, bg));
                }
                doc.Add(t);
            }

            // ── SUMMARY ───────────────────────────────────────────────────────
            int totalBoxItems = _boxes.Sum(b => b.Items.Count);
            doc.Add(new Paragraph(
                $"\nTotal Boxes: {_boxes.Count}   |   Box Items: {totalBoxItems}" +
                $"   |   Non-Box Items: {_nonBox.Count}   |   Grand Total: {totalBoxItems + _nonBox.Count}",
                fBold)
            { SpacingBefore = 10, Alignment = Element.ALIGN_RIGHT });

            doc.Add(new Paragraph(
                $"\nGenerated: {DateTime.Now:dd-MMM-yyyy HH:mm}   |   By: {Environment.UserName}", fMeta)
            { Alignment = Element.ALIGN_RIGHT });


            // Red separator line at bottom
            var bottomLine = new Paragraph(new Chunk(new iTextSharp.text.pdf.draw.LineSeparator(1f, 100f, redLine, Element.ALIGN_CENTER, 0)));
            bottomLine.SpacingBefore = 5;
            doc.Add(bottomLine);

            // ── FOOTER ─────────────────────────────────────────────────────────
            // Add footer before closing
            var footerTable = new PdfPTable(2) { WidthPercentage = 100, SpacingBefore = 20};
            footerTable.DefaultCell.Border = Rectangle.NO_BORDER;
            footerTable.SetWidths(new float[] { 60, 40 });

            // Left side - Office address
            var leftCell = new PdfPCell() {Border = Rectangle.NO_BORDER };
            leftCell.AddElement(new Paragraph("ITW India Private Limited (Instron Division)",
                FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.BLACK)));
            leftCell.AddElement(new Paragraph("No. 497E, 14th Cross, 4th Phase, PIA, Bangalore – 560 058, India", fFooter));
            leftCell.AddElement(new Paragraph("Ph: +91 (80) 28360184, Fax: +91 (80) 28360047", fFooter));

            var webEmail = new Paragraph();
            webEmail.Add(new Chunk("www.instron.com ", FontFactory.GetFont(FontFactory.HELVETICA, 7, BaseColor.BLUE)));
            webEmail.Add(new Chunk("Email: sales.india@instron.com", fFooter));
            leftCell.AddElement(webEmail);
            footerTable.AddCell(leftCell);

            // Right side - Registered office
            var rightCell = new PdfPCell() { HorizontalAlignment = Element.ALIGN_LEFT, Border = Rectangle.NO_BORDER };
            rightCell.AddElement(new Paragraph("Registered Office:",
                FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.BLACK)));
            rightCell.AddElement(new Paragraph("ITW India Private Limited.", fFooter));
            rightCell.AddElement(new Paragraph("Plot Nos. 50-59, Sector-25, Faridabad, Ballabgarh,", fFooter));
            rightCell.AddElement(new Paragraph("Haryana, India- 121004", fFooter));
            rightCell.AddElement(new Paragraph("CIN No.- U32301HR1979PTC038643", fFooter));
            footerTable.AddCell(rightCell);

            doc.Add(footerTable);

            // Red separator line at bottom
            var bottomLine2 = new Paragraph(new Chunk(new iTextSharp.text.pdf.draw.LineSeparator(1f, 100f, redLine, Element.ALIGN_CENTER, 0)));
            bottomLine2.SpacingBefore = 5;
            doc.Add(bottomLine2);

            doc.Close();
        }

        private void BuildPdfold(string path)
        {
            var doc = new Document(PageSize.A4, 36, 36, 50, 40);
            PdfWriter.GetInstance(doc, new FileStream(path, FileMode.Create));
            doc.Open();

            var fTitle = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14, BaseColor.BLACK);
            var fHead = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.WHITE);
            var fCell = FontFactory.GetFont(FontFactory.HELVETICA, 8, BaseColor.BLACK);
            var fBold = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.BLACK);
            var fMeta = FontFactory.GetFont(FontFactory.HELVETICA, 7, BaseColor.DARK_GRAY);

            var blue = new BaseColor(30, 80, 160);
            var grey = new BaseColor(90, 90, 90);

            // ── Header ────────────────────────────────────────────────────────
            doc.Add(new Paragraph("PACKING LIST", fTitle) { Alignment = Element.ALIGN_CENTER });
            doc.Add(new Paragraph(
                $"Project: {_projectCode}   |   Packing No: {txtPackingNo.Text}   |   Date: {dtpDate.Value:dd-MM-yyyy}",
                fMeta)
            { Alignment = Element.ALIGN_CENTER, SpacingAfter = 10 });

            // ── Boxes ─────────────────────────────────────────────────────────
            foreach (var box in _boxes)
            {
                if (box.Items.Count == 0) continue;

                // Box header row
                var bt = new PdfPTable(1) { WidthPercentage = 100, SpacingBefore = 10 };
                string hdr = $"  {box.BoxLabel.ToUpper()}";
                if (!string.IsNullOrWhiteSpace(box.Dimensions)) hdr += $"   ({box.Dimensions})";
                if (box.GrossWeight > 0) hdr += $"   GW: {box.GrossWeight} kg   NW: {box.NetWeight} kg";
                bt.AddCell(new PdfPCell(new Phrase(hdr, fHead))
                { BackgroundColor = blue, Padding = 5 });
                doc.Add(bt);

                var t = new PdfPTable(new float[] { 5, 22, 38, 8, 7, 20 }) { WidthPercentage = 100 };
                foreach (var h in new[] { "S/N", "Product No", "Product Name", "Qty", "UOM", "Type" })
                    t.AddCell(new PdfPCell(new Phrase(h, fHead))
                    { BackgroundColor = blue, Padding = 3, HorizontalAlignment = Element.ALIGN_CENTER });

                int sn = 1;
                foreach (var item in box.Items)
                {
                    var bg = sn % 2 == 0 ? new BaseColor(236, 244, 255) : BaseColor.WHITE;
                    t.AddCell(Cell(sn++.ToString(), fCell, bg));
                    t.AddCell(Cell(item.ProductCode, fCell, bg));
                    t.AddCell(Cell(item.ProductName, fCell, bg));
                    t.AddCell(Cell(item.Quantity.ToString("G29"), fCell, bg));
                    t.AddCell(Cell(item.UOM, fCell, bg));
                    t.AddCell(Cell(item.ProductType, fCell, bg));
                }
                doc.Add(t);
            }

            // ── Non-box ───────────────────────────────────────────────────────
            if (_nonBox.Count > 0)
            {
                var nbt = new PdfPTable(1) { WidthPercentage = 100, SpacingBefore = 14 };
                nbt.AddCell(new PdfPCell(new Phrase("  NON-BOX ITEMS  (SHIP LOOSE)", fHead))
                { BackgroundColor = grey, Padding = 5 });
                doc.Add(nbt);

                var t = new PdfPTable(new float[] { 5, 22, 44, 8, 7, 14 }) { WidthPercentage = 100 };
                foreach (var h in new[] { "S/N", "Product No", "Product Name", "Qty", "UOM", "Type" })
                    t.AddCell(new PdfPCell(new Phrase(h, fHead))
                    { BackgroundColor = grey, Padding = 3, HorizontalAlignment = Element.ALIGN_CENTER });

                int sn = 1;
                foreach (var item in _nonBox)
                {
                    var bg = sn % 2 == 0 ? new BaseColor(248, 248, 248) : BaseColor.WHITE;
                    t.AddCell(Cell(sn++.ToString(), fCell, bg));
                    t.AddCell(Cell(item.ProductCode, fCell, bg));
                    t.AddCell(Cell(item.ProductName, fCell, bg));
                    t.AddCell(Cell(item.Quantity.ToString("G29"), fCell, bg));
                    t.AddCell(Cell(item.UOM, fCell, bg));
                    t.AddCell(Cell(item.ProductType, fCell, bg));
                }
                doc.Add(t);
            }

            // ── Summary ───────────────────────────────────────────────────────
            int totalBoxItems = _boxes.Sum(b => b.Items.Count);
            doc.Add(new Paragraph(
                $"\nTotal Boxes: {_boxes.Count}   |   Box Items: {totalBoxItems}" +
                $"   |   Non-Box Items: {_nonBox.Count}   |   Grand Total: {totalBoxItems + _nonBox.Count}",
                fBold)
            { SpacingBefore = 10, Alignment = Element.ALIGN_RIGHT });

            doc.Add(new Paragraph(
                $"\nGenerated: {DateTime.Now:dd-MMM-yyyy HH:mm}   |   By: {Environment.UserName}", fMeta)
            { Alignment = Element.ALIGN_RIGHT });

            doc.Close();
        }

        private static PdfPCell Cell(string t, iTextSharp.text.Font f, BaseColor bg) =>
            new PdfPCell(new Phrase(t ?? "", f)) { BackgroundColor = bg, Padding = 3 };

        // =========================================================================
        //  CLEAR
        // =========================================================================

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Clear all packing list data?", "Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                ClearAll();
        }

        private void ClearAll()
        {
            _bom.Clear(); _boxes.Clear(); _nonBox.Clear(); _boxCtr = 0;
            RefreshBom(); RefreshBoxList(); RefreshNonBox();
            SetBoxDetailEnabled(false);
            GeneratePackingNo();
            SetStatus("Cleared.");
        }

        // =========================================================================
        //  DB HELPERS
        // =========================================================================

        private void EnsureTablesExist()
        {
            const string sql = @"
IF NOT EXISTS(SELECT 1 FROM sys.tables WHERE name='ProjectPackingListHeader')
CREATE TABLE ProjectPackingListHeader(
    ID          INT IDENTITY PRIMARY KEY,
    PackingNo   NVARCHAR(50) NOT NULL UNIQUE,
    ProjectCode NVARCHAR(50),
    PackingDate DATE,
    TotalBoxes  INT DEFAULT 0,
    CreatedDate DATETIME DEFAULT GETDATE(),
    CreatedBy   NVARCHAR(100),
    Remarks     NVARCHAR(500));

IF NOT EXISTS(SELECT 1 FROM sys.tables WHERE name='ProjectPackingListDetail')
CREATE TABLE ProjectPackingListDetail(
    ID            INT IDENTITY PRIMARY KEY,
    PackingNo     NVARCHAR(50)  NOT NULL,
    SlNo          INT,
    BoxNumber     INT,
    BoxLabel      NVARCHAR(100),
    BoxDimensions NVARCHAR(100),
    GrossWeight   DECIMAL(10,3),
    NetWeight     DECIMAL(10,3),
    BomID         INT,
    ProductNo     NVARCHAR(100),
    ProductName   NVARCHAR(500),
    ProductCode   NVARCHAR(100),
    Quantity      DECIMAL(18,4),
    UOM           NVARCHAR(50),
    ItemType      NVARCHAR(20));";
            try { using (var cn = Open()) using (var cmd = new SqlCommand(sql, cn)) cmd.ExecuteNonQuery(); }
            catch (Exception ex) { Err("EnsureTables", ex); }
        }

        private SqlConnection Open()
        {
            var cn = new SqlConnection(ConnStr);
            cn.Open();
            return cn;
        }

        private static void Exec(SqlConnection cn, SqlTransaction tx, string sql, params SqlParameter[] ps)
        {
            using (var cmd = new SqlCommand(sql, cn, tx)) { cmd.Parameters.AddRange(ps); cmd.ExecuteNonQuery(); }
        }

        private static SqlParameter P(string n, object v) => new SqlParameter(n, v ?? DBNull.Value);

        // =========================================================================
        //  UI HELPERS
        // =========================================================================

        private void GeneratePackingNo() =>
            txtPackingNo.Text = "PKG-" + DateTime.Now.ToString("yyyyMMdd-HHmmss");

        private void SetStatus(string msg)
        {
            lblStatus.Text = msg;
            lblStatus.ForeColor = msg.StartsWith("Error") ? Color.Firebrick : Color.DimGray;
        }

        private static void Warn(string msg) =>
            MessageBox.Show(msg, "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

        private static void Err(string ctx, Exception ex) =>
            MessageBox.Show($"Error in {ctx}:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

        private static string SimplePrompt(string title, string label, string def = "")
        {
            var f = new Form
            {
                Text = title,
                Size = new Size(360, 120),
                FormBorderStyle = FormBorderStyle.FixedDialog,
                StartPosition = FormStartPosition.CenterParent,
                MaximizeBox = false,
                MinimizeBox = false
            };
            var lb = new Label { Text = label, AutoSize = true, Location = new Point(10, 14) };
            var tb = new TextBox { Location = new Point(10, 34), Width = 324, Text = def };
            var ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Location = new Point(160, 62), Width = 80 };
            var ca = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Location = new Point(254, 62), Width = 80 };
            f.AcceptButton = ok; f.CancelButton = ca;
            f.Controls.AddRange(new Control[] { lb, tb, ok, ca });
            return f.ShowDialog() == DialogResult.OK ? tb.Text.Trim() : def;
        }


        //this function for closing the windows screen..
        private void fnClose()
        {
            this.Hide();
            //Project_Master.frmProjectHome Home = new Project_Master.frmProjectHome();
            Home.Show();
        }

        private void frmProjectmaster_FormClosing(object sender, FormClosingEventArgs e)
        {
            //  frmForm2 form = new frmForm2();
            fnClose();
        }
    }
}