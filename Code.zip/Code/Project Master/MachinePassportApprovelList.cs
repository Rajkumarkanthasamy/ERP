﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class MachinePassportApprovelList : Form
    {
        DataTable dtProjectList = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        Machine_Passport Machine_Passport = new Machine_Passport();
        private const uint uPROJECT_PROJECTCODE_SEARCH = 0;
        private DataGridView dgData;
        DataTable dtPOUserlist = new DataTable();
        Global GLobalClass = new Global();
        public MachinePassportApprovelList()
        {
            InitializeComponent();

            // Initialize the DataGridView control

            this.dgData = new System.Windows.Forms.DataGridView();

            this.dgData.Location = new System.Drawing.Point(12, 12);

            this.dgData.Name = "dgData";

            this.dgData.Size = new System.Drawing.Size(776, 375);

            this.dgData.TabIndex = 0;

            // Add any other properties or event handlers as needed
        }

        private void MachinePassportApprovelList_Load(object sender, EventArgs e)
        {

            DataGridViewCheckBoxColumn chkBoxColumn = new DataGridViewCheckBoxColumn();


            chkBoxColumn.Width = 40;
            chkBoxColumn.Name = "Accept";
            chkBoxColumn.HeaderText = "Accept";
            chkBoxColumn.Frozen = true; // Make the new column frozen

            dgApproveProjectList.Columns[0].ReadOnly = false;

            
            //All 2nd level Approvel--->Approver
            if (login.GetUserDetails[2].ToLower() == "santhoshdj" || login.GetUserDetails[2].ToLower() == "ravi" || login.GetUserDetails[2].ToLower() == "ramesh")
            {
                chkBoxColumn.Frozen = true; // Make the new column frozen
                dgApproveProjectList.Columns.Insert(0, chkBoxColumn);

                dtPOUserlist = DAL.fnMpPOOrderFilter(0, login.GetUserDetails[2]).Tables[0];

                DataTable combinedData = new DataTable(); // Create a new DataTable to combine data

                foreach (DataRow DT in dtPOUserlist.Rows)
                {
                    dtProjectList = DAL.mpApprovelProjectList(1, DT["MPUserName"].ToString()).Tables[0];
                    combinedData.Merge(dtProjectList); // Merge the data into the combined DataTable
                }

                dgApproveProjectList.DataSource = combinedData; // Bind the combined data to the grid
                dgApproveProjectList.CellContentClick += dgProjectList_CellContentClick;

                for (int i = 1; i < dgApproveProjectList.Columns.Count - 1; i++) // Exclude the checkbox column
                {
                    dgApproveProjectList.Columns[i].Visible = true;
                    dgApproveProjectList.Columns[i].ReadOnly = true;
                }
            }
            
           

        }

        private void dgProjectList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void UpdateStatus(string status, string projectId)
        {
        }

        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void butAccept_Click(object sender, EventArgs e)
        {


            //All First level Approvel--->upadte
            if (login.GetUserDetails[2].ToLower() == "santhoshdj" || login.GetUserDetails[2].ToLower() == "ravi" || login.GetUserDetails[2].ToLower() == "ramesh")
            {



                if (string.IsNullOrWhiteSpace(txtMpApproveRemarks.Text))
                {
                    MessageBox.Show("Remarks cannot be empty. Please enter the remarks.");
                    return;
                }
                bool isChecked = false;

                foreach (DataGridViewRow row in dgApproveProjectList.Rows)
                {
                    if (Convert.ToBoolean(row.Cells["Accept"].Value))
                    {
                        isChecked = true;

                        string ProductSerialNumber = row.Cells["ProductSerialNumber"].Value.ToString();
                        GLobalClass.iSuccess = DAL.updatemachinepassportall(1, txtMpApproveRemarks.Text, login.GetUserDetails[2], ProductSerialNumber);
                    }
                }

                if (isChecked)
                {
                    MessageBox.Show("Approved successfully");
                }
                else
                {
                    MessageBox.Show("Please check at least one checkbox");
                }
                // Reload the page
                this.Reload();
            }
        }


        private void Reload()
        {
            // Create a new instance of the form
            MachinePassportApprovelList form = new MachinePassportApprovelList();

            // Show the new instance of the form
            form.Show();

            // Close the current instance of the form
            this.Close();
        }
        private void btnLoadProjects_Click(object sender, EventArgs e)
        {
            butAccept.Visible = false;
            butreject.Visible = false;

            //dgApproveProjectList.Columns[0].ReadOnly = false; // Make the checkbox column editable

            if (btnLoadProjects.Text == "Load All Projects")
            {
                for (int i = 0; i < dgApproveProjectList.Columns.Count - 1; i++) // Exclude the checkbox column
                {

                    dgApproveProjectList.Columns[i].Visible = true;
                    dgApproveProjectList.Columns[i].ReadOnly = true;


                }

                dtProjectList = DAL.mpApprovelProjectList(0, null).Tables[0];  //get all project from database
                dgApproveProjectList.DataSource = dtProjectList;
                dgApproveProjectList.CellContentClick += dgProjectList_CellContentClick;
                btnLoadProjects.Text = "Load Active Projects";

            }

            else
            {
                for (int i = 0; i < dgApproveProjectList.Columns.Count - 1; i++) // Exclude the checkbox column
                {
                    dgApproveProjectList.Columns[i].Visible = true;
                    dgApproveProjectList.Columns[i].ReadOnly = true;
                }
                dtProjectList = DAL.mpApprovelProjectList(1, null).Tables[0];  //get all active project from database
                dgApproveProjectList.DataSource = dtProjectList;
                btnLoadProjects.Text = "Load All Projects";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Project_Master.MachinePassportApprovelList ProjectSearchForm = new Project_Master.MachinePassportApprovelList();
                this.Hide();
                pleasewaitform pleaseWait = new pleasewaitform();
                // Display form modelessly
                pleaseWait.Show();
                //  ALlow main UI thread to properly display please wait form.
                Application.DoEvents();
                pleaseWait.Hide();
                ProjectSearchForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Click On Approvel Search" + ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            
            Machine_Passport.Show();
        }

        private void butreject_Click(object sender, EventArgs e)
        {
            //All First level Approvel--->upadte
            if (login.GetUserDetails[2].ToLower() == "santhoshdj" || login.GetUserDetails[2].ToLower() == "ravi" || login.GetUserDetails[2].ToLower() == "ramesh")
            {
                bool isChecked = false;

                if (string.IsNullOrWhiteSpace(txtMpApproveRemarks.Text))
                {
                    MessageBox.Show("Please enter a remark message");
                    return;
                }

                foreach (DataGridViewRow row in dgApproveProjectList.Rows)
                {
                    if (Convert.ToBoolean(row.Cells["Accept"].Value))
                    {
                        isChecked = true;

                        string ProductSerialNumber = row.Cells["ProductSerialNumber"].Value.ToString();
                        GLobalClass.iSuccess = DAL.updatemachinepassportall(2, txtMpApproveRemarks.Text, login.GetUserDetails[2], ProductSerialNumber);
                    }


                }

                if (isChecked)
                {
                    MessageBox.Show("Rejected successfully");
                }
                else
                {

                    MessageBox.Show("Please check at least one checkbox");
                }
                // Reload the page
                this.Reload();
            }
        }

        private void labMpApproveRemarks_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}


        
