﻿using System;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmInvoiceUpdate : Form
    {
        public frmInvoiceUpdate()
        {
            InitializeComponent();
        }

        private void frmInvoiceUpdate_Load(object sender, EventArgs e)
        {

        }
    }
}
