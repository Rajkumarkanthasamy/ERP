﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Net;

namespace Erp_Project_With_Buttons
{
    public partial class frmIssue : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration
        frmForm2 frm = new frmForm2();
        Login.frmLoginForm login = new Login.frmLoginForm();
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable DTIndentList = new DataTable();
        DataTable DTWorkOrder = new DataTable();
        DataTable dtupdate = new DataTable();
        DataTable dtisuedReturn = new DataTable();
        DataTable dtIndentNumber = new DataTable();
        DataTable InventoryIndent = new DataTable();
        DataTable dtIssuedItems = new DataTable();
        DataTable dtJOBIssue = new DataTable();
        DataTable dtItemDetails = new DataTable();
        DataTable dtMachineBOMItems = new DataTable();
        SqlConnection SQLCon;
        double dBOMIssued = 0;
        double issue;
        int iLastJOBIssuedNo;
        int iNoItems = 0;
        double oldvalue;
        double iAvailableQty;
        double iStockAvailableQty;
        double iIndentRemainingQuantity;
        Double dStockValue;
        int ijobissuedcount = 0;
        int iLastIssuedNo;
        bool bindentQtyCheck = false;
        string JOBISSUEDNO = string.Empty;
        bool bjobqtyCheck = false;
        string ISSUEDNO = string.Empty;
        string sDot = ".";

        public frmIssue()
        {
            InitializeComponent();
        }
        #endregion
        #region Code to Select Issue Type
        void cmbIssueType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbIssueType.SelectedIndex == 1)
            {
                pnIndent.Visible = true;
                pnJob.Visible = false;
                dgIndent.Visible = true;
                dgvJobIssue.Visible = false; ;

            }
            else if (cmbIssueType.SelectedIndex == 2)
            {
                pnIndent.Visible = false;
                pnJob.Visible = true;
                dgvJobIssue.Visible = true;
                dgIndent.Visible = false;

            }
        }
        //https://172.18.18.78:80/cpa/uploadFile
        private void TestFunction() //async Task
        {
            // ENABLE TLS 1.2 (required)
            ServicePointManager.SecurityProtocol =
                SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

            // BYPASS SSL (same as Postman SSL OFF)
            ServicePointManager.ServerCertificateValidationCallback +=
                (sender, cert, chain, sslErrors) => true;

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(10);

                   // MessageBox.Show("Function called");

                    string url = "https://172.18.18.79/cpa/uploadFile";
                    // live - https://connect-bi.com/cpa/
                    //local - https://172.18.18.79


                    client.DefaultRequestHeaders.Add("User-Agent", "PostmanRuntime/7.52.0");
                    client.DefaultRequestHeaders.Add("Accept", "*/*");
                    client.DefaultRequestHeaders.Add("Accept-Encoding", "gzip, deflate, br");
                    client.DefaultRequestHeaders.Add("Connection", "keep-alive");
                    client.DefaultRequestHeaders.Add("Cookie", "XSRF-TOKEN=eyJpdiI6Ild2SXBwTWxrOHZWTWpTK25kRnNHc2c9PSIsInZhbHVlIjoiYllDNkFCaHUrQ3JnQUsvN29jVEJUSisxNldBUTFPMTQ1WmFYcU1TR2h3SHN0Q3FXVEs3QmJFeTV6VVlTV1U0UzhTUkRlN2NsbjJIaStOTHBCTDdRTEVFenBuSU9TdVN5QWVZV0swdW5ZbHpNUk5qdnpVVnBEampXdVBWamdUdlMiLCJtYWMiOiI3MTBiMGU1OTdlZjdlOTA5NzI1OWE1ZDJjMzNlNDg5ZGE1MmY2ZTNjNjMwMmRmN2YxNzU5YWIyNDNlYjlhN2UwIiwidGFnIjoiIn0%3D; laravel_session=eyJpdiI6InZ2TUduUjlVZEsvTHJBWGoyaUdlTEE9PSIsInZhbHVlIjoiSzd5MUh1S3hHMEtWblVvU2k3T1Y5WkFRNkpwU1pjLzNPMm1nZXJNZjVZNWx3SDY5UVNqVHNhM3FCaDRIRXZkeVFnTm9vckovbXFyMTc5RTdRRlFuUEpoak0yVXkraVIzdFl2S3E3aUxxV3hWSS84NnNWNDFjUUVnNS9qTEIrdGkiLCJtYWMiOiJjZTI1NWQwMWZiN2ZlYTBkMzQ3ODk3NTliNmQ1N2ZmMDVhMjdjMTU4NmI4NjY1N2I1MGIyZTkyNDY3MzljNzhjIiwidGFnIjoiIn0%3D");

                   // var json = "{ \"name\": \"John\", \"age\": 30 }";
                   // var content = new StringContent(json, Encoding.UTF8, "application/json");


                    var form = new MultipartFormDataContent();

                    // ---- Add text fields (same as Postman bulk) ----
                    form.Add(new StringContent("value1"), "key1");
                    form.Add(new StringContent("value2"), "key2");
                    form.Add(new StringContent("12345"), "id");
                    form.Add(new StringContent("test-file"), "filename");


                   ////// HttpResponseMessage response = await client.PostAsync(url, form);
                   //// //string body = await response.Content.ReadAsStringAsync();

                   // MessageBox.Show(
                     //    "STATUS CODE: " + response.StatusCode + " (" + (int)response.StatusCode + ")\n\n" +
                     //    "RESPONSE BODY:\n" + body + "\n\n" +
                      //   "REQUEST SENT SUCCESSFULLY ✔"
                     //);
                }
            }
            catch (Exception ex)
            {
                var inner = ex.InnerException != null ? ex.InnerException.Message : "(no inner exception)";
                MessageBox.Show(
                    "❌ ERROR OCCURRED\n\n" +
                    $"Main Error:\n{ex.Message}\n\n" +
                    $"Inner Error:\n{inner}\n\n"
                );
            }
        }


        #endregion
        #region Code to Load Issue Form Loacal Variables
        private void frmIssue_Load(object sender, EventArgs e)
        {


           // TestFunction();





        dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd-MM-yyyy";
            dgIndent.Columns[1].Width = 520;
            dgvJobIssue.Columns[1].Width = 580;
            timer1.Interval = 1000;
            timer1.Enabled = true;

            SQLCon = new SqlConnection(DataAccessLayer.cs);
            lblUsername.Text = login.GetUserDetails[2];
            DTIndentList = DAL.fnIndentList2(null).Tables[0];

            foreach (DataRow DR in DTIndentList.Rows)
            {
                if (!cmbIndentNO.Items.Contains(DR["IndentNo"].ToString()))
                    cmbIndentNO.Items.Add(DR["IndentNo"].ToString());
            }

            DTWorkOrder = DAL.fnWorkOrderTableList(null, null).Tables[0];

            foreach (DataRow dr in DTWorkOrder.Rows)
            {
                if (!cmbWorkOrderNo.Items.Contains(dr["WONumber"].ToString()))
                    cmbWorkOrderNo.Items.Add(dr["WONumber"].ToString());
            }
        }
        #endregion
        #region Code to Load Select Indent Number Details
        private void cmbIndentNO_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtIndentNumber = DAL.fnIndentList2(cmbIndentNO.Text).Tables[0];

            if (dtIndentNumber.Rows.Count > 0)
            {
                lblIndentProjcode.Text = dtIndentNumber.Rows[0]["ProjectCode"].ToString();
                lblProjectName.Text = dtIndentNumber.Rows[0]["ProjectDescription"].ToString();
                lblcustomername.Text = dtIndentNumber.Rows[0]["Customer"].ToString();
                lblIndentBy.Text = dtIndentNumber.Rows[0]["IndentBy"].ToString();
                lblIndentdate.Text = dtIndentNumber.Rows[0]["IndentDate"].ToString();
                lblRemarks.Text = dtIndentNumber.Rows[0]["Remarks"].ToString();
                lblprojectstatus.Text = dtIndentNumber.Rows[0]["ProjectStatus"].ToString();

                if (!string.IsNullOrEmpty(dtIndentNumber.Rows[0]["ProjectBOMCode"].ToString()))
                {
                    dgIndent.AutoGenerateColumns = false;
                    dgIndent.DataSource = dtIndentNumber;


                    //MessageBox.Show("this block...!");


                    foreach (DataGridViewRow drow in dgIndent.Rows)
                    {

                        dtIssuedItems = DAL.fnIndentIssued(drow.Cells["ProjectBOMCode"].Value.ToString(), drow.Cells["ProductNo"].Value.ToString(), drow.Cells["itemcode"].Value.ToString()).Tables[0];




                        InventoryIndent = DAL.fnGetERPInventoryFIFOLogs(drow.Cells["itemcode"].Value.ToString(), cmbIndentNO.Text).Tables[0];

                        //MessageBox.Show(InventoryIndent.Rows.Count.ToString());

                        foreach (DataRow data in InventoryIndent.Rows)
                        {
                            //MessageBox.Show(data["FIFOFollowed"].ToString());
                            if (data["FIFOFollowed"].ToString() == "true")
                            {
                                drow.Cells["FIFOFollowed"].Value = "✔";
                                drow.Cells["FIFOFollowed"].Style.BackColor = Color.Green;
                            }
                            else
                            {
                                drow.Cells["FIFOFollowed"].Value = "❌";
                                drow.Cells["FIFOFollowed"].Style.BackColor = Color.Red;
                            }
                        }


                        //drow.DefaultCellStyle.BackColor = Color.Red;

                        if (dtIssuedItems.Rows.Count > 0)
                        {
                            drow.Cells["IssuedQty"].Value = dtIssuedItems.Rows[0]["IssuedQty"].ToString();
                        }

                        drow.Cells["IssuedQuantity"].Value = drow.Cells["IndentQty"].Value;

                        if (Convert.ToDouble(drow.Cells["AvailableQty"].Value) == 0)
                        {
                            drow.Cells["AvailableQty"].Style.BackColor = Color.Red;
                        }
                    }


                }
                else
                {
                    //MessageBox.Show("Else part");
                    dgIndent.AutoGenerateColumns = false;
                    dgIndent.DataSource = dtIndentNumber;

                    //foreach (DataGridViewRow drow in dgIndent.Rows)
                    //{
                    //    drow.Cells["IssuedQuantity"].Value = drow.Cells["IndentQty"].Value;
                    //}
                    //foreach (DataGridViewRow row in dgIndent.Rows)
                    //{
                    //    row.Cells["IssuedQty"].Value = 0;
                    //    row.Cells["ProjectBOMQty"].Value = 0;

                    //    if (Convert.ToDouble(row.Cells["AvailableQty"].Value) == 0)
                    //    {
                    //        row.Cells["AvailableQty"].Style.BackColor = Color.Red;
                    //    }
                    //}


                    //this below code for FIFO LOG
                    foreach (DataGridViewRow drow in dgIndent.Rows)
                    {


                        InventoryIndent = DAL.fnGetERPInventoryFIFOLogs(drow.Cells["itemcode"].Value.ToString(), cmbIndentNO.Text).Tables[0];

                        // MessageBox.Show(InventoryIndent.Rows.Count.ToString());

                        foreach (DataRow data in InventoryIndent.Rows)
                        {
                            //MessageBox.Show(data["FIFOFollowed"].ToString());
                            if (data["FIFOFollowed"].ToString() == "true")
                            {
                                drow.Cells["FIFOFollowed"].Value = "✔";
                                drow.Cells["FIFOFollowed"].Style.BackColor = Color.Green;
                            }
                            else
                            {
                                drow.Cells["FIFOFollowed"].Value = "❌";
                                drow.Cells["FIFOFollowed"].Style.BackColor = Color.Red;
                            }
                        }

                    }
                    //END
                    foreach (DataGridViewRow drow in dgIndent.Rows)
                    {
                        drow.Cells["IssuedQuantity"].Value = drow.Cells["IndQty"].Value;
                    }
                    foreach (DataGridViewRow row in dgIndent.Rows)
                    {
                        row.Cells["IssuedQty"].Value = 0;
                        row.Cells["ProjectBOMQty"].Value = 0;

                        if (Convert.ToDouble(row.Cells["AvailableQty"].Value) == 0)
                        {
                            row.Cells["AvailableQty"].Style.BackColor = Color.Red;
                        }
                    }
                }



                btnAccept.Enabled = true;
            }
        }
        #endregion
        #region Function to Get Last JobIssued Number
        private void fnGetJobIssueNumber()
        {
            DataTable dtJObIssuedNo = new DataTable();
            dtJObIssuedNo = DAL.fnJobIssuedIDNo().Tables[0];
            if (dtJObIssuedNo.Rows.Count > 0)
            {
                string sIssuedNo = dtJObIssuedNo.Rows[0]["JobIssueNo"].ToString();
                if (sIssuedNo != string.Empty && sIssuedNo != null)
                {
                    iLastJOBIssuedNo = Convert.ToInt32(sIssuedNo.Substring(10, 08));
                }
                else
                {
                    iLastJOBIssuedNo = 10000000;
                }
                iLastJOBIssuedNo++;
                JOBISSUEDNO = ("JobIssued/" + iLastJOBIssuedNo);
            }
            else
            {
                iLastJOBIssuedNo = 10000000;
                iLastJOBIssuedNo++;
                JOBISSUEDNO = ("JobIssued/" + iLastJOBIssuedNo);
            }
        }
        #endregion
        #region Function to Get Last Issued Number
        private void fnGetIssuedNUmber()
        {
            DataTable dtIssuedNo = new DataTable();
            dtIssuedNo = DAL.fnIssuedIDNo().Tables[0];
            if (dtIssuedNo.Rows.Count > 0)
            {
                string sIssuedNo = dtIssuedNo.Rows[0]["IssueNo"].ToString();
                if (sIssuedNo != string.Empty && sIssuedNo != null)
                {
                    iLastIssuedNo = Convert.ToInt32(sIssuedNo.Substring(08, 08));
                }
                else
                {
                    iLastIssuedNo = 10000000;
                }
                iLastIssuedNo++;
                ISSUEDNO = ("IssueID/" + iLastIssuedNo);
            }
            else
            {
                iLastIssuedNo = 10000000;
                iLastIssuedNo++;
                ISSUEDNO = ("IssueID/" + iLastIssuedNo);
            }
        }
        #endregion
        #region Function to Check Indent Issue Available Quantity Items
        private void indentQtyCheck()
        {
            bindentQtyCheck = true;
            foreach (DataGridViewRow drow in dgIndent.Rows)
            {
                if (Convert.ToDouble(drow.Cells["AvailableQty"].Value) == 0)
                {
                    MessageBox.Show("For item '" + drow.Cells["itemcode"].Value + "' stock available quantity is 0 ", "Warning", 0, MessageBoxIcon.Warning);
                    bindentQtyCheck = false;
                    break;
                }
                if (Convert.ToDouble(drow.Cells["IssuedQuantity"].Value) <= 0)
                {
                    MessageBox.Show("For item '" + drow.Cells["itemcode"].Value + "' Issue Quantity should be greater than 0 ", "Warning", 0, MessageBoxIcon.Warning);
                    bindentQtyCheck = false;
                    break;
                }

            }
            if (bindentQtyCheck == true)
            {
                foreach (DataGridViewRow drow in dgIndent.Rows)
                {
                    if (Convert.ToDouble(drow.Cells["ProjectBOMQty"].Value) > 0)
                    {
                        if ((Convert.ToDouble(drow.Cells["IssuedQty"].Value) == Convert.ToDouble(drow.Cells["ProjectBOMQty"].Value)))
                        {
                            MessageBox.Show("Enterd quantity for item '" + drow.Cells["itemcode"].Value + "' already issued.", "Warning", 0, MessageBoxIcon.Warning);
                            bindentQtyCheck = false;
                            break;
                        }
                    }
                    if (Convert.ToDouble(drow.Cells["IssuedQuantity"].Value) > Convert.ToDouble(drow.Cells["AvailableQty"].Value) ||
                        Convert.ToDouble(drow.Cells["IssuedQuantity"].Value) > Convert.ToDouble(drow.Cells["IndentQty"].Value))
                    {
                        MessageBox.Show("Enterd quantity for item '" + drow.Cells["itemcode"].Value + "' greater than the indent quantity or available quantity", "Warning", 0, MessageBoxIcon.Warning);
                        bindentQtyCheck = false;
                        break;
                    }

                }
            }
        }
        #endregion
        #region Function to Check Job Issue Available Quantity Items
        private void JobQtyCheck()
        {
            bjobqtyCheck = true;

            foreach (DataGridViewRow drow in dgvJobIssue.Rows)
            {
                if (Convert.ToDouble(drow.Cells["AvailableQty1"].Value) == 0)
                {
                    MessageBox.Show("For item '" + drow.Cells["Item_Code"].Value + "' stock available quantity is 0", "Warning", 0, MessageBoxIcon.Warning);
                    bjobqtyCheck = false;
                    break;
                }
            }

            if (bjobqtyCheck == true)
            {
                foreach (DataGridViewRow drow in dgvJobIssue.Rows)
                {
                    if (Convert.ToDouble(drow.Cells["JobQuantity"].Value) <= 0)
                    {
                        MessageBox.Show("Enter job issue quantity for item '" + drow.Cells["Item_Code"].Value + "'", "Warning", 0, MessageBoxIcon.Warning);
                        bjobqtyCheck = false;
                        break;
                    }
                    if (Convert.ToDouble(drow.Cells["JobQuantity"].Value) > Convert.ToDouble(drow.Cells["OrderdQuantity"].Value))
                    {
                        MessageBox.Show("Quantity for item '" + drow.Cells["Item_Code"].Value + "' is greater than work order quantity", "Warning", 0, MessageBoxIcon.Warning);
                        bjobqtyCheck = false;
                        break;
                    }
                    else if (Convert.ToDouble(drow.Cells["JobQuantity"].Value) > Convert.ToDouble(drow.Cells["AvailableQty1"].Value))
                    {
                        MessageBox.Show("Quantity for item '" + drow.Cells["Item_Code"].Value + "' is greater than stock available quantity", "Warning", 0, MessageBoxIcon.Warning);
                        bjobqtyCheck = false;
                        break;
                    }

                    if (Convert.ToDouble(drow.Cells["ActualQty"].Value) <= 0)
                    {
                        MessageBox.Show("Enter actual sent quantity for item '" + drow.Cells["Item_Code"].Value + "'", "Warning", 0, MessageBoxIcon.Warning);
                        bjobqtyCheck = false;
                        break;
                    }
                }


            }
        }
        #endregion

        DataTable dtProjectType = new DataTable();
        DataTable dtProjectAllCost = new DataTable();
        double dProjectCost = 0;
        double dTotalIssuedAmount = 0;
        double dCurrentIssuedAmount = 0;
        double dIndentreturn = 0;
        double dJObreturn = 0;
        double dJObIssued = 0;
        double dTotalProjectSum = 0;
        bool bProjectCost = true;
        private void fnProjectAmountCheck()
        {
            bProjectCost = true;
            dProjectCost = 0;
            dTotalIssuedAmount = 0;
            dCurrentIssuedAmount = 0;
            dIndentreturn = 0;
            dJObreturn = 0;
            dJObIssued = 0;
            dTotalProjectSum = 0;
            dtProjectType = DAL.fnProjectCostLimitCIP(0, lblIndentProjcode.Text).Tables[0];
            if (dtProjectType.Rows.Count > 0)
            {
                if (dtProjectType.Rows[0]["ProjectType"].ToString() == "Fixed Asset (CIP)")
                {
                    dtProjectAllCost = DAL.fnProjectCostLimitCIP(2, lblIndentProjcode.Text).Tables[0];

                    if (dtProjectAllCost.Rows.Count > 0)
                    {
                        dProjectCost = Convert.ToDouble(dtProjectAllCost.Rows[0]["TotalAmount"].ToString());
                        dTotalProjectSum = dtProjectAllCost.AsEnumerable().Sum(r => r.Field<double>("TotalAmount"));
                        dTotalProjectSum = dTotalProjectSum - dProjectCost;
                    }

                    dCurrentIssuedAmount = Convert.ToDouble(0);
                    if (cmbIssueType.SelectedIndex == 1)
                    {
                        foreach (DataGridViewRow drow in dgIndent.Rows)
                        {
                            dCurrentIssuedAmount += Convert.ToDouble(drow.Cells["UnitPrice"].Value) * Convert.ToDouble(drow.Cells["IssuedQuantity"].Value);
                        }
                    }
                    else if (cmbIssueType.SelectedIndex == 2)
                    {
                        foreach (DataGridViewRow drow in dgvJobIssue.Rows)
                        {
                            dCurrentIssuedAmount += Convert.ToDouble(drow.Cells["UnitPrice1"].Value) * Convert.ToDouble(drow.Cells["JobQuantity"].Value);
                        }
                    }


                    if (dtProjectType.Rows[0]["Type"].ToString() == "Inhouse")
                    {
                        dProjectCost = (dProjectCost / 1.3);
                        if ((dTotalProjectSum + dCurrentIssuedAmount) < dProjectCost)
                        {
                            bProjectCost = true;
                        }
                        else
                        {
                            bProjectCost = false;
                        }
                    }
                }
            }
        }


        DataTable dtKanBanItemCheck = new DataTable();
        #region Code to Issue the Indent Items
        private void btnAccept_Click(object sender, EventArgs e)
        {
            fnProjectAmountCheck();
           // MessageBox.Show(cmbIssueType.SelectedIndex.ToString(), "cmbIssueType.SelectedIndex");
            if (cmbIssueType.SelectedIndex == 1)
            {
                indentQtyCheck();

                if (bindentQtyCheck == true && bProjectCost == true)
                {
                    fnGetIssuedNUmber();
                    iNoItems = 0;

                    foreach (DataGridViewRow row in dgIndent.Rows)
                    {
                        dtItemDetails = DAL.fnIssueItemDetails(row.Cells["itemcode"].Value.ToString()).Tables[0];

                        dtMachineBOMItems = DAL.fnIssueMachineBOMDetails(row.Cells["itemcode"].Value.ToString(), lblIndentProjcode.Text, row.Cells["ProductNo"].Value.ToString()).Tables[0];

                        iIndentRemainingQuantity = Convert.ToDouble(row.Cells["IndentQty"].Value) - Convert.ToDouble(row.Cells["IssuedQuantity"].Value);

                        GLobalClass.iSuccess = DAL.fnAddIssue(Global.uINSERT, row.Cells["itemcode"].Value.ToString(), cmbIndentNO.Text, Convert.ToDouble(row.Cells["IssuedQuantity"].Value),
                        (lblIndentProjcode.Text), cmbIssueType.Text, dateTimePicker1.Text, "", Convert.ToDouble(row.Cells["IssuedQuantity"].Value), iIndentRemainingQuantity, lblIndentBy.Text,
                        lblIndentdate.Text, ISSUEDNO.ToString(), row.Cells["ProjectBOMCode"].Value.ToString(), row.Cells["ProductNo"].Value.ToString(), Convert.ToDouble(row.Cells["unitprice"].Value));

                        //this Below code for adding the Inventory Issue
                        try
                        {
                            InventoryIndent = DAL.fnIndentAndItemToPickLocation(row.Cells["itemcode"].Value.ToString(), cmbIndentNO.Text).Tables[0];

                            int fnAddERPInventoryIssue_Status = DAL.fnAddERPInventoryIssue(Global.uINSERT, row.Cells["itemcode"].Value.ToString(), cmbIndentNO.Text, (lblIndentProjcode.Text), lblIndentBy.Text,
                                Convert.ToDouble(row.Cells["IssuedQuantity"].Value), Convert.ToDouble(row.Cells["IssuedQuantity"].Value), cmbIssueType.Text, "REMARKS", "close", row.Cells["ProjectBOMCode"].Value.ToString(),
                                row.Cells["ProductNo"].Value.ToString(), InventoryIndent.Rows[0]["GINNumber"].ToString(), InventoryIndent.Rows[0]["BatchCode"].ToString(), InventoryIndent.Rows[0]["Location"].ToString(), dateTimePicker1.Text, login.GetUserDetails[2]
                                );

                        }
                        catch (Exception error)
                        {
                            //MessageBox.Show("message from ERP issue creation");
                            // MessageBox.Show( error.Message, "POP for create Issue STatus");
                            int fnAddERPInventoryIssue_Status = DAL.fnAddERPInventoryIssue(Global.uINSERT, row.Cells["itemcode"].Value.ToString(), cmbIndentNO.Text, (lblIndentProjcode.Text), lblIndentBy.Text,
                                Convert.ToDouble(row.Cells["IssuedQuantity"].Value), Convert.ToDouble(row.Cells["IssuedQuantity"].Value), cmbIssueType.Text, "REMARKS", "close", row.Cells["ProjectBOMCode"].Value.ToString(),
                                row.Cells["ProductNo"].Value.ToString(), null, null, null, dateTimePicker1.Text, login.GetUserDetails[2]
                                );
                        }

                        try
                        {

                            int fnUpdateInventoryIndentClose_status = DAL.fnUpdateInventoryIndentClose("UPDATE", row.Cells["itemcode"].Value.ToString(), cmbIndentNO.Text, "close");

                        }
                        catch (Exception error)
                        {
                            // MessageBox.Show("This error message from ERP Update Indent");
                            // MessageBox.Show(error.Message, "POP for ERP Update Indent");
                        }
                        // code end for adding the Inventory Issue

                        if (dtItemDetails.Rows.Count > 0)
                        {
                            iNoItems++;

                            iAvailableQty = Convert.ToDouble(dtItemDetails.Rows[0]["AvailableQty"].ToString()) - Convert.ToDouble(row.Cells["IssuedQuantity"].Value);
                            dStockValue = Convert.ToDouble(dtItemDetails.Rows[0]["UnitCost"].ToString()) * iAvailableQty;

                            if (dtItemDetails.Rows[0]["Issue"].ToString() == "")
                            {
                                issue = Convert.ToDouble(row.Cells["IssuedQuantity"].Value);
                            }
                            else
                            {
                                issue = Convert.ToDouble(dtItemDetails.Rows[0]["Issue"].ToString()) + Convert.ToDouble(row.Cells["IssuedQuantity"].Value);
                            }

                            SqlCommand cmd1 = new SqlCommand("UPDATE ItemMaster SET AvailableQty='" + iAvailableQty + "',Issue='" + issue + "',StockValue='" + dStockValue + "' WHERE ItemCode='" + row.Cells["itemcode"].Value.ToString() + "'", SQLCon);
                            SQLCon.Open();
                            cmd1.ExecuteNonQuery();
                            SQLCon.Close();

                            SqlCommand cmd = new SqlCommand("UPDATE Indent SET IndentRemainingQty='" + iIndentRemainingQuantity + "' WHERE ItemCode='" + row.Cells["itemcode"].Value.ToString() + "' and IndentNo='" + cmbIndentNO.Text + "'", SQLCon);
                            SQLCon.Open();
                            cmd.ExecuteNonQuery();
                            SQLCon.Close();

                            if (iIndentRemainingQuantity == 0)
                            {
                               // MessageBox.Show("Indent RemaingQuantity is 0");
                                SqlCommand cmd5 = new SqlCommand("UPDATE Indent SET Status='Closed' WHERE ItemCode='" + row.Cells["itemcode"].Value.ToString() + "' and IndentNo='" + cmbIndentNO.Text + "'", SQLCon);
                                SQLCon.Open();
                                cmd5.ExecuteNonQuery();
                                SQLCon.Close();
                            }
                        }


                        if (dtMachineBOMItems.Rows.Count > 0)
                        {
                            if (string.IsNullOrEmpty(dtMachineBOMItems.Rows[0]["IssuedQty"].ToString()))
                            {
                                dBOMIssued = Convert.ToDouble(row.Cells["IssuedQuantity"].Value);
                            }
                            else
                            {
                                dBOMIssued = Convert.ToDouble(dtMachineBOMItems.Rows[0]["IssuedQty"].ToString()) + Convert.ToDouble(row.Cells["IssuedQuantity"].Value);
                            }

                            int fnUpdateMachineBOMUpdatetatus = DAL.fnUpdateMachineBOMUpdate("UPDATEBOM", row.Cells["ProjectBOMCode"].Value.ToString(), row.Cells["itemcode"].Value.ToString(), row.Cells["ProductNo"].Value.ToString(), dBOMIssued);

                            //MessageBox.Show("updating the Machine BOM-1");
                            //SqlCommand cmd = new SqlCommand("UPDATE MachineBOM SET IssuedQty='" + dBOMIssued + "' WHERE ItemName='" + row.Cells["itemcode"].Value.ToString() + "' and ProjectBOMCode='" + row.Cells["ProjectBOMCode"].Value.ToString() + "' and ProductNo='" + row.Cells["ProductNo"].Value.ToString() + "'", SQLCon);
                           // SQLCon.Open();
                            //cmd.ExecuteNonQuery();
                           // SQLCon.Close();
                        }


                    }

                    if (lblIndentProjcode.Text == "51423973035")
                    {
                        foreach (DataGridViewRow row in dgIndent.Rows)
                        {
                            dtKanBanItemCheck = DAL.fnKanBanItemList(row.Cells["itemcode"].Value.ToString()).Tables[0];
                            if (dtKanBanItemCheck.Rows.Count == 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddKanBanItem(Global.uINSERT, row.Cells["itemcode"].Value.ToString(), row.Cells["ItemDescription1"].Value.ToString(), dateTimePicker1.Text,
                                     Convert.ToDouble(row.Cells["unitprice"].Value), "", "", "", "", 0, "", "", "", "", "", "", "");
                            }

                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanItemDetails(1, Convert.ToDouble(row.Cells["IssuedQuantity"].Value), row.Cells["itemcode"].Value.ToString());
                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanItemDetails(2, Convert.ToDouble(row.Cells["IssuedQuantity"].Value), row.Cells["itemcode"].Value.ToString());

                            if (GLobalClass.iSuccess > 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddKanBanReciept(0, row.Cells["itemcode"].Value.ToString(), Convert.ToDouble(row.Cells["IssuedQuantity"].Value),
                                   Convert.ToDouble(row.Cells["unitprice"].Value), dateTimePicker1.Text, cmbIndentNO.Text);

                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbIndentNO.Text, login.GetUserDetails[2], dateTimePicker1.Text, "KanBan Transducer Receipt Added", "KanBanReceipt");

                            }
                        }
                    }

                    else if (lblIndentProjcode.Text == "613201177001")
                    {
                        foreach (DataGridViewRow row in dgIndent.Rows)
                        {
                            dtKanBanItemCheck = DAL.fnKanBanElectronicsRawItemList(row.Cells["itemcode"].Value.ToString()).Tables[0];
                            if (dtKanBanItemCheck.Rows.Count == 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddKanBanItem(22, row.Cells["itemcode"].Value.ToString(), row.Cells["ItemDescription1"].Value.ToString(), dateTimePicker1.Text,
                                     Convert.ToDouble(row.Cells["unitprice"].Value), "", "", "", "", 0, "", "", "", "", "", "", "");
                            }

                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(1, Convert.ToDouble(row.Cells["IssuedQuantity"].Value), row.Cells["itemcode"].Value.ToString());
                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(2, Convert.ToDouble(row.Cells["IssuedQuantity"].Value), row.Cells["itemcode"].Value.ToString());

                            if (GLobalClass.iSuccess > 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddKanBanElectronicReciept(0, row.Cells["itemcode"].Value.ToString(), Convert.ToDouble(row.Cells["IssuedQuantity"].Value),
                                   Convert.ToDouble(row.Cells["unitprice"].Value), dateTimePicker1.Text, cmbIndentNO.Text);

                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbIndentNO.Text, login.GetUserDetails[2], dateTimePicker1.Text, "KanBan Electronics Receipt Added", "KanBanElectronicsReceipt");

                            }
                        }
                    }
                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbIndentNO.Text, login.GetUserDetails[2], dateTimePicker1.Text, "Indent Issued", "Issued");

                    MessageBox.Show(" Item issued No: ' " + ISSUEDNO + " ' , Items '" + iNoItems + "' issued successfully ", "Success", 0, MessageBoxIcon.Information);
                    cmbIndentNO.Items.RemoveAt(cmbIndentNO.SelectedIndex);
                    btnAccept.Enabled = false;
                }
                else
                {
                    if (bProjectCost == false)
                    {
                        MessageBox.Show("Issued items limit is more than capex amount. Contact Accounts department for more details. \n \n Project Capex Amount : " + Math.Round(dProjectCost) + " \n Total Project Issued Amount : " + Math.Round(dTotalProjectSum) + " \n Current Project Issuing Amount : " + Math.Round(dCurrentIssuedAmount) + "", "Error", 0, MessageBoxIcon.Error);
                    }
                }
            }
            else if (cmbIssueType.SelectedIndex == 2)
            {
                JobQtyCheck();
                if (bjobqtyCheck == true && bProjectCost == true)
                {
                    fnGetJobIssueNumber();
                    ijobissuedcount = 0;
                    foreach (DataGridViewRow row in dgvJobIssue.Rows)
                    {

                        double dJobRemQty = 0;
                        string sItemCode = (row.Cells["Item_Code"].Value).ToString();
                        GLobalClass.iSuccess = DAL.fnAddJobIssue(Global.uINSERT, cmbWorkOrderNo.Text, row.Cells["Item_Code"].Value.ToString(), Convert.ToDouble(row.Cells["OrderdQuantity"].Value), Convert.ToDouble(row.Cells["Remaining_Quantity"].Value), (dateTimePicker1.Text), Convert.ToDouble(row.Cells["JobQuantity"].Value), JOBISSUEDNO.ToString(), Convert.ToDouble(row.Cells["UnitPrice1"].Value));

                        dtMachineBOMItems = DAL.fnIssueMachineBOMDetails(row.Cells["Item_Code"].Value.ToString(), lblJobProjcode.Text, row.Cells["jProductNo"].Value.ToString()).Tables[0];

                        dtItemDetails = DAL.fnIssueItemDetails(sItemCode).Tables[0];

                        dJobRemQty = Convert.ToDouble(row.Cells["Remaining_Quantity"].Value) - Convert.ToDouble(row.Cells["JobQuantity"].Value);

                        ijobissuedcount++;

                        iStockAvailableQty = Convert.ToDouble(dtItemDetails.Rows[0]["AvailableQty"].ToString());
                        iAvailableQty = Convert.ToDouble(iStockAvailableQty) - Convert.ToDouble(row.Cells["JobQuantity"].Value);

                        dStockValue = iAvailableQty * Convert.ToDouble(dtItemDetails.Rows[0]["UnitCost"].ToString());

                        SqlCommand cmd1 = new SqlCommand("UPDATE ItemMaster SET AvailableQty='" + iAvailableQty + "', StockValue='" + dStockValue + "' WHERE ItemCode='" + sItemCode + "'", SQLCon);
                        SQLCon.Open();
                        cmd1.ExecuteNonQuery();
                        SQLCon.Close();

                        if (dtMachineBOMItems.Rows.Count > 0)
                        {
                            MessageBox.Show("updating the Machine BOM-2");
                            if (string.IsNullOrEmpty(dtMachineBOMItems.Rows[0]["IssuedQty"].ToString()))
                            {
                                dBOMIssued = Convert.ToDouble(row.Cells["IssuedQuantity"].Value);
                            }
                            else
                            {
                                dBOMIssued = Convert.ToDouble(dtMachineBOMItems.Rows[0]["IssuedQty"].ToString()) + Convert.ToDouble(row.Cells["JobQuantity"].Value);
                            }
                            int fnUpdateMachineBOMUpdatetatus = DAL.fnUpdateMachineBOMUpdate("UPDATE", lblJobProjcode.Text, row.Cells["Item_Code"].Value.ToString(), row.Cells["jProductNo"].Value.ToString(), dBOMIssued);

                           //// SqlCommand cmd77 = new SqlCommand("UPDATE MachineBOM SET IssuedQty='" + dBOMIssued + "' WHERE ItemName='" + row.Cells["Item_Code"].Value.ToString() + "' and ProjectCode='" + lblJobProjcode.Text + "' and ProductNo='" + row.Cells["jProductNo"].Value.ToString() + "'", SQLCon);
                            //SQLCon.Open();
                           // cmd77.ExecuteNonQuery();
                            //SQLCon.Close();

                        }


                        SqlCommand cmd22 = new SqlCommand("UPDATE WorkOrder SET [IPRemainingOrderQty]='" + dJobRemQty + "',ActualSentQty='" + Convert.ToDouble(row.Cells["ActualQty"].Value) + "' WHERE IPItemCode='" + sItemCode + "' and WONumber='" + cmbWorkOrderNo.Text + "'", SQLCon);
                        SQLCon.Open();
                        cmd22.ExecuteNonQuery();
                        SQLCon.Close();

                        if (dJobRemQty <= 0)
                        {
                            SqlCommand cmd5 = new SqlCommand("UPDATE WorkOrder SET JobIssueStatus='Closed' WHERE IPItemCode='" + sItemCode + "' and WONumber='" + cmbWorkOrderNo.Text + "'", SQLCon);
                            SQLCon.Open();
                            cmd5.ExecuteNonQuery();
                            SQLCon.Close();
                        }
                        //  row.Cells["Remaining_Quantity"].Value = dJobRemQty;
                    }

                    if (lblJobProjcode.Text == "51423973035")
                    {
                        foreach (DataGridViewRow row in dgvJobIssue.Rows)
                        {
                            dtKanBanItemCheck = DAL.fnKanBanItemList(row.Cells["Item_Code"].Value.ToString()).Tables[0];
                            if (dtKanBanItemCheck.Rows.Count == 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddKanBanItem(Global.uINSERT, row.Cells["Item_Code"].Value.ToString(), row.Cells["ItemDescription"].Value.ToString(), dateTimePicker1.Text,
                                     Convert.ToDouble(row.Cells["UnitPrice1"].Value), "", "", "", "", 0, "", "", "", "", "", "", "");
                            }

                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanItemDetails(1, Convert.ToDouble(row.Cells["JobQuantity"].Value), row.Cells["Item_Code"].Value.ToString());
                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanItemDetails(2, Convert.ToDouble(row.Cells["JobQuantity"].Value), row.Cells["Item_Code"].Value.ToString());

                            if (GLobalClass.iSuccess > 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddKanBanReciept(0, row.Cells["Item_Code"].Value.ToString(), Convert.ToDouble(row.Cells["JobQuantity"].Value),
                                   Convert.ToDouble(row.Cells["UnitPrice1"].Value), dateTimePicker1.Text, cmbWorkOrderNo.Text);

                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbWorkOrderNo.Text, login.GetUserDetails[2], dateTimePicker1.Text, "KanBan Transducer Receipt Added", "KanBanReceipt");

                            }
                        }
                    }

                    else if (lblJobProjcode.Text == "613201177001")
                    {
                        foreach (DataGridViewRow row in dgvJobIssue.Rows)
                        {
                            dtKanBanItemCheck = DAL.fnKanBanElectronicsRawItemList(row.Cells["Item_Code"].Value.ToString()).Tables[0];
                            if (dtKanBanItemCheck.Rows.Count == 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddKanBanItem(22, row.Cells["Item_Code"].Value.ToString(), row.Cells["ItemDescription"].Value.ToString(), dateTimePicker1.Text,
                                     Convert.ToDouble(row.Cells["UnitPrice1"].Value), "", "", "", "", 0, "", "", "", "", "", "", "");
                            }

                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(1, Convert.ToDouble(row.Cells["JobQuantity"].Value), row.Cells["Item_Code"].Value.ToString());
                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(2, Convert.ToDouble(row.Cells["JobQuantity"].Value), row.Cells["Item_Code"].Value.ToString());

                            if (GLobalClass.iSuccess > 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddKanBanElectronicReciept(0, row.Cells["Item_Code"].Value.ToString(), Convert.ToDouble(row.Cells["JobQuantity"].Value),
                                   Convert.ToDouble(row.Cells["UnitPrice1"].Value), dateTimePicker1.Text, cmbWorkOrderNo.Text);

                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbWorkOrderNo.Text, login.GetUserDetails[2], dateTimePicker1.Text, "KanBan Electronics Receipt Added", "KanBanElectronicsReceipt");
                            }
                        }
                    }

                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbWorkOrderNo.Text, login.GetUserDetails[2], dateTimePicker1.Text, "Job Issued", "JobIssue");

                    MessageBox.Show("JobIssued No: ' " + JOBISSUEDNO + " ' , Items '" + ijobissuedcount + "' issued successfully ", "Success", 0, MessageBoxIcon.Information);
                    cmbWorkOrderNo.Items.RemoveAt(cmbWorkOrderNo.SelectedIndex);
                    btnAccept.Enabled = false;
                }
                else
                {
                    if (bProjectCost == false)
                    {
                        MessageBox.Show("Issued items limit is more than capex amount. Contact Accounts department for more details. \n \n Project Capex Amount : " + Math.Round(dProjectCost) + " \n Total Project Issued Amount : " + Math.Round(dTotalProjectSum) + " \n Current Project Issuing Amount : " + Math.Round(dCurrentIssuedAmount) + "", "Error", 0, MessageBoxIcon.Error);
                    }
                }
            }


        }
        #endregion
        #region FormExit
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }



        private void frmIssue_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }
        #endregion
        #region Code to Load Job Issue Items
        private void cmbWorkOrderNo_SelectedIndexChanged(object sender, EventArgs e)
        {

            dtJOBIssue = DAL.fnWorkOrderTableList(null, cmbWorkOrderNo.Text).Tables[0];
            if (dtJOBIssue.Rows.Count > 0)
            {
                dgvJobIssue.AutoGenerateColumns = false;
                dgvJobIssue.DataSource = dtJOBIssue;
                lblJobProjcode.Text = dtJOBIssue.Rows[0]["ProjectCode"].ToString();
                lblJobProject.Text = dtJOBIssue.Rows[0]["ProjectDescription"].ToString();
                lblWoBy.Text = dtJOBIssue.Rows[0]["PreparedBy"].ToString();
                lblWODate.Text = dtJOBIssue.Rows[0]["WOgeneratedDate"].ToString();
                lbljobCustomername.Text = dtJOBIssue.Rows[0]["Customer"].ToString();
                lblJobVendor.Text = dtJOBIssue.Rows[0]["VendorName"].ToString();

                foreach (DataGridViewRow row in dgvJobIssue.Rows)
                {
                    row.Cells["JobQuantity"].Value = row.Cells["Remaining_Quantity"].Value;
                }
                foreach (DataGridViewRow row in dgvJobIssue.Rows)
                {
                    if (Convert.ToDouble(row.Cells["AvailableQty1"].Value) > 0 && (Convert.ToDouble(row.Cells["AvailableQty1"].Value) >= Convert.ToDouble(row.Cells["JobQuantity"].Value)))
                    {
                        row.Cells["AvailableQty1"].Style.BackColor = Color.LightGreen;
                    }
                    else
                    {
                        row.Cells["AvailableQty1"].Style.BackColor = Color.Red;
                    }
                }
                btnAccept.Enabled = true;
            }

            else
            {
                dgvJobIssue.DataSource = null;
                lblJobProjcode.ResetText();
                lblJobProject.ResetText();
                lblWoBy.ResetText();
                lblWODate.ResetText();
                lbljobCustomername.ResetText();
                lblJobVendor.ResetText();
                btnAccept.Enabled = false;
            }
        }
        #endregion
        #region Code to Display Time
        private void timer1_Tick(object sender, EventArgs e)
        {
            lbltime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }
        #endregion
        #region Function for Numeric Validation

        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }


        private void dgvJobIssue_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvJobIssue.CurrentCell.OwningColumn.Name == "JobQuantity")
            {
                oldvalue = Convert.ToDouble(dgvJobIssue.CurrentCell.Value);
            }
        }

        private void dgvJobIssue_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if ((dgvJobIssue.CurrentCell.Value != null) && (dgvJobIssue.CurrentCell.Value.ToString() != sDot && Convert.ToDouble(dgvJobIssue.CurrentCell.Value.ToString()) != 0))// )// && // != null)
            {
                if (Convert.ToDouble(dgvJobIssue.CurrentRow.Cells["JobQuantity"].Value) > Convert.ToDouble(dgvJobIssue.CurrentRow.Cells["Remaining_Quantity"].Value))
                {
                    MessageBox.Show("Quantity entered is greater than work order quantity  ", "Warning", 0, MessageBoxIcon.Warning);
                    dgvJobIssue.CurrentRow.Cells["JobQuantity"].Value = oldvalue;
                }

                if (Convert.ToDouble(dgvJobIssue.CurrentRow.Cells["JobQuantity"].Value) > Convert.ToDouble(dgvJobIssue.CurrentRow.Cells["AvailableQty1"].Value))
                {
                    MessageBox.Show("Quantity entered is greater than stock available quantity  ", "Warning", 0, MessageBoxIcon.Warning);
                    dgvJobIssue.CurrentRow.Cells["JobQuantity"].Value = oldvalue;
                }
            }
            else
            {
                MessageBox.Show("Enter a valid Quantity", "Warning", 0, MessageBoxIcon.Warning);
                dgvJobIssue.CurrentRow.Cells["JobQuantity"].Value = oldvalue;
            }
        }

        private void dgvJobIssue_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void dgIndent_CellBeginEdit_1(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgIndent.CurrentCell.OwningColumn.Name == "IssuedQuantity")
            {
                oldvalue = Convert.ToDouble(dgIndent.CurrentCell.Value);
            }
        }

        private void dgIndent_EditingControlShowing_1(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void dgIndent_CellEndEdit_1(object sender, DataGridViewCellEventArgs e)
        {
            if (dgIndent.CurrentCell.OwningColumn.Name == "IssuedQuantity")
            {
                if ((dgIndent.CurrentCell.Value != null) && (dgIndent.CurrentCell.Value.ToString() != sDot && Convert.ToDouble(dgIndent.CurrentCell.Value.ToString()) != 0))// )// && // != null)
                {
                    if (Convert.ToDouble(dgIndent.CurrentRow.Cells["ProjectBOMQty"].Value) != 0)
                    {
                        if (Convert.ToDouble(dgIndent.CurrentRow.Cells["IssuedQuantity"].Value) > Convert.ToDouble(dgIndent.CurrentRow.Cells["AvailableQty"].Value) || Convert.ToDouble(dgIndent.CurrentRow.Cells["IssuedQuantity"].Value) > Convert.ToDouble(dgIndent.CurrentRow.Cells["ProjectBOMQty"].Value) || Convert.ToDouble(dgIndent.CurrentRow.Cells["IssuedQuantity"].Value) > Convert.ToDouble(dgIndent.CurrentRow.Cells["IndentQty"].Value))
                        {
                            MessageBox.Show("Enterd quantity is greater than the Indent quantity or Available quantity or BOM quantiy", "Warning", 0, MessageBoxIcon.Warning);
                            dgIndent.CurrentRow.Cells["IssuedQuantity"].Value = oldvalue;
                        }
                    }
                    else
                    {
                        if (Convert.ToDouble(dgIndent.CurrentRow.Cells["IssuedQuantity"].Value) > Convert.ToDouble(dgIndent.CurrentRow.Cells["AvailableQty"].Value) || Convert.ToDouble(dgIndent.CurrentRow.Cells["IssuedQuantity"].Value) > Convert.ToDouble(dgIndent.CurrentRow.Cells["IndentQty"].Value))
                        {
                            MessageBox.Show("Enterd quantity is greater than the Indent quantity or Available quantity", "Warning", 0, MessageBoxIcon.Warning);
                            dgIndent.CurrentRow.Cells["IssuedQuantity"].Value = oldvalue;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Enter a valid Quantity", "Warning", 0, MessageBoxIcon.Warning);
                    dgIndent.CurrentRow.Cells["IssuedQuantity"].Value = oldvalue;
                }
            }
        }
        #endregion

    }
}
