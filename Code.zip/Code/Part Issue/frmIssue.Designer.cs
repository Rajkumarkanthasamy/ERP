﻿namespace Erp_Project_With_Buttons
{
    partial class frmIssue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmIssue));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lbltime = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnAccept = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pnJob = new System.Windows.Forms.Panel();
            this.lblWODate = new System.Windows.Forms.Label();
            this.lblWoBy = new System.Windows.Forms.Label();
            this.lblJobVendor = new System.Windows.Forms.Label();
            this.lblJobProjcode = new System.Windows.Forms.Label();
            this.lblJobProject = new System.Windows.Forms.Label();
            this.cmbWorkOrderNo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbljobCustomername = new System.Windows.Forms.Label();
            this.lblWorkOrderNo = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblSearchVendor = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblpartissue = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.cmbIssueType = new System.Windows.Forms.ComboBox();
            this.lblissuetype = new System.Windows.Forms.Label();
            this.pnIndent = new System.Windows.Forms.Panel();
            this.lblprojectstatus = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblRemarks = new System.Windows.Forms.Label();
            this.lblIndentdate = new System.Windows.Forms.Label();
            this.lblIndentBy = new System.Windows.Forms.Label();
            this.lblIndentProjcode = new System.Windows.Forms.Label();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbIndentNO = new System.Windows.Forms.ComboBox();
            this.lblcustomername = new System.Windows.Forms.Label();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.lbldayt = new System.Windows.Forms.Label();
            this.lblprojdesc = new System.Windows.Forms.Label();
            this.lblindentnumber = new System.Windows.Forms.Label();
            this.lblitemccode = new System.Windows.Forms.Label();
            this.lblProjectNumber = new System.Windows.Forms.Label();
            this.dgIndent = new System.Windows.Forms.DataGridView();
            this.itemcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectBOMQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssuedQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssuedQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectBOMCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FIFOFollowed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvJobIssue = new System.Windows.Forms.DataGridView();
            this.Item_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableQty1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrderdQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remaining_Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JobQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JProductNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ActualQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.pnJob.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnIndent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgIndent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJobIssue)).BeginInit();
            this.SuspendLayout();
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.ForeColor = System.Drawing.Color.Black;
            this.lbltime.Location = new System.Drawing.Point(51, 151);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(51, 23);
            this.lbltime.TabIndex = 26;
            this.lbltime.Text = "Time";
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Black;
            this.lblWelcome.Location = new System.Drawing.Point(6, 91);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(98, 24);
            this.lblWelcome.TabIndex = 20;
            this.lblWelcome.Text = "Welcome :";
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.ForeColor = System.Drawing.Color.Black;
            this.lblUsername.Location = new System.Drawing.Point(102, 91);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(0, 24);
            this.lblUsername.TabIndex = 19;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Add-icon.png");
            this.imageList1.Images.SetKeyName(1, "table-add-icon.png");
            this.imageList1.Images.SetKeyName(2, "order-history-icon.png");
            this.imageList1.Images.SetKeyName(3, "Package-Add-icon.png");
            this.imageList1.Images.SetKeyName(4, "Excel-icon.png");
            this.imageList1.Images.SetKeyName(5, "Actions-address-book-new-icon.png");
            this.imageList1.Images.SetKeyName(6, "invoice-icon.png");
            this.imageList1.Images.SetKeyName(7, "Apps-kspread-icon.png");
            this.imageList1.Images.SetKeyName(8, "Apps-klipper-icon.png");
            this.imageList1.Images.SetKeyName(9, "Upline-icon.png");
            this.imageList1.Images.SetKeyName(10, "reports-icon.png");
            this.imageList1.Images.SetKeyName(11, "Mimetypes-application-vnd-sun-xml-calc-template-icon.png");
            this.imageList1.Images.SetKeyName(12, "catalog-icon.png");
            this.imageList1.Images.SetKeyName(13, "Add-icon.png");
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnAccept);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.Location = new System.Drawing.Point(245, 606);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1044, 64);
            this.groupBox2.TabIndex = 122;
            this.groupBox2.TabStop = false;
            // 
            // btnAccept
            // 
            this.btnAccept.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAccept.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAccept.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccept.Location = new System.Drawing.Point(758, 11);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(90, 48);
            this.btnAccept.TabIndex = 118;
            this.btnAccept.Text = "Issue";
            this.toolTip1.SetToolTip(this.btnAccept, "Click Here To Issue Items");
            this.btnAccept.UseVisualStyleBackColor = false;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(907, 11);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(93, 48);
            this.btnExit.TabIndex = 119;
            this.btnExit.Text = "Exit";
            this.toolTip1.SetToolTip(this.btnExit, "Click Here To Exit This Page");
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pnJob);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.lbltime);
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Controls.Add(this.lblWelcome);
            this.groupBox1.Controls.Add(this.lblUsername);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.cmbIssueType);
            this.groupBox1.Controls.Add(this.lblissuetype);
            this.groupBox1.Controls.Add(this.pnIndent);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold);
            this.groupBox1.ForeColor = System.Drawing.Color.Red;
            this.groupBox1.Location = new System.Drawing.Point(9, -2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1283, 192);
            this.groupBox1.TabIndex = 116;
            this.groupBox1.TabStop = false;
            // 
            // pnJob
            // 
            this.pnJob.Controls.Add(this.lblWODate);
            this.pnJob.Controls.Add(this.lblWoBy);
            this.pnJob.Controls.Add(this.lblJobVendor);
            this.pnJob.Controls.Add(this.lblJobProjcode);
            this.pnJob.Controls.Add(this.lblJobProject);
            this.pnJob.Controls.Add(this.cmbWorkOrderNo);
            this.pnJob.Controls.Add(this.label1);
            this.pnJob.Controls.Add(this.lbljobCustomername);
            this.pnJob.Controls.Add(this.lblWorkOrderNo);
            this.pnJob.Controls.Add(this.label3);
            this.pnJob.Controls.Add(this.lblSearchVendor);
            this.pnJob.Controls.Add(this.label4);
            this.pnJob.Controls.Add(this.label5);
            this.pnJob.Controls.Add(this.label9);
            this.pnJob.Location = new System.Drawing.Point(284, 53);
            this.pnJob.Name = "pnJob";
            this.pnJob.Size = new System.Drawing.Size(965, 135);
            this.pnJob.TabIndex = 132;
            this.pnJob.Visible = false;
            // 
            // lblWODate
            // 
            this.lblWODate.AutoSize = true;
            this.lblWODate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWODate.ForeColor = System.Drawing.Color.Black;
            this.lblWODate.Location = new System.Drawing.Point(662, 68);
            this.lblWODate.Name = "lblWODate";
            this.lblWODate.Size = new System.Drawing.Size(17, 19);
            this.lblWODate.TabIndex = 135;
            this.lblWODate.Text = "*";
            // 
            // lblWoBy
            // 
            this.lblWoBy.AutoSize = true;
            this.lblWoBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWoBy.ForeColor = System.Drawing.Color.Black;
            this.lblWoBy.Location = new System.Drawing.Point(665, 40);
            this.lblWoBy.Name = "lblWoBy";
            this.lblWoBy.Size = new System.Drawing.Size(17, 19);
            this.lblWoBy.TabIndex = 134;
            this.lblWoBy.Text = "*";
            // 
            // lblJobVendor
            // 
            this.lblJobVendor.AutoSize = true;
            this.lblJobVendor.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJobVendor.ForeColor = System.Drawing.Color.Black;
            this.lblJobVendor.Location = new System.Drawing.Point(665, 8);
            this.lblJobVendor.Name = "lblJobVendor";
            this.lblJobVendor.Size = new System.Drawing.Size(17, 19);
            this.lblJobVendor.TabIndex = 133;
            this.lblJobVendor.Text = "*";
            // 
            // lblJobProjcode
            // 
            this.lblJobProjcode.AutoSize = true;
            this.lblJobProjcode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJobProjcode.ForeColor = System.Drawing.Color.Black;
            this.lblJobProjcode.Location = new System.Drawing.Point(152, 44);
            this.lblJobProjcode.Name = "lblJobProjcode";
            this.lblJobProjcode.Size = new System.Drawing.Size(17, 19);
            this.lblJobProjcode.TabIndex = 132;
            this.lblJobProjcode.Text = "*";
            // 
            // lblJobProject
            // 
            this.lblJobProject.AutoSize = true;
            this.lblJobProject.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJobProject.ForeColor = System.Drawing.Color.Black;
            this.lblJobProject.Location = new System.Drawing.Point(150, 73);
            this.lblJobProject.Name = "lblJobProject";
            this.lblJobProject.Size = new System.Drawing.Size(17, 19);
            this.lblJobProject.TabIndex = 131;
            this.lblJobProject.Text = "*";
            // 
            // cmbWorkOrderNo
            // 
            this.cmbWorkOrderNo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbWorkOrderNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbWorkOrderNo.DropDownHeight = 150;
            this.cmbWorkOrderNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWorkOrderNo.DropDownWidth = 181;
            this.cmbWorkOrderNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWorkOrderNo.FormattingEnabled = true;
            this.cmbWorkOrderNo.IntegralHeight = false;
            this.cmbWorkOrderNo.Location = new System.Drawing.Point(154, 5);
            this.cmbWorkOrderNo.Name = "cmbWorkOrderNo";
            this.cmbWorkOrderNo.Size = new System.Drawing.Size(215, 27);
            this.cmbWorkOrderNo.TabIndex = 116;
            this.cmbWorkOrderNo.SelectedIndexChanged += new System.EventHandler(this.cmbWorkOrderNo_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(544, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 19);
            this.label1.TabIndex = 130;
            this.label1.Text = "Work Order By :";
            // 
            // lbljobCustomername
            // 
            this.lbljobCustomername.AutoSize = true;
            this.lbljobCustomername.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbljobCustomername.ForeColor = System.Drawing.Color.Black;
            this.lbljobCustomername.Location = new System.Drawing.Point(150, 97);
            this.lbljobCustomername.Name = "lbljobCustomername";
            this.lbljobCustomername.Size = new System.Drawing.Size(17, 19);
            this.lbljobCustomername.TabIndex = 128;
            this.lbljobCustomername.Text = "*";
            // 
            // lblWorkOrderNo
            // 
            this.lblWorkOrderNo.AutoSize = true;
            this.lblWorkOrderNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWorkOrderNo.ForeColor = System.Drawing.Color.Black;
            this.lblWorkOrderNo.Location = new System.Drawing.Point(30, 10);
            this.lblWorkOrderNo.Name = "lblWorkOrderNo";
            this.lblWorkOrderNo.Size = new System.Drawing.Size(122, 19);
            this.lblWorkOrderNo.TabIndex = 101;
            this.lblWorkOrderNo.Text = "Work Order No :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(26, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 19);
            this.label3.TabIndex = 129;
            this.label3.Text = "Customer Name :";
            // 
            // lblSearchVendor
            // 
            this.lblSearchVendor.AutoSize = true;
            this.lblSearchVendor.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchVendor.ForeColor = System.Drawing.Color.Black;
            this.lblSearchVendor.Location = new System.Drawing.Point(548, 8);
            this.lblSearchVendor.Name = "lblSearchVendor";
            this.lblSearchVendor.Size = new System.Drawing.Size(114, 19);
            this.lblSearchVendor.TabIndex = 90;
            this.lblSearchVendor.Text = " Vendor Name :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(529, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 19);
            this.label4.TabIndex = 88;
            this.label4.Text = "Work Order Date :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(63, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 19);
            this.label5.TabIndex = 126;
            this.label5.Text = "Proj Name :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(48, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(104, 19);
            this.label9.TabIndex = 87;
            this.label9.Text = "Project Code :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(851, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 19);
            this.label6.TabIndex = 133;
            this.label6.Text = "Issued Date :";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.lblpartissue);
            this.panel3.Location = new System.Drawing.Point(6, 20);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(264, 45);
            this.panel3.TabIndex = 82;
            // 
            // lblpartissue
            // 
            this.lblpartissue.AutoSize = true;
            this.lblpartissue.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpartissue.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblpartissue.Location = new System.Drawing.Point(61, 3);
            this.lblpartissue.Name = "lblpartissue";
            this.lblpartissue.Size = new System.Drawing.Size(123, 33);
            this.lblpartissue.TabIndex = 81;
            this.lblpartissue.Text = "Part Issue";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CustomFormat = "";
            this.dateTimePicker1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(952, 19);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(118, 27);
            this.dateTimePicker1.TabIndex = 120;
            // 
            // cmbIssueType
            // 
            this.cmbIssueType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbIssueType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbIssueType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbIssueType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.cmbIssueType.FormattingEnabled = true;
            this.cmbIssueType.Items.AddRange(new object[] {
            "None",
            "Indents",
            "Job"});
            this.cmbIssueType.Location = new System.Drawing.Point(438, 22);
            this.cmbIssueType.Name = "cmbIssueType";
            this.cmbIssueType.Size = new System.Drawing.Size(215, 27);
            this.cmbIssueType.TabIndex = 91;
            this.toolTip1.SetToolTip(this.cmbIssueType, "Select Issue Type");
            this.cmbIssueType.SelectedIndexChanged += new System.EventHandler(this.cmbIssueType_SelectedIndexChanged);
            // 
            // lblissuetype
            // 
            this.lblissuetype.AutoSize = true;
            this.lblissuetype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblissuetype.ForeColor = System.Drawing.Color.Black;
            this.lblissuetype.Location = new System.Drawing.Point(353, 27);
            this.lblissuetype.Name = "lblissuetype";
            this.lblissuetype.Size = new System.Drawing.Size(87, 19);
            this.lblissuetype.TabIndex = 82;
            this.lblissuetype.Text = "Issue Type :";
            // 
            // pnIndent
            // 
            this.pnIndent.Controls.Add(this.lblprojectstatus);
            this.pnIndent.Controls.Add(this.label8);
            this.pnIndent.Controls.Add(this.lblRemarks);
            this.pnIndent.Controls.Add(this.lblIndentdate);
            this.pnIndent.Controls.Add(this.lblIndentBy);
            this.pnIndent.Controls.Add(this.lblIndentProjcode);
            this.pnIndent.Controls.Add(this.lblProjectName);
            this.pnIndent.Controls.Add(this.label2);
            this.pnIndent.Controls.Add(this.cmbIndentNO);
            this.pnIndent.Controls.Add(this.lblcustomername);
            this.pnIndent.Controls.Add(this.lblcustomer);
            this.pnIndent.Controls.Add(this.lbldayt);
            this.pnIndent.Controls.Add(this.lblprojdesc);
            this.pnIndent.Controls.Add(this.lblindentnumber);
            this.pnIndent.Controls.Add(this.lblitemccode);
            this.pnIndent.Controls.Add(this.lblProjectNumber);
            this.pnIndent.Location = new System.Drawing.Point(289, 50);
            this.pnIndent.Name = "pnIndent";
            this.pnIndent.Size = new System.Drawing.Size(932, 136);
            this.pnIndent.TabIndex = 123;
            this.pnIndent.Visible = false;
            // 
            // lblprojectstatus
            // 
            this.lblprojectstatus.AutoSize = true;
            this.lblprojectstatus.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojectstatus.ForeColor = System.Drawing.Color.Black;
            this.lblprojectstatus.Location = new System.Drawing.Point(655, 102);
            this.lblprojectstatus.Name = "lblprojectstatus";
            this.lblprojectstatus.Size = new System.Drawing.Size(17, 19);
            this.lblprojectstatus.TabIndex = 139;
            this.lblprojectstatus.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(531, 102);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 19);
            this.label8.TabIndex = 140;
            this.label8.Text = "Project Status :";
            // 
            // lblRemarks
            // 
            this.lblRemarks.AutoSize = true;
            this.lblRemarks.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemarks.ForeColor = System.Drawing.Color.Black;
            this.lblRemarks.Location = new System.Drawing.Point(656, 60);
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.Size = new System.Drawing.Size(17, 19);
            this.lblRemarks.TabIndex = 138;
            this.lblRemarks.Text = "*";
            // 
            // lblIndentdate
            // 
            this.lblIndentdate.AutoSize = true;
            this.lblIndentdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndentdate.ForeColor = System.Drawing.Color.Black;
            this.lblIndentdate.Location = new System.Drawing.Point(656, 10);
            this.lblIndentdate.Name = "lblIndentdate";
            this.lblIndentdate.Size = new System.Drawing.Size(17, 19);
            this.lblIndentdate.TabIndex = 137;
            this.lblIndentdate.Text = "*";
            // 
            // lblIndentBy
            // 
            this.lblIndentBy.AutoSize = true;
            this.lblIndentBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndentBy.ForeColor = System.Drawing.Color.Black;
            this.lblIndentBy.Location = new System.Drawing.Point(656, 37);
            this.lblIndentBy.Name = "lblIndentBy";
            this.lblIndentBy.Size = new System.Drawing.Size(17, 19);
            this.lblIndentBy.TabIndex = 136;
            this.lblIndentBy.Text = "*";
            // 
            // lblIndentProjcode
            // 
            this.lblIndentProjcode.AutoSize = true;
            this.lblIndentProjcode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndentProjcode.ForeColor = System.Drawing.Color.Black;
            this.lblIndentProjcode.Location = new System.Drawing.Point(146, 52);
            this.lblIndentProjcode.Name = "lblIndentProjcode";
            this.lblIndentProjcode.Size = new System.Drawing.Size(17, 19);
            this.lblIndentProjcode.TabIndex = 135;
            this.lblIndentProjcode.Text = "*";
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.Color.Black;
            this.lblProjectName.Location = new System.Drawing.Point(144, 79);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(17, 19);
            this.lblProjectName.TabIndex = 134;
            this.lblProjectName.Text = "*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(578, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 19);
            this.label2.TabIndex = 132;
            this.label2.Text = "Remarks  :";
            // 
            // cmbIndentNO
            // 
            this.cmbIndentNO.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbIndentNO.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbIndentNO.DropDownHeight = 150;
            this.cmbIndentNO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbIndentNO.DropDownWidth = 181;
            this.cmbIndentNO.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbIndentNO.FormattingEnabled = true;
            this.cmbIndentNO.IntegralHeight = false;
            this.cmbIndentNO.Location = new System.Drawing.Point(148, 8);
            this.cmbIndentNO.Name = "cmbIndentNO";
            this.cmbIndentNO.Size = new System.Drawing.Size(215, 27);
            this.cmbIndentNO.TabIndex = 114;
            this.toolTip1.SetToolTip(this.cmbIndentNO, "Select Indent Number");
            this.cmbIndentNO.SelectedIndexChanged += new System.EventHandler(this.cmbIndentNO_SelectedIndexChanged);
            // 
            // lblcustomername
            // 
            this.lblcustomername.AutoSize = true;
            this.lblcustomername.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomername.ForeColor = System.Drawing.Color.Black;
            this.lblcustomername.Location = new System.Drawing.Point(144, 104);
            this.lblcustomername.Name = "lblcustomername";
            this.lblcustomername.Size = new System.Drawing.Size(17, 19);
            this.lblcustomername.TabIndex = 128;
            this.lblcustomername.Text = "*";
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.Color.Black;
            this.lblcustomer.Location = new System.Drawing.Point(20, 104);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(126, 19);
            this.lblcustomer.TabIndex = 129;
            this.lblcustomer.Text = "Customer Name :";
            // 
            // lbldayt
            // 
            this.lbldayt.AutoSize = true;
            this.lbldayt.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldayt.ForeColor = System.Drawing.Color.Black;
            this.lbldayt.Location = new System.Drawing.Point(559, 10);
            this.lbldayt.Name = "lbldayt";
            this.lbldayt.Size = new System.Drawing.Size(98, 19);
            this.lbldayt.TabIndex = 88;
            this.lbldayt.Text = "Indent Date :";
            // 
            // lblprojdesc
            // 
            this.lblprojdesc.AutoSize = true;
            this.lblprojdesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojdesc.ForeColor = System.Drawing.Color.Black;
            this.lblprojdesc.Location = new System.Drawing.Point(57, 79);
            this.lblprojdesc.Name = "lblprojdesc";
            this.lblprojdesc.Size = new System.Drawing.Size(89, 19);
            this.lblprojdesc.TabIndex = 126;
            this.lblprojdesc.Text = "Proj Name :";
            // 
            // lblindentnumber
            // 
            this.lblindentnumber.AutoSize = true;
            this.lblindentnumber.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblindentnumber.ForeColor = System.Drawing.Color.Black;
            this.lblindentnumber.Location = new System.Drawing.Point(28, 11);
            this.lblindentnumber.Name = "lblindentnumber";
            this.lblindentnumber.Size = new System.Drawing.Size(122, 19);
            this.lblindentnumber.TabIndex = 85;
            this.lblindentnumber.Text = "Indent Number :";
            // 
            // lblitemccode
            // 
            this.lblitemccode.AutoSize = true;
            this.lblitemccode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemccode.ForeColor = System.Drawing.Color.Black;
            this.lblitemccode.Location = new System.Drawing.Point(574, 37);
            this.lblitemccode.Name = "lblitemccode";
            this.lblitemccode.Size = new System.Drawing.Size(83, 19);
            this.lblitemccode.TabIndex = 84;
            this.lblitemccode.Text = "Indent By :";
            // 
            // lblProjectNumber
            // 
            this.lblProjectNumber.AutoSize = true;
            this.lblProjectNumber.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectNumber.ForeColor = System.Drawing.Color.Black;
            this.lblProjectNumber.Location = new System.Drawing.Point(45, 52);
            this.lblProjectNumber.Name = "lblProjectNumber";
            this.lblProjectNumber.Size = new System.Drawing.Size(104, 19);
            this.lblProjectNumber.TabIndex = 87;
            this.lblProjectNumber.Text = "Project Code :";
            // 
            // dgIndent
            // 
            this.dgIndent.AllowUserToAddRows = false;
            this.dgIndent.AllowUserToDeleteRows = false;
            this.dgIndent.AllowUserToResizeRows = false;
            this.dgIndent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgIndent.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgIndent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgIndent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.itemcode,
            this.ItemDescription1,
            this.UnitPrice,
            this.ProjectBOMQty,
            this.AvailableQty,
            this.IndQty,
            this.IssuedQty,
            this.IndentQty,
            this.IssuedQuantity,
            this.ProjectBOMCode,
            this.ProductNo,
            this.FIFOFollowed});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgIndent.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgIndent.EnableHeadersVisualStyles = false;
            this.dgIndent.Location = new System.Drawing.Point(12, 210);
            this.dgIndent.MultiSelect = false;
            this.dgIndent.Name = "dgIndent";
            this.dgIndent.RowHeadersVisible = false;
            this.dgIndent.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgIndent.Size = new System.Drawing.Size(1280, 375);
            this.dgIndent.TabIndex = 123;
            this.dgIndent.Visible = false;
            this.dgIndent.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgIndent_CellBeginEdit_1);
            this.dgIndent.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgIndent_CellEndEdit_1);
            this.dgIndent.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgIndent_EditingControlShowing_1);
            // 
            // itemcode
            // 
            this.itemcode.DataPropertyName = "ItemCode";
            this.itemcode.HeaderText = "ItemCode";
            this.itemcode.Name = "itemcode";
            this.itemcode.ReadOnly = true;
            this.itemcode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.itemcode.Width = 80;
            // 
            // ItemDescription1
            // 
            this.ItemDescription1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription1.DataPropertyName = "ItemDescription";
            this.ItemDescription1.HeaderText = "Item Description";
            this.ItemDescription1.Name = "ItemDescription1";
            this.ItemDescription1.ReadOnly = true;
            this.ItemDescription1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription1.Width = 127;
            // 
            // UnitPrice
            // 
            this.UnitPrice.DataPropertyName = "UnitCost";
            this.UnitPrice.HeaderText = "UnitPrice";
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.ReadOnly = true;
            this.UnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitPrice.Width = 78;
            // 
            // ProjectBOMQty
            // 
            this.ProjectBOMQty.DataPropertyName = "BOMQty";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ProjectBOMQty.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProjectBOMQty.HeaderText = "BOM Qty";
            this.ProjectBOMQty.Name = "ProjectBOMQty";
            this.ProjectBOMQty.ReadOnly = true;
            this.ProjectBOMQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectBOMQty.Width = 70;
            // 
            // AvailableQty
            // 
            this.AvailableQty.DataPropertyName = "AvailableQty";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.AvailableQty.DefaultCellStyle = dataGridViewCellStyle3;
            this.AvailableQty.HeaderText = "Available Qty";
            this.AvailableQty.Name = "AvailableQty";
            this.AvailableQty.ReadOnly = true;
            this.AvailableQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AvailableQty.Width = 96;
            // 
            // IndQty
            // 
            this.IndQty.DataPropertyName = "IndentQty";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IndQty.DefaultCellStyle = dataGridViewCellStyle4;
            this.IndQty.HeaderText = "Indent Qty";
            this.IndQty.Name = "IndQty";
            this.IndQty.ReadOnly = true;
            this.IndQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IndQty.Width = 80;
            // 
            // IssuedQty
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IssuedQty.DefaultCellStyle = dataGridViewCellStyle5;
            this.IssuedQty.HeaderText = "Issued Qty";
            this.IssuedQty.Name = "IssuedQty";
            this.IssuedQty.ReadOnly = true;
            this.IssuedQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IssuedQty.Width = 77;
            // 
            // IndentQty
            // 
            this.IndentQty.DataPropertyName = "IndentRemainingQty";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IndentQty.DefaultCellStyle = dataGridViewCellStyle6;
            this.IndentQty.HeaderText = "Indent Rem Qty";
            this.IndentQty.Name = "IndentQty";
            this.IndentQty.ReadOnly = true;
            this.IndentQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IndentQty.Width = 88;
            // 
            // IssuedQuantity
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.IssuedQuantity.DefaultCellStyle = dataGridViewCellStyle7;
            this.IssuedQuantity.HeaderText = "Issue Qty";
            this.IssuedQuantity.Name = "IssuedQuantity";
            this.IssuedQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IssuedQuantity.Width = 69;
            // 
            // ProjectBOMCode
            // 
            this.ProjectBOMCode.DataPropertyName = "ProjectBOMCode";
            this.ProjectBOMCode.HeaderText = "ProjectBOMCode";
            this.ProjectBOMCode.Name = "ProjectBOMCode";
            this.ProjectBOMCode.ReadOnly = true;
            this.ProjectBOMCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectBOMCode.Visible = false;
            this.ProjectBOMCode.Width = 132;
            // 
            // ProductNo
            // 
            this.ProductNo.DataPropertyName = "ProductNo";
            this.ProductNo.HeaderText = "ProductNo";
            this.ProductNo.Name = "ProductNo";
            this.ProductNo.ReadOnly = true;
            this.ProductNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductNo.Visible = false;
            this.ProductNo.Width = 90;
            // 
            // FIFOFollowed
            // 
            this.FIFOFollowed.DataPropertyName = "FIFOFollowed";
            this.FIFOFollowed.DefaultCellStyle = dataGridViewCellStyle2;
            this.FIFOFollowed.HeaderText = "FIFO Followed";
            this.FIFOFollowed.Name = "FIFOFollowed";
            this.FIFOFollowed.ReadOnly = true;
            this.FIFOFollowed.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FIFOFollowed.Width = 99;
            // 
            // dgvJobIssue
            // 
            this.dgvJobIssue.AllowUserToAddRows = false;
            this.dgvJobIssue.AllowUserToDeleteRows = false;
            this.dgvJobIssue.AllowUserToResizeRows = false;
            this.dgvJobIssue.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvJobIssue.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvJobIssue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvJobIssue.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Item_Code,
            this.ItemDescription,
            this.UnitPrice1,
            this.AvailableQty1,
            this.OrderdQuantity,
            this.Remaining_Quantity,
            this.JobQuantity,
            this.JProductNo,
            this.ActualQty});
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvJobIssue.DefaultCellStyle = dataGridViewCellStyle15;
            this.dgvJobIssue.EnableHeadersVisualStyles = false;
            this.dgvJobIssue.Location = new System.Drawing.Point(9, 228);
            this.dgvJobIssue.MultiSelect = false;
            this.dgvJobIssue.Name = "dgvJobIssue";
            this.dgvJobIssue.RowHeadersVisible = false;
            this.dgvJobIssue.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvJobIssue.Size = new System.Drawing.Size(1283, 357);
            this.dgvJobIssue.TabIndex = 121;
            this.dgvJobIssue.Visible = false;
            this.dgvJobIssue.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvJobIssue_CellBeginEdit);
            this.dgvJobIssue.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvJobIssue_CellEndEdit);
            this.dgvJobIssue.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvJobIssue_EditingControlShowing);
            // 
            // Item_Code
            // 
            this.Item_Code.DataPropertyName = "IPItemCode";
            this.Item_Code.HeaderText = "ItemCode";
            this.Item_Code.Name = "Item_Code";
            this.Item_Code.ReadOnly = true;
            this.Item_Code.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Item_Code.Width = 80;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            this.ItemDescription.HeaderText = "ItemDescription";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 137;
            // 
            // UnitPrice1
            // 
            this.UnitPrice1.DataPropertyName = "UnitCost";
            this.UnitPrice1.HeaderText = "UnitPrice";
            this.UnitPrice1.Name = "UnitPrice1";
            this.UnitPrice1.ReadOnly = true;
            this.UnitPrice1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitPrice1.Width = 78;
            // 
            // AvailableQty1
            // 
            this.AvailableQty1.DataPropertyName = "AvailableQty";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.AvailableQty1.DefaultCellStyle = dataGridViewCellStyle10;
            this.AvailableQty1.HeaderText = "Available Qty";
            this.AvailableQty1.Name = "AvailableQty1";
            this.AvailableQty1.ReadOnly = true;
            this.AvailableQty1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AvailableQty1.Width = 96;
            // 
            // OrderdQuantity
            // 
            this.OrderdQuantity.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.OrderdQuantity.DataPropertyName = "IPOrderQty";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.OrderdQuantity.DefaultCellStyle = dataGridViewCellStyle11;
            this.OrderdQuantity.HeaderText = "Order Qty";
            this.OrderdQuantity.Name = "OrderdQuantity";
            this.OrderdQuantity.ReadOnly = true;
            this.OrderdQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OrderdQuantity.Width = 76;
            // 
            // Remaining_Quantity
            // 
            this.Remaining_Quantity.DataPropertyName = "IPRemainingOrderQty";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Remaining_Quantity.DefaultCellStyle = dataGridViewCellStyle12;
            this.Remaining_Quantity.HeaderText = "Remaining Qty";
            this.Remaining_Quantity.Name = "Remaining_Quantity";
            this.Remaining_Quantity.ReadOnly = true;
            this.Remaining_Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Remaining_Quantity.Width = 104;
            // 
            // JobQuantity
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle13.NullValue = null;
            this.JobQuantity.DefaultCellStyle = dataGridViewCellStyle13;
            this.JobQuantity.HeaderText = "Issue Qty";
            this.JobQuantity.Name = "JobQuantity";
            this.JobQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.JobQuantity.Width = 69;
            // 
            // JProductNo
            // 
            this.JProductNo.DataPropertyName = "ProductNo";
            this.JProductNo.HeaderText = "ProductNo";
            this.JProductNo.Name = "JProductNo";
            this.JProductNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.JProductNo.Visible = false;
            this.JProductNo.Width = 90;
            // 
            // ActualQty
            // 
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ActualQty.DefaultCellStyle = dataGridViewCellStyle14;
            this.ActualQty.HeaderText = "Actual Sent Qty";
            this.ActualQty.Name = "ActualQty";
            this.ActualQty.Width = 107;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frmIssue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dgvJobIssue);
            this.Controls.Add(this.dgIndent);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmIssue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Issue";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmIssue_FormClosing);
            this.Load += new System.EventHandler(this.frmIssue_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.pnJob.ResumeLayout(false);
            this.pnJob.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.pnIndent.ResumeLayout(false);
            this.pnIndent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgIndent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJobIssue)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.Label lblpartissue;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.DataGridView dgvJobIssue;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbWorkOrderNo;
        private System.Windows.Forms.Label lblindentnumber;
        private System.Windows.Forms.ComboBox cmbIndentNO;
        private System.Windows.Forms.Label lbldayt;
        private System.Windows.Forms.Label lblitemccode;
        private System.Windows.Forms.ComboBox cmbIssueType;
        private System.Windows.Forms.Label lblissuetype;
        private System.Windows.Forms.Label lblSearchVendor;
        private System.Windows.Forms.Label lblWorkOrderNo;
        private System.Windows.Forms.Label lblProjectNumber;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblprojdesc;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.Label lblcustomername;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnJob;
        private System.Windows.Forms.Label lbljobCustomername;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel pnIndent;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.Label lblJobProject;
        private System.Windows.Forms.Label lblWODate;
        private System.Windows.Forms.Label lblWoBy;
        private System.Windows.Forms.Label lblJobVendor;
        private System.Windows.Forms.Label lblJobProjcode;
        private System.Windows.Forms.Label lblRemarks;
        private System.Windows.Forms.Label lblIndentdate;
        private System.Windows.Forms.Label lblIndentBy;
        private System.Windows.Forms.Label lblIndentProjcode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgIndent;
        private System.Windows.Forms.Label lblprojectstatus;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn FIFOFollowed;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription1;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectBOMQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssuedQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssuedQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectBOMCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Item_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice1;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableQty1;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderdQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remaining_Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn JobQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn JProductNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ActualQty;

    }
}