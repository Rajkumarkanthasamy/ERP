﻿namespace ItemCodeCreationApp
{
    partial class frmItemCodeApproval
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpPendingRequests = new System.Windows.Forms.GroupBox();
            this.dgvPendingRequests = new System.Windows.Forms.DataGridView();
            this.colSelect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colRequestID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRequestDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRequestor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDepartment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colItemCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAuthorizedCreator = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colApprovalStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grpFilters = new System.Windows.Forms.GroupBox();
            this.lblFilterCategory = new System.Windows.Forms.Label();
            this.cmbFilterCategory = new System.Windows.Forms.ComboBox();
            this.lblFilterDepartment = new System.Windows.Forms.Label();
            this.cmbFilterDepartment = new System.Windows.Forms.ComboBox();
            this.lblFilterStatus = new System.Windows.Forms.Label();
            this.cmbFilterStatus = new System.Windows.Forms.ComboBox();
            this.btnFilter = new System.Windows.Forms.Button();
            this.btnClearFilter = new System.Windows.Forms.Button();
            this.grpSelectedRequest = new System.Windows.Forms.GroupBox();
            this.lblSelectedRequestID = new System.Windows.Forms.Label();
            this.txtSelectedRequestID = new System.Windows.Forms.TextBox();
            this.lblSelectedItemCode = new System.Windows.Forms.Label();
            this.txtSelectedItemCode = new System.Windows.Forms.TextBox();
            this.lblSelectedDescription = new System.Windows.Forms.Label();
            this.txtSelectedDescription = new System.Windows.Forms.TextBox();
            this.lblSelectedCategory = new System.Windows.Forms.Label();
            this.txtSelectedCategory = new System.Windows.Forms.TextBox();
            this.lblSelectedRequestor = new System.Windows.Forms.Label();
            this.txtSelectedRequestor = new System.Windows.Forms.TextBox();
            this.lblSelectedDepartment = new System.Windows.Forms.Label();
            this.txtSelectedDepartment = new System.Windows.Forms.TextBox();
            this.lblSelectedTechnicalSpec = new System.Windows.Forms.Label();
            this.txtSelectedTechnicalSpec = new System.Windows.Forms.TextBox();
            this.lblSelectedUOM = new System.Windows.Forms.Label();
            this.txtSelectedUOM = new System.Windows.Forms.TextBox();
            this.lblSelectedCriticality = new System.Windows.Forms.Label();
            this.txtSelectedCriticality = new System.Windows.Forms.TextBox();
            this.lblSelectedHSN = new System.Windows.Forms.Label();
            this.txtSelectedHSN = new System.Windows.Forms.TextBox();
            this.grpApprovalAction = new System.Windows.Forms.GroupBox();
            this.lblAction = new System.Windows.Forms.Label();
            this.cmbAction = new System.Windows.Forms.ComboBox();
            this.lblApprovalRemarks = new System.Windows.Forms.Label();
            this.txtApprovalRemarks = new System.Windows.Forms.TextBox();
            this.lblApproverName = new System.Windows.Forms.Label();
            this.txtApproverName = new System.Windows.Forms.TextBox();
            this.lblApprovalDate = new System.Windows.Forms.Label();
            this.dtpApprovalDate = new System.Windows.Forms.DateTimePicker();
            this.btnApprove = new System.Windows.Forms.Button();
            this.btnReject = new System.Windows.Forms.Button();
            this.btnHold = new System.Windows.Forms.Button();
            this.grpBulkActions = new System.Windows.Forms.GroupBox();
            this.btnBulkApprove = new System.Windows.Forms.Button();
            this.btnBulkReject = new System.Windows.Forms.Button();
            this.btnBulkHold = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblTotalPending = new System.Windows.Forms.Label();
            this.txtTotalPending = new System.Windows.Forms.TextBox();
            this.lblTotalApproved = new System.Windows.Forms.Label();
            this.txtTotalApproved = new System.Windows.Forms.TextBox();
            this.lblTotalRejected = new System.Windows.Forms.Label();
            this.txtTotalRejected = new System.Windows.Forms.TextBox();
            this.lblUserRole = new System.Windows.Forms.Label();
            this.txtUserRole = new System.Windows.Forms.TextBox();
            this.grpPendingRequests.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPendingRequests)).BeginInit();
            this.grpFilters.SuspendLayout();
            this.grpSelectedRequest.SuspendLayout();
            this.grpApprovalAction.SuspendLayout();
            this.grpBulkActions.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(320, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(320, 24);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Item Code Approval Dashboard";
            // 
            // grpPendingRequests
            // 
            this.grpPendingRequests.Controls.Add(this.dgvPendingRequests);
            this.grpPendingRequests.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpPendingRequests.Location = new System.Drawing.Point(12, 100);
            this.grpPendingRequests.Name = "grpPendingRequests";
            this.grpPendingRequests.Size = new System.Drawing.Size(900, 250);
            this.grpPendingRequests.TabIndex = 1;
            this.grpPendingRequests.TabStop = false;
            this.grpPendingRequests.Text = "Pending Item Code Requests";
            // 
            // dgvPendingRequests
            // 
            this.dgvPendingRequests.AllowUserToAddRows = false;
            this.dgvPendingRequests.AllowUserToDeleteRows = false;
            this.dgvPendingRequests.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPendingRequests.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPendingRequests.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSelect,
            this.colRequestID,
            this.colRequestDate,
            this.colRequestor,
            this.colDepartment,
            this.colItemCategory,
            this.colItemDescription,
            this.colItemCode,
            this.colAuthorizedCreator,
            this.colApprovalStatus});
            this.dgvPendingRequests.Location = new System.Drawing.Point(6, 20);
            this.dgvPendingRequests.MultiSelect = false;
            this.dgvPendingRequests.Name = "dgvPendingRequests";
            this.dgvPendingRequests.ReadOnly = true;
            this.dgvPendingRequests.RowHeadersVisible = false;
            this.dgvPendingRequests.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPendingRequests.Size = new System.Drawing.Size(888, 224);
            this.dgvPendingRequests.TabIndex = 0;
            this.dgvPendingRequests.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPendingRequests_CellClick);
            this.dgvPendingRequests.SelectionChanged += new System.EventHandler(this.dgvPendingRequests_SelectionChanged);
            // 
            // colSelect
            // 
            this.colSelect.HeaderText = "Select";
            this.colSelect.Name = "colSelect";
            this.colSelect.ReadOnly = true;
            this.colSelect.Width = 50;
            // 
            // colRequestID
            // 
            this.colRequestID.HeaderText = "Request ID";
            this.colRequestID.Name = "colRequestID";
            this.colRequestID.ReadOnly = true;
            // 
            // colRequestDate
            // 
            this.colRequestDate.HeaderText = "Request Date";
            this.colRequestDate.Name = "colRequestDate";
            this.colRequestDate.ReadOnly = true;
            // 
            // colRequestor
            // 
            this.colRequestor.HeaderText = "Requestor";
            this.colRequestor.Name = "colRequestor";
            this.colRequestor.ReadOnly = true;
            // 
            // colDepartment
            // 
            this.colDepartment.HeaderText = "Department";
            this.colDepartment.Name = "colDepartment";
            this.colDepartment.ReadOnly = true;
            // 
            // colItemCategory
            // 
            this.colItemCategory.HeaderText = "Item Category";
            this.colItemCategory.Name = "colItemCategory";
            this.colItemCategory.ReadOnly = true;
            // 
            // colItemDescription
            // 
            this.colItemDescription.HeaderText = "Description";
            this.colItemDescription.Name = "colItemDescription";
            this.colItemDescription.ReadOnly = true;
            // 
            // colItemCode
            // 
            this.colItemCode.HeaderText = "Item Code";
            this.colItemCode.Name = "colItemCode";
            this.colItemCode.ReadOnly = true;
            // 
            // colAuthorizedCreator
            // 
            this.colAuthorizedCreator.HeaderText = "Creator";
            this.colAuthorizedCreator.Name = "colAuthorizedCreator";
            this.colAuthorizedCreator.ReadOnly = true;
            // 
            // colApprovalStatus
            // 
            this.colApprovalStatus.HeaderText = "Status";
            this.colApprovalStatus.Name = "colApprovalStatus";
            this.colApprovalStatus.ReadOnly = true;
            // 
            // grpFilters
            // 
            this.grpFilters.Controls.Add(this.btnClearFilter);
            this.grpFilters.Controls.Add(this.btnFilter);
            this.grpFilters.Controls.Add(this.cmbFilterStatus);
            this.grpFilters.Controls.Add(this.lblFilterStatus);
            this.grpFilters.Controls.Add(this.cmbFilterDepartment);
            this.grpFilters.Controls.Add(this.lblFilterDepartment);
            this.grpFilters.Controls.Add(this.cmbFilterCategory);
            this.grpFilters.Controls.Add(this.lblFilterCategory);
            this.grpFilters.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpFilters.Location = new System.Drawing.Point(12, 45);
            this.grpFilters.Name = "grpFilters";
            this.grpFilters.Size = new System.Drawing.Size(900, 55);
            this.grpFilters.TabIndex = 2;
            this.grpFilters.TabStop = false;
            this.grpFilters.Text = "Filters";
            // 
            // lblFilterCategory
            // 
            this.lblFilterCategory.AutoSize = true;
            this.lblFilterCategory.Location = new System.Drawing.Point(10, 25);
            this.lblFilterCategory.Name = "lblFilterCategory";
            this.lblFilterCategory.Size = new System.Drawing.Size(58, 15);
            this.lblFilterCategory.TabIndex = 0;
            this.lblFilterCategory.Text = "Category:";
            // 
            // cmbFilterCategory
            // 
            this.cmbFilterCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFilterCategory.FormattingEnabled = true;
            this.cmbFilterCategory.Location = new System.Drawing.Point(70, 22);
            this.cmbFilterCategory.Name = "cmbFilterCategory";
            this.cmbFilterCategory.Size = new System.Drawing.Size(150, 23);
            this.cmbFilterCategory.TabIndex = 1;
            // 
            // lblFilterDepartment
            // 
            this.lblFilterDepartment.AutoSize = true;
            this.lblFilterDepartment.Location = new System.Drawing.Point(230, 25);
            this.lblFilterDepartment.Name = "lblFilterDepartment";
            this.lblFilterDepartment.Size = new System.Drawing.Size(75, 15);
            this.lblFilterDepartment.TabIndex = 2;
            this.lblFilterDepartment.Text = "Department:";
            // 
            // cmbFilterDepartment
            // 
            this.cmbFilterDepartment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFilterDepartment.FormattingEnabled = true;
            this.cmbFilterDepartment.Location = new System.Drawing.Point(310, 22);
            this.cmbFilterDepartment.Name = "cmbFilterDepartment";
            this.cmbFilterDepartment.Size = new System.Drawing.Size(150, 23);
            this.cmbFilterDepartment.TabIndex = 3;
            // 
            // lblFilterStatus
            // 
            this.lblFilterStatus.AutoSize = true;
            this.lblFilterStatus.Location = new System.Drawing.Point(470, 25);
            this.lblFilterStatus.Name = "lblFilterStatus";
            this.lblFilterStatus.Size = new System.Drawing.Size(45, 15);
            this.lblFilterStatus.TabIndex = 4;
            this.lblFilterStatus.Text = "Status:";
            // 
            // cmbFilterStatus
            // 
            this.cmbFilterStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFilterStatus.FormattingEnabled = true;
            this.cmbFilterStatus.Location = new System.Drawing.Point(520, 22);
            this.cmbFilterStatus.Name = "cmbFilterStatus";
            this.cmbFilterStatus.Size = new System.Drawing.Size(120, 23);
            this.cmbFilterStatus.TabIndex = 5;
            // 
            // btnFilter
            // 
            this.btnFilter.BackColor = System.Drawing.Color.LightBlue;
            this.btnFilter.Location = new System.Drawing.Point(660, 20);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(80, 25);
            this.btnFilter.TabIndex = 6;
            this.btnFilter.Text = "Apply Filter";
            this.btnFilter.UseVisualStyleBackColor = false;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // btnClearFilter
            // 
            this.btnClearFilter.BackColor = System.Drawing.Color.LightYellow;
            this.btnClearFilter.Location = new System.Drawing.Point(750, 20);
            this.btnClearFilter.Name = "btnClearFilter";
            this.btnClearFilter.Size = new System.Drawing.Size(80, 25);
            this.btnClearFilter.TabIndex = 7;
            this.btnClearFilter.Text = "Clear";
            this.btnClearFilter.UseVisualStyleBackColor = false;
            this.btnClearFilter.Click += new System.EventHandler(this.btnClearFilter_Click);
            // 
            // grpSelectedRequest
            // 
            this.grpSelectedRequest.Controls.Add(this.txtSelectedHSN);
            this.grpSelectedRequest.Controls.Add(this.lblSelectedHSN);
            this.grpSelectedRequest.Controls.Add(this.txtSelectedCriticality);
            this.grpSelectedRequest.Controls.Add(this.lblSelectedCriticality);
            this.grpSelectedRequest.Controls.Add(this.txtSelectedUOM);
            this.grpSelectedRequest.Controls.Add(this.lblSelectedUOM);
            this.grpSelectedRequest.Controls.Add(this.txtSelectedTechnicalSpec);
            this.grpSelectedRequest.Controls.Add(this.lblSelectedTechnicalSpec);
            this.grpSelectedRequest.Controls.Add(this.txtSelectedDepartment);
            this.grpSelectedRequest.Controls.Add(this.lblSelectedDepartment);
            this.grpSelectedRequest.Controls.Add(this.txtSelectedRequestor);
            this.grpSelectedRequest.Controls.Add(this.lblSelectedRequestor);
            this.grpSelectedRequest.Controls.Add(this.txtSelectedCategory);
            this.grpSelectedRequest.Controls.Add(this.lblSelectedCategory);
            this.grpSelectedRequest.Controls.Add(this.txtSelectedDescription);
            this.grpSelectedRequest.Controls.Add(this.lblSelectedDescription);
            this.grpSelectedRequest.Controls.Add(this.txtSelectedItemCode);
            this.grpSelectedRequest.Controls.Add(this.lblSelectedItemCode);
            this.grpSelectedRequest.Controls.Add(this.txtSelectedRequestID);
            this.grpSelectedRequest.Controls.Add(this.lblSelectedRequestID);
            this.grpSelectedRequest.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSelectedRequest.Location = new System.Drawing.Point(12, 360);
            this.grpSelectedRequest.Name = "grpSelectedRequest";
            this.grpSelectedRequest.Size = new System.Drawing.Size(480, 280);
            this.grpSelectedRequest.TabIndex = 3;
            this.grpSelectedRequest.TabStop = false;
            this.grpSelectedRequest.Text = "Selected Request Details";
            // 
            // lblSelectedRequestID
            // 
            this.lblSelectedRequestID.AutoSize = true;
            this.lblSelectedRequestID.Location = new System.Drawing.Point(15, 25);
            this.lblSelectedRequestID.Name = "lblSelectedRequestID";
            this.lblSelectedRequestID.Size = new System.Drawing.Size(68, 15);
            this.lblSelectedRequestID.TabIndex = 0;
            this.lblSelectedRequestID.Text = "Request ID:";
            // 
            // txtSelectedRequestID
            // 
            this.txtSelectedRequestID.Location = new System.Drawing.Point(120, 22);
            this.txtSelectedRequestID.Name = "txtSelectedRequestID";
            this.txtSelectedRequestID.ReadOnly = true;
            this.txtSelectedRequestID.Size = new System.Drawing.Size(120, 21);
            this.txtSelectedRequestID.TabIndex = 1;
            // 
            // lblSelectedItemCode
            // 
            this.lblSelectedItemCode.AutoSize = true;
            this.lblSelectedItemCode.Location = new System.Drawing.Point(260, 25);
            this.lblSelectedItemCode.Name = "lblSelectedItemCode";
            this.lblSelectedItemCode.Size = new System.Drawing.Size(65, 15);
            this.lblSelectedItemCode.TabIndex = 2;
            this.lblSelectedItemCode.Text = "Item Code:";
            // 
            // txtSelectedItemCode
            // 
            this.txtSelectedItemCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSelectedItemCode.Location = new System.Drawing.Point(330, 22);
            this.txtSelectedItemCode.Name = "txtSelectedItemCode";
            this.txtSelectedItemCode.ReadOnly = true;
            this.txtSelectedItemCode.Size = new System.Drawing.Size(130, 21);
            this.txtSelectedItemCode.TabIndex = 3;
            // 
            // lblSelectedDescription
            // 
            this.lblSelectedDescription.AutoSize = true;
            this.lblSelectedDescription.Location = new System.Drawing.Point(15, 55);
            this.lblSelectedDescription.Name = "lblSelectedDescription";
            this.lblSelectedDescription.Size = new System.Drawing.Size(72, 15);
            this.lblSelectedDescription.TabIndex = 4;
            this.lblSelectedDescription.Text = "Description:";
            // 
            // txtSelectedDescription
            // 
            this.txtSelectedDescription.Location = new System.Drawing.Point(120, 52);
            this.txtSelectedDescription.Name = "txtSelectedDescription";
            this.txtSelectedDescription.ReadOnly = true;
            this.txtSelectedDescription.Size = new System.Drawing.Size(340, 21);
            this.txtSelectedDescription.TabIndex = 5;
            // 
            // lblSelectedCategory
            // 
            this.lblSelectedCategory.AutoSize = true;
            this.lblSelectedCategory.Location = new System.Drawing.Point(15, 85);
            this.lblSelectedCategory.Name = "lblSelectedCategory";
            this.lblSelectedCategory.Size = new System.Drawing.Size(58, 15);
            this.lblSelectedCategory.TabIndex = 6;
            this.lblSelectedCategory.Text = "Category:";
            // 
            // txtSelectedCategory
            // 
            this.txtSelectedCategory.Location = new System.Drawing.Point(120, 82);
            this.txtSelectedCategory.Name = "txtSelectedCategory";
            this.txtSelectedCategory.ReadOnly = true;
            this.txtSelectedCategory.Size = new System.Drawing.Size(150, 21);
            this.txtSelectedCategory.TabIndex = 7;
            // 
            // lblSelectedRequestor
            // 
            this.lblSelectedRequestor.AutoSize = true;
            this.lblSelectedRequestor.Location = new System.Drawing.Point(15, 115);
            this.lblSelectedRequestor.Name = "lblSelectedRequestor";
            this.lblSelectedRequestor.Size = new System.Drawing.Size(63, 15);
            this.lblSelectedRequestor.TabIndex = 8;
            this.lblSelectedRequestor.Text = "Requestor:";
            // 
            // txtSelectedRequestor
            // 
            this.txtSelectedRequestor.Location = new System.Drawing.Point(120, 112);
            this.txtSelectedRequestor.Name = "txtSelectedRequestor";
            this.txtSelectedRequestor.ReadOnly = true;
            this.txtSelectedRequestor.Size = new System.Drawing.Size(150, 21);
            this.txtSelectedRequestor.TabIndex = 9;
            // 
            // lblSelectedDepartment
            // 
            this.lblSelectedDepartment.AutoSize = true;
            this.lblSelectedDepartment.Location = new System.Drawing.Point(15, 145);
            this.lblSelectedDepartment.Name = "lblSelectedDepartment";
            this.lblSelectedDepartment.Size = new System.Drawing.Size(75, 15);
            this.lblSelectedDepartment.TabIndex = 10;
            this.lblSelectedDepartment.Text = "Department:";
            // 
            // txtSelectedDepartment
            // 
            this.txtSelectedDepartment.Location = new System.Drawing.Point(120, 142);
            this.txtSelectedDepartment.Name = "txtSelectedDepartment";
            this.txtSelectedDepartment.ReadOnly = true;
            this.txtSelectedDepartment.Size = new System.Drawing.Size(150, 21);
            this.txtSelectedDepartment.TabIndex = 11;
            // 
            // lblSelectedTechnicalSpec
            // 
            this.lblSelectedTechnicalSpec.AutoSize = true;
            this.lblSelectedTechnicalSpec.Location = new System.Drawing.Point(15, 175);
            this.lblSelectedTechnicalSpec.Name = "lblSelectedTechnicalSpec";
            this.lblSelectedTechnicalSpec.Size = new System.Drawing.Size(83, 15);
            this.lblSelectedTechnicalSpec.TabIndex = 12;
            this.lblSelectedTechnicalSpec.Text = "Technical Spec:";
            // 
            // txtSelectedTechnicalSpec
            // 
            this.txtSelectedTechnicalSpec.Location = new System.Drawing.Point(120, 172);
            this.txtSelectedTechnicalSpec.Multiline = true;
            this.txtSelectedTechnicalSpec.Name = "txtSelectedTechnicalSpec";
            this.txtSelectedTechnicalSpec.ReadOnly = true;
            this.txtSelectedTechnicalSpec.Size = new System.Drawing.Size(340, 40);
            this.txtSelectedTechnicalSpec.TabIndex = 13;
            // 
            // lblSelectedUOM
            // 
            this.lblSelectedUOM.AutoSize = true;
            this.lblSelectedUOM.Location = new System.Drawing.Point(15, 220);
            this.lblSelectedUOM.Name = "lblSelectedUOM";
            this.lblSelectedUOM.Size = new System.Drawing.Size(36, 15);
            this.lblSelectedUOM.TabIndex = 14;
            this.lblSelectedUOM.Text = "UOM:";
            // 
            // txtSelectedUOM
            // 
            this.txtSelectedUOM.Location = new System.Drawing.Point(120, 217);
            this.txtSelectedUOM.Name = "txtSelectedUOM";
            this.txtSelectedUOM.ReadOnly = true;
            this.txtSelectedUOM.Size = new System.Drawing.Size(100, 21);
            this.txtSelectedUOM.TabIndex = 15;
            // 
            // lblSelectedCriticality
            // 
            this.lblSelectedCriticality.AutoSize = true;
            this.lblSelectedCriticality.Location = new System.Drawing.Point(240, 220);
            this.lblSelectedCriticality.Name = "lblSelectedCriticality";
            this.lblSelectedCriticality.Size = new System.Drawing.Size(59, 15);
            this.lblSelectedCriticality.TabIndex = 16;
            this.lblSelectedCriticality.Text = "Criticality:";
            // 
            // txtSelectedCriticality
            // 
            this.txtSelectedCriticality.Location = new System.Drawing.Point(310, 217);
            this.txtSelectedCriticality.Name = "txtSelectedCriticality";
            this.txtSelectedCriticality.ReadOnly = true;
            this.txtSelectedCriticality.Size = new System.Drawing.Size(150, 21);
            this.txtSelectedCriticality.TabIndex = 17;
            // 
            // lblSelectedHSN
            // 
            this.lblSelectedHSN.AutoSize = true;
            this.lblSelectedHSN.Location = new System.Drawing.Point(15, 250);
            this.lblSelectedHSN.Name = "lblSelectedHSN";
            this.lblSelectedHSN.Size = new System.Drawing.Size(65, 15);
            this.lblSelectedHSN.TabIndex = 18;
            this.lblSelectedHSN.Text = "HSN Code:";
            // 
            // txtSelectedHSN
            // 
            this.txtSelectedHSN.Location = new System.Drawing.Point(120, 247);
            this.txtSelectedHSN.Name = "txtSelectedHSN";
            this.txtSelectedHSN.ReadOnly = true;
            this.txtSelectedHSN.Size = new System.Drawing.Size(120, 21);
            this.txtSelectedHSN.TabIndex = 19;
            // 
            // grpApprovalAction
            // 
            this.grpApprovalAction.Controls.Add(this.dtpApprovalDate);
            this.grpApprovalAction.Controls.Add(this.lblApprovalDate);
            this.grpApprovalAction.Controls.Add(this.txtApproverName);
            this.grpApprovalAction.Controls.Add(this.lblApproverName);
            this.grpApprovalAction.Controls.Add(this.txtApprovalRemarks);
            this.grpApprovalAction.Controls.Add(this.lblApprovalRemarks);
            this.grpApprovalAction.Controls.Add(this.cmbAction);
            this.grpApprovalAction.Controls.Add(this.lblAction);
            this.grpApprovalAction.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpApprovalAction.Location = new System.Drawing.Point(510, 360);
            this.grpApprovalAction.Name = "grpApprovalAction";
            this.grpApprovalAction.Size = new System.Drawing.Size(400, 180);
            this.grpApprovalAction.TabIndex = 4;
            this.grpApprovalAction.TabStop = false;
            this.grpApprovalAction.Text = "Approval Action";
            // 
            // lblAction
            // 
            this.lblAction.AutoSize = true;
            this.lblAction.Location = new System.Drawing.Point(15, 25);
            this.lblAction.Name = "lblAction";
            this.lblAction.Size = new System.Drawing.Size(43, 15);
            this.lblAction.TabIndex = 0;
            this.lblAction.Text = "Action:";
            // 
            // cmbAction
            // 
            this.cmbAction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAction.FormattingEnabled = true;
            this.cmbAction.Location = new System.Drawing.Point(120, 22);
            this.cmbAction.Name = "cmbAction";
            this.cmbAction.Size = new System.Drawing.Size(150, 23);
            this.cmbAction.TabIndex = 1;
            // 
            // lblApprovalRemarks
            // 
            this.lblApprovalRemarks.AutoSize = true;
            this.lblApprovalRemarks.Location = new System.Drawing.Point(15, 55);
            this.lblApprovalRemarks.Name = "lblApprovalRemarks";
            this.lblApprovalRemarks.Size = new System.Drawing.Size(58, 15);
            this.lblApprovalRemarks.TabIndex = 2;
            this.lblApprovalRemarks.Text = "Remarks:";
            // 
            // txtApprovalRemarks
            // 
            this.txtApprovalRemarks.Location = new System.Drawing.Point(120, 52);
            this.txtApprovalRemarks.Multiline = true;
            this.txtApprovalRemarks.Name = "txtApprovalRemarks";
            this.txtApprovalRemarks.Size = new System.Drawing.Size(260, 50);
            this.txtApprovalRemarks.TabIndex = 3;
            // 
            // lblApproverName
            // 
            this.lblApproverName.AutoSize = true;
            this.lblApproverName.Location = new System.Drawing.Point(15, 110);
            this.lblApproverName.Name = "lblApproverName";
            this.lblApproverName.Size = new System.Drawing.Size(91, 15);
            this.lblApproverName.TabIndex = 4;
            this.lblApproverName.Text = "Approver Name:";
            // 
            // txtApproverName
            // 
            this.txtApproverName.Location = new System.Drawing.Point(120, 107);
            this.txtApproverName.Name = "txtApproverName";
            this.txtApproverName.Size = new System.Drawing.Size(200, 21);
            this.txtApproverName.TabIndex = 5;
            // 
            // lblApprovalDate
            // 
            this.lblApprovalDate.AutoSize = true;
            this.lblApprovalDate.Location = new System.Drawing.Point(15, 140);
            this.lblApprovalDate.Name = "lblApprovalDate";
            this.lblApprovalDate.Size = new System.Drawing.Size(36, 15);
            this.lblApprovalDate.TabIndex = 6;
            this.lblApprovalDate.Text = "Date:";
            // 
            // dtpApprovalDate
            // 
            this.dtpApprovalDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpApprovalDate.Location = new System.Drawing.Point(120, 137);
            this.dtpApprovalDate.Name = "dtpApprovalDate";
            this.dtpApprovalDate.Size = new System.Drawing.Size(120, 21);
            this.dtpApprovalDate.TabIndex = 7;
            // 
            // btnApprove
            // 
            this.btnApprove.BackColor = System.Drawing.Color.LightGreen;
            this.btnApprove.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApprove.Location = new System.Drawing.Point(510, 550);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new System.Drawing.Size(120, 35);
            this.btnApprove.TabIndex = 5;
            this.btnApprove.Text = "Approve";
            this.btnApprove.UseVisualStyleBackColor = false;
            this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click);
            // 
            // btnReject
            // 
            this.btnReject.BackColor = System.Drawing.Color.LightCoral;
            this.btnReject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReject.Location = new System.Drawing.Point(650, 550);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(120, 35);
            this.btnReject.TabIndex = 6;
            this.btnReject.Text = "Reject";
            this.btnReject.UseVisualStyleBackColor = false;
            this.btnReject.Click += new System.EventHandler(this.btnReject_Click);
            // 
            // btnHold
            // 
            this.btnHold.BackColor = System.Drawing.Color.LightYellow;
            this.btnHold.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHold.Location = new System.Drawing.Point(790, 550);
            this.btnHold.Name = "btnHold";
            this.btnHold.Size = new System.Drawing.Size(120, 35);
            this.btnHold.TabIndex = 7;
            this.btnHold.Text = "On Hold";
            this.btnHold.UseVisualStyleBackColor = false;
            this.btnHold.Click += new System.EventHandler(this.btnHold_Click);
            // 
            // grpBulkActions
            // 
            this.grpBulkActions.Controls.Add(this.btnBulkHold);
            this.grpBulkActions.Controls.Add(this.btnBulkReject);
            this.grpBulkActions.Controls.Add(this.btnBulkApprove);
            this.grpBulkActions.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBulkActions.Location = new System.Drawing.Point(12, 650);
            this.grpBulkActions.Name = "grpBulkActions";
            this.grpBulkActions.Size = new System.Drawing.Size(480, 60);
            this.grpBulkActions.TabIndex = 8;
            this.grpBulkActions.TabStop = false;
            this.grpBulkActions.Text = "Bulk Actions (Multiple Selection)";
            // 
            // btnBulkApprove
            // 
            this.btnBulkApprove.BackColor = System.Drawing.Color.LightGreen;
            this.btnBulkApprove.Location = new System.Drawing.Point(20, 22);
            this.btnBulkApprove.Name = "btnBulkApprove";
            this.btnBulkApprove.Size = new System.Drawing.Size(130, 28);
            this.btnBulkApprove.TabIndex = 0;
            this.btnBulkApprove.Text = "Bulk Approve";
            this.btnBulkApprove.UseVisualStyleBackColor = false;
            this.btnBulkApprove.Click += new System.EventHandler(this.btnBulkApprove_Click);
            // 
            // btnBulkReject
            // 
            this.btnBulkReject.BackColor = System.Drawing.Color.LightCoral;
            this.btnBulkReject.Location = new System.Drawing.Point(170, 22);
            this.btnBulkReject.Name = "btnBulkReject";
            this.btnBulkReject.Size = new System.Drawing.Size(130, 28);
            this.btnBulkReject.TabIndex = 1;
            this.btnBulkReject.Text = "Bulk Reject";
            this.btnBulkReject.UseVisualStyleBackColor = false;
            this.btnBulkReject.Click += new System.EventHandler(this.btnBulkReject_Click);
            // 
            // btnBulkHold
            // 
            this.btnBulkHold.BackColor = System.Drawing.Color.LightYellow;
            this.btnBulkHold.Location = new System.Drawing.Point(320, 22);
            this.btnBulkHold.Name = "btnBulkHold";
            this.btnBulkHold.Size = new System.Drawing.Size(130, 28);
            this.btnBulkHold.TabIndex = 2;
            this.btnBulkHold.Text = "Bulk On Hold";
            this.btnBulkHold.UseVisualStyleBackColor = false;
            this.btnBulkHold.Click += new System.EventHandler(this.btnBulkHold_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.Location = new System.Drawing.Point(510, 650);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(90, 28);
            this.btnRefresh.TabIndex = 9;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnExport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.Location = new System.Drawing.Point(610, 650);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(90, 28);
            this.btnExport.TabIndex = 10;
            this.btnExport.Text = "Export";
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Location = new System.Drawing.Point(710, 650);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(90, 28);
            this.btnPrint.TabIndex = 11;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.LightCoral;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(820, 650);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(90, 28);
            this.btnClose.TabIndex = 12;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblTotalPending
            // 
            this.lblTotalPending.AutoSize = true;
            this.lblTotalPending.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalPending.Location = new System.Drawing.Point(15, 720);
            this.lblTotalPending.Name = "lblTotalPending";
            this.lblTotalPending.Size = new System.Drawing.Size(95, 15);
            this.lblTotalPending.TabIndex = 13;
            this.lblTotalPending.Text = "Total Pending:";
            // 
            // txtTotalPending
            // 
            this.txtTotalPending.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalPending.Location = new System.Drawing.Point(110, 717);
            this.txtTotalPending.Name = "txtTotalPending";
            this.txtTotalPending.ReadOnly = true;
            this.txtTotalPending.Size = new System.Drawing.Size(50, 21);
            this.txtTotalPending.TabIndex = 14;
            this.txtTotalPending.Text = "0";
            // 
            // lblTotalApproved
            // 
            this.lblTotalApproved.AutoSize = true;
            this.lblTotalApproved.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalApproved.Location = new System.Drawing.Point(180, 720);
            this.lblTotalApproved.Name = "lblTotalApproved";
            this.lblTotalApproved.Size = new System.Drawing.Size(107, 15);
            this.lblTotalApproved.TabIndex = 15;
            this.lblTotalApproved.Text = "Total Approved:";
            // 
            // txtTotalApproved
            // 
            this.txtTotalApproved.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalApproved.Location = new System.Drawing.Point(290, 717);
            this.txtTotalApproved.Name = "txtTotalApproved";
            this.txtTotalApproved.ReadOnly = true;
            this.txtTotalApproved.Size = new System.Drawing.Size(50, 21);
            this.txtTotalApproved.TabIndex = 16;
            this.txtTotalApproved.Text = "0";
            // 
            // lblTotalRejected
            // 
            this.lblTotalRejected.AutoSize = true;
            this.lblTotalRejected.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalRejected.Location = new System.Drawing.Point(360, 720);
            this.lblTotalRejected.Name = "lblTotalRejected";
            this.lblTotalRejected.Size = new System.Drawing.Size(100, 15);
            this.lblTotalRejected.TabIndex = 17;
            this.lblTotalRejected.Text = "Total Rejected:";
            // 
            // txtTotalRejected
            // 
            this.txtTotalRejected.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalRejected.Location = new System.Drawing.Point(465, 717);
            this.txtTotalRejected.Name = "txtTotalRejected";
            this.txtTotalRejected.ReadOnly = true;
            this.txtTotalRejected.Size = new System.Drawing.Size(50, 21);
            this.txtTotalRejected.TabIndex = 18;
            this.txtTotalRejected.Text = "0";
            // 
            // lblUserRole
            // 
            this.lblUserRole.AutoSize = true;
            this.lblUserRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserRole.Location = new System.Drawing.Point(550, 720);
            this.lblUserRole.Name = "lblUserRole";
            this.lblUserRole.Size = new System.Drawing.Size(69, 15);
            this.lblUserRole.TabIndex = 19;
            this.lblUserRole.Text = "User Role:";
            // 
            // txtUserRole
            // 
            this.txtUserRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUserRole.Location = new System.Drawing.Point(625, 717);
            this.txtUserRole.Name = "txtUserRole";
            this.txtUserRole.ReadOnly = true;
            this.txtUserRole.Size = new System.Drawing.Size(200, 21);
            this.txtUserRole.TabIndex = 20;
            // 
            // frmItemCodeApproval
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(924, 751);
            this.Controls.Add(this.txtUserRole);
            this.Controls.Add(this.lblUserRole);
            this.Controls.Add(this.txtTotalRejected);
            this.Controls.Add(this.lblTotalRejected);
            this.Controls.Add(this.txtTotalApproved);
            this.Controls.Add(this.lblTotalApproved);
            this.Controls.Add(this.txtTotalPending);
            this.Controls.Add(this.lblTotalPending);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.grpBulkActions);
            this.Controls.Add(this.btnHold);
            this.Controls.Add(this.btnReject);
            this.Controls.Add(this.btnApprove);
            this.Controls.Add(this.grpApprovalAction);
            this.Controls.Add(this.grpSelectedRequest);
            this.Controls.Add(this.grpFilters);
            this.Controls.Add(this.grpPendingRequests);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmItemCodeApproval";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Item Code Approval Dashboard";
            this.Load += new System.EventHandler(this.frmItemCodeApproval_Load);
            this.grpPendingRequests.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPendingRequests)).EndInit();
            this.grpFilters.ResumeLayout(false);
            this.grpFilters.PerformLayout();
            this.grpSelectedRequest.ResumeLayout(false);
            this.grpSelectedRequest.PerformLayout();
            this.grpApprovalAction.ResumeLayout(false);
            this.grpApprovalAction.PerformLayout();
            this.grpBulkActions.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox grpPendingRequests;
        private System.Windows.Forms.DataGridView dgvPendingRequests;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colSelect;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRequestID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRequestDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRequestor;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDepartment;
        private System.Windows.Forms.DataGridViewTextBoxColumn colItemCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn colItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn colItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAuthorizedCreator;
        private System.Windows.Forms.DataGridViewTextBoxColumn colApprovalStatus;
        private System.Windows.Forms.GroupBox grpFilters;
        private System.Windows.Forms.Label lblFilterCategory;
        private System.Windows.Forms.ComboBox cmbFilterCategory;
        private System.Windows.Forms.Label lblFilterDepartment;
        private System.Windows.Forms.ComboBox cmbFilterDepartment;
        private System.Windows.Forms.Label lblFilterStatus;
        private System.Windows.Forms.ComboBox cmbFilterStatus;
        private System.Windows.Forms.Button btnFilter;
        private System.Windows.Forms.Button btnClearFilter;
        private System.Windows.Forms.GroupBox grpSelectedRequest;
        private System.Windows.Forms.Label lblSelectedRequestID;
        private System.Windows.Forms.TextBox txtSelectedRequestID;
        private System.Windows.Forms.Label lblSelectedItemCode;
        private System.Windows.Forms.TextBox txtSelectedItemCode;
        private System.Windows.Forms.Label lblSelectedDescription;
        private System.Windows.Forms.TextBox txtSelectedDescription;
        private System.Windows.Forms.Label lblSelectedCategory;
        private System.Windows.Forms.TextBox txtSelectedCategory;
        private System.Windows.Forms.Label lblSelectedRequestor;
        private System.Windows.Forms.TextBox txtSelectedRequestor;
        private System.Windows.Forms.Label lblSelectedDepartment;
        private System.Windows.Forms.TextBox txtSelectedDepartment;
        private System.Windows.Forms.Label lblSelectedTechnicalSpec;
        private System.Windows.Forms.TextBox txtSelectedTechnicalSpec;
        private System.Windows.Forms.Label lblSelectedUOM;
        private System.Windows.Forms.TextBox txtSelectedUOM;
        private System.Windows.Forms.Label lblSelectedCriticality;
        private System.Windows.Forms.TextBox txtSelectedCriticality;
        private System.Windows.Forms.Label lblSelectedHSN;
        private System.Windows.Forms.TextBox txtSelectedHSN;
        private System.Windows.Forms.GroupBox grpApprovalAction;
        private System.Windows.Forms.Label lblAction;
        private System.Windows.Forms.ComboBox cmbAction;
        private System.Windows.Forms.Label lblApprovalRemarks;
        private System.Windows.Forms.TextBox txtApprovalRemarks;
        private System.Windows.Forms.Label lblApproverName;
        private System.Windows.Forms.TextBox txtApproverName;
        private System.Windows.Forms.Label lblApprovalDate;
        private System.Windows.Forms.DateTimePicker dtpApprovalDate;
        private System.Windows.Forms.Button btnApprove;
        private System.Windows.Forms.Button btnReject;
        private System.Windows.Forms.Button btnHold;
        private System.Windows.Forms.GroupBox grpBulkActions;
        private System.Windows.Forms.Button btnBulkApprove;
        private System.Windows.Forms.Button btnBulkReject;
        private System.Windows.Forms.Button btnBulkHold;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblTotalPending;
        private System.Windows.Forms.TextBox txtTotalPending;
        private System.Windows.Forms.Label lblTotalApproved;
        private System.Windows.Forms.TextBox txtTotalApproved;
        private System.Windows.Forms.Label lblTotalRejected;
        private System.Windows.Forms.TextBox txtTotalRejected;
        private System.Windows.Forms.Label lblUserRole;
        private System.Windows.Forms.TextBox txtUserRole;
    }
}