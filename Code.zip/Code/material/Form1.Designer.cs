﻿//namespace WinFormsApp1
//{
//    partial class Form1
//    {
//        /// <summary>
//        ///  Required designer variable.
//        /// </summary>
//        private System.ComponentModel.IContainer components = null;

//        /// <summary>
//        ///  Clean up any resources being used.
//        /// </summary>
//        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
//        protected override void Dispose(bool disposing)
//        {
//            if (disposing && (components != null))
//            {
//                components.Dispose();
//            }
//            base.Dispose(disposing);
//        }

//        #region Windows Form Designer generated code

//        /// <summary>
//        ///  Required method for Designer support - do not modify
//        ///  the contents of this method with the code editor.
//        /// </summary>
//        private void InitializeComponent()
//        {
//            components = new System.ComponentModel.Container();
//            AutoScaleMode = AutoScaleMode.Font;
//            ClientSize = new Size(800, 450);
//            Text = "Form1";
//        }

//        #endregion
//    }
//}


namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpRequestDetails = new System.Windows.Forms.GroupBox();
            this.lblRequestDate = new System.Windows.Forms.Label();
            this.dtpRequestDate = new System.Windows.Forms.DateTimePicker();
            this.lblRequestor = new System.Windows.Forms.Label();
            this.txtRequestor = new System.Windows.Forms.TextBox();
            this.lblDepartment = new System.Windows.Forms.Label();
            this.cmbDepartment = new System.Windows.Forms.ComboBox();
            this.lblItemCategory = new System.Windows.Forms.Label();
            this.cmbItemCategory = new System.Windows.Forms.ComboBox();
            this.lblItemDescription = new System.Windows.Forms.Label();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.lblTechnicalSpec = new System.Windows.Forms.Label();
            this.txtTechnicalSpec = new System.Windows.Forms.TextBox();
            this.lblUnitOfMeasure = new System.Windows.Forms.Label();
            this.cmbUnitOfMeasure = new System.Windows.Forms.ComboBox();
            this.lblDrawingReference = new System.Windows.Forms.Label();
            this.txtDrawingReference = new System.Windows.Forms.TextBox();
            this.lblCriticalityLevel = new System.Windows.Forms.Label();
            this.cmbCriticalityLevel = new System.Windows.Forms.ComboBox();
            this.lblHSNCode = new System.Windows.Forms.Label();
            this.txtHSNCode = new System.Windows.Forms.TextBox();
            this.grpItemCodeStructure = new System.Windows.Forms.GroupBox();
            this.lblPrefix = new System.Windows.Forms.Label();
            this.txtPrefix = new System.Windows.Forms.TextBox();
            this.lblCategoryCode = new System.Windows.Forms.Label();
            this.txtCategoryCode = new System.Windows.Forms.TextBox();
            this.lblSequentialNumber = new System.Windows.Forms.Label();
            this.txtSequentialNumber = new System.Windows.Forms.TextBox();
            this.lblGeneratedItemCode = new System.Windows.Forms.Label();
            this.txtGeneratedItemCode = new System.Windows.Forms.TextBox();
            this.btnGenerateCode = new System.Windows.Forms.Button();
            this.grpApproval = new System.Windows.Forms.GroupBox();//
            this.grpItemStructure = new System.Windows.Forms.GroupBox();//grpItemStructure
            this.lblAuthorizedCreator = new System.Windows.Forms.Label();
            this.cmbAuthorizedCreator = new System.Windows.Forms.ComboBox();
            this.lblApprovalAuthority = new System.Windows.Forms.Label();
            this.cmbApprovalAuthority = new System.Windows.Forms.ComboBox();
            this.lblApprovalStatus = new System.Windows.Forms.Label();
            this.cmbApprovalStatus = new System.Windows.Forms.ComboBox();
            this.lblApprovalRemarks = new System.Windows.Forms.Label();
            this.txtApprovalRemarks = new System.Windows.Forms.TextBox();
            this.grpLocation = new System.Windows.Forms.GroupBox();
            this.lblStoreLocation = new System.Windows.Forms.Label();
            this.txtStoreLocation = new System.Windows.Forms.TextBox();
            this.lblBinNumber = new System.Windows.Forms.Label();
            this.txtBinNumber = new System.Windows.Forms.TextBox();
            this.grpEmergency = new System.Windows.Forms.GroupBox();
            this.chkEmergency = new System.Windows.Forms.CheckBox();
            this.lblEmergencyApproval = new System.Windows.Forms.Label();
            this.cmbEmergencyApproval = new System.Windows.Forms.ComboBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.lblPreparedBy = new System.Windows.Forms.Label();
            this.txtPreparedBy = new System.Windows.Forms.TextBox();
            this.lblApprovedBy = new System.Windows.Forms.Label();
            this.txtApprovedBy = new System.Windows.Forms.TextBox();
            this.lblEffectiveDate = new System.Windows.Forms.Label();
            this.dtpEffectiveDate = new System.Windows.Forms.DateTimePicker();
            this.grpRequestDetails.SuspendLayout();
            this.grpItemCodeStructure.SuspendLayout();
            this.grpApproval.SuspendLayout();
            this.grpLocation.SuspendLayout();
            this.grpEmergency.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(280, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(420, 24);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "SOP - Item Code Creation in ERP (ICCRF)";
            // 
            // grpRequestDetails
            // 
            this.grpRequestDetails.Controls.Add(this.lblCriticalityLevel);
            this.grpRequestDetails.Controls.Add(this.cmbCriticalityLevel);
            this.grpRequestDetails.Controls.Add(this.lblDrawingReference);
            this.grpRequestDetails.Controls.Add(this.txtDrawingReference);
            this.grpRequestDetails.Controls.Add(this.lblUnitOfMeasure);
            this.grpRequestDetails.Controls.Add(this.cmbUnitOfMeasure);
            this.grpRequestDetails.Controls.Add(this.lblTechnicalSpec);
            this.grpRequestDetails.Controls.Add(this.txtTechnicalSpec);
            this.grpRequestDetails.Controls.Add(this.lblItemDescription);
            this.grpRequestDetails.Controls.Add(this.txtItemDescription);
            this.grpRequestDetails.Controls.Add(this.lblItemCategory);
            this.grpRequestDetails.Controls.Add(this.cmbItemCategory);
            this.grpRequestDetails.Controls.Add(this.lblDepartment);
            this.grpRequestDetails.Controls.Add(this.cmbDepartment);
            this.grpRequestDetails.Controls.Add(this.lblRequestor);
            this.grpRequestDetails.Controls.Add(this.txtRequestor);
            this.grpRequestDetails.Controls.Add(this.lblRequestDate);
            this.grpRequestDetails.Controls.Add(this.dtpRequestDate);
            this.grpRequestDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpRequestDetails.Location = new System.Drawing.Point(12, 45);
            this.grpRequestDetails.Name = "grpRequestDetails";
            this.grpRequestDetails.Size = new System.Drawing.Size(480, 320);
            this.grpRequestDetails.TabIndex = 1;
            this.grpRequestDetails.TabStop = false;
            this.grpRequestDetails.Text = "Step 1: Item Code Request Initiation";
            // 
            // lblRequestDate
            // 
            this.lblRequestDate.AutoSize = true;
            this.lblRequestDate.Location = new System.Drawing.Point(15, 30);
            this.lblRequestDate.Name = "lblRequestDate";
            this.lblRequestDate.Size = new System.Drawing.Size(82, 15);
            this.lblRequestDate.TabIndex = 0;
            this.lblRequestDate.Text = "Request Date:";
            // 
            // dtpRequestDate
            // 
            this.dtpRequestDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpRequestDate.Location = new System.Drawing.Point(150, 26);
            this.dtpRequestDate.Name = "dtpRequestDate";
            this.dtpRequestDate.Size = new System.Drawing.Size(120, 21);
            this.dtpRequestDate.TabIndex = 1;
            // 
            // lblRequestor
            // 
            this.lblRequestor.AutoSize = true;
            this.lblRequestor.Location = new System.Drawing.Point(15, 60);
            this.lblRequestor.Name = "lblRequestor";
            this.lblRequestor.Size = new System.Drawing.Size(66, 15);
            this.lblRequestor.TabIndex = 2;
            this.lblRequestor.Text = "Requestor:";
            // 
            // txtRequestor
            // 
            this.txtRequestor.Location = new System.Drawing.Point(150, 56);
            this.txtRequestor.Name = "txtRequestor";
            this.txtRequestor.Size = new System.Drawing.Size(200, 21);
            this.txtRequestor.TabIndex = 3;
            // 
            // lblDepartment
            // 
            this.lblDepartment.AutoSize = true;
            this.lblDepartment.Location = new System.Drawing.Point(15, 90);
            this.lblDepartment.Name = "lblDepartment";
            this.lblDepartment.Size = new System.Drawing.Size(75, 15);
            this.lblDepartment.TabIndex = 4;
            this.lblDepartment.Text = "Department:";
            // 
            // cmbDepartment
            // 
            this.cmbDepartment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDepartment.FormattingEnabled = true;
            this.cmbDepartment.Location = new System.Drawing.Point(150, 86);
            this.cmbDepartment.Name = "cmbDepartment";
            this.cmbDepartment.Size = new System.Drawing.Size(200, 23);
            this.cmbDepartment.TabIndex = 5;
            // 
            // lblItemCategory
            // 
            this.lblItemCategory.AutoSize = true;
            this.lblItemCategory.Location = new System.Drawing.Point(15, 120);
            this.lblItemCategory.Name = "lblItemCategory";
            this.lblItemCategory.Size = new System.Drawing.Size(86, 15);
            this.lblItemCategory.TabIndex = 6;
            this.lblItemCategory.Text = "Item Category:";
            // 
            // cmbItemCategory
            // 
            this.cmbItemCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbItemCategory.FormattingEnabled = true;
            this.cmbItemCategory.Location = new System.Drawing.Point(150, 116);
            this.cmbItemCategory.Name = "cmbItemCategory";
            this.cmbItemCategory.Size = new System.Drawing.Size(200, 23);
            this.cmbItemCategory.TabIndex = 7;
            this.cmbItemCategory.SelectedIndexChanged += new System.EventHandler(this.cmbItemCategory_SelectedIndexChanged);
            // 
            // lblItemDescription
            // 
            this.lblItemDescription.AutoSize = true;
            this.lblItemDescription.Location = new System.Drawing.Point(15, 150);
            this.lblItemDescription.Name = "lblItemDescription";
            this.lblItemDescription.Size = new System.Drawing.Size(100, 15);
            this.lblItemDescription.TabIndex = 8;
            this.lblItemDescription.Text = "Item Description:";
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Location = new System.Drawing.Point(150, 146);
            this.txtItemDescription.MaxLength = 40;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(300, 21);
            this.txtItemDescription.TabIndex = 9;
            this.txtItemDescription.TextChanged += new System.EventHandler(this.txtItemDescription_TextChanged);
            // 
            // lblTechnicalSpec
            // 
            this.lblTechnicalSpec.AutoSize = true;
            this.lblTechnicalSpec.Location = new System.Drawing.Point(15, 180);
            this.lblTechnicalSpec.Name = "lblTechnicalSpec";
            this.lblTechnicalSpec.Size = new System.Drawing.Size(125, 15);
            this.lblTechnicalSpec.TabIndex = 10;
            this.lblTechnicalSpec.Text = "Technical Spec / Ref:";
            // 
            // txtTechnicalSpec
            // 
            this.txtTechnicalSpec.Location = new System.Drawing.Point(150, 176);
            this.txtTechnicalSpec.Multiline = true;
            this.txtTechnicalSpec.Name = "txtTechnicalSpec";
            this.txtTechnicalSpec.Size = new System.Drawing.Size(300, 40);
            this.txtTechnicalSpec.TabIndex = 11;
            // 
            // lblUnitOfMeasure
            // 
            this.lblUnitOfMeasure.AutoSize = true;
            this.lblUnitOfMeasure.Location = new System.Drawing.Point(15, 230);
            this.lblUnitOfMeasure.Name = "lblUnitOfMeasure";
            this.lblUnitOfMeasure.Size = new System.Drawing.Size(100, 15);
            this.lblUnitOfMeasure.TabIndex = 12;
            this.lblUnitOfMeasure.Text = "Unit of Measure:";
            // 
            // cmbUnitOfMeasure
            // 
            this.cmbUnitOfMeasure.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUnitOfMeasure.FormattingEnabled = true;
            this.cmbUnitOfMeasure.Location = new System.Drawing.Point(150, 226);
            this.cmbUnitOfMeasure.Name = "cmbUnitOfMeasure";
            this.cmbUnitOfMeasure.Size = new System.Drawing.Size(120, 23);
            this.cmbUnitOfMeasure.TabIndex = 13;
            // 
            // lblDrawingReference
            // 
            this.lblDrawingReference.AutoSize = true;
            this.lblDrawingReference.Location = new System.Drawing.Point(15, 260);
            this.lblDrawingReference.Name = "lblDrawingReference";
            this.lblDrawingReference.Size = new System.Drawing.Size(111, 15);
            this.lblDrawingReference.TabIndex = 14;
            this.lblDrawingReference.Text = "Drawing Reference:";
            // 
            // txtDrawingReference
            // 
            this.txtDrawingReference.Location = new System.Drawing.Point(150, 256);
            this.txtDrawingReference.Name = "txtDrawingReference";
            this.txtDrawingReference.Size = new System.Drawing.Size(200, 21);
            this.txtDrawingReference.TabIndex = 15;
            // 
            // lblCriticalityLevel
            // 
            this.lblCriticalityLevel.AutoSize = true;
            this.lblCriticalityLevel.Location = new System.Drawing.Point(15, 290);
            this.lblCriticalityLevel.Name = "lblCriticalityLevel";
            this.lblCriticalityLevel.Size = new System.Drawing.Size(93, 15);
            this.lblCriticalityLevel.TabIndex = 16;
            this.lblCriticalityLevel.Text = "Criticality (ABC):";
            // 
            // cmbCriticalityLevel
            // 
            this.cmbCriticalityLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCriticalityLevel.FormattingEnabled = true;
            this.cmbCriticalityLevel.Location = new System.Drawing.Point(150, 286);
            this.cmbCriticalityLevel.Name = "cmbCriticalityLevel";
            this.cmbCriticalityLevel.Size = new System.Drawing.Size(120, 23);
            this.cmbCriticalityLevel.TabIndex = 17;
            // 
            // lblHSNCode
            // 
            this.lblHSNCode.AutoSize = true;
            this.lblHSNCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHSNCode.Location = new System.Drawing.Point(15, 30);
            this.lblHSNCode.Name = "lblHSNCode";
            this.lblHSNCode.Size = new System.Drawing.Size(68, 15);
            this.lblHSNCode.TabIndex = 0;
            this.lblHSNCode.Text = "HSN Code:";
            // 
            // txtHSNCode
            // 
            this.txtHSNCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHSNCode.Location = new System.Drawing.Point(150, 26);
            this.txtHSNCode.Name = "txtHSNCode";
            this.txtHSNCode.Size = new System.Drawing.Size(150, 21);
            this.txtHSNCode.TabIndex = 1;
            // 
            // grpItemCodeStructure
            // 
            this.grpItemCodeStructure.Controls.Add(this.btnGenerateCode);
            this.grpItemCodeStructure.Controls.Add(this.txtGeneratedItemCode);
            this.grpItemCodeStructure.Controls.Add(this.lblGeneratedItemCode);
            this.grpItemCodeStructure.Controls.Add(this.txtSequentialNumber);
            this.grpItemCodeStructure.Controls.Add(this.lblSequentialNumber);
            this.grpItemCodeStructure.Controls.Add(this.txtCategoryCode);
            this.grpItemCodeStructure.Controls.Add(this.lblCategoryCode);
            this.grpItemCodeStructure.Controls.Add(this.txtPrefix);
            this.grpItemCodeStructure.Controls.Add(this.lblPrefix);
            this.grpItemCodeStructure.Controls.Add(this.txtHSNCode);
            this.grpItemCodeStructure.Controls.Add(this.lblHSNCode);
            this.grpItemCodeStructure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpItemCodeStructure.Location = new System.Drawing.Point(510, 45);
            this.grpItemCodeStructure.Name = "grpItemCodeStructure";
            this.grpItemCodeStructure.Size = new System.Drawing.Size(460, 200);
            this.grpItemCodeStructure.TabIndex = 2;
            this.grpItemCodeStructure.TabStop = false;
            this.grpItemCodeStructure.Text = "Step 2 & 5: Item Code Creation / Naming Standards";
            // 
            // lblPrefix
            // 
            this.lblPrefix.AutoSize = true;
            this.lblPrefix.Location = new System.Drawing.Point(15, 60);
            this.lblPrefix.Name = "lblPrefix";
            this.lblPrefix.Size = new System.Drawing.Size(39, 15);
            this.lblPrefix.TabIndex = 2;
            this.lblPrefix.Text = "Prefix:";
            // 
            // txtPrefix
            // 
            this.txtPrefix.Location = new System.Drawing.Point(150, 56);
            this.txtPrefix.Name = "txtPrefix";
            this.txtPrefix.ReadOnly = true;
            this.txtPrefix.Size = new System.Drawing.Size(100, 21);
            this.txtPrefix.TabIndex = 3;
            // 
            // lblCategoryCode
            // 
            this.lblCategoryCode.AutoSize = true;
            this.lblCategoryCode.Location = new System.Drawing.Point(15, 90);
            this.lblCategoryCode.Name = "lblCategoryCode";
            this.lblCategoryCode.Size = new System.Drawing.Size(90, 15);
            this.lblCategoryCode.TabIndex = 4;
            this.lblCategoryCode.Text = "Category Code:";
            // 
            // txtCategoryCode
            // 
            this.txtCategoryCode.Location = new System.Drawing.Point(150, 86);
            this.txtCategoryCode.Name = "txtCategoryCode";
            this.txtCategoryCode.ReadOnly = true;
            this.txtCategoryCode.Size = new System.Drawing.Size(100, 21);
            this.txtCategoryCode.TabIndex = 5;
            // 
            // lblSequentialNumber
            // 
            this.lblSequentialNumber.AutoSize = true;
            this.lblSequentialNumber.Location = new System.Drawing.Point(15, 120);
            this.lblSequentialNumber.Name = "lblSequentialNumber";
            this.lblSequentialNumber.Size = new System.Drawing.Size(115, 15);
            this.lblSequentialNumber.TabIndex = 6;
            this.lblSequentialNumber.Text = "Sequential Number:";
            // 
            // txtSequentialNumber
            // 
            this.txtSequentialNumber.Location = new System.Drawing.Point(150, 116);
            this.txtSequentialNumber.Name = "txtSequentialNumber";
            this.txtSequentialNumber.Size = new System.Drawing.Size(100, 21);
            this.txtSequentialNumber.TabIndex = 7;
            // 
            // lblGeneratedItemCode
            // 
            this.lblGeneratedItemCode.AutoSize = true;
            this.lblGeneratedItemCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGeneratedItemCode.Location = new System.Drawing.Point(15, 150);
            this.lblGeneratedItemCode.Name = "lblGeneratedItemCode";
            this.lblGeneratedItemCode.Size = new System.Drawing.Size(138, 15);
            this.lblGeneratedItemCode.TabIndex = 8;
            this.lblGeneratedItemCode.Text = "Generated Item Code:";
            // 
            // txtGeneratedItemCode
            // 
            this.txtGeneratedItemCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGeneratedItemCode.Location = new System.Drawing.Point(150, 146);
            this.txtGeneratedItemCode.Name = "txtGeneratedItemCode";
            this.txtGeneratedItemCode.ReadOnly = true;
            this.txtGeneratedItemCode.Size = new System.Drawing.Size(150, 21);
            this.txtGeneratedItemCode.TabIndex = 9;
            // 
            // btnGenerateCode
            // 
            this.btnGenerateCode.BackColor = System.Drawing.Color.LightBlue;
            this.btnGenerateCode.Location = new System.Drawing.Point(320, 144);
            this.btnGenerateCode.Name = "btnGenerateCode";
            this.btnGenerateCode.Size = new System.Drawing.Size(120, 25);
            this.btnGenerateCode.TabIndex = 10;
            this.btnGenerateCode.Text = "Generate Code";
            this.btnGenerateCode.UseVisualStyleBackColor = false;
            this.btnGenerateCode.Click += new System.EventHandler(this.btnGenerateCode_Click);
            // 
            // grpApproval
            // 
            this.grpApproval.Controls.Add(this.txtApprovalRemarks);
            this.grpApproval.Controls.Add(this.lblApprovalRemarks);
            this.grpApproval.Controls.Add(this.cmbApprovalStatus);
            this.grpApproval.Controls.Add(this.lblApprovalStatus);
            this.grpApproval.Controls.Add(this.cmbApprovalAuthority);
            this.grpApproval.Controls.Add(this.lblApprovalAuthority);
            this.grpApproval.Controls.Add(this.cmbAuthorizedCreator);
            this.grpApproval.Controls.Add(this.lblAuthorizedCreator);
            this.grpApproval.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpApproval.Location = new System.Drawing.Point(12, 375);
            this.grpApproval.Name = "grpApproval";
            this.grpApproval.Size = new System.Drawing.Size(480, 180);
            this.grpApproval.TabIndex = 3;
            this.grpApproval.TabStop = false;
            this.grpApproval.Text = "Step 3: Approval & Activation";
            // 
            // lblAuthorizedCreator
            // 
            this.lblAuthorizedCreator.AutoSize = true;
            this.lblAuthorizedCreator.Location = new System.Drawing.Point(15, 30);
            this.lblAuthorizedCreator.Name = "lblAuthorizedCreator";
            this.lblAuthorizedCreator.Size = new System.Drawing.Size(111, 15);
            this.lblAuthorizedCreator.TabIndex = 0;
            this.lblAuthorizedCreator.Text = "Authorized Creator:";
            // 
            // cmbAuthorizedCreator
            // 
            this.cmbAuthorizedCreator.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAuthorizedCreator.FormattingEnabled = true;
            this.cmbAuthorizedCreator.Location = new System.Drawing.Point(150, 26);
            this.cmbAuthorizedCreator.Name = "cmbAuthorizedCreator";
            this.cmbAuthorizedCreator.Size = new System.Drawing.Size(200, 23);
            this.cmbAuthorizedCreator.TabIndex = 1;
            // 
            // lblApprovalAuthority
            // 
            this.lblApprovalAuthority.AutoSize = true;
            this.lblApprovalAuthority.Location = new System.Drawing.Point(15, 60);
            this.lblApprovalAuthority.Name = "lblApprovalAuthority";
            this.lblApprovalAuthority.Size = new System.Drawing.Size(106, 15);
            this.lblApprovalAuthority.TabIndex = 2;
            this.lblApprovalAuthority.Text = "Approval Authority:";
            // 
            // cmbApprovalAuthority
            // 
            this.cmbApprovalAuthority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbApprovalAuthority.FormattingEnabled = true;
            this.cmbApprovalAuthority.Location = new System.Drawing.Point(150, 56);
            this.cmbApprovalAuthority.Name = "cmbApprovalAuthority";
            this.cmbApprovalAuthority.Size = new System.Drawing.Size(200, 23);
            this.cmbApprovalAuthority.TabIndex = 3;
            // 
            // lblApprovalStatus
            // 
            this.lblApprovalStatus.AutoSize = true;
            this.lblApprovalStatus.Location = new System.Drawing.Point(15, 90);
            this.lblApprovalStatus.Name = "lblApprovalStatus";
            this.lblApprovalStatus.Size = new System.Drawing.Size(93, 15);
            this.lblApprovalStatus.TabIndex = 4;
            this.lblApprovalStatus.Text = "Approval Status:";
            // 
            // cmbApprovalStatus
            // 
            this.cmbApprovalStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbApprovalStatus.FormattingEnabled = true;
            this.cmbApprovalStatus.Location = new System.Drawing.Point(150, 86);
            this.cmbApprovalStatus.Name = "cmbApprovalStatus";
            this.cmbApprovalStatus.Size = new System.Drawing.Size(150, 23);
            this.cmbApprovalStatus.TabIndex = 5;
            // 
            // lblApprovalRemarks
            // 
            this.lblApprovalRemarks.AutoSize = true;
            this.lblApprovalRemarks.Location = new System.Drawing.Point(15, 120);
            this.lblApprovalRemarks.Name = "lblApprovalRemarks";
            this.lblApprovalRemarks.Size = new System.Drawing.Size(58, 15);
            this.lblApprovalRemarks.TabIndex = 6;
            this.lblApprovalRemarks.Text = "Remarks:";
            // 
            // txtApprovalRemarks
            // 
            this.txtApprovalRemarks.Location = new System.Drawing.Point(150, 116);
            this.txtApprovalRemarks.Multiline = true;
            this.txtApprovalRemarks.Name = "txtApprovalRemarks";
            this.txtApprovalRemarks.Size = new System.Drawing.Size(300, 50);
            this.txtApprovalRemarks.TabIndex = 7;
            // 
            // grpLocation
            // 
            this.grpLocation.Controls.Add(this.txtBinNumber);
            this.grpLocation.Controls.Add(this.lblBinNumber);
            this.grpLocation.Controls.Add(this.txtStoreLocation);
            this.grpLocation.Controls.Add(this.lblStoreLocation);
            this.grpLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpLocation.Location = new System.Drawing.Point(510, 255);
            this.grpLocation.Name = "grpLocation";
            this.grpLocation.Size = new System.Drawing.Size(460, 110);
            this.grpLocation.TabIndex = 4;
            this.grpLocation.TabStop = false;
            this.grpLocation.Text = "Step 4: Store Location (Upon GIN)";
            // 
            // lblStoreLocation
            // 
            this.lblStoreLocation.AutoSize = true;
            this.lblStoreLocation.Location = new System.Drawing.Point(15, 30);
            this.lblStoreLocation.Name = "lblStoreLocation";
            this.lblStoreLocation.Size = new System.Drawing.Size(89, 15);
            this.lblStoreLocation.TabIndex = 0;
            this.lblStoreLocation.Text = "Store Location:";
            // 
            // txtStoreLocation
            // 
            this.txtStoreLocation.Location = new System.Drawing.Point(150, 26);
            this.txtStoreLocation.Name = "txtStoreLocation";
            this.txtStoreLocation.Size = new System.Drawing.Size(200, 21);
            this.txtStoreLocation.TabIndex = 1;
            // 
            // lblBinNumber
            // 
            this.lblBinNumber.AutoSize = true;
            this.lblBinNumber.Location = new System.Drawing.Point(15, 60);
            this.lblBinNumber.Name = "lblBinNumber";
            this.lblBinNumber.Size = new System.Drawing.Size(75, 15);
            this.lblBinNumber.TabIndex = 2;
            this.lblBinNumber.Text = "Bin Number:";
            // 
            // txtBinNumber
            // 
            this.txtBinNumber.Location = new System.Drawing.Point(150, 56);
            this.txtBinNumber.Name = "txtBinNumber";
            this.txtBinNumber.Size = new System.Drawing.Size(150, 21);
            this.txtBinNumber.TabIndex = 3;
            // 
            // grpEmergency
            // 
            this.grpEmergency.Controls.Add(this.cmbEmergencyApproval);
            this.grpEmergency.Controls.Add(this.lblEmergencyApproval);
            this.grpEmergency.Controls.Add(this.chkEmergency);
            this.grpEmergency.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpEmergency.Location = new System.Drawing.Point(510, 375);
            this.grpEmergency.Name = "grpEmergency";
            this.grpEmergency.Size = new System.Drawing.Size(460, 110);
            this.grpEmergency.TabIndex = 5;
            this.grpEmergency.TabStop = false;
            this.grpEmergency.Text = "Exceptions & Escalation";
            // 
            // chkEmergency
            // 
            this.chkEmergency.AutoSize = true;
            this.chkEmergency.Location = new System.Drawing.Point(18, 25);
            this.chkEmergency.Name = "chkEmergency";
            this.chkEmergency.Size = new System.Drawing.Size(220, 19);
            this.chkEmergency.TabIndex = 0;
            this.chkEmergency.Text = "Emergency Item Creation Required";
            this.chkEmergency.UseVisualStyleBackColor = true;
            this.chkEmergency.CheckedChanged += new System.EventHandler(this.chkEmergency_CheckedChanged);
            // 
            // lblEmergencyApproval
            // 
            this.lblEmergencyApproval.AutoSize = true;
            this.lblEmergencyApproval.Location = new System.Drawing.Point(15, 55);
            this.lblEmergencyApproval.Name = "lblEmergencyApproval";
            this.lblEmergencyApproval.Size = new System.Drawing.Size(117, 15);
            this.lblEmergencyApproval.TabIndex = 1;
            this.lblEmergencyApproval.Text = "Emergency Approval:";
            // 
            // cmbEmergencyApproval
            // 
            this.cmbEmergencyApproval.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEmergencyApproval.Enabled = false;
            this.cmbEmergencyApproval.FormattingEnabled = true;
            this.cmbEmergencyApproval.Location = new System.Drawing.Point(150, 51);
            this.cmbEmergencyApproval.Name = "cmbEmergencyApproval";
            this.cmbEmergencyApproval.Size = new System.Drawing.Size(200, 23);
            this.cmbEmergencyApproval.TabIndex = 2;
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.LightGreen;
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(12, 570);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(120, 35);
            this.btnSubmit.TabIndex = 6;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.LightYellow;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(150, 570);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(120, 35);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.LightCoral;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(288, 570);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(120, 35);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Location = new System.Drawing.Point(426, 570);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(120, 35);
            this.btnPrint.TabIndex = 9;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // lblPreparedBy
            // 
            this.lblPreparedBy.AutoSize = true;
            this.lblPreparedBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreparedBy.Location = new System.Drawing.Point(570, 570);
            this.lblPreparedBy.Name = "lblPreparedBy";
            this.lblPreparedBy.Size = new System.Drawing.Size(67, 13);
            this.lblPreparedBy.TabIndex = 10;
            this.lblPreparedBy.Text = "Prepared By:";
            // 
            // txtPreparedBy
            // 
            this.txtPreparedBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPreparedBy.Location = new System.Drawing.Point(643, 567);
            this.txtPreparedBy.Name = "txtPreparedBy";
            this.txtPreparedBy.ReadOnly = true;
            this.txtPreparedBy.Size = new System.Drawing.Size(120, 20);
            this.txtPreparedBy.TabIndex = 11;
            this.txtPreparedBy.Text = "Material Manager";
            // 
            // lblApprovedBy
            // 
            this.lblApprovedBy.AutoSize = true;
            this.lblApprovedBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApprovedBy.Location = new System.Drawing.Point(570, 593);
            this.lblApprovedBy.Name = "lblApprovedBy";
            this.lblApprovedBy.Size = new System.Drawing.Size(68, 13);
            this.lblApprovedBy.TabIndex = 12;
            this.lblApprovedBy.Text = "Approved By:";
            // 
            // txtApprovedBy
            // 
            this.txtApprovedBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApprovedBy.Location = new System.Drawing.Point(643, 590);
            this.txtApprovedBy.Name = "txtApprovedBy";
            this.txtApprovedBy.ReadOnly = true;
            this.txtApprovedBy.Size = new System.Drawing.Size(120, 20);
            this.txtApprovedBy.TabIndex = 13;
            this.txtApprovedBy.Text = "Operations Head";
            // 
            // lblEffectiveDate
            // 
            this.lblEffectiveDate.AutoSize = true;
            this.lblEffectiveDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEffectiveDate.Location = new System.Drawing.Point(570, 616);
            this.lblEffectiveDate.Name = "lblEffectiveDate";
            this.lblEffectiveDate.Size = new System.Drawing.Size(73, 13);
            this.lblEffectiveDate.TabIndex = 14;
            this.lblEffectiveDate.Text = "Effective Date:";
            // 
            // dtpEffectiveDate
            // 
            this.dtpEffectiveDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpEffectiveDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEffectiveDate.Location = new System.Drawing.Point(643, 613);
            this.dtpEffectiveDate.Name = "dtpEffectiveDate";
            this.dtpEffectiveDate.Size = new System.Drawing.Size(120, 20);
            this.dtpEffectiveDate.TabIndex = 15;
            // 
            // frmItemCodeCreation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(984, 641);
            this.Controls.Add(this.dtpEffectiveDate);
            this.Controls.Add(this.lblEffectiveDate);
            this.Controls.Add(this.txtApprovedBy);
            this.Controls.Add(this.lblApprovedBy);
            this.Controls.Add(this.txtPreparedBy);
            this.Controls.Add(this.lblPreparedBy);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.grpEmergency);
            this.Controls.Add(this.grpLocation);
            this.Controls.Add(this.grpApproval);
            this.Controls.Add(this.grpItemCodeStructure);
            this.Controls.Add(this.grpRequestDetails);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmItemCodeCreation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Item Code Creation - ERP";
            this.Load += new System.EventHandler(this.frmItemCodeCreation_Load);
            this.grpRequestDetails.ResumeLayout(false);
            this.grpRequestDetails.PerformLayout();
            this.grpItemCodeStructure.ResumeLayout(false);
            this.grpItemStructure.PerformLayout();
            this.grpApproval.ResumeLayout(false);
            this.grpApproval.PerformLayout();
            this.grpLocation.ResumeLayout(false);
            this.grpLocation.PerformLayout();
            this.grpEmergency.ResumeLayout(false);
            this.grpEmergency.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox grpRequestDetails;
        private System.Windows.Forms.Label lblRequestDate;
        private System.Windows.Forms.DateTimePicker dtpRequestDate;
        private System.Windows.Forms.Label lblRequestor;
        private System.Windows.Forms.TextBox txtRequestor;
        private System.Windows.Forms.Label lblDepartment;
        private System.Windows.Forms.ComboBox cmbDepartment;
        private System.Windows.Forms.Label lblItemCategory;
        private System.Windows.Forms.ComboBox cmbItemCategory;
        private System.Windows.Forms.Label lblItemDescription;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.Label lblTechnicalSpec;
        private System.Windows.Forms.TextBox txtTechnicalSpec;
        private System.Windows.Forms.Label lblUnitOfMeasure;
        private System.Windows.Forms.ComboBox cmbUnitOfMeasure;
        private System.Windows.Forms.Label lblDrawingReference;
        private System.Windows.Forms.TextBox txtDrawingReference;
        private System.Windows.Forms.Label lblCriticalityLevel;
        private System.Windows.Forms.ComboBox cmbCriticalityLevel;
        private System.Windows.Forms.Label lblHSNCode;
        private System.Windows.Forms.TextBox txtHSNCode;
        private System.Windows.Forms.GroupBox grpItemCodeStructure;
        private System.Windows.Forms.Label lblPrefix;
        private System.Windows.Forms.TextBox txtPrefix;
        private System.Windows.Forms.Label lblCategoryCode;
        private System.Windows.Forms.TextBox txtCategoryCode;
        private System.Windows.Forms.Label lblSequentialNumber;
        private System.Windows.Forms.TextBox txtSequentialNumber;
        private System.Windows.Forms.Label lblGeneratedItemCode;
        private System.Windows.Forms.TextBox txtGeneratedItemCode;
        private System.Windows.Forms.Button btnGenerateCode;
        private System.Windows.Forms.GroupBox grpApproval;//
        private System.Windows.Forms.GroupBox grpItemStructure;//grpItemStructure
        private System.Windows.Forms.Label lblAuthorizedCreator;
        private System.Windows.Forms.ComboBox cmbAuthorizedCreator;
        private System.Windows.Forms.Label lblApprovalAuthority;
        private System.Windows.Forms.ComboBox cmbApprovalAuthority;
        private System.Windows.Forms.Label lblApprovalStatus;
        private System.Windows.Forms.ComboBox cmbApprovalStatus;
        private System.Windows.Forms.Label lblApprovalRemarks;
        private System.Windows.Forms.TextBox txtApprovalRemarks;
        private System.Windows.Forms.GroupBox grpLocation;
        private System.Windows.Forms.Label lblStoreLocation;
        private System.Windows.Forms.TextBox txtStoreLocation;
        private System.Windows.Forms.Label lblBinNumber;
        private System.Windows.Forms.TextBox txtBinNumber;
        private System.Windows.Forms.GroupBox grpEmergency;
        private System.Windows.Forms.CheckBox chkEmergency;
        private System.Windows.Forms.Label lblEmergencyApproval;
        private System.Windows.Forms.ComboBox cmbEmergencyApproval;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Label lblPreparedBy;
        private System.Windows.Forms.TextBox txtPreparedBy;
        private System.Windows.Forms.Label lblApprovedBy;
        private System.Windows.Forms.TextBox txtApprovedBy;
        private System.Windows.Forms.Label lblEffectiveDate;
        private System.Windows.Forms.DateTimePicker dtpEffectiveDate;
    }
}