﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace ItemCodeCreationApp
{
    public partial class frmItemCodeApproval : Form
    {
        // Sample data store - in real app, this would be a database
        private List<ItemCodeRequest> _allRequests;
        private List<ItemCodeRequest> _filteredRequests;
        private ItemCodeRequest _selectedRequest;

        // User role from login (in real app, this comes from authentication)
        private string _currentUserRole = "Material Manager";
        private string _currentUserName = Environment.UserName;

        // Categories for filter
        private readonly List<string> _categories = new List<string>
        {
            "All", "Capex / Fixed Asset", "Maintenance", "Consumables", "Services",
            "Packing Items", "Kanban", "Electrical & Electronics", "Hydraulics",
            "Mechanical", "Test Lab", "Consumables Non-Inventory",
            "Project-Specific (Design)", "Machining Items", "Mechanical Brought-Out Parts", "R & D"
        };

        // Departments for filter
        private readonly List<string> _departments = new List<string>
        {
            "All", "Purchase", "Maintenance", "Production", "R & D", "Test Lab",
            "Design", "Machining", "Hydraulics", "Electrical", "Stores",
            "Quality", "Project", "Packing"
        };

        // Status options for filter
        private readonly List<string> _statusOptions = new List<string>
        {
            "All", "Pending", "Approved", "Rejected", "On Hold"
        };

        // Action options
        private readonly List<string> _actions = new List<string>
        {
            "Approve", "Reject", "On Hold"
        };

        public frmItemCodeApproval()
        {
            InitializeComponent();
        }

        private void frmItemCodeApproval_Load(object sender, EventArgs e)
        {
            // Set user role display
            txtUserRole.Text = _currentUserRole;
            txtApproverName.Text = _currentUserName;
            dtpApprovalDate.Value = DateTime.Now;

            // Load filter dropdowns
            LoadFilterDropdowns();
            LoadActionDropdown();

            // Load sample data (in real app, load from database)
            LoadSampleData();

            // Refresh grid
            RefreshGrid();
            UpdateStatistics();
        }

        private void LoadFilterDropdowns()
        {
            // Category filter
            cmbFilterCategory.Items.Clear();
            foreach (var cat in _categories)
            {
                cmbFilterCategory.Items.Add(cat);
            }
            cmbFilterCategory.SelectedIndex = 0;

            // Department filter
            cmbFilterDepartment.Items.Clear();
            foreach (var dept in _departments)
            {
                cmbFilterDepartment.Items.Add(dept);
            }
            cmbFilterDepartment.SelectedIndex = 0;

            // Status filter
            cmbFilterStatus.Items.Clear();
            foreach (var status in _statusOptions)
            {
                cmbFilterStatus.Items.Add(status);
            }
            cmbFilterStatus.SelectedIndex = 0;
        }

        private void LoadActionDropdown()
        {
            cmbAction.Items.Clear();
            foreach (var action in _actions)
            {
                cmbAction.Items.Add(action);
            }
            cmbAction.SelectedIndex = 0;
        }

        private void LoadSampleData()
        {
            _allRequests = new List<ItemCodeRequest>
            {
                new ItemCodeRequest
                {
                    RequestID = "ICCRF-2026-001",
                    RequestDate = DateTime.Now.AddDays(-2),
                    Requestor = "Theertha Rao",
                    Department = "Purchase",
                    ItemCategory = "Capex / Fixed Asset",
                    ItemDescription = "CNC MACHINE VMC 850",
                    TechnicalSpec = "Vertical Machining Center, 850x500x500mm",
                    UnitOfMeasure = "Nos",
                    DrawingReference = "DRW-CNC-001",
                    CriticalityLevel = "A - High Critical",
                    HSNCode = "8457.10.00",
                    ItemCode = "FA-XX-1001",
                    AuthorizedCreator = "Purchase Department",
                    ApprovalAuthority = "Material Manager",
                    ApprovalStatus = "Pending",
                    StoreLocation = "",
                    BinNumber = ""
                },
                new ItemCodeRequest
                {
                    RequestID = "ICCRF-2026-002",
                    RequestDate = DateTime.Now.AddDays(-1),
                    Requestor = "Kumar Ravi",
                    Department = "Machining",
                    ItemCategory = "Machining Items",
                    ItemDescription = "CARBIDE END MILL 12MM",
                    TechnicalSpec = "Solid Carbide, 4 Flute, 12mm Diameter",
                    UnitOfMeasure = "Nos",
                    DrawingReference = "DRW-TOOL-045",
                    CriticalityLevel = "B - Medium Critical",
                    HSNCode = "8207.70.90",
                    ItemCode = "MAC-XX-1002",
                    AuthorizedCreator = "Mr. Santosh",
                    ApprovalAuthority = "Operations Head",
                    ApprovalStatus = "Pending",
                    StoreLocation = "",
                    BinNumber = ""
                },
                new ItemCodeRequest
                {
                    RequestID = "ICCRF-2026-003",
                    RequestDate = DateTime.Now.AddDays(-3),
                    Requestor = "Ravi Naiker",
                    Department = "Electrical",
                    ItemCategory = "Electrical & Electronics",
                    ItemDescription = "PLC MODULE S7-1200",
                    TechnicalSpec = "Siemens S7-1200, 24DI/16DO",
                    UnitOfMeasure = "Nos",
                    DrawingReference = "DRW-ELE-112",
                    CriticalityLevel = "A - High Critical",
                    HSNCode = "8537.10.90",
                    ItemCode = "ELE-XX-1003",
                    AuthorizedCreator = "Mr. Ravi Naiker",
                    ApprovalAuthority = "Operations Head",
                    ApprovalStatus = "Pending",
                    StoreLocation = "",
                    BinNumber = ""
                },
                new ItemCodeRequest
                {
                    RequestID = "ICCRF-2026-004",
                    RequestDate = DateTime.Now.AddDays(-5),
                    Requestor = "Sanjay PB",
                    Department = "Hydraulics",
                    ItemCategory = "Hydraulics",
                    ItemDescription = "HYDRAULIC CYLINDER 100X200",
                    TechnicalSpec = "Bore 100mm, Stroke 200mm, 250 Bar",
                    UnitOfMeasure = "Nos",
                    DrawingReference = "DRW-HYD-078",
                    CriticalityLevel = "A - High Critical",
                    HSNCode = "8412.21.00",
                    ItemCode = "HYD-XX-1004",
                    AuthorizedCreator = "Mr. Santosh",
                    ApprovalAuthority = "Operations Head",
                    ApprovalStatus = "Approved",
                    StoreLocation = "Store-A",
                    BinNumber = "H-12-05"
                },
                new ItemCodeRequest
                {
                    RequestID = "ICCRF-2026-005",
                    RequestDate = DateTime.Now.AddDays(-1),
                    Requestor = "Veena",
                    Department = "Purchase",
                    ItemCategory = "Consumables",
                    ItemDescription = "CUTTING OIL SYNTHETIC 20L",
                    TechnicalSpec = "Synthetic cutting fluid, 20 Liter drum",
                    UnitOfMeasure = "Drum",
                    DrawingReference = "",
                    CriticalityLevel = "C - Low Critical",
                    HSNCode = "3403.19.00",
                    ItemCode = "CON-XX-1005",
                    AuthorizedCreator = "Purchase Department",
                    ApprovalAuthority = "Material Manager",
                    ApprovalStatus = "Pending",
                    StoreLocation = "",
                    BinNumber = ""
                },
                new ItemCodeRequest
                {
                    RequestID = "ICCRF-2026-006",
                    RequestDate = DateTime.Now.AddDays(-4),
                    Requestor = "Manoj",
                    Department = "Test Lab",
                    ItemCategory = "Test Lab",
                    ItemDescription = "DIGITAL MICROMETER 0-25MM",
                    TechnicalSpec = "Digital micrometer, 0-25mm range, 0.001mm resolution",
                    UnitOfMeasure = "Nos",
                    DrawingReference = "DRW-TEL-023",
                    CriticalityLevel = "B - Medium Critical",
                    HSNCode = "9017.30.00",
                    ItemCode = "TEL-XX-1006",
                    AuthorizedCreator = "Mr. Manoj",
                    ApprovalAuthority = "Operations Head",
                    ApprovalStatus = "Rejected",
                    StoreLocation = "",
                    BinNumber = "",
                    ApprovalRemarks = "Duplicate item already exists in system."
                },
                new ItemCodeRequest
                {
                    RequestID = "ICCRF-2026-007",
                    RequestDate = DateTime.Now,
                    Requestor = "Sachin Ravipati",
                    Department = "Design",
                    ItemCategory = "Project-Specific (Design)",
                    ItemDescription = "CUSTOM BRACKET ASSEMBLY",
                    TechnicalSpec = "SS304, Project P-2026-045, Custom fabricated",
                    UnitOfMeasure = "Nos",
                    DrawingReference = "DRW-PRJ-089",
                    CriticalityLevel = "A - High Critical",
                    HSNCode = "7326.90.90",
                    ItemCode = "PRJ-XX-1007",
                    AuthorizedCreator = "Mr. Kumar Ravi",
                    ApprovalAuthority = "Operations Head",
                    ApprovalStatus = "On Hold",
                    StoreLocation = "",
                    BinNumber = "",
                    ApprovalRemarks = "Awaiting design finalization."
                }
            };

            _filteredRequests = new List<ItemCodeRequest>(_allRequests);
        }

        private void RefreshGrid()
        {
            dgvPendingRequests.Rows.Clear();
            dgvPendingRequests.Columns["colSelect"].ReadOnly = false;

            foreach (var request in _filteredRequests)
            {
                int rowIndex = dgvPendingRequests.Rows.Add(
                    false,
                    request.RequestID,
                    request.RequestDate.ToShortDateString(),
                    request.Requestor,
                    request.Department,
                    request.ItemCategory,
                    request.ItemDescription,
                    request.ItemCode,
                    request.AuthorizedCreator,
                    request.ApprovalStatus
                );

                // Color code rows based on status
                Color rowColor = Color.White;
                switch (request.ApprovalStatus)
                {
                    case "Approved":
                        rowColor = Color.LightGreen;
                        break;
                    case "Rejected":
                        rowColor = Color.LightCoral;
                        break;
                    case "On Hold":
                        rowColor = Color.LightYellow;
                        break;
                    case "Pending":
                        rowColor = Color.White;
                        break;
                }
                dgvPendingRequests.Rows[rowIndex].DefaultCellStyle.BackColor = rowColor;
            }

            txtTotalPending.Text = _allRequests.Count(r => r.ApprovalStatus == "Pending").ToString();
            txtTotalApproved.Text = _allRequests.Count(r => r.ApprovalStatus == "Approved").ToString();
            txtTotalRejected.Text = _allRequests.Count(r => r.ApprovalStatus == "Rejected").ToString();
        }

        private void UpdateStatistics()
        {
            txtTotalPending.Text = _allRequests.Count(r => r.ApprovalStatus == "Pending").ToString();
            txtTotalApproved.Text = _allRequests.Count(r => r.ApprovalStatus == "Approved").ToString();
            txtTotalRejected.Text = _allRequests.Count(r => r.ApprovalStatus == "Rejected").ToString();
        }

        private void dgvPendingRequests_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == 0) // Checkbox column
            {
                DataGridViewCheckBoxCell cell = (DataGridViewCheckBoxCell)dgvPendingRequests.Rows[e.RowIndex].Cells[0];
                cell.Value = !(cell.Value == null ? false : (bool)cell.Value);
            }
        }

        private void dgvPendingRequests_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvPendingRequests.SelectedRows.Count > 0)
            {
                int rowIndex = dgvPendingRequests.SelectedRows[0].Index;
                if (rowIndex >= 0 && rowIndex < _filteredRequests.Count)
                {
                    _selectedRequest = _filteredRequests[rowIndex];
                    DisplaySelectedRequest();
                }
            }
        }

        private void DisplaySelectedRequest()
        {
            if (_selectedRequest == null) return;

            txtSelectedRequestID.Text = _selectedRequest.RequestID;
            txtSelectedItemCode.Text = _selectedRequest.ItemCode;
            txtSelectedDescription.Text = _selectedRequest.ItemDescription;
            txtSelectedCategory.Text = _selectedRequest.ItemCategory;
            txtSelectedRequestor.Text = _selectedRequest.Requestor;
            txtSelectedDepartment.Text = _selectedRequest.Department;
            txtSelectedTechnicalSpec.Text = _selectedRequest.TechnicalSpec;
            txtSelectedUOM.Text = _selectedRequest.UnitOfMeasure;
            txtSelectedCriticality.Text = _selectedRequest.CriticalityLevel;
            txtSelectedHSN.Text = _selectedRequest.HSNCode;

            // Set default action based on current status
            if (_selectedRequest.ApprovalStatus == "Pending")
            {
                cmbAction.SelectedItem = "Approve";
            }
            else if (_selectedRequest.ApprovalStatus == "On Hold")
            {
                cmbAction.SelectedItem = "Approve";
            }

            txtApprovalRemarks.Text = _selectedRequest.ApprovalRemarks ?? "";
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void btnClearFilter_Click(object sender, EventArgs e)
        {
            cmbFilterCategory.SelectedIndex = 0;
            cmbFilterDepartment.SelectedIndex = 0;
            cmbFilterStatus.SelectedIndex = 0;
            ApplyFilters();
        }

        private void ApplyFilters()
        {
            string categoryFilter = cmbFilterCategory.SelectedItem?.ToString();
            string departmentFilter = cmbFilterDepartment.SelectedItem?.ToString();
            string statusFilter = cmbFilterStatus.SelectedItem?.ToString();

            _filteredRequests = _allRequests.Where(r =>
            {
                bool categoryMatch = categoryFilter == "All" || r.ItemCategory == categoryFilter;
                bool departmentMatch = departmentFilter == "All" || r.Department == departmentFilter;
                bool statusMatch = statusFilter == "All" || r.ApprovalStatus == statusFilter;
                return categoryMatch && departmentMatch && statusMatch;
            }).ToList();

            RefreshGrid();
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            ProcessApproval("Approved");
        }

        private void btnReject_Click(object sender, EventArgs e)
        {
            ProcessApproval("Rejected");
        }

        private void btnHold_Click(object sender, EventArgs e)
        {
            ProcessApproval("On Hold");
        }

        private void ProcessApproval(string status)
        {
            if (_selectedRequest == null)
            {
                MessageBox.Show("Please select a request from the grid.", "No Selection",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validate approver authority
            if (!ValidateApproverAuthority(_selectedRequest))
            {
                MessageBox.Show($"You do not have authority to approve {_selectedRequest.ItemCategory} items.\n\nRequired Authority: {_selectedRequest.ApprovalAuthority}",
                    "Authorization Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Confirm action
            DialogResult result = MessageBox.Show(
                $"Are you sure you want to {status.ToLower()} this request?\n\nRequest ID: {_selectedRequest.RequestID}\nItem Code: {_selectedRequest.ItemCode}\nDescription: {_selectedRequest.ItemDescription}",
                $"Confirm {status}",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // Update request
                _selectedRequest.ApprovalStatus = status;
                _selectedRequest.ApprovalRemarks = txtApprovalRemarks.Text;
                _selectedRequest.ApprovedBy = txtApproverName.Text;
                _selectedRequest.ApprovalDate = dtpApprovalDate.Value;

                // If approved, activate for transactions
                if (status == "Approved")
                {
                    _selectedRequest.IsActive = true;
                    MessageBox.Show(
                        $"Item Code {_selectedRequest.ItemCode} has been APPROVED and ACTIVATED for transactions.\n\nThe item is now available for use in PR, PO, GRN, and BOM transactions.",
                        "Approval Successful",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                else if (status == "Rejected")
                {
                    MessageBox.Show(
                        $"Item Code {_selectedRequest.ItemCode} has been REJECTED.\n\nReason: {txtApprovalRemarks.Text}",
                        "Request Rejected",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                else if (status == "On Hold")
                {
                    MessageBox.Show(
                        $"Item Code {_selectedRequest.ItemCode} has been placed ON HOLD.\n\nReason: {txtApprovalRemarks.Text}",
                        "Request On Hold",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }

                // Refresh display
                RefreshGrid();
                UpdateStatistics();
                ClearSelectedRequest();
            }
        }

        private bool ValidateApproverAuthority(ItemCodeRequest request)
        {
            // Check if current user role matches required approval authority
            // Material Manager can approve: Capex, Maintenance, Consumables, Services, Packing, Kanban, NOI, R&D
            // Operations Head can approve: Electrical, Hydraulics, Mechanical, Test Lab, Project, Machining, MBO

            if (_currentUserRole == "Operations Head")
            {
                return request.ApprovalAuthority == "Operations Head";
            }
            else if (_currentUserRole == "Material Manager")
            {
                return request.ApprovalAuthority == "Material Manager";
            }

            return false;
        }

        private void btnBulkApprove_Click(object sender, EventArgs e)
        {
            ProcessBulkAction("Approved");
        }

        private void btnBulkReject_Click(object sender, EventArgs e)
        {
            ProcessBulkAction("Rejected");
        }

        private void btnBulkHold_Click(object sender, EventArgs e)
        {
            ProcessBulkAction("On Hold");
        }

        private void ProcessBulkAction(string status)
        {
            List<ItemCodeRequest> selectedRequests = new List<ItemCodeRequest>();

            for (int i = 0; i < dgvPendingRequests.Rows.Count; i++)
            {
                DataGridViewCheckBoxCell checkCell = (DataGridViewCheckBoxCell)dgvPendingRequests.Rows[i].Cells[0];
                if (checkCell.Value != null && (bool)checkCell.Value)
                {
                    selectedRequests.Add(_filteredRequests[i]);
                }
            }

            if (selectedRequests.Count == 0)
            {
                MessageBox.Show("Please select at least one request using the checkboxes.", "No Selection",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validate all selected requests
            List<ItemCodeRequest> validRequests = new List<ItemCodeRequest>();
            List<string> invalidRequests = new List<string>();

            foreach (var request in selectedRequests)
            {
                if (ValidateApproverAuthority(request))
                {
                    validRequests.Add(request);
                }
                else
                {
                    invalidRequests.Add($"{request.RequestID} ({request.ItemCategory})");
                }
            }

            if (validRequests.Count == 0)
            {
                MessageBox.Show("You do not have authority to approve any of the selected requests.",
                    "Authorization Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (invalidRequests.Count > 0)
            {
                MessageBox.Show($"The following requests cannot be processed due to authorization mismatch:\n\n{string.Join("\n", invalidRequests)}",
                    "Partial Authorization", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            DialogResult result = MessageBox.Show(
                $"Are you sure you want to {status.ToLower()} {validRequests.Count} selected request(s)?",
                $"Confirm Bulk {status}",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                foreach (var request in validRequests)
                {
                    request.ApprovalStatus = status;
                    request.ApprovedBy = txtApproverName.Text;
                    request.ApprovalDate = dtpApprovalDate.Value;
                    request.IsActive = (status == "Approved");
                }

                MessageBox.Show($"{validRequests.Count} request(s) have been {status.ToLower()} successfully.",
                    "Bulk Action Complete",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                RefreshGrid();
                UpdateStatistics();
                ClearSelectedRequest();
            }
        }

        private void ClearSelectedRequest()
        {
            _selectedRequest = null;
            txtSelectedRequestID.Clear();
            txtSelectedItemCode.Clear();
            txtSelectedDescription.Clear();
            txtSelectedCategory.Clear();
            txtSelectedRequestor.Clear();
            txtSelectedDepartment.Clear();
            txtSelectedTechnicalSpec.Clear();
            txtSelectedUOM.Clear();
            txtSelectedCriticality.Clear();
            txtSelectedHSN.Clear();
            txtApprovalRemarks.Clear();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ApplyFilters();
            MessageBox.Show("Data refreshed successfully.", "Refresh",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "CSV files (*.csv)|*.csv|Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            saveDialog.FileName = $"ItemCodeApproval_{DateTime.Now:yyyyMMdd}.csv";

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter writer = new StreamWriter(saveDialog.FileName))
                    {
                        // Header
                        writer.WriteLine("RequestID,RequestDate,Requestor,Department,ItemCategory,ItemDescription,ItemCode,AuthorizedCreator,ApprovalAuthority,ApprovalStatus,ApprovedBy,ApprovalDate,ApprovalRemarks");

                        // Data
                        // foreach (var request in _filteredRequests)
                        // {
                        //  ",{request.ItemCode},{request.AuthorizedCreator},{request.ApprovalAuthority},{request.ApprovalStatus},{request.ApprovedBy},{request.ApprovalDate:yyyy-MM-dd},"{ request.ApprovalRemarks}
                        // "");
                        //  }
                    }

                    MessageBox.Show($"Data exported successfully to:\n{saveDialog.FileName}", "Export Complete",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Export failed:\n{ex.Message}", "Export Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintDocument printDoc = new PrintDocument();
            printDoc.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);

            PrintPreviewDialog previewDialog = new PrintPreviewDialog();
            previewDialog.Document = printDoc;
            previewDialog.ShowDialog();
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            Graphics graphics = e.Graphics;
            Font font = new Font("Arial", 9);
            Font boldFont = new Font("Arial", 9, FontStyle.Bold);
            Font titleFont = new Font("Arial", 14, FontStyle.Bold);
            Font headerFont = new Font("Arial", 11, FontStyle.Bold);

            float lineHeight = font.GetHeight() + 3;
            float x = 40;
            float y = 40;
            float pageWidth = e.PageBounds.Width - 80;

            // Title
            graphics.DrawString("ITEM CODE APPROVAL REPORT", titleFont, Brushes.Black, x, y);
            y += lineHeight * 2;

            // Report info
            graphics.DrawString($"Generated By: {txtApproverName.Text}    Role: {_currentUserRole}", font, Brushes.Black, x, y);
            y += lineHeight;
            graphics.DrawString($"Date: {DateTime.Now:dd-MMM-yyyy HH:mm}    Total Records: {_filteredRequests.Count}", font, Brushes.Black, x, y);
            y += lineHeight * 2;

            // Column headers
            graphics.DrawLine(Pens.Black, x, y, x + pageWidth, y);
            y += 3;
            graphics.DrawString("Req.ID", boldFont, Brushes.Black, x, y);
            graphics.DrawString("Date", boldFont, Brushes.Black, x + 80, y);
            graphics.DrawString("Requestor", boldFont, Brushes.Black, x + 150, y);
            graphics.DrawString("Category", boldFont, Brushes.Black, x + 250, y);
            graphics.DrawString("Item Code", boldFont, Brushes.Black, x + 380, y);
            graphics.DrawString("Status", boldFont, Brushes.Black, x + 480, y);
            graphics.DrawString("Approved By", boldFont, Brushes.Black, x + 560, y);
            y += lineHeight;
            graphics.DrawLine(Pens.Black, x, y, x + pageWidth, y);
            y += 3;

            // Data rows
            foreach (var request in _filteredRequests)
            {
                if (y > e.PageBounds.Height - 60)
                {
                    e.HasMorePages = true;
                    return;
                }

                graphics.DrawString(request.RequestID, font, Brushes.Black, x, y);
                graphics.DrawString(request.RequestDate.ToString("dd-MMM"), font, Brushes.Black, x + 80, y);
                graphics.DrawString(request.Requestor, font, Brushes.Black, x + 150, y);
                graphics.DrawString(request.ItemCategory.Length > 15 ? request.ItemCategory.Substring(0, 15) + "..." : request.ItemCategory, font, Brushes.Black, x + 250, y);
                graphics.DrawString(request.ItemCode, font, Brushes.Black, x + 380, y);

                Brush statusBrush = Brushes.Black;
                switch (request.ApprovalStatus)
                {
                    case "Approved": statusBrush = Brushes.Green; break;
                    case "Rejected": statusBrush = Brushes.Red; break;
                    case "On Hold": statusBrush = Brushes.Orange; break;
                }
                graphics.DrawString(request.ApprovalStatus, font, statusBrush, x + 480, y);
                graphics.DrawString(request.ApprovedBy ?? "-", font, Brushes.Black, x + 560, y);

                y += lineHeight;
            }

            y += 5;
            graphics.DrawLine(Pens.Black, x, y, x + pageWidth, y);
            y += lineHeight;
            graphics.DrawString($"Pending: {txtTotalPending.Text}    Approved: {txtTotalApproved.Text}    Rejected: {txtTotalRejected.Text}", boldFont, Brushes.Black, x, y);

            e.HasMorePages = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    // Data Model Class
    public class ItemCodeRequest
    {
        public string RequestID { get; set; }
        public DateTime RequestDate { get; set; }
        public string Requestor { get; set; }
        public string Department { get; set; }
        public string ItemCategory { get; set; }
        public string ItemDescription { get; set; }
        public string TechnicalSpec { get; set; }
        public string UnitOfMeasure { get; set; }
        public string DrawingReference { get; set; }
        public string CriticalityLevel { get; set; }
        public string HSNCode { get; set; }
        public string ItemCode { get; set; }
        public string AuthorizedCreator { get; set; }
        public string ApprovalAuthority { get; set; }
        public string ApprovalStatus { get; set; }
        public string ApprovalRemarks { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime? ApprovalDate { get; set; }
        public string StoreLocation { get; set; }
        public string BinNumber { get; set; }
        public bool IsActive { get; set; }
        public bool IsEmergency { get; set; }
    }
}