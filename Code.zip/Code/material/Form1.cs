﻿//using System.Drawing.Printing;

//namespace WinFormsApp1
//{
//    public partial class Form1 : Form
//    {
//        public Form1()
//        {
//            InitializeComponent();
//        }
//    }
//}


using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        // Dictionary to store item category prefixes as per SOP
        private readonly Dictionary<string, string> _categoryPrefixes = new Dictionary<string, string>
        {
            { "Capex / Fixed Asset", "FA" },
            { "Maintenance", "MNT" },
            { "Consumables", "CON" },
            { "Services", "SER" },
            { "Packing Items", "PM" },
            { "Kanban", "KAN" },
            { "Electrical & Electronics", "ELE" },
            { "Hydraulics", "HYD" },
            { "Mechanical", "MEC" },
            { "Test Lab", "TEL" },
            { "Consumables Non-Inventory", "NOI" },
            { "Project-Specific (Design)", "PRJ" },
            { "Machining Items", "MAC" },
            { "Mechanical Brought-Out Parts", "MBO" },
            { "R & D", "RND" }
        };

        // Dictionary for authorized creators based on category
        private readonly Dictionary<string, List<string>> _authorizedCreators = new Dictionary<string, List<string>>
        {
            { "Capex / Fixed Asset", new List<string> { "Purchase Department" } },
            { "Maintenance", new List<string> { "Purchase Department" } },
            { "Consumables", new List<string> { "Purchase Department" } },
            { "Services", new List<string> { "Purchase Department" } },
            { "Packing Items", new List<string> { "Purchase Department" } },
            { "Kanban", new List<string> { "Purchase Department" } },
            { "Electrical & Electronics", new List<string> { "Mr. Ravi Naiker" } },
            { "Hydraulics", new List<string> { "Mr. Santosh", "Mr. Sanjay" } },
            { "Mechanical", new List<string> { "Mr. Santosh", "Mr. Kumar Ravi", "Mr. Vishal" } },
            { "Test Lab", new List<string> { "Mr. Manoj" } },
            { "Consumables Non-Inventory", new List<string> { "Purchase Department" } },
            { "Project-Specific (Design)", new List<string> { "Mr. Kumar Ravi", "Mr. Sachin" } },
            { "Machining Items", new List<string> { "Mr. Santosh", "Mr. Kumar Ravi", "Mr. Vishal" } },
            { "Mechanical Brought-Out Parts", new List<string> { "Mr. Santosh", "Mr. Kumar Ravi", "Mr. Vishal" } },
            { "R & D", new List<string> { "Purchase Department" } }
        };

        // Dictionary for approval authorities
        private readonly Dictionary<string, string> _approvalAuthorities = new Dictionary<string, string>
        {
            { "Capex / Fixed Asset", "Material Manager" },
            { "Maintenance", "Material Manager" },
            { "Consumables", "Material Manager" },
            { "Services", "Material Manager" },
            { "Packing Items", "Material Manager" },
            { "Kanban", "Material Manager" },
            { "Electrical & Electronics", "Operations Head" },
            { "Hydraulics", "Operations Head" },
            { "Mechanical", "Operations Head" },
            { "Test Lab", "Operations Head" },
            { "Consumables Non-Inventory", "Material Manager" },
            { "Project-Specific (Design)", "Operations Head" },
            { "Machining Items", "Operations Head" },
            { "Mechanical Brought-Out Parts", "Operations Head" },
            { "R & D", "Material Manager" }
        };

        // List of departments
        private readonly List<string> _departments = new List<string>
        {
            "Purchase", "Maintenance", "Production", "R & D", "Test Lab",
            "Design", "Machining", "Hydraulics", "Electrical", "Stores",
            "Quality", "Project", "Packing", "HR", "Finance"
        };

        // List of units of measure
        private readonly List<string> _unitsOfMeasure = new List<string>
        {
            "Nos", "Kg", "Meter", "Liter", "Set", "Box", "Roll", "Pair",
            "Sheet", "Packet", "Bundle", "Drum", "Can", "Bag", "Each"
        };

        // List of criticality levels
        private readonly List<string> _criticalityLevels = new List<string>
        {
            "A - High Critical", "B - Medium Critical", "C - Low Critical"
        };

        // List of approval statuses
        private readonly List<string> _approvalStatuses = new List<string>
        {
            "Pending", "Approved", "Rejected", "On Hold"
        };

        // List of emergency approvers
        private readonly List<string> _emergencyApprovers = new List<string>
        {
            "Operations Head", "Material Manager"
        };

        // Sequential number counter (in real app, this would come from database)
        private static int _sequentialCounter = 1000;

        public Form1()
        {
            InitializeComponent();
        }

        private void frmItemCodeCreation_Load(object sender, EventArgs e)
        {
            // Set default dates
            dtpRequestDate.Value = DateTime.Now;
            dtpEffectiveDate.Value = DateTime.Now;

            // Load dropdowns
            LoadDepartments();
            LoadItemCategories();
            LoadUnitsOfMeasure();
            LoadCriticalityLevels();
            LoadApprovalStatuses();
            LoadEmergencyApprovers();

            // Set default requestor
            txtRequestor.Text = Environment.UserName;

            // Set default prepared by and approved by
            txtPreparedBy.Text = "Material Manager";
            txtApprovedBy.Text = "Operations Head";
        }

        private void LoadDepartments()
        {
            cmbDepartment.DataSource = null;
            cmbDepartment.Items.Clear();
            foreach (var dept in _departments)
            {
                cmbDepartment.Items.Add(dept);
            }
            cmbDepartment.SelectedIndex = -1;
        }

        private void LoadItemCategories()
        {
            cmbItemCategory.DataSource = null;
            cmbItemCategory.Items.Clear();
            foreach (var category in _categoryPrefixes.Keys)
            {
                cmbItemCategory.Items.Add(category);
            }
            cmbItemCategory.SelectedIndex = -1;
        }

        private void LoadUnitsOfMeasure()
        {
            cmbUnitOfMeasure.DataSource = null;
            cmbUnitOfMeasure.Items.Clear();
            foreach (var unit in _unitsOfMeasure)
            {
                cmbUnitOfMeasure.Items.Add(unit);
            }
            cmbUnitOfMeasure.SelectedIndex = -1;
        }

        private void LoadCriticalityLevels()
        {
            cmbCriticalityLevel.DataSource = null;
            cmbCriticalityLevel.Items.Clear();
            foreach (var level in _criticalityLevels)
            {
                cmbCriticalityLevel.Items.Add(level);
            }
            cmbCriticalityLevel.SelectedIndex = -1;
        }

        private void LoadApprovalStatuses()
        {
            cmbApprovalStatus.DataSource = null;
            cmbApprovalStatus.Items.Clear();
            foreach (var status in _approvalStatuses)
            {
                cmbApprovalStatus.Items.Add(status);
            }
            cmbApprovalStatus.SelectedIndex = 0; // Default to Pending
        }

        private void LoadEmergencyApprovers()
        {
            cmbEmergencyApproval.DataSource = null;
            cmbEmergencyApproval.Items.Clear();
            foreach (var approver in _emergencyApprovers)
            {
                cmbEmergencyApproval.Items.Add(approver);
            }
            cmbEmergencyApproval.SelectedIndex = -1;
        }

        private void cmbItemCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbItemCategory.SelectedItem != null)
            {
                string selectedCategory = cmbItemCategory.SelectedItem.ToString();

                // Update prefix and category code
                if (_categoryPrefixes.ContainsKey(selectedCategory))
                {
                    string prefix = _categoryPrefixes[selectedCategory];
                    txtPrefix.Text = prefix;
                    txtCategoryCode.Text = prefix;
                }

                // Update authorized creators
                cmbAuthorizedCreator.Items.Clear();
                if (_authorizedCreators.ContainsKey(selectedCategory))
                {
                    foreach (var creator in _authorizedCreators[selectedCategory])
                    {
                        cmbAuthorizedCreator.Items.Add(creator);
                    }
                    cmbAuthorizedCreator.SelectedIndex = 0;
                }

                // Update approval authority
                if (_approvalAuthorities.ContainsKey(selectedCategory))
                {
                    cmbApprovalAuthority.Items.Clear();
                    cmbApprovalAuthority.Items.Add(_approvalAuthorities[selectedCategory]);
                    cmbApprovalAuthority.SelectedIndex = 0;
                }
            }
        }

        private void txtItemDescription_TextChanged(object sender, EventArgs e)
        {
            // Convert to uppercase as per SOP requirement
            txtItemDescription.Text = txtItemDescription.Text.ToUpper();
            txtItemDescription.SelectionStart = txtItemDescription.Text.Length;
        }

        private void btnGenerateCode_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPrefix.Text))
            {
                MessageBox.Show("Please select an Item Category first.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtSequentialNumber.Text))
            {
                // Auto-generate sequential number
                _sequentialCounter++;
                txtSequentialNumber.Text = _sequentialCounter.ToString("D4");
            }

            // Generate item code in format: PREFIX-XX-NNNN
            string prefix = txtPrefix.Text;
            string sequentialNum = txtSequentialNumber.Text.PadLeft(4, '0');
            string categoryCode = "XX"; // Default category sub-code

            // Generate the final item code
            string itemCode = $"{prefix}-{categoryCode}-{sequentialNum}";
            txtGeneratedItemCode.Text = itemCode;

            MessageBox.Show($"Item Code Generated: {itemCode}", "Success",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void chkEmergency_CheckedChanged(object sender, EventArgs e)
        {
            cmbEmergencyApproval.Enabled = chkEmergency.Checked;
            if (!chkEmergency.Checked)
            {
                cmbEmergencyApproval.SelectedIndex = -1;
            }
            else
            {
                cmbEmergencyApproval.SelectedIndex = 0;
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Validation
            if (!ValidateForm())
            {
                return;
            }

            // Check if item code is generated
            if (string.IsNullOrWhiteSpace(txtGeneratedItemCode.Text))
            {
                DialogResult result = MessageBox.Show(
                    "Item code not generated yet. Generate now?",
                    "Confirm",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    btnGenerateCode_Click(sender, e);
                }
                else
                {
                    return;
                }
            }

            // Save data (in real application, this would save to database)
            string confirmationMessage = $@"Item Code Creation Request Submitted Successfully!

Request Details:
----------------
Request Date: {dtpRequestDate.Value.ToShortDateString()}
Requestor: {txtRequestor.Text}
Department: {cmbDepartment.SelectedItem}
Item Category: {cmbItemCategory.SelectedItem}
Item Description: {txtItemDescription.Text}
Technical Spec: {txtTechnicalSpec.Text}
Unit of Measure: {cmbUnitOfMeasure.SelectedItem}
Drawing Reference: {txtDrawingReference.Text}
Criticality Level: {cmbCriticalityLevel.SelectedItem}
HSN Code: {txtHSNCode.Text}

Generated Item Code: {txtGeneratedItemCode.Text}

Authorized Creator: {cmbAuthorizedCreator.SelectedItem}
Approval Authority: {cmbApprovalAuthority.SelectedItem}
Approval Status: {cmbApprovalStatus.SelectedItem}

Emergency: {(chkEmergency.Checked ? "Yes - " + cmbEmergencyApproval.SelectedItem : "No")}

Store Location: {txtStoreLocation.Text}
Bin Number: {txtBinNumber.Text}

Prepared By: {txtPreparedBy.Text}
Approved By: {txtApprovedBy.Text}
Effective Date: {dtpEffectiveDate.Value.ToShortDateString()}

Note: Post-creation validation must be completed within 48 hours.";

            MessageBox.Show(confirmationMessage, "Submission Successful",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            // In a real application, you would save to database here
            // SaveToDatabase();
        }

        private bool ValidateForm()
        {
            if (string.IsNullOrWhiteSpace(txtRequestor.Text))
            {
                MessageBox.Show("Requestor name is required.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtRequestor.Focus();
                return false;
            }

            if (cmbDepartment.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a Department.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbDepartment.Focus();
                return false;
            }

            if (cmbItemCategory.SelectedIndex == -1)
            {
                MessageBox.Show("Please select an Item Category.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbItemCategory.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtItemDescription.Text))
            {
                MessageBox.Show("Item Description is required.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtItemDescription.Focus();
                return false;
            }

            if (txtItemDescription.Text.Length > 40)
            {
                MessageBox.Show("Item Description must be 40 characters or less.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtItemDescription.Focus();
                return false;
            }

            if (cmbUnitOfMeasure.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a Unit of Measure.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbUnitOfMeasure.Focus();
                return false;
            }

            if (cmbCriticalityLevel.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a Criticality Level.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbCriticalityLevel.Focus();
                return false;
            }

            if (cmbAuthorizedCreator.SelectedIndex == -1)
            {
                MessageBox.Show("Please select an Authorized Creator.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbAuthorizedCreator.Focus();
                return false;
            }

            if (chkEmergency.Checked && cmbEmergencyApproval.SelectedIndex == -1)
            {
                MessageBox.Show("Please select an Emergency Approval authority.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbEmergencyApproval.Focus();
                return false;
            }

            return true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to clear all fields?",
                "Confirm Clear",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                ClearAllFields();
            }
        }

        private void ClearAllFields()
        {
            dtpRequestDate.Value = DateTime.Now;
            txtRequestor.Text = Environment.UserName;
            cmbDepartment.SelectedIndex = -1;
            cmbItemCategory.SelectedIndex = -1;
            txtItemDescription.Clear();
            txtTechnicalSpec.Clear();
            cmbUnitOfMeasure.SelectedIndex = -1;
            txtDrawingReference.Clear();
            cmbCriticalityLevel.SelectedIndex = -1;
            txtHSNCode.Clear();
            txtPrefix.Clear();
            txtCategoryCode.Clear();
            txtSequentialNumber.Clear();
            txtGeneratedItemCode.Clear();
            cmbAuthorizedCreator.Items.Clear();
            cmbApprovalAuthority.Items.Clear();
            cmbApprovalStatus.SelectedIndex = 0;
            txtApprovalRemarks.Clear();
            txtStoreLocation.Clear();
            txtBinNumber.Clear();
            chkEmergency.Checked = false;
            cmbEmergencyApproval.SelectedIndex = -1;
            dtpEffectiveDate.Value = DateTime.Now;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to exit?",
                "Confirm Exit",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintDocument printDoc = new PrintDocument();
            printDoc.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);

            PrintPreviewDialog previewDialog = new PrintPreviewDialog();
            previewDialog.Document = printDoc;
            previewDialog.ShowDialog();
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            Graphics graphics = e.Graphics;
            Font font = new Font("Arial", 10);
            Font boldFont = new Font("Arial", 10, FontStyle.Bold);
            Font titleFont = new Font("Arial", 14, FontStyle.Bold);
            Font headerFont = new Font("Arial", 12, FontStyle.Bold);

            float lineHeight = font.GetHeight() + 4;
            float x = 50;
            float y = 50;
            float pageWidth = e.PageBounds.Width - 100;

            // Title
            graphics.DrawString("ITEM CODE CREATION REQUEST FORM (ICCRF)", titleFont, Brushes.Black, x, y);
            y += lineHeight * 2;

            // Header Info
            graphics.DrawString($"Request Date: {dtpRequestDate.Value.ToShortDateString()}", font, Brushes.Black, x, y);
            graphics.DrawString($"Requestor: {txtRequestor.Text}", font, Brushes.Black, x + 300, y);
            y += lineHeight;
            graphics.DrawString($"Department: {(cmbDepartment.SelectedItem ?? "N/A")}", font, Brushes.Black, x, y);
            y += lineHeight * 2;

            // Section 1: Request Details
            graphics.DrawString("STEP 1: ITEM CODE REQUEST INITIATION", headerFont, Brushes.DarkBlue, x, y);
            y += lineHeight;
            graphics.DrawLine(Pens.Black, x, y, x + pageWidth, y);
            y += lineHeight;

            graphics.DrawString($"Item Category: {(cmbItemCategory.SelectedItem ?? "N/A")}", font, Brushes.Black, x, y);
            y += lineHeight;
            graphics.DrawString($"Item Description: {txtItemDescription.Text}", font, Brushes.Black, x, y);
            y += lineHeight;
            graphics.DrawString($"Technical Spec / Drawing Ref: {txtTechnicalSpec.Text}", font, Brushes.Black, x, y);
            y += lineHeight;
            graphics.DrawString($"Unit of Measure: {(cmbUnitOfMeasure.SelectedItem ?? "N/A")}", font, Brushes.Black, x, y);
            graphics.DrawString($"Drawing Reference: {txtDrawingReference.Text}", font, Brushes.Black, x + 250, y);
            y += lineHeight;
            graphics.DrawString($"Criticality Level (ABC): {(cmbCriticalityLevel.SelectedItem ?? "N/A")}", font, Brushes.Black, x, y);
            graphics.DrawString($"HSN Code: {txtHSNCode.Text}", font, Brushes.Black, x + 250, y);
            y += lineHeight * 2;

            // Section 2: Item Code Structure
            graphics.DrawString("STEP 2 & 5: ITEM CODE STRUCTURE", headerFont, Brushes.DarkBlue, x, y);
            y += lineHeight;
            graphics.DrawLine(Pens.Black, x, y, x + pageWidth, y);
            y += lineHeight;

            graphics.DrawString($"Prefix: {txtPrefix.Text}", font, Brushes.Black, x, y);
            graphics.DrawString($"Category Code: {txtCategoryCode.Text}", font, Brushes.Black, x + 150, y);
            graphics.DrawString($"Sequential No: {txtSequentialNumber.Text}", font, Brushes.Black, x + 300, y);
            y += lineHeight;
            graphics.DrawString($"GENERATED ITEM CODE: {txtGeneratedItemCode.Text}", boldFont, Brushes.DarkRed, x, y);
            y += lineHeight * 2;

            // Section 3: Approval
            graphics.DrawString("STEP 3: APPROVAL & ACTIVATION", headerFont, Brushes.DarkBlue, x, y);
            y += lineHeight;
            graphics.DrawLine(Pens.Black, x, y, x + pageWidth, y);
            y += lineHeight;

            graphics.DrawString($"Authorized Creator: {(cmbAuthorizedCreator.SelectedItem ?? "N/A")}", font, Brushes.Black, x, y);
            y += lineHeight;
            graphics.DrawString($"Approval Authority: {(cmbApprovalAuthority.SelectedItem ?? "N/A")}", font, Brushes.Black, x, y);
            y += lineHeight;
            graphics.DrawString($"Approval Status: {(cmbApprovalStatus.SelectedItem ?? "N/A")}", font, Brushes.Black, x, y);
            y += lineHeight;
            graphics.DrawString($"Remarks: {txtApprovalRemarks.Text}", font, Brushes.Black, x, y);
            y += lineHeight * 2;

            // Section 4: Location
            graphics.DrawString("STEP 4: STORE LOCATION (UPON GIN)", headerFont, Brushes.DarkBlue, x, y);
            y += lineHeight;
            graphics.DrawLine(Pens.Black, x, y, x + pageWidth, y);
            y += lineHeight;

            graphics.DrawString($"Store Location: {txtStoreLocation.Text}", font, Brushes.Black, x, y);
            graphics.DrawString($"Bin Number: {txtBinNumber.Text}", font, Brushes.Black, x + 250, y);
            y += lineHeight * 2;

            // Emergency Section
            if (chkEmergency.Checked)
            {
                graphics.DrawString("EMERGENCY CREATION", headerFont, Brushes.Red, x, y);
                y += lineHeight;
                graphics.DrawString($"Emergency Approval By: {(cmbEmergencyApproval.SelectedItem ?? "N/A")}", font, Brushes.Red, x, y);
                y += lineHeight;
                graphics.DrawString("Note: Post-creation validation must be completed within 48 hours.", font, Brushes.Red, x, y);
                y += lineHeight * 2;
            }

            // Footer
            graphics.DrawLine(Pens.Black, x, y, x + pageWidth, y);
            y += lineHeight;
            graphics.DrawString($"Prepared By: {txtPreparedBy.Text}", font, Brushes.Black, x, y);
            graphics.DrawString($"Approved By: {txtApprovedBy.Text}", font, Brushes.Black, x + 200, y);
            graphics.DrawString($"Effective Date: {dtpEffectiveDate.Value.ToShortDateString()}", font, Brushes.Black, x + 400, y);
            y += lineHeight * 2;

            // SOP Reference
            graphics.DrawString("This form follows SOP for Item Code Creation in ERP. All item codes must follow structured coding logic.",
                new Font("Arial", 8, FontStyle.Italic), Brushes.Gray, x, y);
        }
    }
}