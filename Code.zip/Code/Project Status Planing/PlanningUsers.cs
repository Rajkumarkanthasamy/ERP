﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Status_Planing
{
    public partial class PlanningUsers : Form
    {
        DataTable dtUserName = new DataTable();
        DataTable dtOldUserNames = new DataTable();
        DataTable dtUsercheck = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        bool bUserexist = false;
        public PlanningUsers()
        {
            InitializeComponent();
        }

        public void fnProductCode(string ProductCode)
        {
            lblProductCode.Text = ProductCode;
        }
        public void fnProjectCode(string ProjectCode)
        {
            lblProjectCode.Text = ProjectCode;
        }
        public void fnAssignedBy(string AssignedBy)
        {
            lblAssignedBy.Text = AssignedBy;
        }


        private void PlanningUsers_Load(object sender, EventArgs e)
        {
            txtusername.ResetText();
            DataGridViewColumn column = dgvadduser.Columns[0];
            column.Width = 5;
            DataGridViewColumn column1 = dgvadduser.Columns[1];
            column1.Width = 220;

            dtUserName = DAL.fnUserList(null).Tables[0];


            if (!string.IsNullOrEmpty(lblProductCode.Text))
            {
                dtOldUserNames = DAL.fnProjectPlanningUser(lblProductCode.Text, lblProjectCode.Text).Tables[0];
            }

            dgvoldusers.AutoGenerateColumns = false;
            dgvoldusers.DataSource = dtOldUserNames;
            dgvoldusers.Columns["oUserName"].DefaultCellStyle.BackColor = Color.FromArgb(255, 128, 128);

            dgvadduser.AutoGenerateColumns = false;
            dgvadduser.DataSource = dtUserName;

            dgvadduser.Columns["Select"].DefaultCellStyle.BackColor = Color.FromArgb(128, 255, 128);
            dgvadduser.Columns["UserName"].DefaultCellStyle.BackColor = Color.FromArgb(255, 128, 128);
        }

        DataView dvUserList = new DataView();
        private void fnRowFilter(string sRowFilter)
        {
            dvUserList = new DataView(dtUserName);
            dvUserList.RowFilter = "UserName like '" + sRowFilter + "%'";
            dvUserList.Sort = "UserName asc";
            dgvadduser.DataSource = dvUserList.ToTable();
        }

        private void txtusername_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(txtusername.Text);
        }

        private void dgvoldusers_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {               
                if (Convert.ToBoolean(LoginForm.GetUserDetails[13].ToString()))
                {
                    GLobalClass.iSuccess = DAL.fnAddProjectPlanningUsers(Global.uDELETE, dgvoldusers.CurrentRow.Cells["oUserName"].Value.ToString(), lblProductCode.Text,lblProjectCode.Text,lblAssignedBy.Text);
                    dgvoldusers.Rows.RemoveAt(dgvoldusers.Rows.IndexOf(dgvoldusers.CurrentRow));
                }
            }
        }

        private void dgvadduser_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvadduser.CurrentCell.OwningColumn.Name == "Select")
            {
                foreach (DataRow dtusernames in dtOldUserNames.Rows)
                {
                    if (dgvadduser.CurrentRow.Cells["UserName"].Value.ToString() == dtusernames["UserName"].ToString())
                    {
                        bUserexist = true;
                        MessageBox.Show("User " + dgvadduser.CurrentRow.Cells["UserName"].Value.ToString() + " Already Exist");
                        break;
                    }
                    else
                    {
                        bUserexist = false;
                    }
                }

                if (bUserexist == false)
                {
                    GLobalClass.iSuccess = DAL.fnAddProjectPlanningUsers(Global.uINSERT, dgvadduser.CurrentRow.Cells["UserName"].Value.ToString(), lblProductCode.Text, lblProjectCode.Text, lblAssignedBy.Text);
                    dgvadduser.Rows.RemoveAt(dgvadduser.Rows.IndexOf(dgvadduser.CurrentRow));
                     dtOldUserNames = DAL.fnProjectPlanningUser(lblProductCode.Text, lblProjectCode.Text).Tables[0];
                    dgvoldusers.AutoGenerateColumns = false;
                    dgvoldusers.DataSource = dtOldUserNames;
                }
            }

        }

    }
}
