﻿namespace Erp_Project_With_Buttons.Project_Status_Planing
{
    partial class PlanningUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label2 = new System.Windows.Forms.Label();
            this.lblExistingUsers = new System.Windows.Forms.Label();
            this.lblnewuser = new System.Windows.Forms.Label();
            this.dgvoldusers = new System.Windows.Forms.DataGridView();
            this.oUserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblsearch = new System.Windows.Forms.Label();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.lblProductCode = new System.Windows.Forms.Label();
            this.dgvadduser = new System.Windows.Forms.DataGridView();
            this.Select = new System.Windows.Forms.DataGridViewButtonColumn();
            this.UserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.lblAssignedBy = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvoldusers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvadduser)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(402, 430);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(228, 19);
            this.label2.TabIndex = 19;
            this.label2.Text = "Press Delete Key to Delete Users";
            // 
            // lblExistingUsers
            // 
            this.lblExistingUsers.AutoSize = true;
            this.lblExistingUsers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExistingUsers.ForeColor = System.Drawing.Color.Red;
            this.lblExistingUsers.Location = new System.Drawing.Point(468, 80);
            this.lblExistingUsers.Name = "lblExistingUsers";
            this.lblExistingUsers.Size = new System.Drawing.Size(100, 19);
            this.lblExistingUsers.TabIndex = 17;
            this.lblExistingUsers.Text = "Existing Users";
            // 
            // lblnewuser
            // 
            this.lblnewuser.AutoSize = true;
            this.lblnewuser.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnewuser.ForeColor = System.Drawing.Color.Lime;
            this.lblnewuser.Location = new System.Drawing.Point(74, 47);
            this.lblnewuser.Name = "lblnewuser";
            this.lblnewuser.Size = new System.Drawing.Size(149, 19);
            this.lblnewuser.TabIndex = 16;
            this.lblnewuser.Text = "Add User Permission";
            // 
            // dgvoldusers
            // 
            this.dgvoldusers.AllowUserToAddRows = false;
            this.dgvoldusers.AllowUserToDeleteRows = false;
            this.dgvoldusers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvoldusers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvoldusers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvoldusers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.oUserName});
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvoldusers.DefaultCellStyle = dataGridViewCellStyle15;
            this.dgvoldusers.Location = new System.Drawing.Point(420, 110);
            this.dgvoldusers.Name = "dgvoldusers";
            this.dgvoldusers.RowHeadersVisible = false;
            this.dgvoldusers.Size = new System.Drawing.Size(205, 310);
            this.dgvoldusers.TabIndex = 15;
            this.dgvoldusers.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvoldusers_KeyUp);
            // 
            // oUserName
            // 
            this.oUserName.DataPropertyName = "UserName";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.oUserName.DefaultCellStyle = dataGridViewCellStyle14;
            this.oUserName.HeaderText = "User Name";
            this.oUserName.Name = "oUserName";
            this.oUserName.ReadOnly = true;
            this.oUserName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // lblsearch
            // 
            this.lblsearch.AutoSize = true;
            this.lblsearch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsearch.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblsearch.Location = new System.Drawing.Point(23, 79);
            this.lblsearch.Name = "lblsearch";
            this.lblsearch.Size = new System.Drawing.Size(89, 19);
            this.lblsearch.TabIndex = 14;
            this.lblsearch.Text = "Search User";
            // 
            // txtusername
            // 
            this.txtusername.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtusername.Location = new System.Drawing.Point(120, 78);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(204, 26);
            this.txtusername.TabIndex = 13;
            this.txtusername.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtusername_KeyUp);
            // 
            // lblProductCode
            // 
            this.lblProductCode.AutoSize = true;
            this.lblProductCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductCode.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblProductCode.Location = new System.Drawing.Point(74, 9);
            this.lblProductCode.Name = "lblProductCode";
            this.lblProductCode.Size = new System.Drawing.Size(41, 19);
            this.lblProductCode.TabIndex = 12;
            this.lblProductCode.Text = "****";
            // 
            // dgvadduser
            // 
            this.dgvadduser.AllowUserToAddRows = false;
            this.dgvadduser.AllowUserToDeleteRows = false;
            this.dgvadduser.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvadduser.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvadduser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvadduser.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.UserName});
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvadduser.DefaultCellStyle = dataGridViewCellStyle18;
            this.dgvadduser.Location = new System.Drawing.Point(18, 109);
            this.dgvadduser.Name = "dgvadduser";
            this.dgvadduser.RowHeadersVisible = false;
            this.dgvadduser.Size = new System.Drawing.Size(306, 310);
            this.dgvadduser.TabIndex = 11;
            this.dgvadduser.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvadduser_CellClick);
            // 
            // Select
            // 
            this.Select.HeaderText = "Select";
            this.Select.Name = "Select";
            this.Select.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Select.Text = "ADD";
            // 
            // UserName
            // 
            this.UserName.DataPropertyName = "UserName";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.UserName.DefaultCellStyle = dataGridViewCellStyle17;
            this.UserName.HeaderText = "User Name";
            this.UserName.Name = "UserName";
            this.UserName.ReadOnly = true;
            this.UserName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblProjectCode.Location = new System.Drawing.Point(221, 9);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(41, 19);
            this.lblProjectCode.TabIndex = 20;
            this.lblProjectCode.Text = "****";
            // 
            // lblAssignedBy
            // 
            this.lblAssignedBy.AutoSize = true;
            this.lblAssignedBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssignedBy.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblAssignedBy.Location = new System.Drawing.Point(428, 9);
            this.lblAssignedBy.Name = "lblAssignedBy";
            this.lblAssignedBy.Size = new System.Drawing.Size(41, 19);
            this.lblAssignedBy.TabIndex = 21;
            this.lblAssignedBy.Text = "****";
            // 
            // PlanningUsers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(648, 458);
            this.Controls.Add(this.lblAssignedBy);
            this.Controls.Add(this.lblProjectCode);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblExistingUsers);
            this.Controls.Add(this.lblnewuser);
            this.Controls.Add(this.dgvoldusers);
            this.Controls.Add(this.lblsearch);
            this.Controls.Add(this.txtusername);
            this.Controls.Add(this.lblProductCode);
            this.Controls.Add(this.dgvadduser);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PlanningUsers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PlanningUsers";
            this.Load += new System.EventHandler(this.PlanningUsers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvoldusers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvadduser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblExistingUsers;
        private System.Windows.Forms.Label lblnewuser;
        private System.Windows.Forms.DataGridView dgvoldusers;
        private System.Windows.Forms.DataGridViewTextBoxColumn oUserName;
        private System.Windows.Forms.Label lblsearch;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.Label lblProductCode;
        private System.Windows.Forms.DataGridView dgvadduser;
        private System.Windows.Forms.DataGridViewButtonColumn Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserName;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.Label lblAssignedBy;
    }
}