﻿namespace Erp_Project_With_Buttons.Project_Status_Planing
{
    partial class ProjectStatusPlaning
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProjectStatusPlaning));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tvProduct = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.gbtreesearch = new System.Windows.Forms.GroupBox();
            this.txtsearchtree = new System.Windows.Forms.TextBox();
            this.btnsearchtree = new System.Windows.Forms.Button();
            this.lblProjectStaus = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.txtcustomer = new System.Windows.Forms.Label();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.txtProjectName = new System.Windows.Forms.Label();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.cmbProjectCode = new System.Windows.Forms.ComboBox();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAssignUsers = new System.Windows.Forms.Button();
            this.oDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.lblusername = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.dgItemOrProductList = new System.Windows.Forms.DataGridView();
            this.ProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlAddProjectPlan = new System.Windows.Forms.Panel();
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.txtItemCode = new System.Windows.Forms.TextBox();
            this.lblItemCode = new System.Windows.Forms.Label();
            this.dgBOMList = new System.Windows.Forms.DataGridView();
            this.uItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uBOMQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LatestCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.gbtreesearch.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).BeginInit();
            this.pnlAddProjectPlan.SuspendLayout();
            this.gbSearchOptions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMList)).BeginInit();
            this.SuspendLayout();
            // 
            // tvProduct
            // 
            this.tvProduct.Enabled = false;
            this.tvProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvProduct.Location = new System.Drawing.Point(5, 117);
            this.tvProduct.Name = "tvProduct";
            this.tvProduct.Size = new System.Drawing.Size(373, 220);
            this.tvProduct.StateImageList = this.imageList1;
            this.tvProduct.TabIndex = 63;
            this.tvProduct.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.tvProduct_AfterLabelEdit);
            this.tvProduct.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProduct_NodeMouseDoubleClick);
            this.tvProduct.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tvProduct_KeyUp);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(1, "diagram_v2_17.ico");
            this.imageList1.Images.SetKeyName(2, "Dryicons-Aesthetica-2-Process-accept.ico");
            this.imageList1.Images.SetKeyName(3, "Dryicons-Aesthetica-2-Process-remove.ico");
            this.imageList1.Images.SetKeyName(4, "Rafiqul-Hassan-Blogger-Settings.ico");
            // 
            // gbtreesearch
            // 
            this.gbtreesearch.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbtreesearch.Controls.Add(this.txtsearchtree);
            this.gbtreesearch.Controls.Add(this.btnsearchtree);
            this.gbtreesearch.Enabled = false;
            this.gbtreesearch.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.gbtreesearch.Location = new System.Drawing.Point(5, 67);
            this.gbtreesearch.Name = "gbtreesearch";
            this.gbtreesearch.Size = new System.Drawing.Size(374, 49);
            this.gbtreesearch.TabIndex = 64;
            this.gbtreesearch.TabStop = false;
            this.gbtreesearch.Text = "Search Options";
            // 
            // txtsearchtree
            // 
            this.txtsearchtree.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchtree.Location = new System.Drawing.Point(5, 14);
            this.txtsearchtree.Name = "txtsearchtree";
            this.txtsearchtree.Size = new System.Drawing.Size(311, 26);
            this.txtsearchtree.TabIndex = 133;
            this.txtsearchtree.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtsearchtree_KeyUp);
            // 
            // btnsearchtree
            // 
            this.btnsearchtree.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearchtree.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnsearchtree.Location = new System.Drawing.Point(320, 13);
            this.btnsearchtree.Name = "btnsearchtree";
            this.btnsearchtree.Size = new System.Drawing.Size(51, 29);
            this.btnsearchtree.TabIndex = 132;
            this.btnsearchtree.Text = "Search";
            this.btnsearchtree.UseVisualStyleBackColor = true;
            this.btnsearchtree.Click += new System.EventHandler(this.btnsearchtree_Click);
            // 
            // lblProjectStaus
            // 
            this.lblProjectStaus.AutoSize = true;
            this.lblProjectStaus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectStaus.ForeColor = System.Drawing.Color.Gold;
            this.lblProjectStaus.Location = new System.Drawing.Point(980, 35);
            this.lblProjectStaus.Name = "lblProjectStaus";
            this.lblProjectStaus.Size = new System.Drawing.Size(12, 18);
            this.lblProjectStaus.TabIndex = 82;
            this.lblProjectStaus.Text = ".";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(882, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 18);
            this.label5.TabIndex = 83;
            this.label5.Text = "Project Status :";
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectView.Location = new System.Drawing.Point(321, 2);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 29);
            this.btnProjectView.TabIndex = 81;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            // 
            // txtcustomer
            // 
            this.txtcustomer.AutoSize = true;
            this.txtcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustomer.ForeColor = System.Drawing.Color.Gold;
            this.txtcustomer.Location = new System.Drawing.Point(446, 6);
            this.txtcustomer.Name = "txtcustomer";
            this.txtcustomer.Size = new System.Drawing.Size(12, 18);
            this.txtcustomer.TabIndex = 79;
            this.txtcustomer.Text = ".";
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.Color.White;
            this.lblcustomer.Location = new System.Drawing.Point(374, 6);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(75, 18);
            this.lblcustomer.TabIndex = 80;
            this.lblcustomer.Text = "Customer :";
            // 
            // txtProjectName
            // 
            this.txtProjectName.AutoSize = true;
            this.txtProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectName.ForeColor = System.Drawing.Color.Gold;
            this.txtProjectName.Location = new System.Drawing.Point(97, 36);
            this.txtProjectName.Name = "txtProjectName";
            this.txtProjectName.Size = new System.Drawing.Size(12, 18);
            this.txtProjectName.TabIndex = 77;
            this.txtProjectName.Text = ".";
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.Color.White;
            this.lblProjectName.Location = new System.Drawing.Point(3, 36);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(96, 18);
            this.lblProjectName.TabIndex = 78;
            this.lblProjectName.Text = "Project Name:";
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.DropDownHeight = 130;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectCode.FormattingEnabled = true;
            this.cmbProjectCode.IntegralHeight = false;
            this.cmbProjectCode.Location = new System.Drawing.Point(107, 3);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.Size = new System.Drawing.Size(211, 26);
            this.cmbProjectCode.TabIndex = 76;
            this.cmbProjectCode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectCode_SelectedIndexChanged);
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.White;
            this.lblProjectCode.Location = new System.Drawing.Point(3, 6);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(98, 18);
            this.lblProjectCode.TabIndex = 75;
            this.lblProjectCode.Text = "Project Code*:";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btnAssignUsers);
            this.panel1.Controls.Add(this.oDateTimePicker);
            this.panel1.Controls.Add(this.lblProjectCode);
            this.panel1.Controls.Add(this.lblProjectStaus);
            this.panel1.Controls.Add(this.cmbProjectCode);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.lblProjectName);
            this.panel1.Controls.Add(this.btnProjectView);
            this.panel1.Controls.Add(this.txtProjectName);
            this.panel1.Controls.Add(this.txtcustomer);
            this.panel1.Controls.Add(this.lblcustomer);
            this.panel1.Location = new System.Drawing.Point(5, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1297, 60);
            this.panel1.TabIndex = 84;
            // 
            // btnAssignUsers
            // 
            this.btnAssignUsers.Enabled = false;
            this.btnAssignUsers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssignUsers.Location = new System.Drawing.Point(1157, 22);
            this.btnAssignUsers.Name = "btnAssignUsers";
            this.btnAssignUsers.Size = new System.Drawing.Size(112, 31);
            this.btnAssignUsers.TabIndex = 136;
            this.btnAssignUsers.Text = "Assign Users";
            this.btnAssignUsers.UseVisualStyleBackColor = true;
            this.btnAssignUsers.Visible = false;
            this.btnAssignUsers.Click += new System.EventHandler(this.btnAssignUsers_Click);
            // 
            // oDateTimePicker
            // 
            this.oDateTimePicker.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.oDateTimePicker.Location = new System.Drawing.Point(1040, -3);
            this.oDateTimePicker.Name = "oDateTimePicker";
            this.oDateTimePicker.Size = new System.Drawing.Size(24, 27);
            this.oDateTimePicker.TabIndex = 125;
            this.oDateTimePicker.Visible = false;
            this.oDateTimePicker.CloseUp += new System.EventHandler(this.oDateTimePicker_CloseUp);
            this.oDateTimePicker.TabIndexChanged += new System.EventHandler(this.oDateTimePicker_TabIndexChanged);
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.BackColor = System.Drawing.Color.Gold;
            this.lblusername.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.ForeColor = System.Drawing.Color.Gold;
            this.lblusername.Location = new System.Drawing.Point(12, 27);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(28, 23);
            this.lblusername.TabIndex = 130;
            this.lblusername.Text = "**";
            this.lblusername.Visible = false;
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(824, 15);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(73, 46);
            this.btnSave.TabIndex = 135;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dgItemOrProductList
            // 
            this.dgItemOrProductList.AllowUserToAddRows = false;
            this.dgItemOrProductList.AllowUserToDeleteRows = false;
            this.dgItemOrProductList.AllowUserToResizeRows = false;
            this.dgItemOrProductList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgItemOrProductList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgItemOrProductList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dgItemOrProductList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgItemOrProductList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductCode,
            this.ProductName,
            this.ProductType,
            this.Quantity,
            this.AssignedBy});
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgItemOrProductList.DefaultCellStyle = dataGridViewCellStyle20;
            this.dgItemOrProductList.Location = new System.Drawing.Point(386, 69);
            this.dgItemOrProductList.MultiSelect = false;
            this.dgItemOrProductList.Name = "dgItemOrProductList";
            this.dgItemOrProductList.RowHeadersVisible = false;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgItemOrProductList.RowsDefaultCellStyle = dataGridViewCellStyle21;
            this.dgItemOrProductList.Size = new System.Drawing.Size(914, 270);
            this.dgItemOrProductList.TabIndex = 131;
            this.dgItemOrProductList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemOrProductList_CellClick);
            this.dgItemOrProductList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemOrProductList_CellEndEdit);
            this.dgItemOrProductList.CellLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemOrProductList_CellLeave);
            // 
            // ProductCode
            // 
            this.ProductCode.DataPropertyName = "ProductCode";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProductCode.DefaultCellStyle = dataGridViewCellStyle17;
            this.ProductCode.HeaderText = "Product Code";
            this.ProductCode.Name = "ProductCode";
            this.ProductCode.ReadOnly = true;
            this.ProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductCode.Width = 108;
            // 
            // ProductName
            // 
            this.ProductName.DataPropertyName = "ProductName";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProductName.DefaultCellStyle = dataGridViewCellStyle18;
            this.ProductName.HeaderText = "Product Name";
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductName.Width = 114;
            // 
            // ProductType
            // 
            this.ProductType.DataPropertyName = "ProductType";
            this.ProductType.HeaderText = "Product Type";
            this.ProductType.Name = "ProductType";
            this.ProductType.ReadOnly = true;
            this.ProductType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductType.Width = 107;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle19;
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 75;
            // 
            // AssignedBy
            // 
            this.AssignedBy.DataPropertyName = "AssignedBy";
            this.AssignedBy.HeaderText = "Added By";
            this.AssignedBy.Name = "AssignedBy";
            this.AssignedBy.ReadOnly = true;
            this.AssignedBy.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.AssignedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AssignedBy.Width = 81;
            // 
            // pnlAddProjectPlan
            // 
            this.pnlAddProjectPlan.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlAddProjectPlan.Controls.Add(this.btnSave);
            this.pnlAddProjectPlan.Controls.Add(this.lblusername);
            this.pnlAddProjectPlan.Enabled = false;
            this.pnlAddProjectPlan.Location = new System.Drawing.Point(386, 611);
            this.pnlAddProjectPlan.Name = "pnlAddProjectPlan";
            this.pnlAddProjectPlan.Size = new System.Drawing.Size(919, 68);
            this.pnlAddProjectPlan.TabIndex = 136;
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.txtItemCode);
            this.gbSearchOptions.Controls.Add(this.lblItemCode);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(5, 342);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(373, 68);
            this.gbSearchOptions.TabIndex = 138;
            this.gbSearchOptions.TabStop = false;
            // 
            // txtItemCode
            // 
            this.txtItemCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemCode.Location = new System.Drawing.Point(96, 15);
            this.txtItemCode.Multiline = true;
            this.txtItemCode.Name = "txtItemCode";
            this.txtItemCode.Size = new System.Drawing.Size(271, 47);
            this.txtItemCode.TabIndex = 1;
            this.txtItemCode.Enter += new System.EventHandler(this.txtItemCode_Enter);
            this.txtItemCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemCode_KeyUp);
            // 
            // lblItemCode
            // 
            this.lblItemCode.AutoSize = true;
            this.lblItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemCode.Location = new System.Drawing.Point(2, 21);
            this.lblItemCode.Name = "lblItemCode";
            this.lblItemCode.Size = new System.Drawing.Size(98, 19);
            this.lblItemCode.TabIndex = 0;
            this.lblItemCode.Text = "Search Item :";
            // 
            // dgBOMList
            // 
            this.dgBOMList.AllowUserToAddRows = false;
            this.dgBOMList.AllowUserToDeleteRows = false;
            this.dgBOMList.AllowUserToResizeRows = false;
            this.dgBOMList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgBOMList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgBOMList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgBOMList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dgBOMList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgBOMList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.uItemCode,
            this.uItemDescription,
            this.uBOMQty,
            this.UnitPrice,
            this.LatestCost,
            this.BOMAmount});
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgBOMList.DefaultCellStyle = dataGridViewCellStyle29;
            this.dgBOMList.Location = new System.Drawing.Point(386, 357);
            this.dgBOMList.MultiSelect = false;
            this.dgBOMList.Name = "dgBOMList";
            this.dgBOMList.RowHeadersVisible = false;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgBOMList.RowsDefaultCellStyle = dataGridViewCellStyle30;
            this.dgBOMList.Size = new System.Drawing.Size(919, 248);
            this.dgBOMList.TabIndex = 139;
            // 
            // uItemCode
            // 
            this.uItemCode.DataPropertyName = "ItemName";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.uItemCode.DefaultCellStyle = dataGridViewCellStyle23;
            this.uItemCode.HeaderText = "Item Code";
            this.uItemCode.Name = "uItemCode";
            this.uItemCode.ReadOnly = true;
            this.uItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uItemCode.Width = 76;
            // 
            // uItemDescription
            // 
            this.uItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.uItemDescription.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.uItemDescription.DefaultCellStyle = dataGridViewCellStyle24;
            this.uItemDescription.HeaderText = "Item Description";
            this.uItemDescription.Name = "uItemDescription";
            this.uItemDescription.ReadOnly = true;
            this.uItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uItemDescription.Width = 125;
            // 
            // uBOMQty
            // 
            this.uBOMQty.DataPropertyName = "Quantity";
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.uBOMQty.DefaultCellStyle = dataGridViewCellStyle25;
            this.uBOMQty.HeaderText = "BOM Qty";
            this.uBOMQty.Name = "uBOMQty";
            this.uBOMQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uBOMQty.Width = 70;
            // 
            // UnitPrice
            // 
            this.UnitPrice.DataPropertyName = "UnitCost";
            dataGridViewCellStyle26.Format = "N2";
            dataGridViewCellStyle26.NullValue = null;
            this.UnitPrice.DefaultCellStyle = dataGridViewCellStyle26;
            this.UnitPrice.HeaderText = "Unit Cost";
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.ReadOnly = true;
            this.UnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitPrice.Width = 69;
            // 
            // LatestCost
            // 
            this.LatestCost.DataPropertyName = "LatestCost";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.Format = "N2";
            dataGridViewCellStyle27.NullValue = null;
            this.LatestCost.DefaultCellStyle = dataGridViewCellStyle27;
            this.LatestCost.HeaderText = "Latest Cost";
            this.LatestCost.Name = "LatestCost";
            this.LatestCost.ReadOnly = true;
            this.LatestCost.Width = 99;
            // 
            // BOMAmount
            // 
            this.BOMAmount.DataPropertyName = "BOMAmount";
            dataGridViewCellStyle28.Format = "N2";
            dataGridViewCellStyle28.NullValue = null;
            this.BOMAmount.DefaultCellStyle = dataGridViewCellStyle28;
            this.BOMAmount.HeaderText = "Amount";
            this.BOMAmount.Name = "BOMAmount";
            this.BOMAmount.ReadOnly = true;
            this.BOMAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMAmount.Width = 71;
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(5, 418);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(375, 256);
            this.chklbItemList.TabIndex = 140;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ProjectStatusPlaning
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(1308, 686);
            this.Controls.Add(this.chklbItemList);
            this.Controls.Add(this.dgBOMList);
            this.Controls.Add(this.gbSearchOptions);
            this.Controls.Add(this.pnlAddProjectPlan);
            this.Controls.Add(this.dgItemOrProductList);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gbtreesearch);
            this.Controls.Add(this.tvProduct);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ProjectStatusPlaning";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BIM v1.0008";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ProjectStatusPlaning_FormClosing);
            this.Load += new System.EventHandler(this.ProjectStatusPlaning_Load);
            this.gbtreesearch.ResumeLayout(false);
            this.gbtreesearch.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).EndInit();
            this.pnlAddProjectPlan.ResumeLayout(false);
            this.pnlAddProjectPlan.PerformLayout();
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView tvProduct;
        private System.Windows.Forms.GroupBox gbtreesearch;
        private System.Windows.Forms.TextBox txtsearchtree;
        private System.Windows.Forms.Button btnsearchtree;
        private System.Windows.Forms.Label lblProjectStaus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.Label txtcustomer;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.Label txtProjectName;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.ComboBox cmbProjectCode;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.DateTimePicker oDateTimePicker;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.Button btnAssignUsers;
        private System.Windows.Forms.DataGridView dgItemOrProductList;
        private System.Windows.Forms.Panel pnlAddProjectPlan;
        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.TextBox txtItemCode;
        private System.Windows.Forms.Label lblItemCode;
        private System.Windows.Forms.DataGridView dgBOMList;
        private System.Windows.Forms.DataGridViewTextBoxColumn uItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn uItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn uBOMQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn LatestCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMAmount;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssignedBy;
        private System.Windows.Forms.Timer timer1;
    }
}