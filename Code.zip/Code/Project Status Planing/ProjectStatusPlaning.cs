﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Status_Planing
{
    public partial class ProjectStatusPlaning : Form
    {
        public ProjectStatusPlaning()
        {
            InitializeComponent();
        }

        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        frmForm2 form = new frmForm2();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtWIPProjectlist = new DataTable();
        DataTable dtTreeFromTable = new DataTable();
        TreeNode tnCurrentParentNode = new TreeNode();
        DataTable dtProjectList = new DataTable();
        DataView dvProjectName = new DataView();
        private List<TreeNode> CurrentNodeMatches = new List<TreeNode>();
        private int LastNodeIndex = 0;
        private string LastSearchText;
        PlanningUsers AddUsers = new PlanningUsers();

        private void ProjectStatusPlaning_Load(object sender, EventArgs e)
        {
          ///  dtpActualStart.CustomFormat = "dd-MM-yyyy";
          //  dtpActualEnd.CustomFormat = "dd-MM-yyyy";
          
            dtDGDatatable = DAL.fnProjectStatusPlanning("").Tables[0];
            timer1.Start();
            lblusername.Text = "Welcome : " + Login.frmLoginForm.sUserDetails[2];

            //dgItemOrProductList.Columns[0].Width = 150;
            //dgItemOrProductList.Columns[1].Width = 150;
            //dgItemOrProductList.Columns[2].Width = 150;
            //dgItemOrProductList.Columns[3].Width = 250;
            //dgItemOrProductList.Columns[4].Width = 150;
          //  dgItemOrProductList.Columns[5].Width = 150;
        ////    dgItemOrProductList.Columns[6].Width = 150;
         //   dgItemOrProductList.Columns[7].Width = 535;


            //if (Convert.ToBoolean(login.GetUserDetails[13]))
            //{
            ////    dgItemOrProductList.Columns[3].ReadOnly = false;
            //  //  dgItemOrProductList.Columns[4].ReadOnly = false;
            ////    dgItemOrProductList.Columns[5].ReadOnly = false;
            ////    dgItemOrProductList.Columns[7].ReadOnly = false;
            // //   btnAssignUsers.Enabled = true;
            ////    gbtreesearch.Enabled = true;
            //  //  tvProduct.Enabled = true;
            //}
            //else
            //{
                dgItemOrProductList.Columns[3].ReadOnly = true;
                dgItemOrProductList.Columns[4].ReadOnly = true;
            //    dgItemOrProductList.Columns[5].ReadOnly = true;
         //       dgItemOrProductList.Columns[7].ReadOnly = true;
                btnAssignUsers.Enabled = false;
                gbtreesearch.Enabled = false;
                tvProduct.Enabled = false;
           // }

            dtWIPProjectlist = DAL.fnWIPProjectList(null).Tables[0];
            if (dtWIPProjectlist.Rows.Count > 0)
            {
                foreach (DataRow DR in dtWIPProjectlist.Rows)
                {
                    if (!cmbProjectCode.Items.Contains(DR["ProjectCode"].ToString()))
                        cmbProjectCode.Items.Add(DR["ProjectCode"].ToString());
                }

                dtTreeFromTable = DAL.fnGetProductTreeView().Tables["ProductTreeView"]; //get the tree folders and sub-folders from database
                if (dtTreeFromTable.Rows.Count > 0)
                {
                    tvProduct.Nodes.AddRange(GLobalClass.fnTreeFromTable(dtTreeFromTable, "ParentID", "NodeID", "Name", "ImageIndex")); // display the folders in the treeview
                    tnCurrentParentNode = null;
                    tvProduct.CollapseAll();
                    tvProduct.Sort();
                }
            }
            dtProjectList = DAL.fnProjectList(null).Tables[0];
            dtItemList = DAL.fnBOMItemList(null).Tables[0];
        }
        DataTable dtProjectStatusPlanning = new DataTable();
        DataTable dtProjectSearch = new DataTable();
        DataTable dtTableFilter = new DataTable();
        DataTable dtItemList = new DataTable();
    
        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtProjectStatusPlanning = DAL.fnProjectStatusPlanning(cmbProjectCode.Text).Tables[0];
            gbtreesearch.Enabled = true;
            tvProduct.Enabled = true;
            if (dtProjectStatusPlanning.Rows.Count > 0)
            {
                dgItemOrProductList.AutoGenerateColumns = false;
                dgItemOrProductList.DataSource = dtProjectStatusPlanning;
                btnAssignUsers.Enabled = true;
            }
            else
            {
                dgItemOrProductList.DataSource = null;
                btnAssignUsers.Enabled = false;
            }

            dtProjectSearch = DAL.fnProjectList(cmbProjectCode.Text).Tables[0];

            if (dtProjectSearch.Rows.Count > 0)
            {
                txtProjectName.Text = dtProjectSearch.Rows[0]["ProjectDescription"].ToString();
                txtcustomer.Text = dtProjectSearch.Rows[0]["Customer"].ToString();
                lblProjectStaus.Text = dtProjectSearch.Rows[0]["Status"].ToString();
            }
            else
            {
                txtProjectName.ResetText();
                txtcustomer.ResetText();
                lblProjectStaus.ResetText();
            }

            tvProduct.Enabled = true;
            tvProduct.CollapseAll();
        }



        private void SearchNodes(string SearchText, TreeNode StartNode)
        {
            while (StartNode != null)
            {
                if (StartNode.Text.ToLower().Contains(SearchText.ToLower()))
                {
                    CurrentNodeMatches.Add(StartNode);
                };
                if (StartNode.Nodes.Count != 0)
                {
                    SearchNodes(SearchText, StartNode.Nodes[0]);//Recursive Search 
                };
                StartNode = StartNode.NextNode;
            };

        }

        private void btnsearchtree_Click(object sender, EventArgs e)
        {
            string searchText = this.txtsearchtree.Text;
            if (String.IsNullOrEmpty(searchText))
            {
                return;
            };

            if (LastSearchText != searchText)
            {
                //It's a new Search
                CurrentNodeMatches.Clear();
                LastSearchText = searchText;
                LastNodeIndex = 0;
                SearchNodes(searchText, tvProduct.Nodes[0]);
            }

            if (LastNodeIndex >= 0 && CurrentNodeMatches.Count > 0 && LastNodeIndex < CurrentNodeMatches.Count)
            {
                TreeNode selectedNode = CurrentNodeMatches[LastNodeIndex];
                LastNodeIndex++;
                this.tvProduct.SelectedNode = selectedNode;
                this.tvProduct.SelectedNode.Expand();
                this.tvProduct.Select();
            }
        }

        private void cleartreeview_Click(object sender, EventArgs e)
        {
        }

        private void txtsearchtree_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnsearchtree_Click(sender, e);
            }
        }

        private void tvProduct_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            tvProduct.LabelEdit = false;
        }

        private void tvProduct_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnsearchtree_Click(sender, e);
            }
        }

        string sNName = string.Empty;
        DataTable dtParentName = new DataTable();
        DataTable dtProductCode = new DataTable();
        DataTable dtParentid = new DataTable();
        DataTable dtCompleteBOM = new DataTable();
        DataTable dtDGDatatable = new DataTable();
        DataRow DR;
        string[] sNamee;
        string sParentName;
        private void tvProduct_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            sNName = e.Node.Name;
            tvProduct.SelectedNode = e.Node;
            tvProduct.LabelEdit = false;
            bool bItemCheck = false;
            string Productcode;

            if (e.Node.Parent != null && e.Node != null && e.Node.Name != "All Product" && (e.Node.StateImageIndex == 2 || e.Node.StateImageIndex == 4 || e.Node.StateImageIndex == 3))
            {
                dtParentName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                if (dtParentName.Rows.Count > 0)
                {
                    dtProductCode = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtParentName.Rows[0]["NodeID"].ToString()).Tables[0];
                    if (dtProductCode.Rows.Count > 0)
                    {
                        Productcode = dtProductCode.Rows[0]["ProductCode"].ToString();
                        foreach (DataGridViewRow dr in dgItemOrProductList.Rows)
                        {
                            if (dr.Cells["ProductCode"].Value.ToString() == Productcode)
                            {
                                MessageBox.Show("Selected Product already present in the BOM item list", "Warning", 0, MessageBoxIcon.Warning);
                                bItemCheck = true;
                                break;
                            }
                        }
                    }
                }

                if (!bItemCheck)
                {
                     sNName = e.Node.Name;
                    // string sNamee = e.Node.FullPath;
                    sParentName = "";
                    sNamee = e.Node.FullPath.ToString().Split('\\');
                    int i = 0;
                    for (i = 1; i < sNamee.Length - 1; i++)
                    {
                        if (i == 1)
                        {
                            sParentName = sNamee[i];
                        }
                        else
                        {
                            sParentName = sParentName + " / " + sNamee[i];
                        }
                    }

                    dtParentid = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                    dtParentid = DAL.fnGetTreeNode(sNName, dtParentid.Rows[0]["NodeID"].ToString()).Tables[0];

                    if (dtParentid.Rows.Count > 0)
                    {
                        DR = dtProjectStatusPlanning.NewRow();
                        DR["ProductCode"] = dtParentid.Rows[0]["ProductCode"].ToString();
                        DR["ProductName"] = dtParentid.Rows[0]["Name"].ToString();
                        DR["ProductType"] = sParentName;
                        DR["Quantity"] = 1;
                     //   DR["StartDate"] = DateTime.Now.ToShortDateString();
                      //DR["EndDate"] = DateTime.Now.ToShortDateString();
                      //  string sUserName = Login.frmLoginForm.sUserDetails[2];
                     //   sUserName = System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(sUserName.ToLower());
                        DR["AssignedBy"] = System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Login.frmLoginForm.sUserDetails[2].ToLower());
                       // DR["Remarks"] = "";

                        dtProjectStatusPlanning.Rows.Add(DR);
                        dgItemOrProductList.AutoGenerateColumns = false;
                        dgItemOrProductList.DataSource = dtProjectStatusPlanning;

                   //     GLobalClass.iSuccess = DAL.fnAddProjectStatusPlanning(Global.uINSERT, cmbProjectCode.Text, dtParentid.Rows[0]["ProductCode"].ToString(), dtParentid.Rows[0]["Name"].ToString(),
                       //                                                         tvProduct.SelectedNode.Parent.Name, 1, DateTime.Now.ToShortDateString(), DateTime.Now.ToShortDateString(), Login.frmLoginForm.sUserDetails[2],"");

                    }
                }
            }
        }

        private void ProjectStatusPlaning_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (GLobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                this.Hide();
                form.Show();
            }
            else
                e.Cancel = true;
        }
        DataTable dtOldUserNames = new DataTable();
        private void dgItemOrProductList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (e.ColumnIndex == 4|| e.ColumnIndex == 5)
            //{
            //    if (Convert.ToBoolean(login.GetUserDetails[13]))
            //    {
            //        oDateTimePicker.Visible = false;
            //        oDateTimePicker = new DateTimePicker();
            //        dgItemOrProductList.Controls.Add(oDateTimePicker);
            //        oDateTimePicker.Format = DateTimePickerFormat.Custom;
            //        oDateTimePicker.CustomFormat = "dd-MM-yyyy";
            //        Rectangle oRectangle = dgItemOrProductList.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true);
            //        oDateTimePicker.Size = new Size(oRectangle.Width, oRectangle.Height);
            //        oDateTimePicker.Location = new Point(oRectangle.X, oRectangle.Y);
            //        oDateTimePicker.CloseUp += new EventHandler(oDateTimePicker_CloseUp);
            //        oDateTimePicker.TextChanged += new EventHandler(oDateTimePicker_TabIndexChanged);
            //        oDateTimePicker.Visible = true;
            //    }
            //}
            //else
            //{
            //    oDateTimePicker.Visible = false;
            //}

            if (e.ColumnIndex == 0 || e.ColumnIndex == 1 || e.ColumnIndex == 2)
            {
                dtProjectStatusPlanningHistory = DAL.fnProjectStatusPlanningHistory(cmbProjectCode.Text, dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString()).Tables[0];
                if (dtProjectStatusPlanningHistory.Rows.Count > 0)
                {
                  //  dgvPlanHistory.AutoGenerateColumns = false;
                 //   dgvPlanHistory.DataSource = dtProjectStatusPlanningHistory;

                    dtOldUserNames = DAL.fnProjectPlanningUser(null,Login.frmLoginForm.sUserDetails[2]).Tables[0];
                    if (dtOldUserNames.Rows.Count > 0)
                    {
                        pnlAddProjectPlan.Enabled = true;
                        btnAssignUsers.Enabled = true;
                    }
                    else
                    {
                        pnlAddProjectPlan.Enabled = false;
                        btnAssignUsers.Enabled = false;
                    }
                }
                else
                {
                 //   dgvPlanHistory.DataSource = null;
                    pnlAddProjectPlan.Enabled = false;
                }
            }
        }

        DataTable dtProjectStatusPlanningHistory = new DataTable();
        private void oDateTimePicker_CloseUp(object sender, EventArgs e)
        {
            oDateTimePicker.Visible = false;
        }

        private void oDateTimePicker_TabIndexChanged(object sender, EventArgs e)
        {
            dgItemOrProductList.CurrentCell.Value = oDateTimePicker.Text.ToString();
        }

      //  private int xPos = 8;
        private void timer1_Tick(object sender, EventArgs e)
        {
           // lblusername.BackColor = Color.Gold;
            //if (xPos > 1250)
            //{
            //    xPos = 8;
            //}
            //if (this.Width == xPos)
            //{
            //    //repeat marquee
            //    lblusername.Location = new System.Drawing.Point(8, 35);
               
            //    xPos = 8;
            //}
            //else
            //{
            //    lblusername.Location = new System.Drawing.Point(xPos, 35);
            //    xPos++; xPos++; xPos++; xPos++;
            //}
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
        

        }

        private void dgItemOrProductList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void dgItemOrProductList_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void btnAssignUsers_Click(object sender, EventArgs e)
        {
            //AddUsers.fnProductCode(dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString());
            //AddUsers.fnProjectCode(cmbProjectCode.Text);
            //AddUsers.fnAssignedBy(dgItemOrProductList.CurrentRow.Cells["AssignedBy"].Value.ToString());
            //AddUsers.ShowDialog();
        }
         DataView dvfilterItemList = new DataView();
        private void txtItemCode_Enter(object sender, EventArgs e)
        {
            RowFilter(txtItemCode.Text);
        }

        #region Row Filter Function
        private void RowFilter(string rowfilter)
        {
            chklbItemList.Items.Clear();
            dvfilterItemList = new DataView(dtItemList);

             if (txtItemCode.Text.Length > 5)
                    {
                        dvfilterItemList.RowFilter = "ItemCode like '%" + rowfilter + "%' or ItemDescription like '%" + rowfilter + "%'";
                        foreach (DataRowView dv in dvfilterItemList)
                        {
                            chklbItemList.Items.Add(string.Concat(dv[17].ToString(), ") ", dv[0].ToString(),", ", dv[12].ToString(), ", ", dv[1].ToString()));
                        }
                    }
        
        }
        #endregion

        private void txtItemCode_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
                RowFilter(txtItemCode.Text);
            else
                RowFilter(txtItemCode.Text);
        }
    }
}
