﻿namespace Erp_Project_With_Buttons.Customer_Master
{
    partial class CustomerMasterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerMasterForm));
            this.pnMain = new System.Windows.Forms.Panel();
            this.txtState = new System.Windows.Forms.TextBox();
            this.txtDistict = new System.Windows.Forms.ComboBox();
            this.cmbApproveCustomer = new System.Windows.Forms.ComboBox();
            this.lblProjecttype = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnIMExit = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblReturnedby = new System.Windows.Forms.Label();
            this.llQuit = new System.Windows.Forms.LinkLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.cmbCustomerCode = new System.Windows.Forms.ComboBox();
            this.txtcinno = new System.Windows.Forms.TextBox();
            this.chkActive = new System.Windows.Forms.CheckBox();
            this.txtPINCode = new System.Windows.Forms.TextBox();
            this.lblcinno = new System.Windows.Forms.Label();
            this.txtCountry = new System.Windows.Forms.TextBox();
            this.lblCustomerType = new System.Windows.Forms.Label();
            this.txtpanno = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtserviceno = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtTIN = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.lblpanno = new System.Windows.Forms.Label();
            this.txtContactPerson = new System.Windows.Forms.TextBox();
            this.lblCompanyURL = new System.Windows.Forms.Label();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.txtGST = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtCompanyURL = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblservceno = new System.Windows.Forms.Label();
            this.txtFaxNo = new System.Windows.Forms.TextBox();
            this.lblCSTNo = new System.Windows.Forms.Label();
            this.txtMoblieNo = new System.Windows.Forms.TextBox();
            this.lbltanno = new System.Windows.Forms.Label();
            this.txtPhoneNo = new System.Windows.Forms.TextBox();
            this.txtCSTNo = new System.Windows.Forms.TextBox();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txteccnumber = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lbltLocalTaxNo = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbleccnumber = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtVatNo = new System.Windows.Forms.TextBox();
            this.lblContactPerson = new System.Windows.Forms.Label();
            this.lblOthers = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbCustomerType = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtOthers = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dtpCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pnMain.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnMain
            // 
            this.pnMain.BackColor = System.Drawing.Color.Silver;
            this.pnMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnMain.Controls.Add(this.txtState);
            this.pnMain.Controls.Add(this.txtDistict);
            this.pnMain.Controls.Add(this.cmbApproveCustomer);
            this.pnMain.Controls.Add(this.lblProjecttype);
            this.pnMain.Controls.Add(this.label1);
            this.pnMain.Controls.Add(this.btnIMExit);
            this.pnMain.Controls.Add(this.lblWelcome);
            this.pnMain.Controls.Add(this.lblReturnedby);
            this.pnMain.Controls.Add(this.llQuit);
            this.pnMain.Controls.Add(this.groupBox2);
            this.pnMain.Controls.Add(this.cmbCustomerCode);
            this.pnMain.Controls.Add(this.txtcinno);
            this.pnMain.Controls.Add(this.chkActive);
            this.pnMain.Controls.Add(this.txtPINCode);
            this.pnMain.Controls.Add(this.lblcinno);
            this.pnMain.Controls.Add(this.txtCountry);
            this.pnMain.Controls.Add(this.lblCustomerType);
            this.pnMain.Controls.Add(this.txtpanno);
            this.pnMain.Controls.Add(this.label19);
            this.pnMain.Controls.Add(this.label21);
            this.pnMain.Controls.Add(this.label20);
            this.pnMain.Controls.Add(this.txtserviceno);
            this.pnMain.Controls.Add(this.label22);
            this.pnMain.Controls.Add(this.txtTIN);
            this.pnMain.Controls.Add(this.label23);
            this.pnMain.Controls.Add(this.lblpanno);
            this.pnMain.Controls.Add(this.txtContactPerson);
            this.pnMain.Controls.Add(this.lblCompanyURL);
            this.pnMain.Controls.Add(this.txtAddress1);
            this.pnMain.Controls.Add(this.txtGST);
            this.pnMain.Controls.Add(this.txtAddress2);
            this.pnMain.Controls.Add(this.txtCompanyURL);
            this.pnMain.Controls.Add(this.txtEmail);
            this.pnMain.Controls.Add(this.lblservceno);
            this.pnMain.Controls.Add(this.txtFaxNo);
            this.pnMain.Controls.Add(this.lblCSTNo);
            this.pnMain.Controls.Add(this.txtMoblieNo);
            this.pnMain.Controls.Add(this.lbltanno);
            this.pnMain.Controls.Add(this.txtPhoneNo);
            this.pnMain.Controls.Add(this.txtCSTNo);
            this.pnMain.Controls.Add(this.txtCustomerName);
            this.pnMain.Controls.Add(this.txteccnumber);
            this.pnMain.Controls.Add(this.label15);
            this.pnMain.Controls.Add(this.lbltLocalTaxNo);
            this.pnMain.Controls.Add(this.label16);
            this.pnMain.Controls.Add(this.lbleccnumber);
            this.pnMain.Controls.Add(this.label17);
            this.pnMain.Controls.Add(this.txtVatNo);
            this.pnMain.Controls.Add(this.lblContactPerson);
            this.pnMain.Controls.Add(this.lblOthers);
            this.pnMain.Controls.Add(this.label13);
            this.pnMain.Controls.Add(this.cmbCustomerType);
            this.pnMain.Controls.Add(this.label12);
            this.pnMain.Controls.Add(this.txtOthers);
            this.pnMain.Controls.Add(this.label11);
            this.pnMain.Controls.Add(this.dtpCreatedDate);
            this.pnMain.Controls.Add(this.lblCustomerName);
            this.pnMain.Location = new System.Drawing.Point(9, 7);
            this.pnMain.Name = "pnMain";
            this.pnMain.Size = new System.Drawing.Size(1294, 674);
            this.pnMain.TabIndex = 15;
            // 
            // txtState
            // 
            this.txtState.Enabled = false;
            this.txtState.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtState.Location = new System.Drawing.Point(220, 420);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(336, 26);
            this.txtState.TabIndex = 104;
            // 
            // txtDistict
            // 
            this.txtDistict.DropDownHeight = 130;
           // this.txtDistict.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtDistict.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDistict.FormattingEnabled = true;
            this.txtDistict.IntegralHeight = false;
            this.txtDistict.Location = new System.Drawing.Point(218, 382);
            this.txtDistict.Name = "txtDistict";
            this.txtDistict.Size = new System.Drawing.Size(338, 27);
            this.txtDistict.TabIndex = 103;
            this.txtDistict.SelectedIndexChanged += new System.EventHandler(this.txtDistict_SelectedIndexChanged);
            // 
            // cmbApproveCustomer
            // 
            this.cmbApproveCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbApproveCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbApproveCustomer.DropDownHeight = 90;
            this.cmbApproveCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbApproveCustomer.DropDownWidth = 400;
            this.cmbApproveCustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbApproveCustomer.FormattingEnabled = true;
            this.cmbApproveCustomer.IntegralHeight = false;
            this.cmbApproveCustomer.Location = new System.Drawing.Point(218, 45);
            this.cmbApproveCustomer.Name = "cmbApproveCustomer";
            this.cmbApproveCustomer.Size = new System.Drawing.Size(453, 26);
            this.cmbApproveCustomer.TabIndex = 101;
            this.cmbApproveCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbApproveCustomer_SelectedIndexChanged);
            // 
            // lblProjecttype
            // 
            this.lblProjecttype.AutoSize = true;
            this.lblProjecttype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjecttype.ForeColor = System.Drawing.Color.Black;
            this.lblProjecttype.Location = new System.Drawing.Point(69, 47);
            this.lblProjecttype.Name = "lblProjecttype";
            this.lblProjecttype.Size = new System.Drawing.Size(145, 19);
            this.lblProjecttype.TabIndex = 102;
            this.lblProjecttype.Text = "Approve Customer :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(668, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 33);
            this.label1.TabIndex = 12;
            this.label1.Text = "Customer Master";
            // 
            // btnIMExit
            // 
            this.btnIMExit.FlatAppearance.BorderSize = 0;
            this.btnIMExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIMExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIMExit.Image = global::Erp_Project_With_Buttons.Properties.Resources.glossy_3d_blue_delete_icon__1_;
            this.btnIMExit.Location = new System.Drawing.Point(16, 591);
            this.btnIMExit.Name = "btnIMExit";
            this.btnIMExit.Size = new System.Drawing.Size(55, 57);
            this.btnIMExit.TabIndex = 75;
            this.btnIMExit.UseVisualStyleBackColor = true;
            this.btnIMExit.Click += new System.EventHandler(this.btnIMExit_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Black;
            this.lblWelcome.Location = new System.Drawing.Point(12, 3);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(98, 24);
            this.lblWelcome.TabIndex = 22;
            this.lblWelcome.Text = "Welcome :";
            // 
            // lblReturnedby
            // 
            this.lblReturnedby.AutoSize = true;
            this.lblReturnedby.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturnedby.ForeColor = System.Drawing.Color.Black;
            this.lblReturnedby.Location = new System.Drawing.Point(109, 4);
            this.lblReturnedby.Name = "lblReturnedby";
            this.lblReturnedby.Size = new System.Drawing.Size(0, 24);
            this.lblReturnedby.TabIndex = 21;
            // 
            // llQuit
            // 
            this.llQuit.AutoSize = true;
            this.llQuit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llQuit.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llQuit.LinkColor = System.Drawing.Color.Red;
            this.llQuit.Location = new System.Drawing.Point(77, 613);
            this.llQuit.Name = "llQuit";
            this.llQuit.Size = new System.Drawing.Size(45, 23);
            this.llQuit.TabIndex = 76;
            this.llQuit.TabStop = true;
            this.llQuit.Text = "Quit";
            this.llQuit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llQuit_LinkClicked);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnDelete);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnSearch);
            this.groupBox2.Controls.Add(this.btnClearAll);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(195, 587);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1073, 76);
            this.groupBox2.TabIndex = 71;
            this.groupBox2.TabStop = false;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDelete.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(674, 21);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(102, 45);
            this.btnDelete.TabIndex = 11;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(869, 21);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(102, 45);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(85, 21);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(102, 45);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSearch.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(298, 21);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(102, 45);
            this.btnSearch.TabIndex = 8;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearAll.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearAll.Location = new System.Drawing.Point(479, 21);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(102, 45);
            this.btnClearAll.TabIndex = 7;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = false;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click_1);
            // 
            // cmbCustomerCode
            // 
            this.cmbCustomerCode.DropDownHeight = 100;
            this.cmbCustomerCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomerCode.FormattingEnabled = true;
            this.cmbCustomerCode.IntegralHeight = false;
            this.cmbCustomerCode.ItemHeight = 19;
            this.cmbCustomerCode.Location = new System.Drawing.Point(219, 86);
            this.cmbCustomerCode.Name = "cmbCustomerCode";
            this.cmbCustomerCode.Size = new System.Drawing.Size(340, 27);
            this.cmbCustomerCode.TabIndex = 12;
            this.cmbCustomerCode.SelectedIndexChanged += new System.EventHandler(this.cmbCustomerCode_SelectedIndexChanged);
            // 
            // txtcinno
            // 
            this.txtcinno.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcinno.Location = new System.Drawing.Point(873, 369);
            this.txtcinno.MaxLength = 21;
            this.txtcinno.Name = "txtcinno";
            this.txtcinno.Size = new System.Drawing.Size(310, 27);
            this.txtcinno.TabIndex = 100;
           
            // 
            // chkActive
            // 
            this.chkActive.AutoSize = true;
            this.chkActive.Checked = true;
            this.chkActive.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkActive.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkActive.ForeColor = System.Drawing.Color.Black;
            this.chkActive.Location = new System.Drawing.Point(1125, 558);
            this.chkActive.Name = "chkActive";
            this.chkActive.Size = new System.Drawing.Size(70, 23);
            this.chkActive.TabIndex = 72;
            this.chkActive.Text = "Active";
            this.chkActive.UseVisualStyleBackColor = true;
            // 
            // txtPINCode
            // 
            this.txtPINCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPINCode.Location = new System.Drawing.Point(220, 493);
            this.txtPINCode.Name = "txtPINCode";
            this.txtPINCode.Size = new System.Drawing.Size(339, 27);
            this.txtPINCode.TabIndex = 65;
            // 
            // lblcinno
            // 
            this.lblcinno.AutoSize = true;
            this.lblcinno.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcinno.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcinno.Location = new System.Drawing.Point(827, 372);
            this.lblcinno.Name = "lblcinno";
            this.lblcinno.Size = new System.Drawing.Size(40, 19);
            this.lblcinno.TabIndex = 99;
            this.lblcinno.Text = "CIN :";
            // 
            // txtCountry
            // 
            this.txtCountry.Enabled = false;
            this.txtCountry.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCountry.Location = new System.Drawing.Point(220, 456);
            this.txtCountry.Name = "txtCountry";
            this.txtCountry.Size = new System.Drawing.Size(339, 27);
            this.txtCountry.TabIndex = 64;
            // 
            // lblCustomerType
            // 
            this.lblCustomerType.AutoSize = true;
            this.lblCustomerType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerType.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCustomerType.Location = new System.Drawing.Point(744, 87);
            this.lblCustomerType.Name = "lblCustomerType";
            this.lblCustomerType.Size = new System.Drawing.Size(123, 19);
            this.lblCustomerType.TabIndex = 79;
            this.lblCustomerType.Text = "Customer Type*:";
            // 
            // txtpanno
            // 
            this.txtpanno.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpanno.Location = new System.Drawing.Point(873, 410);
            this.txtpanno.Name = "txtpanno";
            this.txtpanno.Size = new System.Drawing.Size(310, 27);
            this.txtpanno.TabIndex = 96;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label19.Location = new System.Drawing.Point(146, 458);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 19);
            this.label19.TabIndex = 62;
            this.label19.Text = "Country:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label21.Location = new System.Drawing.Point(825, 168);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(40, 19);
            this.label21.TabIndex = 60;
            this.label21.Text = "TIN :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label20.Location = new System.Drawing.Point(139, 496);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 19);
            this.label20.TabIndex = 61;
            this.label20.Text = "PIN Code:";
            // 
            // txtserviceno
            // 
            this.txtserviceno.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtserviceno.Location = new System.Drawing.Point(873, 328);
            this.txtserviceno.Name = "txtserviceno";
            this.txtserviceno.Size = new System.Drawing.Size(310, 27);
            this.txtserviceno.TabIndex = 98;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label22.Location = new System.Drawing.Point(152, 385);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(62, 19);
            this.label22.TabIndex = 59;
            this.label22.Text = "District:";
            // 
            // txtTIN
            // 
            this.txtTIN.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTIN.Location = new System.Drawing.Point(873, 165);
            this.txtTIN.Name = "txtTIN";
            this.txtTIN.Size = new System.Drawing.Size(310, 27);
            this.txtTIN.TabIndex = 66;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label23.Location = new System.Drawing.Point(165, 422);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(49, 19);
            this.label23.TabIndex = 58;
            this.label23.Text = "State:";
            // 
            // lblpanno
            // 
            this.lblpanno.AutoSize = true;
            this.lblpanno.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpanno.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblpanno.Location = new System.Drawing.Point(819, 413);
            this.lblpanno.Name = "lblpanno";
            this.lblpanno.Size = new System.Drawing.Size(46, 19);
            this.lblpanno.TabIndex = 93;
            this.lblpanno.Text = "PAN :";
            // 
            // txtContactPerson
            // 
            this.txtContactPerson.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactPerson.Location = new System.Drawing.Point(220, 345);
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Size = new System.Drawing.Size(338, 27);
            this.txtContactPerson.TabIndex = 56;
            // 
            // lblCompanyURL
            // 
            this.lblCompanyURL.AutoSize = true;
            this.lblCompanyURL.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompanyURL.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCompanyURL.Location = new System.Drawing.Point(754, 496);
            this.lblCompanyURL.Name = "lblCompanyURL";
            this.lblCompanyURL.Size = new System.Drawing.Size(111, 19);
            this.lblCompanyURL.TabIndex = 73;
            this.lblCompanyURL.Text = "Company URL :";
            // 
            // txtAddress1
            // 
            this.txtAddress1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress1.Location = new System.Drawing.Point(219, 123);
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(340, 27);
            this.txtAddress1.TabIndex = 55;
            // 
            // txtGST
            // 
            this.txtGST.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGST.Location = new System.Drawing.Point(873, 123);
            this.txtGST.MaxLength = 15;
            this.txtGST.Name = "txtGST";
            this.txtGST.Size = new System.Drawing.Size(310, 27);
            this.txtGST.TabIndex = 97;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress2.Location = new System.Drawing.Point(219, 160);
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(340, 27);
            this.txtAddress2.TabIndex = 54;
            // 
            // txtCompanyURL
            // 
            this.txtCompanyURL.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompanyURL.Location = new System.Drawing.Point(873, 491);
            this.txtCompanyURL.Name = "txtCompanyURL";
            this.txtCompanyURL.Size = new System.Drawing.Size(310, 27);
            this.txtCompanyURL.TabIndex = 74;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(219, 197);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(340, 27);
            this.txtEmail.TabIndex = 53;
            // 
            // lblservceno
            // 
            this.lblservceno.AutoSize = true;
            this.lblservceno.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblservceno.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblservceno.Location = new System.Drawing.Point(718, 331);
            this.lblservceno.Name = "lblservceno";
            this.lblservceno.Size = new System.Drawing.Size(149, 19);
            this.lblservceno.TabIndex = 95;
            this.lblservceno.Text = "Service Tax Reg. No :";
            // 
            // txtFaxNo
            // 
            this.txtFaxNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFaxNo.Location = new System.Drawing.Point(219, 308);
            this.txtFaxNo.Name = "txtFaxNo";
            this.txtFaxNo.Size = new System.Drawing.Size(340, 27);
            this.txtFaxNo.TabIndex = 52;
            // 
            // lblCSTNo
            // 
            this.lblCSTNo.AutoSize = true;
            this.lblCSTNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCSTNo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCSTNo.Location = new System.Drawing.Point(804, 288);
            this.lblCSTNo.Name = "lblCSTNo";
            this.lblCSTNo.Size = new System.Drawing.Size(61, 19);
            this.lblCSTNo.TabIndex = 75;
            this.lblCSTNo.Text = "CST No:";
            // 
            // txtMoblieNo
            // 
            this.txtMoblieNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMoblieNo.Location = new System.Drawing.Point(218, 271);
            this.txtMoblieNo.Name = "txtMoblieNo";
            this.txtMoblieNo.Size = new System.Drawing.Size(340, 27);
            this.txtMoblieNo.TabIndex = 51;
            // 
            // lbltanno
            // 
            this.lbltanno.AutoSize = true;
            this.lbltanno.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltanno.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbltanno.Location = new System.Drawing.Point(763, 126);
            this.lbltanno.Name = "lbltanno";
            this.lbltanno.Size = new System.Drawing.Size(103, 19);
            this.lbltanno.TabIndex = 94;
            this.lbltanno.Text = "GST Number :";
            // 
            // txtPhoneNo
            // 
            this.txtPhoneNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneNo.Location = new System.Drawing.Point(219, 234);
            this.txtPhoneNo.Name = "txtPhoneNo";
            this.txtPhoneNo.Size = new System.Drawing.Size(340, 27);
            this.txtPhoneNo.TabIndex = 50;
            this.txtPhoneNo.TextChanged += new System.EventHandler(this.txtPhoneNo_TextChanged);
            // 
            // txtCSTNo
            // 
            this.txtCSTNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCSTNo.Location = new System.Drawing.Point(873, 287);
            this.txtCSTNo.Name = "txtCSTNo";
            this.txtCSTNo.Size = new System.Drawing.Size(310, 27);
            this.txtCSTNo.TabIndex = 76;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerName.Location = new System.Drawing.Point(219, 86);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(340, 27);
            this.txtCustomerName.TabIndex = 49;
            // 
            // txteccnumber
            // 
            this.txteccnumber.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txteccnumber.Location = new System.Drawing.Point(873, 205);
            this.txteccnumber.Name = "txteccnumber";
            this.txteccnumber.Size = new System.Drawing.Size(310, 27);
            this.txteccnumber.TabIndex = 87;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label15.Location = new System.Drawing.Point(129, 274);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 19);
            this.label15.TabIndex = 8;
            this.label15.Text = "Mobile No:";
            // 
            // lbltLocalTaxNo
            // 
            this.lbltLocalTaxNo.AutoSize = true;
            this.lbltLocalTaxNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltLocalTaxNo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbltLocalTaxNo.Location = new System.Drawing.Point(806, 249);
            this.lbltLocalTaxNo.Name = "lbltLocalTaxNo";
            this.lbltLocalTaxNo.Size = new System.Drawing.Size(59, 19);
            this.lbltLocalTaxNo.TabIndex = 77;
            this.lbltLocalTaxNo.Text = "Vat No:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label16.Location = new System.Drawing.Point(155, 311);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 19);
            this.label16.TabIndex = 7;
            this.label16.Text = "Fax No:";
            // 
            // lbleccnumber
            // 
            this.lbleccnumber.AutoSize = true;
            this.lbleccnumber.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbleccnumber.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbleccnumber.Location = new System.Drawing.Point(766, 206);
            this.lbleccnumber.Name = "lbleccnumber";
            this.lbleccnumber.Size = new System.Drawing.Size(101, 19);
            this.lbleccnumber.TabIndex = 85;
            this.lbleccnumber.Text = "ECC Number :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label17.Location = new System.Drawing.Point(158, 200);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 19);
            this.label17.TabIndex = 6;
            this.label17.Text = "E-Mail:";
            // 
            // txtVatNo
            // 
            this.txtVatNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVatNo.Location = new System.Drawing.Point(873, 246);
            this.txtVatNo.Name = "txtVatNo";
            this.txtVatNo.Size = new System.Drawing.Size(310, 27);
            this.txtVatNo.TabIndex = 78;
            // 
            // lblContactPerson
            // 
            this.lblContactPerson.AutoSize = true;
            this.lblContactPerson.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactPerson.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblContactPerson.Location = new System.Drawing.Point(97, 348);
            this.lblContactPerson.Name = "lblContactPerson";
            this.lblContactPerson.Size = new System.Drawing.Size(117, 19);
            this.lblContactPerson.TabIndex = 5;
            this.lblContactPerson.Text = "Contact Person:";
            // 
            // lblOthers
            // 
            this.lblOthers.AutoSize = true;
            this.lblOthers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOthers.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblOthers.Location = new System.Drawing.Point(802, 453);
            this.lblOthers.Name = "lblOthers";
            this.lblOthers.Size = new System.Drawing.Size(63, 19);
            this.lblOthers.TabIndex = 81;
            this.lblOthers.Text = "Others :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label13.Location = new System.Drawing.Point(134, 126);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 19);
            this.label13.TabIndex = 4;
            this.label13.Text = "Address-1:";
            // 
            // cmbCustomerType
            // 
            this.cmbCustomerType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCustomerType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCustomerType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomerType.FormattingEnabled = true;
            this.cmbCustomerType.Items.AddRange(new object[] {
            "Metro",
            "Public",
            "Private",
            "Individual",
            "Proprietor",
            "Retailer",
            "Distributor",
            "Institutional",
            "Others",
            "International"});
            this.cmbCustomerType.Location = new System.Drawing.Point(873, 84);
            this.cmbCustomerType.Name = "cmbCustomerType";
            this.cmbCustomerType.Size = new System.Drawing.Size(310, 27);
            this.cmbCustomerType.TabIndex = 83;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(134, 163);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 19);
            this.label12.TabIndex = 3;
            this.label12.Text = "Address-2:";
            // 
            // txtOthers
            // 
            this.txtOthers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOthers.Location = new System.Drawing.Point(873, 450);
            this.txtOthers.Name = "txtOthers";
            this.txtOthers.Size = new System.Drawing.Size(310, 27);
            this.txtOthers.TabIndex = 82;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(133, 237);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 19);
            this.label11.TabIndex = 2;
            this.label11.Text = "Phone No:";
            // 
            // dtpCreatedDate
            // 
            this.dtpCreatedDate.Location = new System.Drawing.Point(1127, 86);
            this.dtpCreatedDate.Name = "dtpCreatedDate";
            this.dtpCreatedDate.Size = new System.Drawing.Size(29, 20);
            this.dtpCreatedDate.TabIndex = 84;
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerName.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCustomerName.Location = new System.Drawing.Point(80, 89);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(134, 19);
            this.lblCustomerName.TabIndex = 1;
            this.lblCustomerName.Text = "Customer Name *:";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Add-icon.png");
            this.imageList1.Images.SetKeyName(1, "table-add-icon.png");
            this.imageList1.Images.SetKeyName(2, "order-history-icon.png");
            this.imageList1.Images.SetKeyName(3, "Package-Add-icon.png");
            this.imageList1.Images.SetKeyName(4, "Excel-icon.png");
            this.imageList1.Images.SetKeyName(5, "Actions-address-book-new-icon.png");
            this.imageList1.Images.SetKeyName(6, "invoice-icon.png");
            this.imageList1.Images.SetKeyName(7, "Apps-kspread-icon.png");
            this.imageList1.Images.SetKeyName(8, "Apps-klipper-icon.png");
            this.imageList1.Images.SetKeyName(9, "Upline-icon.png");
            this.imageList1.Images.SetKeyName(10, "reports-icon.png");
            this.imageList1.Images.SetKeyName(11, "Mimetypes-application-vnd-sun-xml-calc-template-icon.png");
            this.imageList1.Images.SetKeyName(12, "catalog-icon.png");
            this.imageList1.Images.SetKeyName(13, "Add-icon.png");
            // 
            // CustomerMasterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.pnMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "CustomerMasterForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Master";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CustomerMasterForm_FormClosing);
            this.Load += new System.EventHandler(this.CustomerMasterForm_Load);
            this.pnMain.ResumeLayout(false);
            this.pnMain.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnMain;
        private System.Windows.Forms.TextBox txtVatNo;
        private System.Windows.Forms.Label lbltLocalTaxNo;
        private System.Windows.Forms.TextBox txtCSTNo;
        private System.Windows.Forms.Label lblCSTNo;
        private System.Windows.Forms.TextBox txtCompanyURL;
        private System.Windows.Forms.Label lblCompanyURL;
        private System.Windows.Forms.CheckBox chkActive;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.TextBox txtTIN;
        private System.Windows.Forms.TextBox txtPINCode;
        private System.Windows.Forms.TextBox txtCountry;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtContactPerson;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtFaxNo;
        private System.Windows.Forms.TextBox txtMoblieNo;
        private System.Windows.Forms.TextBox txtPhoneNo;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblContactPerson;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.LinkLabel llQuit;
        private System.Windows.Forms.Button btnIMExit;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblReturnedby;
        private System.Windows.Forms.Label lblCustomerType;
        private System.Windows.Forms.TextBox txtOthers;
        private System.Windows.Forms.Label lblOthers;
        private System.Windows.Forms.ComboBox cmbCustomerType;
        private System.Windows.Forms.DateTimePicker dtpCreatedDate;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ComboBox cmbCustomerCode;
        private System.Windows.Forms.TextBox txtcinno;
        private System.Windows.Forms.Label lblcinno;
        private System.Windows.Forms.TextBox txtpanno;
        private System.Windows.Forms.TextBox txtserviceno;
        private System.Windows.Forms.Label lblpanno;
        private System.Windows.Forms.TextBox txtGST;
        private System.Windows.Forms.Label lblservceno;
        private System.Windows.Forms.Label lbltanno;
        private System.Windows.Forms.TextBox txteccnumber;
        private System.Windows.Forms.Label lbleccnumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbApproveCustomer;
        private System.Windows.Forms.Label lblProjecttype;
        private System.Windows.Forms.ComboBox txtDistict;
        private System.Windows.Forms.TextBox txtState;
    }
}