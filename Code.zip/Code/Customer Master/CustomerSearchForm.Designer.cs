﻿namespace Erp_Project_With_Buttons.Customer_Master
{
    partial class CustomerSearchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerSearchForm));
            this.dgCustomerList = new System.Windows.Forms.DataGridView();
            this.CustomerCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MobileNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContactPerson = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhoneNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TINNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FaxNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CompanyURL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.cmbCustomerType = new System.Windows.Forms.ComboBox();
            this.checkShowInactive = new System.Windows.Forms.CheckBox();
            this.lblCustomerType = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.lblCustomerName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgCustomerList)).BeginInit();
            this.gbSearchOptions.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgCustomerList
            // 
            this.dgCustomerList.AllowUserToAddRows = false;
            this.dgCustomerList.AllowUserToDeleteRows = false;
            this.dgCustomerList.AllowUserToResizeRows = false;
            this.dgCustomerList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgCustomerList.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.dgCustomerList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgCustomerList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgCustomerList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgCustomerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCustomerList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CustomerCode,
            this.CustomerName,
            this.MobileNO,
            this.ContactPerson,
            this.PhoneNo,
            this.EmailAddress,
            this.TINNO,
            this.FaxNo,
            this.CompanyURL,
            this.CustomerType});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgCustomerList.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgCustomerList.EnableHeadersVisualStyles = false;
            this.dgCustomerList.Location = new System.Drawing.Point(9, 91);
            this.dgCustomerList.MultiSelect = false;
            this.dgCustomerList.Name = "dgCustomerList";
            this.dgCustomerList.ReadOnly = true;
            this.dgCustomerList.RowHeadersVisible = false;
            this.dgCustomerList.Size = new System.Drawing.Size(1288, 579);
            this.dgCustomerList.TabIndex = 8;
            this.dgCustomerList.DoubleClick += new System.EventHandler(this.dgCustomerList_DoubleClick);
            // 
            // CustomerCode
            // 
            this.CustomerCode.DataPropertyName = "CusCode";
            this.CustomerCode.HeaderText = "Customer Code";
            this.CustomerCode.Name = "CustomerCode";
            this.CustomerCode.ReadOnly = true;
            this.CustomerCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomerCode.Width = 106;
            // 
            // CustomerName
            // 
            this.CustomerName.DataPropertyName = "CustomerName";
            this.CustomerName.HeaderText = "Customer Name";
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.ReadOnly = true;
            this.CustomerName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomerName.Width = 112;
            // 
            // MobileNO
            // 
            this.MobileNO.DataPropertyName = "MobileNo";
            this.MobileNO.HeaderText = "Mobile NO";
            this.MobileNO.Name = "MobileNO";
            this.MobileNO.ReadOnly = true;
            this.MobileNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.MobileNO.Width = 80;
            // 
            // ContactPerson
            // 
            this.ContactPerson.DataPropertyName = "ContactPerson";
            this.ContactPerson.HeaderText = "Contact Person";
            this.ContactPerson.Name = "ContactPerson";
            this.ContactPerson.ReadOnly = true;
            this.ContactPerson.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContactPerson.Width = 107;
            // 
            // PhoneNo
            // 
            this.PhoneNo.DataPropertyName = "PhoneNo";
            this.PhoneNo.HeaderText = "Phone No";
            this.PhoneNo.Name = "PhoneNo";
            this.PhoneNo.ReadOnly = true;
            this.PhoneNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PhoneNo.Width = 75;
            // 
            // EmailAddress
            // 
            this.EmailAddress.DataPropertyName = "EmailAddress";
            this.EmailAddress.HeaderText = "Email";
            this.EmailAddress.Name = "EmailAddress";
            this.EmailAddress.ReadOnly = true;
            this.EmailAddress.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EmailAddress.Width = 52;
            // 
            // TINNO
            // 
            this.TINNO.DataPropertyName = "TINNO";
            this.TINNO.HeaderText = "TIN";
            this.TINNO.Name = "TINNO";
            this.TINNO.ReadOnly = true;
            this.TINNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TINNO.Width = 38;
            // 
            // FaxNo
            // 
            this.FaxNo.DataPropertyName = "FaxNo";
            this.FaxNo.HeaderText = "Fax No";
            this.FaxNo.Name = "FaxNo";
            this.FaxNo.ReadOnly = true;
            this.FaxNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FaxNo.Width = 37;
            // 
            // CompanyURL
            // 
            this.CompanyURL.DataPropertyName = "CompanyURL";
            this.CompanyURL.HeaderText = "URL";
            this.CompanyURL.Name = "CompanyURL";
            this.CompanyURL.ReadOnly = true;
            this.CompanyURL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CompanyURL.Width = 41;
            // 
            // CustomerType
            // 
            this.CustomerType.DataPropertyName = "CustomerType";
            this.CustomerType.HeaderText = "Customer Type";
            this.CustomerType.Name = "CustomerType";
            this.CustomerType.ReadOnly = true;
            this.CustomerType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomerType.Width = 105;
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.cmbCustomerType);
            this.gbSearchOptions.Controls.Add(this.checkShowInactive);
            this.gbSearchOptions.Controls.Add(this.lblCustomerType);
            this.gbSearchOptions.Controls.Add(this.txtCustomerName);
            this.gbSearchOptions.Controls.Add(this.lblCustomerName);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(9, 4);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(1288, 81);
            this.gbSearchOptions.TabIndex = 7;
            this.gbSearchOptions.TabStop = false;
            // 
            // cmbCustomerType
            // 
            this.cmbCustomerType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCustomerType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCustomerType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomerType.FormattingEnabled = true;
            this.cmbCustomerType.Items.AddRange(new object[] {
            "Metro",
            "Public",
            "Private",
            "Individual",
            "Proprietor",
            "Retailer",
            "Distributor",
            "Institutional",
            "Others",
            "International"});
            this.cmbCustomerType.Location = new System.Drawing.Point(762, 29);
            this.cmbCustomerType.Name = "cmbCustomerType";
            this.cmbCustomerType.Size = new System.Drawing.Size(209, 26);
            this.cmbCustomerType.TabIndex = 84;
            this.cmbCustomerType.SelectedIndexChanged += new System.EventHandler(this.cmbCustomerType_SelectedIndexChanged);
            // 
            // checkShowInactive
            // 
            this.checkShowInactive.AutoSize = true;
            this.checkShowInactive.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkShowInactive.Location = new System.Drawing.Point(1149, 30);
            this.checkShowInactive.Name = "checkShowInactive";
            this.checkShowInactive.Size = new System.Drawing.Size(123, 23);
            this.checkShowInactive.TabIndex = 5;
            this.checkShowInactive.Text = "Show Inactive";
            this.checkShowInactive.UseVisualStyleBackColor = true;
            this.checkShowInactive.CheckedChanged += new System.EventHandler(this.checkShowInactive_CheckedChanged);
            // 
            // lblCustomerType
            // 
            this.lblCustomerType.AutoSize = true;
            this.lblCustomerType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerType.Location = new System.Drawing.Point(647, 30);
            this.lblCustomerType.Name = "lblCustomerType";
            this.lblCustomerType.Size = new System.Drawing.Size(115, 19);
            this.lblCustomerType.TabIndex = 2;
            this.lblCustomerType.Text = "Customer Type:";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerName.Location = new System.Drawing.Point(140, 29);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(419, 26);
            this.txtCustomerName.TabIndex = 1;
            this.txtCustomerName.TextChanged += new System.EventHandler(this.txtCustomerName_TextChanged);
            this.txtCustomerName.Enter += new System.EventHandler(this.txtCustomerName_Enter);
            this.txtCustomerName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtCustomerName_KeyUp);
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerName.Location = new System.Drawing.Point(11, 32);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(122, 19);
            this.lblCustomerName.TabIndex = 0;
            this.lblCustomerName.Text = "Customer Name:";
            // 
            // CustomerSearchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.dgCustomerList);
            this.Controls.Add(this.gbSearchOptions);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "CustomerSearchForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Search";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CustomerSearchForm_FormClosing);
            this.Load += new System.EventHandler(this.CustomerSearchForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgCustomerList)).EndInit();
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgCustomerList;
        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.CheckBox checkShowInactive;
        private System.Windows.Forms.Label lblCustomerType;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.ComboBox cmbCustomerType;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn MobileNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContactPerson;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhoneNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmailAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn TINNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn FaxNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn CompanyURL;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerType;
    }
}