﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Customer_Master
{
    public partial class CustomerMasterForm : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration
        frmForm2 frm = new frmForm2();
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtCustomerlist = new DataTable();
        private static DataRow sCustomerCode;
        private string sActive = string.Empty;
        private static int iSearch = 0;
        string scustomercode;
        DataTable dtGetLastCustomerCode = new DataTable();
        string customerCode = string.Empty;
        //Get Customer code from CustomerSearchForm form
        public DataRow fnGetCustomerCode
        {
            get
            {
                return sCustomerCode;
            }
            set
            {
                sCustomerCode = value;
            }

        }
        public CustomerMasterForm()
        {
            InitializeComponent();
        }
        #endregion
        #region To Return Home Form
        private void llHome_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnHome_Click(sender, e);
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            if (GLobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)  //calling close message function
            {
                this.Close();
                frm.Show();
            }
        }
        #endregion
        #region To Quit & Exit Application
        private void llQuit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (GLobalClass.fnMessageResultquit() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                Application.ExitThread();
            }
        }

        private void btnIMExit_Click(object sender, EventArgs e)
        {
            if (GLobalClass.fnMessageResultquit() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                Application.ExitThread();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }


        private void CustomerMasterForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }
        #endregion
        #region Customre Form Load & Intialize Components

        DataTable dtApproveList = new DataTable();
        DataTable dtstateList = new DataTable();
        DataTable dtcityList = new DataTable();
        private void CustomerMasterForm_Load(object sender, EventArgs e)
        {
            try
            {
                dtpCreatedDate.Format = DateTimePickerFormat.Custom;
                dtpCreatedDate.CustomFormat = "dd-MM-yyyy";


                //
                DataTable dtcityList = DAL.getstate(1, null, null).Tables[0];

                // Sort the DataTable by CityName
                DataView dv = dtcityList.DefaultView;
                dv.Sort = "CityName ASC";
                DataTable sortedCityList = dv.ToTable();

                foreach (DataRow dr in sortedCityList.Rows)
                {
                    string cityName = dr["CityName"].ToString();
                    if (!txtDistict.Items.Contains(cityName))
                    {
                        txtDistict.Items.Add(cityName);
                    }
                }

                //

                //dtcityList = DAL.getstate(1, null, null).Tables[0];

                //foreach (DataRow dr in dtcityList.Rows)
                //{
                //    if (!txtDistict.Items.Contains(dr["CityName"].ToString()))
                //    {
                //        txtDistict.Items.Add(dr["CityName"].ToString());
                //    }
                //}

                if (login.GetUserDetails[23] == "Accounts")
                {
                    dtApproveList = DAL.fnCustomerList(2, "").Tables[0];
                    foreach (DataRow dr in dtApproveList.Rows)
                    {
                        if (!cmbApproveCustomer.Items.Contains(dr["CustomerName"].ToString()))
                        {
                            cmbApproveCustomer.Items.Add(dr["CustomerName"].ToString());
                        }
                    }

                    cmbApproveCustomer.Visible = true;
                    lblProjecttype.Visible = true;
                }
                else
                {
                    cmbApproveCustomer.Visible = false;
                    lblProjecttype.Visible = false;

                }

                lblReturnedby.Text = login.GetUserDetails[2];
                if (iSearch == 1)
                {
                    if (fnGetCustomerCode != null)
                    {
                        if (fnGetCustomerCode.ItemArray.Length > 0)
                        {
                            fnLoadCustomerdata(fnGetCustomerCode["CustomerName"].ToString());
                        }
                    }
                    else
                    {
                        cmbCustomerCode.Visible = true;
                        txtCustomerName.Visible = false;
                        cmbCustomerType.Text = Global.sCOMBOBOX_DEFAULT_TEXT;
                        dtCustomerlist = DAL.fnCustomerList(0, null).Tables[0];

                        foreach (DataRow DR in dtCustomerlist.Rows)
                        {
                            if (!cmbCustomerCode.Items.Contains(DR["CustomerName"].ToString()))
                                cmbCustomerCode.Items.Add(DR["CustomerName"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("CustomerMasterForm_CustomerMasterForm_Load  " + ex.Message);
            }
        }
        #endregion

        DataTable dtGetCustomerdetails = new DataTable();
        private void fnLoadCustomerdata(string sCustomerName)
        {
            dtGetCustomerdetails = DAL.fnCustomerList(3, sCustomerName).Tables[0];
            if (dtGetCustomerdetails.Rows.Count > 0)
            {
                cmbCustomerCode.Visible = false;
                txtCustomerName.Enabled = false;
                cmbCustomerCode.Text = dtGetCustomerdetails.Rows[0]["CustomerName"].ToString();
                txtCustomerName.Text = dtGetCustomerdetails.Rows[0]["CustomerName"].ToString();
                txtContactPerson.Text = dtGetCustomerdetails.Rows[0]["ContactPerson"].ToString();
                txtAddress1.Text = dtGetCustomerdetails.Rows[0]["Address1"].ToString();
                txtAddress2.Text = dtGetCustomerdetails.Rows[0]["Address2"].ToString();
                txtCountry.Text = dtGetCustomerdetails.Rows[0]["Country"].ToString();
                txtDistict.Text = dtGetCustomerdetails.Rows[0]["District"].ToString();
                txtEmail.Text = dtGetCustomerdetails.Rows[0]["EmailAddress"].ToString();
                txtFaxNo.Text = dtGetCustomerdetails.Rows[0]["FaxNo"].ToString();
                txtMoblieNo.Text = dtGetCustomerdetails.Rows[0]["MobileNo"].ToString();
                txtPhoneNo.Text = dtGetCustomerdetails.Rows[0]["PhoneNo"].ToString();
                txtState.Text = dtGetCustomerdetails.Rows[0]["State"].ToString();
                txtTIN.Text = dtGetCustomerdetails.Rows[0]["TINNO"].ToString();
                txtPINCode.Text = dtGetCustomerdetails.Rows[0]["PinCode"].ToString();
                txtCSTNo.Text = dtGetCustomerdetails.Rows[0]["CSTNo"].ToString();
                txtCompanyURL.Text = dtGetCustomerdetails.Rows[0]["CompanyURL"].ToString();
                txtVatNo.Text = dtGetCustomerdetails.Rows[0]["VatNumber"].ToString();
                cmbCustomerType.Text = dtGetCustomerdetails.Rows[0]["CustomerType"].ToString();
                txtOthers.Text = dtGetCustomerdetails.Rows[0]["Others"].ToString();
                dtpCreatedDate.Text = dtGetCustomerdetails.Rows[0]["CreatedDate"].ToString();
                txteccnumber.Text = dtGetCustomerdetails.Rows[0]["EccNumber"].ToString(); ;
                txtserviceno.Text = dtGetCustomerdetails.Rows[0]["ServiceTaxRegNo"].ToString(); ;
                txtcinno.Text = dtGetCustomerdetails.Rows[0]["CIN"].ToString(); ;
                txtpanno.Text = dtGetCustomerdetails.Rows[0]["PAN"].ToString(); ;
                txtGST.Text = dtGetCustomerdetails.Rows[0]["GSTCode"].ToString(); ;

                if (dtGetCustomerdetails.Rows[0]["Status"].ToString() == "Active")
                    chkActive.Checked = true;
                else if (dtGetCustomerdetails.Rows[0]["Status"].ToString() == "InActive")
                    chkActive.Checked = false;
                iSearch = 0;
                btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISUPDATE;
            }
        }

        #region Phone Number Validation
        private void txtPhoneNo_TextChanged(object sender, EventArgs e)
        {
            //  GLobalClass.fnIsPhoneNumber(txtPhoneNo);
        }
        #endregion
        #region Function to Delete Customre
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCustomerName.Text != string.Empty)
                {
                    DialogResult Result = MessageBox.Show("Do you want to permenently delete the customer " + txtCustomerName.Text + " ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                    if (Result == DialogResult.Yes)
                    {
                        GLobalClass.iSuccess = DAL.fnAddCustomerMaster(Global.uDELETE, sCustomerCode["CusCode"].ToString(), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);//remove selected vendor from database
                        if (GLobalClass.iSuccess > 0)
                        {
                            MessageBox.Show("Customer " + txtCustomerName.Text + " deleted successfully", "Success", 0, MessageBoxIcon.Information);
                            //calling clearall function
                            btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                        }
                        else
                        {
                            MessageBox.Show("Customer " + txtCustomerName.Text + " was not found", "Error", 0, MessageBoxIcon.Error);
                            btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                            txtCustomerName.Focus();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Customer name field is empty", "Error", 0, MessageBoxIcon.Error);
                    txtCustomerName.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("CustomerMasterForm_btnDelete_Click  " + ex.Message);
            }
        }
        #endregion
        #region Function to Reload Form
        public void FormReload()
        {
            this.Hide();
            Customer_Master.CustomerMasterForm customre = new CustomerMasterForm();
            customre.Show();
        }
        #endregion
        #region Code to Save New Customer Details
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbCustomerCode.Text != string.Empty && cmbCustomerType.Text != string.Empty && !string.IsNullOrEmpty(txtGST.Text) && !string.IsNullOrEmpty(txtcinno.Text) && txtcinno.Text.Length==21)//check all required fields are filled or not
                {
                    if (chkActive.Checked)
                        sActive = "Active";
                    else
                    {
                        sActive = "InActive";
                    }

                    if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                    {
                        dtGetLastCustomerCode = DAL.fnGetLastCustomertNo().Tables[0];
                        scustomercode = dtGetLastCustomerCode.Rows[0]["CusCode"].ToString();
                        string sp = scustomercode.Substring(05, 04);
                        int iLaststomerNONo = Convert.ToInt32(sp);
                        iLaststomerNONo++;
                        scustomercode = string.Empty;
                        scustomercode = ("CUS000" + iLaststomerNONo);
                        GLobalClass.iSuccess = DAL.fnAddCustomerMaster(Global.uINSERT, scustomercode, cmbCustomerCode.Text.Trim(), txtContactPerson.Text, txtAddress1.Text, txtAddress2.Text,
                            txtPhoneNo.Text, txtEmail.Text, txtFaxNo.Text, txtMoblieNo.Text, txtDistict.Text, txtState.Text, txtCountry.Text, txtPINCode.Text, txtTIN.Text, sActive,
                            txtCSTNo.Text, txtCompanyURL.Text, txtVatNo.Text, cmbCustomerType.Text, txtOthers.Text, dtpCreatedDate.Text, txteccnumber.Text, txtserviceno.Text,
                            txtcinno.Text, txtpanno.Text, txtGST.Text, login.GetUserDetails[2]);//add the new Customer datails to the database
                        if (GLobalClass.iSuccess > 0)
                        {
                            MessageBox.Show("New Customer " + cmbCustomerCode.Text + " Inserted Successfully", "Success", 0, MessageBoxIcon.Information);
                            FormReload();
                        }
                    }
                    else
                    {
                        dtCustomerlist = DAL.fnCustomerList(4, null).Tables[0];
                        DataView dv = new DataView(dtCustomerlist);
                        dv.RowFilter = "CustomerName like '" + txtCustomerName.Text + "%'";
                        DataTable dt1 = new DataTable();
                        dt1 = dv.ToTable();
                        customerCode = dt1.Rows[0]["CusCode"].ToString();
                        GLobalClass.iSuccess = DAL.fnAddCustomerMaster(Global.uUPDATE, customerCode, txtCustomerName.Text, txtContactPerson.Text, txtAddress1.Text, txtAddress2.Text,
                            txtPhoneNo.Text, txtEmail.Text, txtFaxNo.Text, txtMoblieNo.Text, txtDistict.Text, txtState.Text, txtCountry.Text, txtPINCode.Text, txtTIN.Text, sActive,
                            txtCSTNo.Text, txtCompanyURL.Text, txtVatNo.Text, cmbCustomerType.Text, txtOthers.Text, null, txteccnumber.Text, txtserviceno.Text, txtcinno.Text, txtpanno.Text, txtGST.Text, "");

                        if (login.GetUserDetails[23] == "Accounts")
                        {
                            GLobalClass.iSuccess = DAL.fnAddCustomerMaster(6, customerCode, login.GetUserDetails[2], dtpCreatedDate.Text, txtAddress1.Text, txtAddress2.Text,
                         txtPhoneNo.Text, txtEmail.Text, txtFaxNo.Text, txtMoblieNo.Text, txtDistict.Text, txtState.Text, txtCountry.Text, txtPINCode.Text, txtTIN.Text, sActive,
                         txtCSTNo.Text, txtCompanyURL.Text, txtVatNo.Text, cmbCustomerType.Text, txtOthers.Text, null, txteccnumber.Text, txtserviceno.Text, txtcinno.Text, txtpanno.Text, txtGST.Text, "");

                        }
                        if (GLobalClass.iSuccess > 0)
                        {
                            if (login.GetUserDetails[23] == "Accounts")
                            {
                                MessageBox.Show("Customer " + txtCustomerName.Text + " Approved successfully", "Success", 0, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("Customer " + txtCustomerName.Text + " updated successfully", "Success", 0, MessageBoxIcon.Information);
                            }
                            btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                            txtCustomerName.Enabled = true;
                            FormReload();
                        }
                    }
                }
                else
                {
                    if (cmbCustomerCode.Text == string.Empty)
                    {
                        MessageBox.Show("Enter Customer Name", "Error", 0, MessageBoxIcon.Error);
                    }
                    //else 
                    //if (txtCustomerName.Text == string.Empty)
                    //{
                    //    MessageBox.Show("Enter Customer Name", "Error", 0, MessageBoxIcon.Error);
                    //    txtCustomerName.Focus();
                    //}
                    // else
                    if (cmbCustomerType.Text == string.Empty)
                    {
                        MessageBox.Show("Select Customer type", "Error", 0, MessageBoxIcon.Error);
                        cmbCustomerType.DroppedDown = true;
                    }
                    else if (string.IsNullOrEmpty(txtGST.Text))
                    {
                        MessageBox.Show("Enter GST Number", "Error", 0, MessageBoxIcon.Error);
                        txtGST.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtcinno.Text))
                    {
                        MessageBox.Show("Enter CIN Number", "Error", 0, MessageBoxIcon.Error);
                        txtcinno.Focus();
                    }                   
                    else if (txtcinno.Text.Length!=21)
                    {
                        MessageBox.Show("The Length of CIN Number should be 21", "Error", 0, MessageBoxIcon.Error);
                        txtcinno.Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("CustomerMasterForm_btnSave_Click  " + ex.Message);
            }
        }
        #endregion
        #region Code to Search a Customer Name
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtCustomerName.Text != string.Empty || cmbCustomerType.Text != string.Empty)
            {
                if (GLobalClass.fnClearallMessage() == DialogResult.Yes)    //clear all message function
                {
                    btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                    Customer_Master.CustomerSearchForm CustomerSearchForm = new Customer_Master.CustomerSearchForm();
                    iSearch = 1;
                    this.Hide();
                    CustomerSearchForm.Show();
                }
            }
            else
            {
                Customer_Master.CustomerSearchForm CustomerSearchForm = new Customer_Master.CustomerSearchForm();
                iSearch = 1;
                this.Hide();
                CustomerSearchForm.Show();
            }

        }
        #endregion
        #region Code to Get Customer COde
        private void cmbCustomerCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(dtCustomerlist);
            dv.RowFilter = "CustomerName like '" + cmbCustomerCode.Text + "%'";
            DataTable dt = new DataTable();
            dt = dv.ToTable();
            customerCode = dt.Rows[0]["CusCode"].ToString();
        }
        #endregion
        #region Function to ClearAll
        private void btnClearAll_Click_1(object sender, EventArgs e)
        {
            FormReload();
        }
        #endregion

        private void cmbApproveCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            fnLoadCustomerdata(cmbApproveCustomer.Text);
        }

        private void txtDistict_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtstateList = DAL.getstate(2, txtDistict.Text, null).Tables[0];
            if (dtstateList.Rows.Count > 0)
            {
                txtState.Text = dtstateList.Rows[0]["StateName"].ToString();
               
                txtCountry.Text = dtstateList.Rows[0]["CountryName"].ToString();
            }
        }
    }
}
