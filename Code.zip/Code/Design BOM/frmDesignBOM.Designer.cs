﻿namespace Erp_Project_With_Buttons.Design_BOM
{
    partial class frmDesignBOM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDesignBOM));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gbProjectDetails = new System.Windows.Forms.GroupBox();
            this.dtpCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.lblProjectStaus = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.txtcustomer = new System.Windows.Forms.Label();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.txtProjectName = new System.Windows.Forms.Label();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.cmbProjectCode = new System.Windows.Forms.ComboBox();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.btnDownload = new System.Windows.Forms.Button();
            this.dgItemOrProductList = new System.Windows.Forms.DataGridView();
            this.ProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Version = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NodeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectBOM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DesignBOM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbtreesearch = new System.Windows.Forms.GroupBox();
            this.cmbVersion = new System.Windows.Forms.ComboBox();
            this.lblVersion = new System.Windows.Forms.Label();
            this.cleartreeview = new System.Windows.Forms.Button();
            this.txtsearchtree = new System.Windows.Forms.TextBox();
            this.btnsearchtree = new System.Windows.Forms.Button();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.txtItemCode = new System.Windows.Forms.TextBox();
            this.tvProduct = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.lblItemcodeorName = new System.Windows.Forms.Label();
            this.txtItemSearch = new System.Windows.Forms.TextBox();
            this.gbControlButtons = new System.Windows.Forms.GroupBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.txtPreparedBy = new System.Windows.Forms.Label();
            this.lblPreparedBy = new System.Windows.Forms.Label();
            this.txtAutherisedBy = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgBOMList = new System.Windows.Forms.DataGridView();
            this.uItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssuedQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uBOMQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DrawingNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Revision = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RefItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Addedby = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAuthorise = new System.Windows.Forms.Button();
            this.btnBOMRelaese = new System.Windows.Forms.Button();
            this.btnUpdateItem = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pnItemAdd = new System.Windows.Forms.Panel();
            this.dgvxcelupload = new System.Windows.Forms.DataGridView();
            this.xslno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xItemDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xMfgPartNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xMake = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xUnitcost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xSpecification = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xItemType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xVendor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xDrawingno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnexcelupload = new System.Windows.Forms.Panel();
            this.btnUpload = new System.Windows.Forms.Button();
            this.lbladditemcount = new System.Windows.Forms.Label();
            this.lblbomitemlist = new System.Windows.Forms.Label();
            this.btnbrowse = new System.Windows.Forms.Button();
            this.txtbrowseaddres = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.dgvItemList = new System.Windows.Forms.DataGridView();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DrawingNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnItemcode = new System.Windows.Forms.Panel();
            this.btnImport = new System.Windows.Forms.Button();
            this.lblimportitems = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.lbltotalitems = new System.Windows.Forms.Label();
            this.lblitemcount = new System.Windows.Forms.Label();
            this.rbItemcode = new System.Windows.Forms.RadioButton();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.rbExcelitem = new System.Windows.Forms.RadioButton();
            this.btnEmailRequest = new System.Windows.Forms.Button();
            this.lblEmail = new System.Windows.Forms.Label();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.gbProjectDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).BeginInit();
            this.gbtreesearch.SuspendLayout();
            this.gbControlButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMList)).BeginInit();
            this.pnItemAdd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvxcelupload)).BeginInit();
            this.pnexcelupload.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemList)).BeginInit();
            this.pnItemcode.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbProjectDetails
            // 
            this.gbProjectDetails.Controls.Add(this.dtpCreatedDate);
            this.gbProjectDetails.Controls.Add(this.lblProjectStaus);
            this.gbProjectDetails.Controls.Add(this.label5);
            this.gbProjectDetails.Controls.Add(this.btnProjectView);
            this.gbProjectDetails.Controls.Add(this.txtcustomer);
            this.gbProjectDetails.Controls.Add(this.lblcustomer);
            this.gbProjectDetails.Controls.Add(this.txtProjectName);
            this.gbProjectDetails.Controls.Add(this.lblProjectName);
            this.gbProjectDetails.Controls.Add(this.cmbProjectCode);
            this.gbProjectDetails.Controls.Add(this.lblProjectCode);
            this.gbProjectDetails.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbProjectDetails.ForeColor = System.Drawing.Color.Black;
            this.gbProjectDetails.Location = new System.Drawing.Point(12, -2);
            this.gbProjectDetails.Name = "gbProjectDetails";
            this.gbProjectDetails.Size = new System.Drawing.Size(1295, 71);
            this.gbProjectDetails.TabIndex = 66;
            this.gbProjectDetails.TabStop = false;
            this.gbProjectDetails.Enter += new System.EventHandler(this.gbProjectDetails_Enter);
            // 
            // dtpCreatedDate
            // 
            this.dtpCreatedDate.Enabled = false;
            this.dtpCreatedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCreatedDate.Location = new System.Drawing.Point(1197, 10);
            this.dtpCreatedDate.Name = "dtpCreatedDate";
            this.dtpCreatedDate.Size = new System.Drawing.Size(87, 22);
            this.dtpCreatedDate.TabIndex = 75;
            // 
            // lblProjectStaus
            // 
            this.lblProjectStaus.AutoSize = true;
            this.lblProjectStaus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectStaus.ForeColor = System.Drawing.Color.Black;
            this.lblProjectStaus.Location = new System.Drawing.Point(102, 43);
            this.lblProjectStaus.Name = "lblProjectStaus";
            this.lblProjectStaus.Size = new System.Drawing.Size(12, 18);
            this.lblProjectStaus.TabIndex = 73;
            this.lblProjectStaus.Text = ".";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(23, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 18);
            this.label5.TabIndex = 74;
            this.label5.Text = "Proj Status :";
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectView.Location = new System.Drawing.Point(316, 9);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 29);
            this.btnProjectView.TabIndex = 72;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            this.btnProjectView.Click += new System.EventHandler(this.btnProjectView_Click);
            // 
            // txtcustomer
            // 
            this.txtcustomer.AutoSize = true;
            this.txtcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustomer.ForeColor = System.Drawing.Color.Black;
            this.txtcustomer.Location = new System.Drawing.Point(449, 43);
            this.txtcustomer.Name = "txtcustomer";
            this.txtcustomer.Size = new System.Drawing.Size(12, 18);
            this.txtcustomer.TabIndex = 5;
            this.txtcustomer.Text = ".";
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.Color.Black;
            this.lblcustomer.Location = new System.Drawing.Point(376, 43);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(75, 18);
            this.lblcustomer.TabIndex = 5;
            this.lblcustomer.Text = "Customer :";
            // 
            // txtProjectName
            // 
            this.txtProjectName.AutoSize = true;
            this.txtProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectName.ForeColor = System.Drawing.Color.Black;
            this.txtProjectName.Location = new System.Drawing.Point(451, 14);
            this.txtProjectName.Name = "txtProjectName";
            this.txtProjectName.Size = new System.Drawing.Size(12, 18);
            this.txtProjectName.TabIndex = 3;
            this.txtProjectName.Text = ".";
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.Color.Black;
            this.lblProjectName.Location = new System.Drawing.Point(355, 14);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(99, 18);
            this.lblProjectName.TabIndex = 3;
            this.lblProjectName.Text = "Project Name :";
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.DropDownHeight = 130;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectCode.FormattingEnabled = true;
            this.cmbProjectCode.IntegralHeight = false;
            this.cmbProjectCode.Location = new System.Drawing.Point(102, 10);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.Size = new System.Drawing.Size(211, 26);
            this.cmbProjectCode.TabIndex = 2;
            this.cmbProjectCode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectCode_SelectedIndexChanged);
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(6, 13);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(98, 18);
            this.lblProjectCode.TabIndex = 1;
            this.lblProjectCode.Text = "Project Code*:";
            // 
            // btnDownload
            // 
            this.btnDownload.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnDownload.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDownload.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnDownload.Location = new System.Drawing.Point(154, 11);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(132, 41);
            this.btnDownload.TabIndex = 144;
            this.btnDownload.Text = "Export to Excel";
            this.btnDownload.UseVisualStyleBackColor = false;
            this.btnDownload.Visible = false;
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
            // 
            // dgItemOrProductList
            // 
            this.dgItemOrProductList.AllowUserToAddRows = false;
            this.dgItemOrProductList.AllowUserToDeleteRows = false;
            this.dgItemOrProductList.AllowUserToResizeRows = false;
            this.dgItemOrProductList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgItemOrProductList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgItemOrProductList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgItemOrProductList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgItemOrProductList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductCode,
            this.ProductName,
            this.Version,
            this.ProductType,
            this.Quantity,
            this.UnitCost,
            this.Amount,
            this.NodeID,
            this.ProjectBOM,
            this.DesignBOM});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgItemOrProductList.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgItemOrProductList.EnableHeadersVisualStyles = false;
            this.dgItemOrProductList.Location = new System.Drawing.Point(394, 75);
            this.dgItemOrProductList.MultiSelect = false;
            this.dgItemOrProductList.Name = "dgItemOrProductList";
            this.dgItemOrProductList.RowHeadersVisible = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgItemOrProductList.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgItemOrProductList.Size = new System.Drawing.Size(907, 253);
            this.dgItemOrProductList.TabIndex = 65;
            this.dgItemOrProductList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemOrProductList_CellClick);
            this.dgItemOrProductList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgItemOrProductList_KeyUp);
            // 
            // ProductCode
            // 
            this.ProductCode.DataPropertyName = "ProductCode";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProductCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProductCode.HeaderText = "Product Code";
            this.ProductCode.Name = "ProductCode";
            this.ProductCode.ReadOnly = true;
            this.ProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductCode.Width = 108;
            // 
            // ProductName
            // 
            this.ProductName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProductName.DataPropertyName = "ProductName";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProductName.DefaultCellStyle = dataGridViewCellStyle3;
            this.ProductName.HeaderText = "Product Name";
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductName.Width = 114;
            // 
            // Version
            // 
            this.Version.DataPropertyName = "Version";
            this.Version.HeaderText = "Version";
            this.Version.Name = "Version";
            this.Version.ReadOnly = true;
            this.Version.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Version.Width = 65;
            // 
            // ProductType
            // 
            this.ProductType.DataPropertyName = "ProductType";
            this.ProductType.HeaderText = "Product Type";
            this.ProductType.Name = "ProductType";
            this.ProductType.ReadOnly = true;
            this.ProductType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductType.Width = 107;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            this.Quantity.ReadOnly = true;
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 75;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle4.Format = "N2";
            dataGridViewCellStyle4.NullValue = null;
            this.UnitCost.DefaultCellStyle = dataGridViewCellStyle4;
            this.UnitCost.HeaderText = "UnitCost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 73;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "UnitCost";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Format = "N2";
            dataGridViewCellStyle5.NullValue = null;
            this.Amount.DefaultCellStyle = dataGridViewCellStyle5;
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Amount.Width = 71;
            // 
            // NodeID
            // 
            this.NodeID.DataPropertyName = "NodeID";
            this.NodeID.HeaderText = "NodeID";
            this.NodeID.Name = "NodeID";
            this.NodeID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NodeID.Visible = false;
            this.NodeID.Width = 66;
            // 
            // ProjectBOM
            // 
            this.ProjectBOM.DataPropertyName = "ProjectBOM";
            this.ProjectBOM.HeaderText = "ProjectBOM";
            this.ProjectBOM.Name = "ProjectBOM";
            this.ProjectBOM.ReadOnly = true;
            this.ProjectBOM.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectBOM.Visible = false;
            this.ProjectBOM.Width = 98;
            // 
            // DesignBOM
            // 
            this.DesignBOM.DataPropertyName = "DesignBOM";
            this.DesignBOM.HeaderText = "DesignBOM";
            this.DesignBOM.Name = "DesignBOM";
            this.DesignBOM.ReadOnly = true;
            this.DesignBOM.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DesignBOM.Visible = false;
            this.DesignBOM.Width = 94;
            // 
            // gbtreesearch
            // 
            this.gbtreesearch.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbtreesearch.Controls.Add(this.cmbVersion);
            this.gbtreesearch.Controls.Add(this.lblVersion);
            this.gbtreesearch.Controls.Add(this.cleartreeview);
            this.gbtreesearch.Controls.Add(this.txtsearchtree);
            this.gbtreesearch.Controls.Add(this.btnsearchtree);
            this.gbtreesearch.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.gbtreesearch.Location = new System.Drawing.Point(10, 101);
            this.gbtreesearch.Name = "gbtreesearch";
            this.gbtreesearch.Size = new System.Drawing.Size(373, 108);
            this.gbtreesearch.TabIndex = 112;
            this.gbtreesearch.TabStop = false;
            // 
            // cmbVersion
            // 
            this.cmbVersion.DropDownHeight = 60;
            this.cmbVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVersion.DropDownWidth = 150;
            this.cmbVersion.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbVersion.FormattingEnabled = true;
            this.cmbVersion.IntegralHeight = false;
            this.cmbVersion.ItemHeight = 18;
            this.cmbVersion.Location = new System.Drawing.Point(120, 73);
            this.cmbVersion.Name = "cmbVersion";
            this.cmbVersion.Size = new System.Drawing.Size(80, 26);
            this.cmbVersion.Sorted = true;
            this.cmbVersion.TabIndex = 138;
            this.cmbVersion.SelectedIndexChanged += new System.EventHandler(this.cmbVersion_SelectedIndexChanged);
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.ForeColor = System.Drawing.Color.Black;
            this.lblVersion.Location = new System.Drawing.Point(13, 77);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(108, 19);
            this.lblVersion.TabIndex = 137;
            this.lblVersion.Text = "Select Version:";
            // 
            // cleartreeview
            // 
            this.cleartreeview.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cleartreeview.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cleartreeview.Location = new System.Drawing.Point(301, 49);
            this.cleartreeview.Name = "cleartreeview";
            this.cleartreeview.Size = new System.Drawing.Size(66, 29);
            this.cleartreeview.TabIndex = 134;
            this.cleartreeview.Text = "Clear";
            this.cleartreeview.UseVisualStyleBackColor = true;
            this.cleartreeview.Click += new System.EventHandler(this.cleartreeview_Click);
            // 
            // txtsearchtree
            // 
            this.txtsearchtree.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchtree.Location = new System.Drawing.Point(10, 17);
            this.txtsearchtree.Name = "txtsearchtree";
            this.txtsearchtree.Size = new System.Drawing.Size(357, 26);
            this.txtsearchtree.TabIndex = 133;
            this.txtsearchtree.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtsearchtree_KeyUp);
            // 
            // btnsearchtree
            // 
            this.btnsearchtree.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearchtree.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnsearchtree.Location = new System.Drawing.Point(232, 49);
            this.btnsearchtree.Name = "btnsearchtree";
            this.btnsearchtree.Size = new System.Drawing.Size(69, 29);
            this.btnsearchtree.TabIndex = 132;
            this.btnsearchtree.Text = "Search";
            this.btnsearchtree.UseVisualStyleBackColor = true;
            this.btnsearchtree.Click += new System.EventHandler(this.btnsearchtree_Click);
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(681, 3);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 213;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(572, 3);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 212;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // txtItemCode
            // 
            this.txtItemCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemCode.Location = new System.Drawing.Point(6, 2);
            this.txtItemCode.Multiline = true;
            this.txtItemCode.Name = "txtItemCode";
            this.txtItemCode.Size = new System.Drawing.Size(556, 23);
            this.txtItemCode.TabIndex = 1;
            this.txtItemCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtItemCode_KeyPress);
            this.txtItemCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemCode_KeyUp);
            // 
            // tvProduct
            // 
            this.tvProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvProduct.Location = new System.Drawing.Point(6, 213);
            this.tvProduct.Name = "tvProduct";
            this.tvProduct.Size = new System.Drawing.Size(379, 409);
            this.tvProduct.StateImageList = this.imageList1;
            this.tvProduct.TabIndex = 115;
            this.tvProduct.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProduct_NodeMouseDoubleClick);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(1, "diagram_v2_17.ico");
            this.imageList1.Images.SetKeyName(2, "Dryicons-Aesthetica-2-Process-accept.ico");
            this.imageList1.Images.SetKeyName(3, "Dryicons-Aesthetica-2-Process-remove.ico");
            this.imageList1.Images.SetKeyName(4, "Rafiqul-Hassan-Blogger-Settings.ico");
            // 
            // lblItemcodeorName
            // 
            this.lblItemcodeorName.AutoSize = true;
            this.lblItemcodeorName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemcodeorName.ForeColor = System.Drawing.Color.Black;
            this.lblItemcodeorName.Location = new System.Drawing.Point(405, 334);
            this.lblItemcodeorName.Name = "lblItemcodeorName";
            this.lblItemcodeorName.Size = new System.Drawing.Size(98, 19);
            this.lblItemcodeorName.TabIndex = 122;
            this.lblItemcodeorName.Text = "Search Item :";
            // 
            // txtItemSearch
            // 
            this.txtItemSearch.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtItemSearch.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemSearch.Location = new System.Drawing.Point(506, 334);
            this.txtItemSearch.Name = "txtItemSearch";
            this.txtItemSearch.Size = new System.Drawing.Size(292, 22);
            this.txtItemSearch.TabIndex = 121;
            this.txtItemSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemSearch_KeyUp);
            // 
            // gbControlButtons
            // 
            this.gbControlButtons.Controls.Add(this.btnDownload);
            this.gbControlButtons.Controls.Add(this.btnSave);
            this.gbControlButtons.Controls.Add(this.btnExit);
            this.gbControlButtons.Controls.Add(this.btnClearAll);
            this.gbControlButtons.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.gbControlButtons.Location = new System.Drawing.Point(766, 629);
            this.gbControlButtons.Name = "gbControlButtons";
            this.gbControlButtons.Size = new System.Drawing.Size(535, 53);
            this.gbControlButtons.TabIndex = 123;
            this.gbControlButtons.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.Enabled = false;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnSave.Location = new System.Drawing.Point(34, 11);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(96, 41);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnExit.Location = new System.Drawing.Point(433, 11);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(96, 41);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearAll.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnClearAll.Location = new System.Drawing.Point(314, 11);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(96, 41);
            this.btnClearAll.TabIndex = 7;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = false;
            // 
            // txtPreparedBy
            // 
            this.txtPreparedBy.AutoSize = true;
            this.txtPreparedBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPreparedBy.ForeColor = System.Drawing.Color.Black;
            this.txtPreparedBy.Location = new System.Drawing.Point(118, 640);
            this.txtPreparedBy.Name = "txtPreparedBy";
            this.txtPreparedBy.Size = new System.Drawing.Size(17, 19);
            this.txtPreparedBy.TabIndex = 124;
            this.txtPreparedBy.Text = "a";
            // 
            // lblPreparedBy
            // 
            this.lblPreparedBy.AutoSize = true;
            this.lblPreparedBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreparedBy.ForeColor = System.Drawing.Color.Black;
            this.lblPreparedBy.Location = new System.Drawing.Point(25, 640);
            this.lblPreparedBy.Name = "lblPreparedBy";
            this.lblPreparedBy.Size = new System.Drawing.Size(97, 19);
            this.lblPreparedBy.TabIndex = 125;
            this.lblPreparedBy.Text = "Prepared By:";
            // 
            // txtAutherisedBy
            // 
            this.txtAutherisedBy.AutoSize = true;
            this.txtAutherisedBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAutherisedBy.ForeColor = System.Drawing.Color.Black;
            this.txtAutherisedBy.Location = new System.Drawing.Point(117, 663);
            this.txtAutherisedBy.Name = "txtAutherisedBy";
            this.txtAutherisedBy.Size = new System.Drawing.Size(17, 19);
            this.txtAutherisedBy.TabIndex = 126;
            this.txtAutherisedBy.Text = "a";
            this.txtAutherisedBy.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(12, 663);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 19);
            this.label1.TabIndex = 127;
            this.label1.Text = "Authorised By:";
            this.label1.Visible = false;
            // 
            // dgBOMList
            // 
            this.dgBOMList.AllowUserToAddRows = false;
            this.dgBOMList.AllowUserToDeleteRows = false;
            this.dgBOMList.AllowUserToResizeRows = false;
            this.dgBOMList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgBOMList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgBOMList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgBOMList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgBOMList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgBOMList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.uItemCode,
            this.uItemDescription,
            this.IssuedQuantity,
            this.uBOMQty,
            this.UnitPrice,
            this.BOMAmount,
            this.DrawingNo,
            this.Revision,
            this.RefItemCode,
            this.Status,
            this.Addedby,
            this.Date});
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgBOMList.DefaultCellStyle = dataGridViewCellStyle16;
            this.dgBOMList.EnableHeadersVisualStyles = false;
            this.dgBOMList.Location = new System.Drawing.Point(394, 375);
            this.dgBOMList.MultiSelect = false;
            this.dgBOMList.Name = "dgBOMList";
            this.dgBOMList.RowHeadersVisible = false;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgBOMList.RowsDefaultCellStyle = dataGridViewCellStyle17;
            this.dgBOMList.Size = new System.Drawing.Size(907, 248);
            this.dgBOMList.TabIndex = 128;
            this.dgBOMList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgBOMList_CellBeginEdit);
            this.dgBOMList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBOMList_CellEndEdit);
            this.dgBOMList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgBOMList_EditingControlShowing);
            this.dgBOMList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgBOMList_KeyUp);
            // 
            // uItemCode
            // 
            this.uItemCode.DataPropertyName = "ItemName";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.uItemCode.DefaultCellStyle = dataGridViewCellStyle9;
            this.uItemCode.HeaderText = "Item Code";
            this.uItemCode.Name = "uItemCode";
            this.uItemCode.ReadOnly = true;
            this.uItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uItemCode.Width = 76;
            // 
            // uItemDescription
            // 
            this.uItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.uItemDescription.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.uItemDescription.DefaultCellStyle = dataGridViewCellStyle10;
            this.uItemDescription.HeaderText = "Item Description";
            this.uItemDescription.Name = "uItemDescription";
            this.uItemDescription.ReadOnly = true;
            this.uItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uItemDescription.Width = 125;
            // 
            // IssuedQuantity
            // 
            this.IssuedQuantity.DataPropertyName = "IssuedQuantity";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IssuedQuantity.DefaultCellStyle = dataGridViewCellStyle11;
            this.IssuedQuantity.HeaderText = "Issued Qty";
            this.IssuedQuantity.Name = "IssuedQuantity";
            this.IssuedQuantity.ReadOnly = true;
            this.IssuedQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IssuedQuantity.Width = 77;
            // 
            // uBOMQty
            // 
            this.uBOMQty.DataPropertyName = "Quantity";
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uBOMQty.DefaultCellStyle = dataGridViewCellStyle12;
            this.uBOMQty.HeaderText = "BOM Qty";
            this.uBOMQty.Name = "uBOMQty";
            this.uBOMQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uBOMQty.Width = 70;
            // 
            // UnitPrice
            // 
            this.UnitPrice.DataPropertyName = "UnitCost";
            dataGridViewCellStyle13.Format = "N2";
            dataGridViewCellStyle13.NullValue = null;
            this.UnitPrice.DefaultCellStyle = dataGridViewCellStyle13;
            this.UnitPrice.HeaderText = "Unit Cost";
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.ReadOnly = true;
            this.UnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitPrice.Width = 69;
            // 
            // BOMAmount
            // 
            this.BOMAmount.DataPropertyName = "BOMAmount";
            dataGridViewCellStyle14.Format = "N2";
            dataGridViewCellStyle14.NullValue = null;
            this.BOMAmount.DefaultCellStyle = dataGridViewCellStyle14;
            this.BOMAmount.HeaderText = "Amount";
            this.BOMAmount.Name = "BOMAmount";
            this.BOMAmount.ReadOnly = true;
            this.BOMAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMAmount.Width = 71;
            // 
            // DrawingNo
            // 
            this.DrawingNo.DataPropertyName = "DrawingNo";
            this.DrawingNo.HeaderText = "Drawing No";
            this.DrawingNo.Name = "DrawingNo";
            this.DrawingNo.ReadOnly = true;
            this.DrawingNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DrawingNo.Width = 86;
            // 
            // Revision
            // 
            this.Revision.DataPropertyName = "RevisionNo";
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Revision.DefaultCellStyle = dataGridViewCellStyle15;
            this.Revision.HeaderText = "Revision No";
            this.Revision.Name = "Revision";
            this.Revision.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Revision.Width = 86;
            // 
            // RefItemCode
            // 
            this.RefItemCode.DataPropertyName = "RefItemCode";
            this.RefItemCode.HeaderText = "Ref ItemCode";
            this.RefItemCode.Name = "RefItemCode";
            this.RefItemCode.ReadOnly = true;
            this.RefItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RefItemCode.Width = 95;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Status.Visible = false;
            this.Status.Width = 58;
            // 
            // Addedby
            // 
            this.Addedby.DataPropertyName = "AddedBy";
            this.Addedby.HeaderText = "Added By";
            this.Addedby.Name = "Addedby";
            this.Addedby.ReadOnly = true;
            this.Addedby.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Addedby.Width = 73;
            // 
            // Date
            // 
            this.Date.DataPropertyName = "AddedDate";
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            this.Date.ReadOnly = true;
            this.Date.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Date.Width = 47;
            // 
            // btnAuthorise
            // 
            this.btnAuthorise.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAuthorise.Enabled = false;
            this.btnAuthorise.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAuthorise.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAuthorise.Location = new System.Drawing.Point(1102, 334);
            this.btnAuthorise.Name = "btnAuthorise";
            this.btnAuthorise.Size = new System.Drawing.Size(96, 29);
            this.btnAuthorise.TabIndex = 129;
            this.btnAuthorise.Text = "Authorise";
            this.btnAuthorise.UseVisualStyleBackColor = false;
            this.btnAuthorise.Click += new System.EventHandler(this.btnAuthorise_Click);
            // 
            // btnBOMRelaese
            // 
            this.btnBOMRelaese.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBOMRelaese.Enabled = false;
            this.btnBOMRelaese.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBOMRelaese.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBOMRelaese.Location = new System.Drawing.Point(1200, 334);
            this.btnBOMRelaese.Name = "btnBOMRelaese";
            this.btnBOMRelaese.Size = new System.Drawing.Size(105, 29);
            this.btnBOMRelaese.TabIndex = 130;
            this.btnBOMRelaese.Text = "Release BOM";
            this.btnBOMRelaese.UseVisualStyleBackColor = false;
            this.btnBOMRelaese.Click += new System.EventHandler(this.btnBOMRelaese_Click);
            // 
            // btnUpdateItem
            // 
            this.btnUpdateItem.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnUpdateItem.Enabled = false;
            this.btnUpdateItem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdateItem.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnUpdateItem.Location = new System.Drawing.Point(170, 75);
            this.btnUpdateItem.Name = "btnUpdateItem";
            this.btnUpdateItem.Size = new System.Drawing.Size(141, 23);
            this.btnUpdateItem.TabIndex = 131;
            this.btnUpdateItem.Text = "Update Items";
            this.btnUpdateItem.UseVisualStyleBackColor = false;
            this.btnUpdateItem.Click += new System.EventHandler(this.btnUpdateItem_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pnItemAdd
            // 
            this.pnItemAdd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnItemAdd.Controls.Add(this.dgvxcelupload);
            this.pnItemAdd.Controls.Add(this.pnexcelupload);
            this.pnItemAdd.Controls.Add(this.btnClose);
            this.pnItemAdd.Controls.Add(this.dgvItemList);
            this.pnItemAdd.Controls.Add(this.pnItemcode);
            this.pnItemAdd.Location = new System.Drawing.Point(394, 238);
            this.pnItemAdd.Name = "pnItemAdd";
            this.pnItemAdd.Size = new System.Drawing.Size(907, 384);
            this.pnItemAdd.TabIndex = 134;
            this.pnItemAdd.Visible = false;
            // 
            // dgvxcelupload
            // 
            this.dgvxcelupload.AllowUserToAddRows = false;
            this.dgvxcelupload.AllowUserToResizeRows = false;
            this.dgvxcelupload.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dgvxcelupload.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvxcelupload.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvxcelupload.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvxcelupload.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.xslno,
            this.xItemCode,
            this.xItemDesc,
            this.xMfgPartNo,
            this.xMake,
            this.xQty,
            this.xUnitcost,
            this.xSpecification,
            this.xItemType,
            this.xLocation,
            this.xVendor,
            this.xDrawingno,
            this.dataGridViewTextBoxColumn1});
            this.dgvxcelupload.EnableHeadersVisualStyles = false;
            this.dgvxcelupload.Location = new System.Drawing.Point(3, 42);
            this.dgvxcelupload.Name = "dgvxcelupload";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvxcelupload.RowHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dgvxcelupload.RowHeadersVisible = false;
            this.dgvxcelupload.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvxcelupload.Size = new System.Drawing.Size(896, 335);
            this.dgvxcelupload.TabIndex = 219;
            // 
            // xslno
            // 
            this.xslno.DataPropertyName = "slno";
            this.xslno.HeaderText = "SlNo";
            this.xslno.Name = "xslno";
            this.xslno.ReadOnly = true;
            this.xslno.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xslno.Width = 44;
            // 
            // xItemCode
            // 
            this.xItemCode.DataPropertyName = "ItemCode";
            this.xItemCode.HeaderText = "ItemCode";
            this.xItemCode.Name = "xItemCode";
            this.xItemCode.ReadOnly = true;
            this.xItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xItemCode.Width = 77;
            // 
            // xItemDesc
            // 
            this.xItemDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.xItemDesc.DataPropertyName = "ItemDesc";
            this.xItemDesc.HeaderText = "ItemDesc";
            this.xItemDesc.Name = "xItemDesc";
            this.xItemDesc.ReadOnly = true;
            this.xItemDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xItemDesc.Width = 99;
            // 
            // xMfgPartNo
            // 
            this.xMfgPartNo.DataPropertyName = "MfgPartNo";
            this.xMfgPartNo.HeaderText = "MfgPartNo";
            this.xMfgPartNo.Name = "xMfgPartNo";
            this.xMfgPartNo.ReadOnly = true;
            this.xMfgPartNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xMfgPartNo.Width = 85;
            // 
            // xMake
            // 
            this.xMake.DataPropertyName = "Make";
            this.xMake.HeaderText = "Make";
            this.xMake.Name = "xMake";
            this.xMake.ReadOnly = true;
            this.xMake.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xMake.Width = 50;
            // 
            // xQty
            // 
            this.xQty.DataPropertyName = "Qty";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.xQty.DefaultCellStyle = dataGridViewCellStyle19;
            this.xQty.HeaderText = "Qty";
            this.xQty.Name = "xQty";
            this.xQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xQty.Width = 38;
            // 
            // xUnitcost
            // 
            this.xUnitcost.DataPropertyName = "Unitcost";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.xUnitcost.DefaultCellStyle = dataGridViewCellStyle20;
            this.xUnitcost.HeaderText = "Unitcost ";
            this.xUnitcost.Name = "xUnitcost";
            this.xUnitcost.ReadOnly = true;
            this.xUnitcost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xUnitcost.Width = 73;
            // 
            // xSpecification
            // 
            this.xSpecification.DataPropertyName = "Specification";
            this.xSpecification.HeaderText = "Specification";
            this.xSpecification.Name = "xSpecification";
            this.xSpecification.ReadOnly = true;
            this.xSpecification.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xSpecification.Width = 97;
            // 
            // xItemType
            // 
            this.xItemType.DataPropertyName = "ItemType";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.xItemType.DefaultCellStyle = dataGridViewCellStyle21;
            this.xItemType.HeaderText = "ItemType";
            this.xItemType.Name = "xItemType";
            this.xItemType.ReadOnly = true;
            this.xItemType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xItemType.Width = 74;
            // 
            // xLocation
            // 
            this.xLocation.DataPropertyName = "Location";
            this.xLocation.HeaderText = "Location";
            this.xLocation.Name = "xLocation";
            this.xLocation.ReadOnly = true;
            this.xLocation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xLocation.Width = 70;
            // 
            // xVendor
            // 
            this.xVendor.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.xVendor.DataPropertyName = "Vendor";
            this.xVendor.HeaderText = "Vendor";
            this.xVendor.Name = "xVendor";
            this.xVendor.ReadOnly = true;
            this.xVendor.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xVendor.Width = 82;
            // 
            // xDrawingno
            // 
            this.xDrawingno.DataPropertyName = "Drawingno";
            this.xDrawingno.HeaderText = "Drawingno";
            this.xDrawingno.Name = "xDrawingno";
            this.xDrawingno.ReadOnly = true;
            this.xDrawingno.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xDrawingno.Width = 85;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Version";
            this.dataGridViewTextBoxColumn1.HeaderText = "Version";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 63;
            // 
            // pnexcelupload
            // 
            this.pnexcelupload.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnexcelupload.Controls.Add(this.btnUpload);
            this.pnexcelupload.Controls.Add(this.lbladditemcount);
            this.pnexcelupload.Controls.Add(this.lblbomitemlist);
            this.pnexcelupload.Controls.Add(this.btnbrowse);
            this.pnexcelupload.Controls.Add(this.txtbrowseaddres);
            this.pnexcelupload.Location = new System.Drawing.Point(5, 3);
            this.pnexcelupload.Name = "pnexcelupload";
            this.pnexcelupload.Size = new System.Drawing.Size(834, 35);
            this.pnexcelupload.TabIndex = 218;
            // 
            // btnUpload
            // 
            this.btnUpload.BackColor = System.Drawing.Color.PaleGreen;
            this.btnUpload.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpload.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpload.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnUpload.Location = new System.Drawing.Point(576, 1);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(50, 27);
            this.btnUpload.TabIndex = 65;
            this.btnUpload.Text = "Upload";
            this.btnUpload.UseVisualStyleBackColor = false;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // lbladditemcount
            // 
            this.lbladditemcount.AutoSize = true;
            this.lbladditemcount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladditemcount.ForeColor = System.Drawing.Color.Red;
            this.lbladditemcount.Location = new System.Drawing.Point(787, 4);
            this.lbladditemcount.Name = "lbladditemcount";
            this.lbladditemcount.Size = new System.Drawing.Size(15, 18);
            this.lbladditemcount.TabIndex = 64;
            this.lbladditemcount.Text = "0";
            // 
            // lblbomitemlist
            // 
            this.lblbomitemlist.AutoSize = true;
            this.lblbomitemlist.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbomitemlist.ForeColor = System.Drawing.Color.Black;
            this.lblbomitemlist.Location = new System.Drawing.Point(644, 4);
            this.lblbomitemlist.Name = "lblbomitemlist";
            this.lblbomitemlist.Size = new System.Drawing.Size(148, 18);
            this.lblbomitemlist.TabIndex = 63;
            this.lblbomitemlist.Text = "No of Items Uploaded:";
            // 
            // btnbrowse
            // 
            this.btnbrowse.BackColor = System.Drawing.Color.PaleGreen;
            this.btnbrowse.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnbrowse.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbrowse.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnbrowse.Location = new System.Drawing.Point(526, 1);
            this.btnbrowse.Name = "btnbrowse";
            this.btnbrowse.Size = new System.Drawing.Size(50, 27);
            this.btnbrowse.TabIndex = 1;
            this.btnbrowse.Text = "Browse";
            this.btnbrowse.UseVisualStyleBackColor = false;
            this.btnbrowse.Click += new System.EventHandler(this.btnbrowse_Click);
            // 
            // txtbrowseaddres
            // 
            this.txtbrowseaddres.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbrowseaddres.Location = new System.Drawing.Point(1, 4);
            this.txtbrowseaddres.Name = "txtbrowseaddres";
            this.txtbrowseaddres.ReadOnly = true;
            this.txtbrowseaddres.Size = new System.Drawing.Size(525, 22);
            this.txtbrowseaddres.TabIndex = 0;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnClose.Location = new System.Drawing.Point(844, 7);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(52, 29);
            this.btnClose.TabIndex = 215;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dgvItemList
            // 
            this.dgvItemList.AllowUserToAddRows = false;
            this.dgvItemList.AllowUserToDeleteRows = false;
            this.dgvItemList.AllowUserToResizeRows = false;
            this.dgvItemList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvItemList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvItemList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvItemList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.dgvItemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvItemList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCode,
            this.ItemDescription,
            this.DrawingNumber});
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvItemList.DefaultCellStyle = dataGridViewCellStyle24;
            this.dgvItemList.EnableHeadersVisualStyles = false;
            this.dgvItemList.Location = new System.Drawing.Point(3, 42);
            this.dgvItemList.MultiSelect = false;
            this.dgvItemList.Name = "dgvItemList";
            this.dgvItemList.ReadOnly = true;
            this.dgvItemList.RowHeadersVisible = false;
            this.dgvItemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvItemList.Size = new System.Drawing.Size(897, 335);
            this.dgvItemList.TabIndex = 214;
            this.dgvItemList.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dgvItemList_MouseDoubleClick);
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 87;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            this.ItemDescription.HeaderText = "Item Description";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // DrawingNumber
            // 
            this.DrawingNumber.DataPropertyName = "DrawingNo";
            this.DrawingNumber.HeaderText = "Drawing No";
            this.DrawingNumber.Name = "DrawingNumber";
            this.DrawingNumber.ReadOnly = true;
            this.DrawingNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DrawingNumber.Width = 98;
            // 
            // pnItemcode
            // 
            this.pnItemcode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnItemcode.Controls.Add(this.txtItemCode);
            this.pnItemcode.Controls.Add(this.chkItemCode);
            this.pnItemcode.Controls.Add(this.chkItemDesc);
            this.pnItemcode.Location = new System.Drawing.Point(10, 2);
            this.pnItemcode.Name = "pnItemcode";
            this.pnItemcode.Size = new System.Drawing.Size(829, 35);
            this.pnItemcode.TabIndex = 217;
            // 
            // btnImport
            // 
            this.btnImport.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnImport.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnImport.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnImport.Location = new System.Drawing.Point(390, 647);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(90, 30);
            this.btnImport.TabIndex = 135;
            this.btnImport.Text = "Import";
            this.btnImport.UseVisualStyleBackColor = false;
            this.btnImport.Visible = false;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // lblimportitems
            // 
            this.lblimportitems.AutoSize = true;
            this.lblimportitems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblimportitems.ForeColor = System.Drawing.Color.Black;
            this.lblimportitems.Location = new System.Drawing.Point(186, 652);
            this.lblimportitems.Name = "lblimportitems";
            this.lblimportitems.Size = new System.Drawing.Size(198, 19);
            this.lblimportitems.TabIndex = 138;
            this.lblimportitems.Text = "New items added for BOM :";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // lbltotalitems
            // 
            this.lbltotalitems.AutoSize = true;
            this.lbltotalitems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalitems.ForeColor = System.Drawing.Color.Black;
            this.lbltotalitems.Location = new System.Drawing.Point(397, 625);
            this.lbltotalitems.Name = "lbltotalitems";
            this.lbltotalitems.Size = new System.Drawing.Size(126, 19);
            this.lbltotalitems.TabIndex = 139;
            this.lbltotalitems.Text = "Total BOM Items:";
            // 
            // lblitemcount
            // 
            this.lblitemcount.AutoSize = true;
            this.lblitemcount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemcount.ForeColor = System.Drawing.Color.Red;
            this.lblitemcount.Location = new System.Drawing.Point(519, 626);
            this.lblitemcount.Name = "lblitemcount";
            this.lblitemcount.Size = new System.Drawing.Size(17, 19);
            this.lblitemcount.TabIndex = 140;
            this.lblitemcount.Text = "0";
            // 
            // rbItemcode
            // 
            this.rbItemcode.AutoSize = true;
            this.rbItemcode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbItemcode.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.rbItemcode.Location = new System.Drawing.Point(805, 337);
            this.rbItemcode.Name = "rbItemcode";
            this.rbItemcode.Size = new System.Drawing.Size(149, 23);
            this.rbItemcode.TabIndex = 143;
            this.rbItemcode.TabStop = true;
            this.rbItemcode.Text = "Add by Item Code";
            this.rbItemcode.UseVisualStyleBackColor = true;
            this.rbItemcode.Visible = false;
            this.rbItemcode.CheckedChanged += new System.EventHandler(this.rbItemcode_CheckedChanged);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // rbExcelitem
            // 
            this.rbExcelitem.AutoSize = true;
            this.rbExcelitem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbExcelitem.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.rbExcelitem.Location = new System.Drawing.Point(959, 337);
            this.rbExcelitem.Name = "rbExcelitem";
            this.rbExcelitem.Size = new System.Drawing.Size(149, 23);
            this.rbExcelitem.TabIndex = 145;
            this.rbExcelitem.TabStop = true;
            this.rbExcelitem.Text = "Add by Item Excel";
            this.rbExcelitem.UseVisualStyleBackColor = true;
            this.rbExcelitem.Visible = false;
            this.rbExcelitem.CheckedChanged += new System.EventHandler(this.rbExcelitem_CheckedChanged);
            // 
            // btnEmailRequest
            // 
            this.btnEmailRequest.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnEmailRequest.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnEmailRequest.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnEmailRequest.Location = new System.Drawing.Point(662, 647);
            this.btnEmailRequest.Name = "btnEmailRequest";
            this.btnEmailRequest.Size = new System.Drawing.Size(90, 30);
            this.btnEmailRequest.TabIndex = 146;
            this.btnEmailRequest.Text = "Email";
            this.btnEmailRequest.UseVisualStyleBackColor = false;
            this.btnEmailRequest.Visible = false;
            this.btnEmailRequest.Click += new System.EventHandler(this.btnEmailRequest_Click);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.ForeColor = System.Drawing.Color.Black;
            this.lblEmail.Location = new System.Drawing.Point(481, 652);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(181, 19);
            this.lblEmail.TabIndex = 147;
            this.lblEmail.Text = "Email Authorise request :";
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // frmDesignBOM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1308, 686);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.btnEmailRequest);
            this.Controls.Add(this.pnItemAdd);
            this.Controls.Add(this.lbltotalitems);
            this.Controls.Add(this.lblitemcount);
            this.Controls.Add(this.lblimportitems);
            this.Controls.Add(this.btnImport);
            this.Controls.Add(this.btnUpdateItem);
            this.Controls.Add(this.btnBOMRelaese);
            this.Controls.Add(this.btnAuthorise);
            this.Controls.Add(this.dgBOMList);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAutherisedBy);
            this.Controls.Add(this.txtPreparedBy);
            this.Controls.Add(this.lblPreparedBy);
            this.Controls.Add(this.gbControlButtons);
            this.Controls.Add(this.lblItemcodeorName);
            this.Controls.Add(this.txtItemSearch);
            this.Controls.Add(this.gbProjectDetails);
            this.Controls.Add(this.dgItemOrProductList);
            this.Controls.Add(this.tvProduct);
            this.Controls.Add(this.gbtreesearch);
            this.Controls.Add(this.rbItemcode);
            this.Controls.Add(this.rbExcelitem);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmDesignBOM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Design BOM";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmDesignBOM_FormClosing);
            this.Load += new System.EventHandler(this.frmDesignBOM_Load);
            this.gbProjectDetails.ResumeLayout(false);
            this.gbProjectDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).EndInit();
            this.gbtreesearch.ResumeLayout(false);
            this.gbtreesearch.PerformLayout();
            this.gbControlButtons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMList)).EndInit();
            this.pnItemAdd.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvxcelupload)).EndInit();
            this.pnexcelupload.ResumeLayout(false);
            this.pnexcelupload.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemList)).EndInit();
            this.pnItemcode.ResumeLayout(false);
            this.pnItemcode.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbProjectDetails;
        private System.Windows.Forms.Label lblProjectStaus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.Label txtcustomer;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.Label txtProjectName;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.ComboBox cmbProjectCode;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.DataGridView dgItemOrProductList;
        private System.Windows.Forms.GroupBox gbtreesearch;
        private System.Windows.Forms.Button cleartreeview;
        private System.Windows.Forms.TextBox txtsearchtree;
        private System.Windows.Forms.Button btnsearchtree;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.TextBox txtItemCode;
        private System.Windows.Forms.TreeView tvProduct;
        private System.Windows.Forms.Label lblItemcodeorName;
        private System.Windows.Forms.TextBox txtItemSearch;
        private System.Windows.Forms.GroupBox gbControlButtons;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label txtPreparedBy;
        private System.Windows.Forms.Label lblPreparedBy;
        private System.Windows.Forms.Label txtAutherisedBy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgBOMList;
        private System.Windows.Forms.DateTimePicker dtpCreatedDate;
        private System.Windows.Forms.Button btnAuthorise;
        private System.Windows.Forms.Button btnBOMRelaese;
        private System.Windows.Forms.Button btnUpdateItem;
        private System.Windows.Forms.ComboBox cmbVersion;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn NodeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectBOM;
        private System.Windows.Forms.DataGridViewTextBoxColumn DesignBOM;
        private System.Windows.Forms.Panel pnItemAdd;
        private System.Windows.Forms.DataGridView dgvItemList;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn DrawingNumber;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.Label lblimportitems;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label lbltotalitems;
        private System.Windows.Forms.Label lblitemcount;
        private System.Windows.Forms.RadioButton rbItemcode;
        private System.Windows.Forms.Panel pnItemcode;
        private System.Windows.Forms.Button btnDownload;
        private System.Windows.Forms.Panel pnexcelupload;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Label lbladditemcount;
        private System.Windows.Forms.Label lblbomitemlist;
        private System.Windows.Forms.Button btnbrowse;
        private System.Windows.Forms.TextBox txtbrowseaddres;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.DataGridView dgvxcelupload;
        private System.Windows.Forms.DataGridViewTextBoxColumn xslno;
        private System.Windows.Forms.DataGridViewTextBoxColumn xItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn xItemDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn xMfgPartNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn xMake;
        private System.Windows.Forms.DataGridViewTextBoxColumn xQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn xUnitcost;
        private System.Windows.Forms.DataGridViewTextBoxColumn xSpecification;
        private System.Windows.Forms.DataGridViewTextBoxColumn xItemType;
        private System.Windows.Forms.DataGridViewTextBoxColumn xLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn xVendor;
        private System.Windows.Forms.DataGridViewTextBoxColumn xDrawingno;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.RadioButton rbExcelitem;
        private System.Windows.Forms.DataGridViewTextBoxColumn uItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn uItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssuedQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn uBOMQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn DrawingNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Revision;
        private System.Windows.Forms.DataGridViewTextBoxColumn RefItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn Addedby;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.Button btnEmailRequest;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Timer timer3;
    }
}