﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Globalization;
using System.Data.OleDb;
using EXCEL = Microsoft.Office.Interop.Excel;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Erp_Project_With_Buttons.Design_BOM
{
    public partial class frmDesignBOM : Form
    {
        #region DataTable Declaration
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        frmForm2 form = new frmForm2();
        Login.frmLoginForm login = new Login.frmLoginForm();
        BindingSource bsItemList = new BindingSource();
        BindingSource bsIteSearch = new BindingSource();
        DataTable dtItemList = new DataTable();
        DataTable dtProjectList = new DataTable();
        DataTable dtTableFilter = new DataTable();
        DataTable dtTreeFromTable = new DataTable();
        DataTable dtDGDatatable = new DataTable();
        DataTable dtProjectBOMList = new DataTable();
        DataTable dtSelectedProjectBOMList = new DataTable();
        DataView dvItemList = new DataView();
        DataView dvProjectName = new DataView();
        DataView dvProjectBOMList = new DataView();
        DataTable dtProjectCheck = new DataTable();
        DataTable dtWIPProjectlist = new DataTable();
        DataTable dtParentid = new DataTable();
        DataTable dtCompleteBOM = new DataTable();
        DataTable dtProjectBOMDeleteDetail = new DataTable();
        DataTable dtProjectBOMDelete = new DataTable();
        DataTable dtMachineBOMDelete = new DataTable();
        DataTable dtIssuedBOMdelete = new DataTable();
        DataTable dtClone = new DataTable();
        DataTable dtNewGridviewItems = new DataTable();
        DataTable dtIssuedBOMItemQTY = new DataTable();
        DataTable dtItemsofMachineBOM = new DataTable();
        DataTable dtDeleteMachineBOMQty = new DataTable();
        DataTable dtUpdateMachineBOM = new DataTable();
        DataTable dtParentName = new DataTable();
        DataTable dtProductCode = new DataTable();
        DataRow DR;
        CultureInfo india = new CultureInfo("hi-IN");
        string sPBOMNo = string.Empty;
        private string sAutherisedPerson = string.Empty;
        private string[] sTableColumns = { "ProductCode", "ProductName", "ProductType", "UOM", "UnitCost", "Quantity", "NodeID" };
        private double fCost = 0.0;
        List<DataGridViewRow> lcheckedRow = new List<DataGridViewRow>();
        TreeNode tnCurrentParentNode = new TreeNode();

        double dNewTotalAmount;
        string sNName = string.Empty;
        string sProductName = string.Empty;
        private double sTotalAmount;
        public int Designform = 0;
        private static string sDesignBOMProjectCode;

        public string fnDesignBOMProjectcode
        {
            get
            {
                return sDesignBOMProjectCode;
            }
            set
            {
                sDesignBOMProjectCode = value;
            }
        }

        #endregion

        public frmDesignBOM()
        {
            InitializeComponent();
        }

        private void frmDesignBOM_Load(object sender, EventArgs e)
        {
            try
            {
                chkItemCode.Checked = true;
                txtPreparedBy.Text = Login.frmLoginForm.sUserDetails[2];
                cmbProjectCode.Text = Global.sCOMBOBOX_DEFAULT_TEXT;
                dtProjectList = DAL.fnProjectList(null).Tables[0];
                dtItemList = DAL.fnItemList(null).Tables[0];
                foreach (string str in sTableColumns)
                {
                    dtDGDatatable.Columns.Add(str);
                }
                dtWIPProjectlist = DAL.fnAllProjectList(null).Tables[0];

                if (dtWIPProjectlist.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtWIPProjectlist.Rows)
                    {
                        if (!cmbProjectCode.Items.Contains(DR["ProjectCode"].ToString()))
                            cmbProjectCode.Items.Add(DR["ProjectCode"].ToString());
                    }
                    dtTreeFromTable = DAL.fnGetProductTreeView().Tables["ProductTreeView"]; //get the tree folders and sub-folders from database
                    if (dtTreeFromTable.Rows.Count > 0)
                    {
                        tvProduct.Nodes.AddRange(GLobalClass.fnTreeFromTable(dtTreeFromTable, "ParentID", "NodeID", "Name", "ImageIndex")); // display the folders in the treeview
                        tnCurrentParentNode = null;
                        tvProduct.CollapseAll();
                        tvProduct.Sort();
                        tvProduct.Enabled = false;
                    }
                }
                dtProjectBOMList = DAL.fnProjectBOMList(null).Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("ProductMasterForm_frmProductMasterForm_Load " + ex.Message);
            }
        }

        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            fnTime3Stop();
            dgBOMList.DataSource = null;
            btnDownload.Visible = false;
            lblitemcount.Text = dgBOMList.Rows.Count.ToString();
            rbItemcode.Visible = false;
            rbExcelitem.Visible = false;
            tvProduct.Enabled = true;
            dvProjectName = new DataView(dtProjectList);
            dvProjectBOMList = new DataView(dtProjectBOMList);
            dvProjectName.RowFilter = "ProjectCode='" + cmbProjectCode.Text + "'";
            if (dvProjectName.ToTable().Rows.Count > 0)
            {
                txtProjectName.Text = dvProjectName.ToTable().Rows[0]["ProjectDescription"].ToString();
                txtcustomer.Text = dvProjectName.ToTable().Rows[0]["Customer"].ToString();
                lblProjectStaus.Text = dvProjectName.ToTable().Rows[0]["Status"].ToString();
            }
            dtDGDatatable = DAL.fnDirectProjectBOMList(cmbProjectCode.Text).Tables[0];
            if (dtDGDatatable.Rows.Count > 0)
            {
                dgItemOrProductList.AutoGenerateColumns = false;
                dgItemOrProductList.DataSource = dtDGDatatable;
                Datagridviewcolor();
            }
            else
            {
                dgItemOrProductList.DataSource = null;
            }
        }

        #region PO Item Color
        private void Datagridviewcolor()
        {
            foreach (DataGridViewRow dgr in dgItemOrProductList.Rows)
            {
                if (Convert.ToBoolean(dgr.Cells[8].Value) && !Convert.ToBoolean(dgr.Cells[9].Value))
                {
                    // dgr.DefaultCellStyle.BackColor = Color.SteelBlue;
                }
                else
                {
                    dgr.DefaultCellStyle.BackColor = Color.BurlyWood;
                }
            }
        }
        #endregion

        #region PO Item Color
        private void ItemDatagridviewcolor()
        {
            foreach (DataGridViewRow dgr in dgBOMList.Rows)
            {
                if ((dgr.Cells[9].Value.ToString()) == "Deactive")
                {
                    dgr.DefaultCellStyle.BackColor = Color.Red;
                }
            }
        }
        #endregion


        private void frmDesignBOM_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (GLobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                this.Hide();
                form.Show();
            }
            else
                e.Cancel = true;
        }
        string[] sNamee;
        string sParentName;
        private void tvProduct_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            sNName = e.Node.Name;
            sParentName = "";
            sNamee = e.Node.FullPath.ToString().Split('\\');
            int i = 0;
            for (i = 1; i < sNamee.Length - 1; i++)
            {
                if (i == 1)
                {
                    sParentName = sNamee[i];
                }
                else
                {
                    sParentName = sParentName + " / " + sNamee[i];
                }
            }
            tvProduct.SelectedNode = e.Node;
            tvProduct.LabelEdit = false;

            if (e.Node.Parent != null && e.Node != null && e.Node.Name != "All Product" && (e.Node.StateImageIndex == 2 || e.Node.StateImageIndex == 4))// || e.Node.StateImageIndex == 3))
            {
                dtParentName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                if (dtParentName.Rows.Count > 0)
                {
                    dtProductCode = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtParentName.Rows[0]["NodeID"].ToString()).Tables[0];
                    dtVersion = DAL.fnFullVersionList(dtProductCode.Rows[0]["NodeID"].ToString()).Tables[0];
                    cmbVersion.Items.Clear();
                    foreach (DataRow DR in dtVersion.Rows)
                    {
                        if (!cmbVersion.Items.Contains(DR["Version"].ToString()))
                            cmbVersion.Items.Add(DR["Version"].ToString());
                    }
                    timer1.Interval = _blinkFrequency;
                    lblVersion.Visible = true;
                    cmbVersion.Visible = true;
                    timer1.Start();
                }
            }
            else if (e.Node.StateImageIndex == 3)
            {
                bool bItemCheck = false;
                string Productcode;
                dtParentName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                dtProductCode = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtParentName.Rows[0]["NodeID"].ToString()).Tables[0];
                if (dtProductCode.Rows.Count > 0)
                {
                    Productcode = dtProductCode.Rows[0]["ProductCode"].ToString();
                    foreach (DataGridViewRow dr in dgItemOrProductList.Rows)
                    {
                        if (dr.Cells["ProductCode"].Value.ToString() == Productcode)
                        {
                            MessageBox.Show("Selected Product already present in the BOM item list", "Warning", 0, MessageBoxIcon.Warning);
                            bItemCheck = true;
                            break;
                        }
                    }
                }

                //dtParentName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                //if (dtParentName.Rows.Count > 0)
                //{
                //    dtProductCode = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtParentName.Rows[0]["NodeID"].ToString()).Tables[0];
                //    if (dtProductCode.Rows.Count > 0)
                //    {
                //        if (string.IsNullOrEmpty(dtProductCode.Rows[0]["BOMAuthorisedBy"].ToString()))
                //        {
                //            bItemCheck = true;
                //            MessageBox.Show("Selected Product is not authorised. Please contact the Authorised person ", "Warning", 0, MessageBoxIcon.Warning);
                //        }
                //    }
                //}
                if (!bItemCheck)
                {
                    fCost = 0.0;
                    dtParentid = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                    dtParentid = DAL.fnGetTreeNode(sNName, dtParentid.Rows[0]["NodeID"].ToString()).Tables[0];
                    if (dtParentid.Rows.Count > 0)
                    {
                        dtCompleteBOM = DAL.fnVersionProductBOMList(dtParentid.Rows[0]["NodeID"].ToString(), cmbVersion.Text).Tables[0];
                        if (dtCompleteBOM.Rows.Count > 0)
                        {
                            foreach (DataRow dr in dtCompleteBOM.Rows)
                            {
                                fCost += Convert.ToDouble(dr["Amount"].ToString());
                            }
                        }
                        DR = dtDGDatatable.NewRow();
                        DR["ProductCode"] = dtParentid.Rows[0]["ProductCode"].ToString();
                        DR["ProductName"] = dtParentid.Rows[0]["Name"].ToString();
                        DR["Version"] = "1";
                        DR["ProductType"] = sParentName;
                        DR["UnitCost"] = fCost;
                        DR["Quantity"] = 1;
                        DR["NodeID"] = dtParentid.Rows[0]["NodeID"].ToString();
                        DR["ProjectBOM"] = 1;
                        DR["DesignBOM"] = 1;
                        dtDGDatatable.Rows.Add(DR);
                        dgItemOrProductList.AutoGenerateColumns = false;
                        dgItemOrProductList.DataSource = dtDGDatatable;
                        Datagridviewcolor();
                        timer1.Stop();
                        if (dgItemOrProductList.Rows.Count > 0)
                        {
                            txtPreparedBy.Text = Login.frmLoginForm.sUserDetails[2];
                            txtAutherisedBy.Text = Login.frmLoginForm.sUserDetails[2];
                            if (!btnSave.Enabled)
                                btnSave_Click(sender, e);
                            // btnSave.Enabled = true;
                        }

                    }
                }
            }
            else
            {
                lblVersion.Visible = false;
                cmbVersion.Visible = false;
                timer1.Stop();
            }
        }

        private void gbProjectDetails_Enter(object sender, EventArgs e)
        {

        }
        DataTable dtLatestCost = new DataTable();
        DataTable dtBOMAuthorise = new DataTable();

        private void dgItemOrProductList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
             rbItemcode.Visible = true;
             rbExcelitem.Visible = true;
            if (Convert.ToBoolean(dgItemOrProductList.CurrentRow.Cells["DesignBOM"].Value))
            {
              //  if (Login.frmLoginForm.sUserDetails[2].ToLower() == "santhoshdj")
                {
                    dtBOMAuthorise = DAL.fnDesignProjectBOMAuthorise(1, dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text).Tables[0];
                    if (dtBOMAuthorise.Rows.Count > 0)
                    {
                        btnAuthorise.Enabled = true;
                    }
                    else
                    {
                        btnAuthorise.Enabled = false;
                    }
                    dtBOMAuthorise = DAL.fnDesignProjectBOMAuthorise(2, dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text).Tables[0];
                    if (dtBOMAuthorise.Rows.Count > 0)
                    {
                        btnBOMRelaese.Enabled = true;
                    }
                    else
                    {
                        btnBOMRelaese.Enabled = false;
                    }
                }
            }
            else
            {
                btnAuthorise.Enabled = false;
                btnBOMRelaese.Enabled = false;
            }

            dgBOMList.DataSource = null;
            lblitemcount.Text = dgBOMList.Rows.Count.ToString();
            string sIssuedQty = string.Empty;
            txtItemSearch.ResetText();
            dtNewGridviewItems = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text,
                dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(),"").Tables[0];
            if (dtNewGridviewItems.Rows.Count > 0)
            {
                fnToLoadMachineBOM();
            }
            else
            {
                dtNewGridviewItems = DAL.fnProductBOMViewList(dgItemOrProductList.CurrentRow.Cells["NodeId"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["Version"].Value.ToString()).Tables[0];
                dgBOMList.AutoGenerateColumns = false;
                dgBOMList.ReadOnly = true;
                dgBOMList.Columns[3].ReadOnly = true;
                dgBOMList.DataSource = dtNewGridviewItems;
                lblitemcount.Text = dgBOMList.Rows.Count.ToString();
            }
        }
        DataTable dtEXCELData = new DataTable();
        private void fnToLoadMachineBOM()
        {
            sProductName = dtNewGridviewItems.Rows[0]["ProductName"].ToString();
          //  dtItemsofMachineBOM = DAL.fnMachineBOMProdutViewItems(dtNewGridviewItems.Rows[0]["ProductNo"].ToString(), cmbProjectCode.Text).Tables[0];
            dtEXCELData = DAL.fnMachineBOMProduDownloadItems(dtNewGridviewItems.Rows[0]["ProductNo"].ToString(), cmbProjectCode.Text).Tables[0];
            dtLatestCost = DAL.fnLatestCost().Tables[0];
            foreach (DataRow rowSampleOne in dtLatestCost.Rows)
            {
                foreach (DataRow rowSampleTwo in dtItemsofMachineBOM.Rows)
                {
                    if (rowSampleTwo["ItemName"].ToString().Equals(rowSampleOne["ItemCode"].ToString()))
                    {
                        rowSampleTwo["LatestCost"] = Convert.ToDouble(rowSampleOne["PurchaseCost"].ToString());
                    }
                }
            }
            foreach (DataRow rowSampleTwo in dtItemsofMachineBOM.Rows)
            {
                if (rowSampleTwo["LatestCost"].ToString().Equals("0"))
                {
                    rowSampleTwo["LatestCost"] = Convert.ToDouble(rowSampleTwo["UnitCost"].ToString());
                }
            }
            if (dtItemsofMachineBOM.Rows.Count > 0)
            {
                dgBOMList.AutoGenerateColumns = false;
                dgBOMList.DataSource = dtItemsofMachineBOM;
                lblitemcount.Text = dgBOMList.Rows.Count.ToString();
                fnImportItemlist();
                ItemDatagridviewcolor();
                btnDownload.Visible = true;
            }
        }

        private void chkSelectItem_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void txtItemCode_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemCode.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemCode.Text);
                    RowFilter();
                }
            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemCode.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemCode.Text);
                    RowFilter();
                }
            }
        }

        #region Row Filter Function
        private void RowFilter()
        {
            if (dvItemList.Count > 0)
            {
                dgvItemList.AutoGenerateColumns = false;
                dgvItemList.DataSource = dvItemList.ToTable();
            }
        }
        #endregion


        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbProjectCode.Text))
            {
                fnSaveProjectBOM(cmbProjectCode.Text);

                if (GLobalClass.iSuccess > 0)
                {
                    MessageBox.Show("ProjectBOM generated and authorised successfully", "Success", 0, MessageBoxIcon.Information);
                    //this.Hide();
                    //Design_BOM.frmDesignBOM DesignBOM = new frmDesignBOM();
                    //DesignBOM.Show();
                }
            }
        }

        #region Save Function for BOM
        private void fnSaveProjectBOM(string sProjectCode)
        {
            DataTable dtResultProductTreeView = new DataTable();
            DataTable dtFinalResult = new DataTable();
            DataTable dtProjectBOMProdcuNumber = new DataTable();
            int iProjectBOMNumber = 0;
            int sLastProductNo = 0;
            string sLastProjectBOMCode = string.Empty;
            string sNewProjectBOMCode = string.Empty;

            if (dgItemOrProductList.Rows.Count > 0)
            {
                dtProjectBOMList = DAL.fnProjectBOMList(sProjectCode).Tables[0];
                dtProjectBOMProdcuNumber = DAL.fnProjectBOMProdcuNumber(sProjectCode).Tables[0];

                if (dtProjectBOMList.Rows.Count > 0)
                {
                    sPBOMNo = dtProjectBOMList.Rows[0]["ProjectBOMCode"].ToString();

                    if (!string.IsNullOrEmpty(sPBOMNo))
                    {
                        sNewProjectBOMCode = sPBOMNo;
                    }
                }

                if (string.IsNullOrEmpty(sNewProjectBOMCode))
                {
                    sLastProjectBOMCode = DAL.fnGetLastProjectBOMCode();
                    if (sLastProjectBOMCode != string.Empty)
                    {
                        iProjectBOMNumber = Convert.ToInt32(sLastProjectBOMCode.Substring(5)) + 1;
                        sNewProjectBOMCode = string.Concat("PBOM00" + Convert.ToString(iProjectBOMNumber));
                    }
                    else
                    {
                        sNewProjectBOMCode = "PBOM001";
                    }
                }

                bool bNewItem = true;

                foreach (DataGridViewRow DGVR in dgItemOrProductList.Rows)
                {
                    bNewItem = true;
                    foreach (DataRow DGVR1 in dtProjectBOMList.Rows)
                    {
                        if (DGVR1["ProductCode"].ToString() == DGVR.Cells["ProductCode"].Value.ToString())
                        {
                            bNewItem = false;
                            break;
                        }
                    }
                    if (bNewItem)
                    {
                        dtProjectBOMProdcuNumber = DAL.fnProjectBOMProdcuNumber(sProjectCode).Tables[0];
                        if (dtProjectBOMProdcuNumber.Rows.Count > 0)
                        {
                            sLastProductNo = Convert.ToInt32(dtProjectBOMProdcuNumber.Rows[0]["ProductNo"].ToString());
                            iProjectBOMNumber = Convert.ToInt32(dtProjectBOMProdcuNumber.Rows[0]["ProjectBOMNumber"].ToString());
                        }

                        sLastProductNo++;
                        string sQty = DGVR.Cells["Quantity"].Value.ToString();
                        if (string.IsNullOrEmpty(sQty))
                        { sQty = "1"; }

                      //  GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uINSERT, sNewProjectBOMCode, sProjectCode, sLastProductNo.ToString(), DGVR.Cells["ProductName"].Value.ToString(), Convert.ToDouble(sQty.ToString()),
                       // Convert.ToDouble(DGVR.Cells["UnitCost"].Value.ToString()), txtPreparedBy.Text, dtpCreatedDate.Text, null, "", DGVR.Cells["Version"].Value.ToString(), DGVR.Cells["ProductCode"].Value.ToString(), DGVR.Cells["ProductType"].Value.ToString(), iProjectBOMNumber, lblProjectStaus.Text, "1", "1", "");

                        dtResultProductTreeView = DAL.fnProductBOMList(null, DGVR.Cells["ProductCode"].Value.ToString()).Tables[0];

                        string snodeid = string.Empty;
                        if (dtResultProductTreeView.Rows.Count > 0)
                        {
                            snodeid = dtResultProductTreeView.Rows[0]["Nodeid"].ToString();
                        }
                        dtFinalResult = DAL.fnVersionProductBOMList(snodeid, DGVR.Cells["Version"].Value.ToString()).Tables[0];
                        dtProjectBOMProdcuNumber = DAL.fnProjectBOMProdcuNumber(sProjectCode).Tables[0];
                        double Qty = 0;
                        if (dtFinalResult.Rows.Count > 0)
                        {
                            if (dtResultProductTreeView.Rows[0]["ImageIndex"].ToString() == "2")
                            {
                                foreach (DataRow dtMachineBOM in dtFinalResult.Rows)
                                {
                                    Qty = Convert.ToDouble(dtMachineBOM["Quantity"].ToString()) * Convert.ToDouble(dtProjectBOMProdcuNumber.Rows[0]["Quantity"].ToString());

                                    //GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uINSERT, dtProjectBOMProdcuNumber.Rows[0]["ProjectBOMCode"].ToString(), sLastProductNo.ToString(),
                                    //    dtMachineBOM["ItemCode"].ToString(), dtProjectBOMProdcuNumber.Rows[0]["ProjectCode"].ToString(), dtMachineBOM["MfgPartNo"].ToString(), dtMachineBOM["Make"].ToString(), dtMachineBOM["Specification"].ToString(),
                                    //    dtMachineBOM["Location"].ToString(), dtMachineBOM["Vendor"].ToString(), dtMachineBOM["DrawingNo"].ToString(), Qty, 0, 0, lblProjectStaus.Text, login.GetUserDetails[2], dtpCreatedDate.Text);
                                }
                            }
                            else
                            {
                                foreach (DataRow dtMachineBOM in dtFinalResult.Rows)
                                {
                                    Qty = Convert.ToDouble(dtMachineBOM["Quantity"].ToString()) * Convert.ToDouble(dtProjectBOMProdcuNumber.Rows[0]["Quantity"].ToString());

                                    //GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uINSERT, dtProjectBOMProdcuNumber.Rows[0]["ProjectBOMCode"].ToString(), sLastProductNo.ToString(),
                                    //    dtMachineBOM["ItemCode"].ToString(), dtProjectBOMProdcuNumber.Rows[0]["ProjectCode"].ToString(), dtMachineBOM["MfgPartNo"].ToString(), dtMachineBOM["Make"].ToString(), dtMachineBOM["Specification"].ToString(),
                                    //    dtMachineBOM["Location"].ToString(), dtMachineBOM["Vendor"].ToString(), dtMachineBOM["DrawingNo"].ToString(), Qty, 0, Qty, lblProjectStaus.Text, login.GetUserDetails[2], dtpCreatedDate.Text);
                                }
                            }
                        }
                    }
                }
            }
        }
        #endregion

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }
        string[] sItemCode;
        DataTable dtSelectItemList = new DataTable();
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {

        }

        #region Total Amount Function
        private void fnTotalAmount(double sAmount)
        {
            dNewTotalAmount = 0.0;
            double number = sAmount;
            int intPortion = (int)number;
            decimal fraction = (decimal)(number - intPortion) * 100;
            int decPortion = (int)Math.Round(fraction);
            if (decPortion < 50)
            {
                double number1 = (double)Math.Round(number);
                dNewTotalAmount = number1;
            }
            else
            {
                double number1 = (double)Math.Ceiling(number);
                dNewTotalAmount = number1;
            }
        }
        #endregion

        private void btnAuthorise_Click(object sender, EventArgs e)
        {
            GLobalClass.iSuccess = DAL.fnUpdateDesignProjectBOM(0, dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text, Login.frmLoginForm.sUserDetails[2], "");
            MessageBox.Show("BOM Authorised Successfully.", "Success", 0, MessageBoxIcon.Information);
        }

        private void btnBOMRelaese_Click(object sender, EventArgs e)
        {
            GLobalClass.iSuccess = DAL.fnUpdateDesignProjectBOM(1, dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text, Login.frmLoginForm.sUserDetails[2], "1");
            MessageBox.Show("BOM released Successfully.", "Success", 0, MessageBoxIcon.Information);
        }
        double dOldQty;
        private void dgBOMList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgBOMList.CurrentCell.OwningColumn.Name == "uBOMQty") //|| dgbomlist.CurrentCell.OwningColumn.Name == "Amount" || dgbomlist.CurrentCell.OwningColumn.Name == "ReqQty")
            {
                dOldQty = Convert.ToDouble(dgBOMList.CurrentCell.Value);
            }
        }

        private void dgBOMList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgBOMList.CurrentCell.OwningColumn.Name == "uBOMQty")
            {
                if (!string.IsNullOrEmpty(dgBOMList.CurrentCell.Value.ToString()) && (dgBOMList.CurrentCell.Value.ToString() != "."))// != null)
                {
                    if (Convert.ToDouble(dgBOMList.CurrentCell.Value.ToString()) != 0)
                    {
                        if (Convert.ToDouble(dgBOMList.CurrentCell.Value.ToString()) != dOldQty)
                        {
                            if (Convert.ToDouble(dgBOMList.CurrentRow.Cells["uBOMQty"].Value) >= Convert.ToDouble(dgBOMList.CurrentRow.Cells["IssuedQuantity"].Value))// && (Convert.ToDouble(dgBOMList.CurrentCell.Value.ToString()) != oldvalue))
                            {
                               // dtUpdateMachineBOM = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text).Tables[0];
                                if (dtUpdateMachineBOM.Rows.Count > 0)
                                {
                                    //GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uUPDATE, dtUpdateMachineBOM.Rows[0]["ProjectBOMCode"].ToString(), dtUpdateMachineBOM.Rows[0]["ProductNo"].ToString(), dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), dtUpdateMachineBOM.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null, Convert.ToDouble(dgBOMList.CurrentRow.Cells["uBOMQty"].Value), 0, 0, null, login.GetUserDetails[2], dtpCreatedDate.Text);

                                    dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value) - Convert.ToDouble(dgBOMList.CurrentRow.Cells["BOMAmount"].Value);

                                    double dc;

                                    dc = Convert.ToDouble(dgBOMList.CurrentRow.Cells["uBOMQty"].Value.ToString()) * Convert.ToDouble(dgBOMList.CurrentRow.Cells["UnitPrice"].Value.ToString());
                                    dc = Math.Round((Double)dc, 2);
                                    fnTotalAmount(dc);
                                    dgBOMList.CurrentRow.Cells["BOMAmount"].Value = dNewTotalAmount.ToString();
                                    dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value) + Convert.ToDouble(dgBOMList.CurrentRow.Cells["BOMAmount"].Value);

                                    fnTotalAmount(Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value));
                                    dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = dNewTotalAmount.ToString();

                                   // dtProjectCheck = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text).Tables[0];
                                    if (dtProjectCheck.Rows.Count > 0)
                                    {
                                        //GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uUPDATE, null, cmbProjectCode.Text, dtProjectCheck.Rows[0]["ProductNo"].ToString(), dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(),
                                        //    Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value), null, null, null, null, null, null, null, 0, null, "", "", "");

                                    }

                                    MessageBox.Show("'" + dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString() + "'  BOM Quantity Updated.", "Success", 0, MessageBoxIcon.Information);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Items already issued for the product. Entered value should be greater than issued quanity ", "Error", 0, MessageBoxIcon.Error);
                                dgBOMList.CurrentCell.Value = dOldQty;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Entered value should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                        dgBOMList.CurrentCell.Value = dOldQty;
                    }
                }
                else
                {
                    MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                    dgBOMList.CurrentCell.Value = dOldQty;
                }
            }
            else if (dgBOMList.CurrentCell.OwningColumn.Name == "Revision")
            {
                if (!string.IsNullOrEmpty(dgBOMList.CurrentCell.Value.ToString()))
                {
                    dtUpdateMachineBOM = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text,
                        dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(),"").Tables[0];
                    if (dtUpdateMachineBOM.Rows.Count > 0)
                    {
                        dgBOMList.CurrentRow.Cells["RefItemCode"].Value = dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString() + "--" + dgBOMList.CurrentRow.Cells["Revision"].Value.ToString();

                        //GLobalClass.iSuccess = DAL.fnAddMachineBOM(6, dtUpdateMachineBOM.Rows[0]["ProjectBOMCode"].ToString(), dtUpdateMachineBOM.Rows[0]["ProductNo"].ToString(),
                        //    dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), dtUpdateMachineBOM.Rows[0]["ProjectCode"].ToString(), dgBOMList.CurrentRow.Cells["RefItemCode"].Value.ToString(), null, null, null, null, null,
                        //        0, 0, 0, dgBOMList.CurrentRow.Cells["Revision"].Value.ToString(), login.GetUserDetails[2], dtpCreatedDate.Text);
                    }
                }
            }
        }


        private void txtItemSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtItemSearch.TextLength > 2)
            {
                if (dtItemsofMachineBOM.Rows.Count > 0)
                {
                    dtClone = dtItemsofMachineBOM.Copy();
                    bsIteSearch.DataSource = dtClone;

                    bsIteSearch.Filter = string.Format("ItemName LIKE '%{0}%' OR ItemDescription LIKE '%{0}%'", txtItemSearch.Text);
                    dgBOMList.DataSource = bsIteSearch;
                }
            }
            else
            {
                bsIteSearch.RemoveFilter();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (GLobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                this.Hide();
                form.Show();
            }
        }

        private void dgBOMList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (dgBOMList.Rows.Count > 0)
                {
                    if (Convert.ToDouble(dgBOMList.CurrentRow.Cells["IssuedQuantity"].Value) == 0)
                    {
                        DialogResult DR = MessageBox.Show("Do you want to delete selected Item?  " + dgBOMList.CurrentRow.Cells["uItemDescription"].Value.ToString() + "", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (DR == DialogResult.Yes)
                        {
                            //dtDeleteMachineBOMQty = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text).Tables[0];
                            if (dtDeleteMachineBOMQty.Rows.Count > 0)
                            {
                               // GLobalClass.iSuccess = DAL.fnDeleteMachineBOMItem(Global.uDELETE, cmbProjectCode.Text, dtDeleteMachineBOMQty.Rows[0]["ProductNo"].ToString(), dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString());

                                dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value.ToString()) - Convert.ToDouble(dgBOMList.CurrentRow.Cells["BOMAmount"].Value.ToString());

                                fnTotalAmount(Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value));
                                dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = dNewTotalAmount.ToString();

                                dtProjectCheck = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text,
                                    dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(),"").Tables[0];
                                if (dtProjectCheck.Rows.Count > 0)
                                {
                                    //GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uUPDATE, null, cmbProjectCode.Text, dtProjectCheck.Rows[0]["ProductNo"].ToString(), dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(),
                                    //    Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value), null, null, null, null, null, null, null, 0, null, "", "", "");

                                    MessageBox.Show("'" + dgBOMList.CurrentRow.Cells["uItemDescription"].Value.ToString() + "'  Machine BOM Item Deleted.", "Information", 0, MessageBoxIcon.Information);
                                    dgBOMList.Rows.RemoveAt(dgBOMList.Rows.IndexOf(dgBOMList.CurrentRow));
                                    lblitemcount.Text = dgBOMList.Rows.Count.ToString();
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("'" + dgBOMList.CurrentRow.Cells["uItemDescription"].Value.ToString() + "'  Machine BOM Item Already Issued. Cannot be deleted!!", "Warning", 0, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        bool bIssuedItem;
        private void dgItemOrProductList_KeyUp(object sender, KeyEventArgs e)
        {
            if (Convert.ToBoolean(dgItemOrProductList.CurrentRow.Cells["DesignBOM"].Value.ToString()))
            {
                if (e.KeyCode == Keys.Delete)
                {
                    if (dgItemOrProductList.Rows.Count > 0)
                    {
                        DialogResult DR = MessageBox.Show("Do you want to delete selected BOM  '" + dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString() + "'", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (DR == DialogResult.Yes)
                        {
                            bIssuedItem = true;
                            foreach (DataGridViewRow dgbom in dgBOMList.Rows)
                            {
                                if (Convert.ToDouble(dgBOMList.CurrentRow.Cells["IssuedQuantity"].Value) > 0)
                                {
                                    bIssuedItem = false;
                                    break;
                                }
                            }
                            if (bIssuedItem)
                            {
                               // dtProjectBOMDeleteDetail = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text).Tables[0];

                                if (dtProjectBOMDeleteDetail.Rows.Count > 0)
                                {
                                    //GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uDELETE, dtProjectBOMDeleteDetail.Rows[0]["ProjectBOMCode"].ToString(), cmbProjectCode.Text,
                                    //    dtProjectBOMDeleteDetail.Rows[0]["ProductNo"].ToString(), sProductName, Convert.ToDouble(null), Convert.ToDouble(null), null, null, null, null, null, null, null, 0, null, "1", "1", "");

                                    //GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uDELETE, dtProjectBOMDeleteDetail.Rows[0]["ProjectBOMCode"].ToString(), dtProjectBOMDeleteDetail.Rows[0]["ProductNo"].ToString(),
                                    //    null, dtProjectBOMDeleteDetail.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null, 0, 0, 0, null, null, null);

                                    dgItemOrProductList.Rows.RemoveAt(dgItemOrProductList.Rows.IndexOf(dgItemOrProductList.CurrentRow));

                                    MessageBox.Show("BOM '" + sProductName + "' deleted successfully.", "Information", 0, MessageBoxIcon.Information);
                                }
                                else
                                {
                                    dgItemOrProductList.Rows.RemoveAt(dgItemOrProductList.Rows.IndexOf(dgItemOrProductList.CurrentRow));
                                }
                            }
                            else
                            {
                                MessageBox.Show("BOM Cannot be deleted.Some Items are already Issued for the selected BOM", "Error", 0, MessageBoxIcon.Error);
                            }
                            if (dgItemOrProductList.Rows.Count == 0)
                            {
                                btnSave.Enabled = false;
                                dgBOMList.DataSource = null;
                                lblitemcount.Text = dgBOMList.Rows.Count.ToString();
                            }
                        }
                    }
                }
            }
        }

        private void btnUpdateItem_Click(object sender, EventArgs e)
        {
            dtItemList = DAL.fnItemList(null).Tables[0];
        }

        private void dgBOMList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void btnProjectView_Click(object sender, EventArgs e)
        {
            Designform = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnDesignBOMProjectcode = Designform.ToString();
            projectsearch.ShowDialog();
            if (fnDesignBOMProjectcode != null)
            {
                cmbProjectCode.Text = sDesignBOMProjectCode;
            }
        }

        private void cmbVersion_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool bItemCheck = false;
            string Productcode;
            dtProductCode = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtParentName.Rows[0]["NodeID"].ToString()).Tables[0];
            if (dtProductCode.Rows.Count > 0)
            {
                Productcode = dtProductCode.Rows[0]["ProductCode"].ToString();
                foreach (DataGridViewRow dr in dgItemOrProductList.Rows)
                {
                    if (dr.Cells["ProductCode"].Value.ToString() == Productcode)
                    {
                        MessageBox.Show("Selected Product already present in the BOM item list", "Warning", 0, MessageBoxIcon.Warning);
                        bItemCheck = true;
                        break;
                    }
                }
            }

            //dtParentName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
            //if (dtParentName.Rows.Count > 0)
            //{
            //    dtProductCode = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtParentName.Rows[0]["NodeID"].ToString()).Tables[0];
            //    if (dtProductCode.Rows.Count > 0)
            //    {
            //        if (string.IsNullOrEmpty(dtProductCode.Rows[0]["BOMAuthorisedBy"].ToString()))
            //        {
            //            bItemCheck = true;
            //            MessageBox.Show("Selected Product is not authorised. Please contact the Authorised person ", "Warning", 0, MessageBoxIcon.Warning);
            //        }
            //    }
            //}
            if (!bItemCheck)
            {
                fCost = 0.0;
                dtParentid = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                dtParentid = DAL.fnGetTreeNode(sNName, dtParentid.Rows[0]["NodeID"].ToString()).Tables[0];
                if (dtParentid.Rows.Count > 0)
                {
                    dtCompleteBOM = DAL.fnVersionProductBOMList(dtParentid.Rows[0]["NodeID"].ToString(), cmbVersion.Text).Tables[0];
                    if (dtCompleteBOM.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dtCompleteBOM.Rows)
                        {
                            fCost += Convert.ToDouble(dr["Amount"].ToString());
                        }
                    }
                    DR = dtDGDatatable.NewRow();
                    DR["ProductCode"] = dtParentid.Rows[0]["ProductCode"].ToString();
                    DR["ProductName"] = dtParentid.Rows[0]["Name"].ToString();
                    DR["Version"] = cmbVersion.Text;
                    DR["ProductType"] = sParentName;
                    DR["UnitCost"] = fCost;
                    DR["Quantity"] = 1;
                    DR["NodeID"] = dtParentid.Rows[0]["NodeID"].ToString();
                    DR["ProjectBOM"] = 1;
                    DR["DesignBOM"] = 1;
                    dtDGDatatable.Rows.Add(DR);
                    dgItemOrProductList.AutoGenerateColumns = false;
                    dgItemOrProductList.DataSource = dtDGDatatable;
                    Datagridviewcolor();
                    timer1.Stop();
                    if (dgItemOrProductList.Rows.Count > 0)
                    {
                        txtPreparedBy.Text = Login.frmLoginForm.sUserDetails[2];
                        txtAutherisedBy.Text = Login.frmLoginForm.sUserDetails[2];
                        if (!btnSave.Enabled)
                            btnSave.Enabled = true;
                    }
                }
            }
        }

        private const int _blinkFrequency = 250;
        private const int _maxNumberOfBlinks = 1000;
        private int _blinkCount = 0;
        DataTable dtVersion = new DataTable();

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblVersion.ForeColor = Color.Red;
            lblVersion.Visible = !lblVersion.Visible;
            _blinkCount++;
            if (_blinkCount == _maxNumberOfBlinks * 2)
            {
                timer1.Stop();
                lblVersion.Visible = true;
            }
        }

        private List<TreeNode> CurrentNodeMatches = new List<TreeNode>();
        private int LastNodeIndex = 0;
        private string LastSearchText;

        private void btnsearchtree_Click(object sender, EventArgs e)
        {
            string searchText = txtsearchtree.Text;
            if (String.IsNullOrEmpty(searchText))
            {
                return;
            };
            if (LastSearchText != searchText)
            {
                CurrentNodeMatches.Clear();
                LastSearchText = searchText;
                LastNodeIndex = 0;
                SearchNodes(searchText, tvProduct.Nodes[0]);
            }
            if (LastNodeIndex >= 0 && CurrentNodeMatches.Count > 0 && LastNodeIndex < CurrentNodeMatches.Count)
            {
                TreeNode selectedNode = CurrentNodeMatches[LastNodeIndex];
                LastNodeIndex++;
                this.tvProduct.SelectedNode = selectedNode;
                this.tvProduct.SelectedNode.Expand();
                this.tvProduct.Select();
            }
        }

        private void SearchNodes(string SearchText, TreeNode StartNode)
        {
            while (StartNode != null)
            {
                if (StartNode.Text.ToLower().Contains(SearchText.ToLower()))
                {
                    CurrentNodeMatches.Add(StartNode);
                };
                if (StartNode.Nodes.Count != 0)
                {
                    SearchNodes(SearchText, StartNode.Nodes[0]);//Recursive Search 
                };
                StartNode = StartNode.NextNode;
            };
        }

        private void cleartreeview_Click(object sender, EventArgs e)
        {
            txtsearchtree.ResetText();
            LastSearchText = "";
            tvProduct.CollapseAll();
        }

        private void txtsearchtree_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnsearchtree_Click(sender, e);
            }
        }

        private void btnAddItems_Click(object sender, EventArgs e)
        {
          
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            pnItemAdd.Visible = false;
        }

        private void dgvItemList_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            bool bItemCheck = false;
            sItemCode = dgvItemList.CurrentRow.Cells[0].Value.ToString().Trim().Split('`'); //;// chklbItemList.SelectedItem.ToString().Trim().Split(')');
            // string sID = sItemCode[0];
            dtSelectItemList = DAL.fnAddItemList(sItemCode[0]).Tables[0];
            if (dtSelectItemList.Rows.Count > 0)
            {
                foreach (DataGridViewRow dr in dgBOMList.Rows)
                {
                    if (dr.Cells["uItemCode"].Value.ToString().Trim().ToLower() == dtSelectItemList.Rows[0]["ItemCode"].ToString().Trim().ToLower())
                    {
                        MessageBox.Show("Selected Itemcode already present in the BOM item list", "Warning", 0, MessageBoxIcon.Warning);
                        bItemCheck = true;
                        break;
                    }
                }
                if (!bItemCheck)
                {
                    fCost = 0.0;
                    dtItemsofMachineBOM.Rows.Add(null, null, dtSelectItemList.Rows[0]["ItemCode"].ToString(), dtSelectItemList.Rows[0]["ItemDescription"].ToString(), "1", "0", dtSelectItemList.Rows[0]["UnitCost"].ToString(), dtSelectItemList.Rows[0]["UnitCost"].ToString(), dtSelectItemList.Rows[0]["UnitCost"].ToString(), null, dtSelectItemList.Rows[0]["DrawingNo"].ToString(),null,null, login.GetUserDetails[2], dtpCreatedDate.Text);
                    dgBOMList.DataSource = dtItemsofMachineBOM;
                    lblitemcount.Text = dgBOMList.Rows.Count.ToString();
                    dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value) + (Convert.ToDouble(dtSelectItemList.Rows[0]["UnitCost"].ToString()));

                    fnTotalAmount(Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value));
                    dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = dNewTotalAmount.ToString();

                    //dtProjectCheck = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text).Tables[0];
                    if (dtProjectCheck.Rows.Count > 0)
                    {
                        //GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uINSERT, dtProjectCheck.Rows[0]["ProjectBOMCode"].ToString(), dtProjectCheck.Rows[0]["ProductNo"].ToString(), dtSelectItemList.Rows[0]["ItemCode"].ToString(), dtProjectCheck.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null, 1, 1, 0, lblProjectStaus.Text, login.GetUserDetails[2], dtpCreatedDate.Text);

                      //  GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uUPDATE, null, cmbProjectCode.Text, dtProjectCheck.Rows[0]["ProductNo"].ToString(), dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value), null, null, null, null, null, null, null, 0, null, "", "", "");

                        if (GLobalClass.iSuccess > 0)
                        {
                            MessageBox.Show("'" + dtSelectItemList.Rows[0]["ItemDescription"].ToString() + "'  Added to Design BOM item list", "Success", 0, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Selected Item is deactivated. Please activate & try to add ", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            lblimportitems.ForeColor = Color.Red;
            lblimportitems.Visible = !lblimportitems.Visible;
            _blinkCount++;
            if (_blinkCount == _maxNumberOfBlinks * 2)
            {
                timer2.Stop();
                lblimportitems.Visible = true;
            }
        }

        List<string> lTreeviewList = new List<string>();
        DataTable dtImportItems = new DataTable();
        DataTable dtImportProductNode = new DataTable();
        private void fnImportItemlist()
        {
            lTreeviewList.Clear();
            dtImportProductNode = DAL.fnProductName(dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString()).Tables[0];
            dtImportItems = DAL.fnProductBOMViewList(dtImportProductNode.Rows[0]["NodeId"].ToString(), dgItemOrProductList.CurrentRow.Cells["Version"].Value.ToString()).Tables[0];
            foreach (DataRow dr in dtItemsofMachineBOM.Rows)
            {
                lTreeviewList.Add(dr["ItemName"].ToString());
            }

            if (lTreeviewList.Count > 0)
            {
                for (int i = 0; i < dtImportItems.Rows.Count; i++)
                {
                    foreach (string s in lTreeviewList)
                    {
                        if (lTreeviewList.Contains(dtImportItems.Rows[i][1].ToString()))
                        {
                            dtImportItems.Rows.RemoveAt(i);
                            i--;
                            break;
                        }
                    }
                }
                if (dtImportItems.Rows.Count > 0)
                {
                    fnTime2Start();
                }
                else
                {
                    fnTime2Stop();
                }
            }
        }

        private void fnTime2Start()
        {
            btnImport.Visible = true;
            btnImport.Visible = true;
            timer2.Interval = _blinkFrequency;
            lblimportitems.Visible = true;
            timer2.Start();
        }

        private void fnTime3Start()
        {
            btnEmailRequest.Visible = true;
            timer3.Interval = _blinkFrequency;
            lblEmail.Visible = true;
            timer3.Start();
        }

        private void fnTime3Stop()
        {
            timer3.Stop();
            btnEmailRequest.Visible = false;
            lblEmail.Visible = false;
        }
        private void fnTime2Stop()
        {
            timer2.Stop();
            btnImport.Visible = false;
            lblimportitems.Visible = false;
        }
        private void btnImport_Click(object sender, EventArgs e)
        {
            ////foreach (DataRow dtMachineBOM in dtImportItems.Rows)
            ////{
            ////    Qty = Convert.ToDouble(dtMachineBOM["Quantity"].ToString()) * Convert.ToDouble(dtProjectBOMProdcuNumber.Rows[0]["Quantity"].ToString());

            ////    GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uINSERT, dtProjectBOMProdcuNumber.Rows[0]["ProjectBOMCode"].ToString(), sLastProductNo.ToString(),
            ////        dtMachineBOM["ItemCode"].ToString(), dtProjectBOMProdcuNumber.Rows[0]["ProjectCode"].ToString(), dtMachineBOM["MfgPartNo"].ToString(), dtMachineBOM["Make"].ToString(), dtMachineBOM["Specification"].ToString(),
            ////        dtMachineBOM["Location"].ToString(), dtMachineBOM["Vendor"].ToString(), dtMachineBOM["DrawingNo"].ToString(), Qty, 0, Convert.ToInt32(Qty), lblProjectStaus.Text);
            ////}

            //// dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value) + (Convert.ToDouble(dtSelectItemList.Rows[0]["UnitCost"].ToString()));

            ////  fnTotalAmount(Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value));
            ////  dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = dNewTotalAmount.ToString();

            //dtProjectCheck = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text).Tables[0];
            //if (dtProjectCheck.Rows.Count > 0)
            //{

            //    // GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uINSERT, dtProjectCheck.Rows[0]["ProjectBOMCode"].ToString(), dtProjectCheck.Rows[0]["ProductNo"].ToString(), dtSelectItemList.Rows[0]["ItemCode"].ToString(),
            //    //dtProjectCheck.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null, 1, 1, 0, lblProjectStaus.Text);


            //    foreach (DataRow dtMachineBOM in dtImportItems.Rows)
            //    {
            //        Double Qty = Convert.ToDouble(dtMachineBOM["Quantity"].ToString()) * Convert.ToDouble(dtProjectCheck.Rows[0]["Quantity"].ToString());

            //        //GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uINSERT, dtProjectCheck.Rows[0]["ProjectBOMCode"].ToString(), dtProjectCheck.Rows[0]["ProductNo"].ToString(),
            //        //    dtMachineBOM["ItemName"].ToString(), dtProjectCheck.Rows[0]["ProjectCode"].ToString(), dtMachineBOM["MfgPartNo"].ToString(), dtMachineBOM["Make"].ToString(), dtMachineBOM["Specification"].ToString(),
            //        //    dtMachineBOM["Location"].ToString(), dtMachineBOM["Vendor"].ToString(), dtMachineBOM["DrawingNo"].ToString(), Qty, 0, 0, lblProjectStaus.Text, login.GetUserDetails[2], dtpCreatedDate.Text);
            //    }

            //    fnToLoadMachineBOM();
            //    sTotalAmount = 0;
            //    foreach (DataGridViewRow dgvr in dgBOMList.Rows)
            //    {
            //        sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitPrice"].Value) * Convert.ToDouble(dgvr.Cells["uBOMQty"].Value);
            //    }
            //    fnTotalAmount(sTotalAmount);
            //    dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = dNewTotalAmount.ToString();

            //    GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uUPDATE, null, cmbProjectCode.Text, dtProjectCheck.Rows[0]["ProductNo"].ToString(), 
            //        dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value), 
            //        Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value), null, null, null, null, null, null, null, 0, null, "", "", "",0,false);

            //    if (GLobalClass.iSuccess > 0)
            //    {
            //        MessageBox.Show("New Items Added to Design BOM list", "Success", 0, MessageBoxIcon.Information);
            //    }
            //}


            //fnTime2Stop();
        }

        private void txtItemCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%' || e.KeyChar == '['))
            {
                e.Handled = true;
            }
        }

       

       

        private void rbItemcode_CheckedChanged(object sender, EventArgs e)
        {
            if (rbItemcode.Checked)
            {
                pnItemAdd.Visible = true;
                pnItemcode.Visible = true;
                pnexcelupload.Visible = false;
                dgvxcelupload.Visible = false;
                dgvItemList.Visible = true;
            }
        }

        private void btnDownload_Click(object sender, EventArgs e)
        {
            if (dtEXCELData.Rows.Count > 0)
            {
                 int iRowIndex = 1;
                string ExcelFolderPath;
                string FileFullPath;
                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                object misValue;
                string excelfilename;
              //  string Productname = sNodeName;
              //  Productname = RemoveSpecialChars(Productname);
               // Productname = Productname.Replace(System.Environment.NewLine, string.Empty);
              //  string Productcode = txtProductCode.Text;
                //Productcode = RemoveSpecialChars(txtProductCode.Text);
               // excelfilename = Productname + "-" + Productcode;

                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\BOM\\";
                FileFullPath = ExcelFolderPath + "" + "-" + DateTime.Now.ToString("dd/MM/yyyy") + ".xls";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "Sheet1";
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    //Commnet here for Design teams
                 //   NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, misValue, misValue, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, misValue, misValue, misValue, misValue, misValue);

                    if (dtEXCELData.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtEXCELData.Rows.Count + 1, dtEXCELData.Columns.Count];
                        for (int col = 0; col < dtEXCELData.Columns.Count; col++)
                        {
                            rawData[0, col] = dtEXCELData.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtEXCELData.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtEXCELData.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtEXCELData.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtEXCELData.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtEXCELData.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring(
                                (dtEXCELData.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A1:{0}{1}", finalColLetter, dtEXCELData.Rows.Count + iRowIndex);


                        NewWorkSheet.get_Range(excelRange, misValue).Value2 = rawData;
                    }

                    NewWorkSheet.get_Range("A6:F999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.get_Range("A6", "F999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                    NewWorkSheet.Rows.AutoFit();
                    NewWorkSheet.Columns.AutoFit();
                    NewWorkSheet.Rows.RowHeight = "18";
                    NewWorkSheet.PageSetup.PrintArea = "A1:D" + dtEXCELData.Rows.Count + iRowIndex + 3 + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    NewWorkBook.Save();
                    ExcelApp.Visible = true;
                    //Commnet here for Design teams
                 /*   ExcelApp.Visible = false;
                    NewWorkBook.Close(true, misValue, misValue);
                    ExcelApp.Quit();

                    releaseObject(NewWorkSheet);
                    releaseObject(NewWorkBook);
                    releaseObject(ExcelApp);

                    if (Directory.Exists(ExcelFolderPath))
                    {
                        Process.Start(ExcelFolderPath);
                    }*/
                }
                catch (Exception ex)
                {
                    ExcelApp.Quit();
                    MessageBox.Show(ex.Message);

                }
            }
            else
            {
                MessageBox.Show("Please select a product to items to export in excel", "Eroor", 0, MessageBoxIcon.Error);
            }
        }

        private void btnbrowse_Click(object sender, EventArgs e)
        {
            txtbrowseaddres.ResetText();
            openFileDialog1.Filter = "Excel Files (*.xls)|*.xls";
            openFileDialog1.InitialDirectory = @"c:\";
            openFileDialog1.FileName = "Select File";
            openFileDialog1.Title = "Select excel file..";
            openFileDialog1.ShowDialog();
        }
        DataTable dtExcelImport = new DataTable();
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            txtbrowseaddres.Text = openFileDialog1.FileName;

            if (!string.IsNullOrEmpty(txtbrowseaddres.Text))
            {
                try
                {
                    string smessageItemCode = string.Empty;
                    string str = string.Empty;
                    dtExcelImport = new DataTable();
                    string sheetname = "";
                    string constr = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source=" + txtbrowseaddres.Text + ";Extended Properties= \"Excel 8.0;HDR=YES;\";";
                    OleDbConnection con = new OleDbConnection(constr);
                    con.Open();
                    DataTable Sheets = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                    foreach (DataRow dr in Sheets.Rows)
                    {
                        sheetname = dr[2].ToString().Replace("'", "");
                        break;
                    }
                    if (!string.IsNullOrEmpty(sheetname))
                    {
                        OleDbDataAdapter sda = new OleDbDataAdapter("select * from [" + sheetname + "]", con);
                        sda.Fill(dtExcelImport);
                    }
                    con.Close();
                    if (dtExcelImport.Rows.Count > 0 && dtExcelImport.Columns.Count == 13 && !string.IsNullOrEmpty(dtExcelImport.Rows[0][0].ToString()))
                    {
                        for (int i = 0; i < dtExcelImport.Columns.Count; i++)
                        {
                            switch (i)
                            {
                                case 0:
                                    str = "slno";
                                    break;
                                case 1:
                                    str = "ItemCode";
                                    break;
                                case 2:
                                    str = "ItemDesc";
                                    break;
                                case 3:
                                    str = "MfgPartNo";
                                    break;
                                case 4:
                                    str = "Make";
                                    break;
                                case 5:
                                    str = "Qty";
                                    break;
                                case 6:
                                    str = "Unitcost";
                                    break;
                                case 7:
                                    str = "Specification";
                                    break;
                                case 8:
                                    str = "ItemType";
                                    break;
                                case 9:
                                    str = "Location";
                                    break;
                                case 10:
                                    str = "Vendor";
                                    break;
                                case 11:
                                    str = "Drawingno";
                                    break;
                                case 12:
                                    str = "Version";
                                    break;
                            }
                            dtExcelImport.Columns[i].ColumnName = str;
                        }

                        for (int i = dtExcelImport.Rows.Count - 1; i >= 0; i--)
                        {
                            if (dtExcelImport.Rows[i][1] == DBNull.Value)
                                dtExcelImport.Rows[i].Delete();
                        }
                        dtExcelImport.AcceptChanges();
                        DataTable dtItemSearch = new DataTable();
                        for (int i = 0; i < dtExcelImport.Rows.Count; i++)
                        {
                            string sItemCodex = dtExcelImport.Rows[i]["ItemCode"].ToString();
                            dtItemSearch = DAL.fnItemListItemsearch(sItemCodex).Tables[0];

                            if (dtItemSearch.Rows.Count > 0)
                            {
                                dtExcelImport.Rows[i]["ItemCode"] = dtItemSearch.Rows[0]["ItemCode"].ToString();
                                dtExcelImport.Rows[i]["ItemDesc"] = dtItemSearch.Rows[0]["ItemDescription"].ToString();
                                dtExcelImport.Rows[i]["Drawingno"] = dtItemSearch.Rows[0]["DrawingNo"].ToString();
                                if (string.IsNullOrEmpty(dtExcelImport.Rows[i]["Qty"].ToString()) || Convert.ToDouble(dtExcelImport.Rows[i]["Qty"].ToString()) == 0.0)
                                {
                                    dtExcelImport.Rows[i]["Qty"] = "1";
                                }

                                if (string.IsNullOrEmpty(dtExcelImport.Rows[0]["Version"].ToString()) || Convert.ToDouble(dtExcelImport.Rows[0]["Version"].ToString()) < 1)
                                {
                                    dtExcelImport.Rows[0]["Version"] = "1";
                                }

                                dtExcelImport.Rows[i]["Version"] = dtExcelImport.Rows[0]["Version"].ToString();
                            }
                            else
                            {
                                dtExcelImport.Rows.RemoveAt(i);
                                i--;
                                if (smessageItemCode.Length > 0)
                                {
                                    smessageItemCode += "," + sItemCodex.ToString();
                                }
                                else
                                {
                                    smessageItemCode = sItemCodex.ToString();
                                }
                            }
                        }

                        if (dtExcelImport.Rows.Count > 0)
                        {
                            Dictionary<string, int> dicSum = new Dictionary<string, int>();
                            foreach (DataRow row in dtExcelImport.Rows)
                            {
                                string group = row["ItemCode"].ToString();
                                int rate = Convert.ToInt32(row["Qty"]);
                                if (dicSum.ContainsKey(group))
                                    dicSum[group] += rate;
                                else
                                    dicSum.Add(group, rate);
                            }

                            DataTable UniqueRecords = RemoveDuplicateRows(dtExcelImport, "ItemCode");
                            double sQty;
                            foreach (var group in dicSum)
                            {
                                foreach (DataRow FinalItems in dtExcelImport.Rows)
                                {
                                    if (FinalItems["ItemCode"].ToString() == group.Key.ToString())
                                    {
                                        sQty = group.Value;
                                        FinalItems["Qty"] = sQty;
                                        break;
                                    }
                                }
                            }

                            dgvxcelupload.AutoGenerateColumns = false;
                            dgvxcelupload.DataSource = dtExcelImport;
                            //  btnaddtobom.Enabled = true;
                            lbladditemcount.Text = dgvxcelupload.Rows.Count.ToString();
                            string s = dtExcelImport.Rows.Count.ToString();

                            if (smessageItemCode.Length > 0)
                            {
                                MessageBox.Show("The listed items are not exist in itemmaster " + smessageItemCode + "");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Uploaded Excel file not contains any valid Itemcode(s) matching with the Item master", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Uploaded Excel file is not in expected format.\n 1) Excel file should contain 13 columns with Names on the first Row \n 2) Items details to be start from the Second Row ", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("btnUpload_Click" + ex.Message);
                }
            }
            else
            {
                //  btnaddtobom.Enabled = false;
                MessageBox.Show("Please Select Excel File to Upload the Items", "Warning", 0, MessageBoxIcon.Warning);
            }
        }
        public DataTable RemoveDuplicateRows(DataTable table, string DistinctColumn)
        {
            try
            {
                ArrayList UniqueRecords = new ArrayList();
                ArrayList DuplicateRecords = new ArrayList();


                foreach (DataRow dRow in table.Rows)
                {
                    if (UniqueRecords.Contains(dRow[DistinctColumn]))
                        DuplicateRecords.Add(dRow);
                    else
                        UniqueRecords.Add(dRow[DistinctColumn]);

                }
                // Remove dupliate rows from DataTable added to DuplicateRecords
                if (DuplicateRecords.Count > 0)
                {
                    foreach (DataRow dRow in DuplicateRecords)
                    {
                        table.Rows.Remove(dRow);
                    }
                }
                // Return the clean DataTable which contains unique records.
                return table;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;

            }
        }

        private void rbExcelitem_CheckedChanged(object sender, EventArgs e)
        {
            if (rbExcelitem.Checked)
            {
                pnItemAdd.Visible = true;
                pnItemcode.Visible = false;
                pnexcelupload.Visible = true;
                dgvxcelupload.Visible = true;
                dgvItemList.Visible = false;

            }
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            if (dtExcelImport.Rows.Count > 0)
            {
                List<string> lUploadList = new List<string>();
                foreach (DataRow dr in dtItemsofMachineBOM.Rows)
                {
                    lUploadList.Add(dr["ItemName"].ToString());
                }
                if (lUploadList.Count > 0)
                {
                    for (int i = 0; i < dgvxcelupload.Rows.Count; i++)
                    {
                        foreach (string s in lUploadList)
                        {
                            if (!lUploadList.Contains(dgvxcelupload.Rows[i].Cells["xItemCode"].Value.ToString()))
                            {
                                lUploadList.Add(dgvxcelupload.Rows[i].Cells["xItemCode"].Value.ToString());
                                break;
                            }
                            else
                            {
                                dgvxcelupload.Rows.RemoveAt(i);
                                i--;
                                break;
                            }
                        }
                    }
                }


                if (dgvxcelupload.Rows.Count > 0)
                {
                    foreach (DataGridViewRow dr in dgvxcelupload.Rows)
                    {

                        fCost = 0.0;
                        dtItemsofMachineBOM.Rows.Add(null, null, dr.Cells["xItemCode"].Value.ToString(), dr.Cells["xItemDesc"].Value.ToString(), dr.Cells["xQty"].Value.ToString(), "0", dr.Cells["xUnitCost"].Value.ToString(), (Convert.ToDouble(dr.Cells["xQty"].Value) * Convert.ToDouble(dr.Cells["xUnitCost"].Value)).ToString(), dr.Cells["xUnitCost"].Value.ToString(), null, dr.Cells["xDrawingno"].Value.ToString());
                        dgBOMList.DataSource = dtItemsofMachineBOM;
                        lblitemcount.Text = dgBOMList.Rows.Count.ToString();
                        dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value) + (Convert.ToDouble(dr.Cells["xQty"].Value) * Convert.ToDouble(dr.Cells["xUnitCost"].Value));

                        fnTotalAmount(Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value));
                        dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = dNewTotalAmount.ToString();
///
                    //    dtProjectCheck = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), cmbProjectCode.Text).Tables[0];
                        if (dtProjectCheck.Rows.Count > 0)
                        {
                            //GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uINSERT, dtProjectCheck.Rows[0]["ProjectBOMCode"].ToString(), dtProjectCheck.Rows[0]["ProductNo"].ToString(), dr.Cells["xItemCode"].Value.ToString(), 
                            //    dtProjectCheck.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null, 
                            //    Convert.ToDouble(dr.Cells["xQty"].Value), 0, 0, lblProjectStaus.Text, login.GetUserDetails[2], dtpCreatedDate.Text);

                          //  GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uUPDATE, null, cmbProjectCode.Text, dtProjectCheck.Rows[0]["ProductNo"].ToString(), dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString(), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value), null, null, null, null, null, null, null, 0, null, "", "", "", 0);

                            if (GLobalClass.iSuccess > 0)
                            {
                                //  MessageBox.Show("'" + dtSelectItemList.Rows[0]["ItemDescription"].ToString() + "'  Added to Design BOM item list", "Success", 0, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
                else
                {
                    dtExcelImport.Clear();
                    MessageBox.Show("Selected uploading Items already exist", "Information", 0, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please select a file for uploading Items", "Warning", 0, MessageBoxIcon.Warning);
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            lblEmail.ForeColor = Color.Red;
            lblEmail.Visible = !lblEmail.Visible;
            _blinkCount++;
            if (_blinkCount == _maxNumberOfBlinks * 2)
            {
                timer3.Stop();
                lblEmail.Visible = true;
            }
        }

        private void btnEmailRequest_Click(object sender, EventArgs e)
        {
            CreateEMail("santhoshdj@biss.in", "<font face=Calibri>Dear Santhosh, <br />Please authorise the product bom created for product '" + dgItemOrProductList.CurrentRow.Cells["ProductCode"].Value.ToString() + "' - '" + dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString() + "' <br /> in Project code " + cmbProjectCode.Text + " <br /> <br />  <b> Regards,<br /> " + login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>");
            
            fnTime3Stop();
            MessageBox.Show("Email alert sent to Santhosh", "Success", 0, MessageBoxIcon.Information);
        }


        private void CreateEMail(string sTo, string sSubject)
        {
            try
            {
                Outlook.Application oApp = new Outlook.Application();
                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                oMsg.Subject = "Authorise Design Product BOM";
                //  oMsg.iHTMLBody = true;
                oMsg.HTMLBody = sSubject;
                // Add a recipient.
                Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                oRecips.Add(sTo);
                oRecips.ResolveAll();
                //if (sCC.Items.Count > 0)
                //{
                //    Outlook.Recipient oRecip;
                //    List<string> sCCRecipsList = new List<string>();
                //    foreach (string tempTO in sCC.Items)
                //    {
                //        if (tempTO != null)
                //            sCCRecipsList.Add(tempTO);
                //    }
                //    foreach (string t in sCCRecipsList)
                //    {

                //        oRecip = (Outlook.Recipient)oRecips.Add(t);
                //        oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                //        oRecip.Resolve();
                //    }
                //    oMsg.Send();
                //    oRecip = null;
                //}
                //else
                {
                    // Send.
                    oMsg.Send();
                    // Clean up.
                    oRecips = null;
                }

                oMsg = null;
                oApp = null;
            }
            catch (Exception ex)
            {

            }
        }
    }
}
