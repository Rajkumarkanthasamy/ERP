﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using Microsoft.VisualBasic.FileIO;
using System.Text.RegularExpressions;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Erp_Project_With_Buttons.Project_Documents
{
    public partial class frmProjectDocs : Form
    {
        frmForm2 frm = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        Global GlobalClass = new Global();

        public frmProjectDocs()
        {
            InitializeComponent();
        }
        public int ProjectDoc = 0;
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }
        private void btnProjectView_Click(object sender, EventArgs e)
        {
            ProjectDoc = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnProjectDoc = ProjectDoc.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectCode.Text = sProjectCode;
            }
        }

        DataTable dtProjectDetails = new DataTable();
        DataTable dtProjectList = new DataTable();
        DataTable dtProjectInfolist = new DataTable();
        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbProjectDocument.Enabled = true;
            cmbDocType.Enabled = true;
            dtProjectDetails = DAL.fnWIPProjectCode(cmbProjectCode.Text).Tables[0];
            if (dtProjectDetails.Rows.Count > 0)
            {
                lblprojname.Text = dtProjectDetails.Rows[0]["ProjectDescription"].ToString();
                lblcustomername.Text = dtProjectDetails.Rows[0]["Customer"].ToString();
                if (login.GetUserDetails[23] == "Accounts")
                {
                    btnDownloadProject.Visible = true;
                    llbDownloadProject.Visible = true;

                    Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                    string sProjName = lblprojname.Text;
                    sProjName = illegalInFileName.Replace(sProjName, " ");
                }
                else
                {
                    btnDownloadProject.Visible = false;
                    llbDownloadProject.Visible = false;
                }

                fnAddProjectInfo();
            }
            else
            {
                lblprojname.ResetText();
                lblcustomername.ResetText();
                btnDownloadProject.Visible = false;
                llbDownloadProject.Visible = false;
            }
        }
        string[] doctype;
        private void fnAddProjectInfo()
        {
            
            if (login.GetUserDetails[23] == "Accounts")
            {
                dtProjectInfolist = DAL.fnProjectInfoList(1, cmbProjectCode.Text, "").Tables[0];
              doctype  =new string[] { "Purchase order with price", "Bank Guarantee format", "Performance Bank Guarantee format","Security Deposit format", "LC","Scope of supply","Technical Specifications/Compliance Statement","MOM with customer","MOCT MOM", "Activity Chart", "Machine Passport","Packing list","Performance Invoice","Invoice", "Dispatch/Delivery Proof", "Bank Guarantee", "Performance Bank Guarantee", "Security Deposit","Installation Report/certificate", "Warranty Certificate","Guarantee Certificate","Country of origin certificate","Payment Receipt" };
            }
            if (login.GetUserDetails[23] == "Projects" || login.GetUserDetails[23] == "Purchase" || login.GetUserDetails[23] == "Support" || login.GetUserDetails[23] == "Validation" || login.GetUserDetails[23] == "Design" || login.GetUserDetails[23] == "Electricals" || login.GetUserDetails[23] == "RnD")
            {
               
                dtProjectInfolist = DAL.fnProjectInfoList(12, cmbProjectCode.Text, "").Tables[0];
                doctype = new string[] { "Purchase order without price", "Scope of supply","Technical Specifications/Compliance Statement","Actuator Performance Curve","MOM with customer","Concept Drawing","MOCT MOM","Activity Chart","System Layout","Site requirement","DAP", "System Manual","PDI/acceptance plan","Acceptance plan at site","Integration Check List","Validation Report/Test Reports","Machine Passport","Packing list","Dispatch/Delivery Proof","Installation Report/certificate" };
            }

            if (login.GetUserDetails[23] == "Sales" || login.GetUserDetails[23] == "Order Processing" || login.GetUserDetails[23] == "Management" || login.GetUserDetails[23] == "Testlab")
            {
                dtProjectInfolist = DAL.fnProjectInfoList(1, cmbProjectCode.Text, "").Tables[0];
                doctype = new string[] {"Purchase order without price","Purchase order with price", "Bank Guarantee format", "Performance Bank Guarantee format","Security Deposit format", "LC","Scope of supply","Technical Specifications/Compliance Statement","Actuator Performance Curve","MOM with customer","Concept Drawing", "MOCT MOM","Activity Chart","System Layout","Site requirement","DAP","System Manual","PDI/acceptance plan","Acceptance plan at site", "Validation Report/Test Reports", "Machine Passport", "Packing list","Performance Invoice","Invoice","Dispatch/Delivery Proof", "Bank Guarantee", "Performance Bank Guarantee", "Security Deposit","Installation Report/certificate", "Warranty Certificate","Guarantee Certificate","Country of origin certificate","Technical Specifications/Compliance Statement","Payment Receipt" };

            }
                bool bDocExist = false;
            if (dtProjectInfolist.Rows.Count > 0)
            {
                //for (int i = dtProjectInfolist.Rows.Count - 1; i >= 0; i--)
                //{
                //    if (!doctype.Contains(dtProjectInfolist.Rows[i]["DocumentType"].ToString()))
                //    {
                //        dtProjectInfolist.Rows.RemoveAt(i);
                //    }
                //}
                foreach (string sDocumnet in doctype)
                {
                    bDocExist = false;
                    foreach (DataRow dr in dtProjectInfolist.Rows)
                    {
                        if (dr["DocumentType"].ToString() == sDocumnet)
                        {
                            bDocExist = true;
                            break;
                        }
                    }
                    if (!bDocExist)
                    {
                        dtProjectInfolist.Rows.Add(0, "", "", "", "", "", "False", "False", "", "", "", sDocumnet);
                    }
                }               
                dgUploadList.AutoGenerateColumns = false;
                dgUploadList.DataSource = dtProjectInfolist;
                Datagridviewcolor();
            }
            else
            {
                foreach (string sDocumnet in doctype)
                {
                    foreach (DataRow dr in dtProjectInfolist.Rows)
                    {
                        if (dr["DocumentType"].ToString() == sDocumnet)
                        {
                            bDocExist = true;
                            break;
                        }
                    }
                    if (!bDocExist)
                    {
                        dtProjectInfolist.Rows.Add(0, "", "", "", "", "", "False", "False", "", "", "", sDocumnet);
                    }
                }
                dgUploadList.AutoGenerateColumns = false;
                dgUploadList.DataSource = dtProjectInfolist;
                Datagridviewcolor();
            }
        }

        private void frmProjectDocs_Load(object sender, EventArgs e)
        {
            dtProjectList = DAL.fnAllProjectList(null).Tables[0];

            if (dtProjectList.Rows.Count > 0)
            {
                foreach (DataRow DR in dtProjectList.Rows)
                {
                    if (!cmbProjectCode.Items.Contains(DR["ProjectCode"].ToString()))
                        cmbProjectCode.Items.Add(DR["ProjectCode"].ToString());
                }
            }

            if (login.GetUserDetails[23] == "Accounts")
            {
                cmbProjectDocument.Items.Add("Finance Documents");
                cmbProjectDocument.Items.Add("Project Documents");
            }
            else
            {
                cmbProjectDocument.Items.Add("Project Documents");
                cmbProjectDocument.Items.Add("Finance Documents");
            }

            //if (login.GetUserDetails[23] == "Accounts")
            //{
            //    btnVerifyDoc.Visible = true;
            //    btnReviewDoc.Visible = true;
            //}
            //else
            //{
                btnVerifyDoc.Visible = false;
                btnReviewDoc.Visible = false;
            //}

            if (fnProjectcode != null)
            {
                cmbProjectCode.Text = sProjectCode;
            }
        }


        private void frmProjectDocs_FormClosing(object sender, FormClosingEventArgs e)
        {
          //  Project_Master.frmProjectHome frmProjectHome = new Project_Master.frmProjectHome();
            this.Hide();
            frm.Show();
        }

        private void btnDownloadProject_Click(object sender, EventArgs e)
        {
            Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
            string sProjName = lblprojname.Text;
            sProjName = illegalInFileName.Replace(sProjName, " ");

            // string sourcePath = @"\\192.168.1.85\ProjectDocuments\" + cmbProjectCode.Text + "-" + sProjName;
            string sourcePath = @"\\192.168.1.81\ERP_Project_Document\" + cmbProjectCode.Text + "-" + sProjName;
            //@"\\192.168.1.81\ERP_Project_Document

            //  string targetPath = "C:\\supportipaddress\\Projects\\" + cmbProjectCode.Text + "-" + lblprojname.Text;
            string ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\ProjectDocuments\\";

            //   string ExcelFolderPath = "MyDocuments";
            if (!Directory.Exists(ExcelFolderPath))
            {
                Directory.CreateDirectory(ExcelFolderPath);
            }

            string targetPath = ExcelFolderPath + cmbProjectCode.Text + " - " + sProjName;

            if (!Directory.Exists(targetPath))
            {
                Directory.CreateDirectory(targetPath);
            }

            if (System.IO.Directory.Exists(sourcePath))
            {
                long length = Directory.GetFiles(sourcePath, "*", System.IO.SearchOption.AllDirectories).Sum(t => (new FileInfo(t).Length));
                if (length > 0)
                {
                    FileSystem.CopyDirectory(sourcePath, targetPath, UIOption.AllDialogs);

                    if (Directory.Exists(targetPath))
                    {
                        MessageBox.Show("Project files downloaded", "Success", 0, MessageBoxIcon.Information);
                        Process.Start(targetPath);
                    }
                }
                else
                {
                    MessageBox.Show("Selected Project does not contain any documents to copy", "Information", 0, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Project documents does not exist. Upload the documents!!", "Information", 0, MessageBoxIcon.Warning);
            }
        }

        private void llbDownloadProject_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnDownloadProject_Click(sender, e);
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
          
        }

        private void btnGoForward_Click(object sender, EventArgs e)
        {
           
        }

        private void webBrowser1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
           
        }

        private void dgUploadList_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }
        Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
        DataTable dtUploadFIle = new DataTable();
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            if (openFileDialog1.SafeFileName.Length < 101)
            {
                bool bFileCheck = false;
                foreach (DataGridViewRow dr in dgUploadList.Rows)
                {
                    if (dr.Cells["UploadedFile2"].Value.ToString() == openFileDialog1.SafeFileName)
                    {
                        bFileCheck = true;
                        break;
                    }
                }
                if (!bFileCheck)
                {
                    string sProjName = lblprojname.Text;
                    sProjName = illegalInFileName.Replace(sProjName, " ");
                    sProjName = sProjName + "\\";
                    string sourcePath = openFileDialog1.FileName;
                    string ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                    if (!Directory.Exists(ExcelFolderPath))
                    {
                        Directory.CreateDirectory(ExcelFolderPath);
                    }

                    // string targetPath = @"\\192.168.1.85\ProjectDocuments\" + cmbProjectCode.Text + "-" + sProjName + dgUploadList.CurrentRow.Cells["UploadedFile"].Value.ToString() + "\\";
                   // \\inbas01\Data\ERP\Pub\
                    string targetPath = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\" + cmbProjectCode.Text + "\\" + cmbProjectDocument.Text + "\\";
                    //string targetPath = @"\\192.168.1.81\ERP_Project_Document\" + cmbProjectCode.Text + "-" + sProjName + cmbProjectDocument.Text + "\\";


                    if (!Directory.Exists(targetPath))
                    {
                        Directory.CreateDirectory(targetPath);
                    }

                    File.Copy(sourcePath, targetPath + Path.GetFileName(sourcePath), true);

                    if (Directory.Exists(targetPath))
                    {
                        GlobalClass.iSuccess = DAL.fnAddProjectDocuments(0, cmbProjectCode.Text, cmbProjectDocument.Text,
                                                  login.GetUserDetails[2], login.GetUserDetails[23], dtpUploaddate.Text, "1", "0", openFileDialog1.SafeFileName, cmbDocType.Text);


                        //  fnAlertMail("Theertha Rao", "New", dgUploadList.CurrentRow.Cells["UploadedFile"].Value.ToString(), Ls);
                        MessageBox.Show("Selected file saved to the server succeessfully", "Success", 0, MessageBoxIcon.Information);
                        fnAddProjectInfo();
                    }
                }
                else
                {
                    MessageBox.Show("Selected file already saved in the server", "Error", 0, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Selected file name characters should be maximum 100. \n\nNote: File extension .xls , .pdf or .jpg will also take 4 characters. \n\nRename the file or Short the name of the file to 100 characters", "Warning", 0, MessageBoxIcon.Warning);
            }
        }

        #region PO Item Color
        private void Datagridviewcolor()
        {
            int count = 0;
            foreach (DataGridViewRow dgr in dgUploadList.Rows)
            {
                if (Convert.ToBoolean(dgr.Cells["UploadStatus"].Value))
                {
                    dgr.DefaultCellStyle.BackColor = Color.LightGreen;
                }
                else
                {
                    dgr.DefaultCellStyle.BackColor = Color.Red;
                }
                count++;
            }
        }
        #endregion

        private void btnVerifyDoc_Click(object sender, EventArgs e)
        {
            //if (dgUploadList.Rows.Count > 0)
            //{
            //    if ((dgUploadList.CurrentRow.Cells["UploadStatus"].Value.ToString() == "True") && (dgUploadList.CurrentRow.Cells["VerifiedStatus"].Value.ToString() == "False") && login.GetUserDetails[23] == "Accounts")
            //    {
            //        GlobalClass.iSuccess = DAL.fnAddProjectDocuments(2, cmbProjectCode.Text, dgUploadList.CurrentRow.Cells["UploadedFile"].Value.ToString(),
            //                                                              login.GetUserDetails[2], login.GetUserDetails[23], dtpUploaddate.Text, "1", "1", openFileDialog1.SafeFileName);

            //        MessageBox.Show("Selected file verified to the server succeessfully", "Success", 0, MessageBoxIcon.Information);
                   

            //      //  fnAlertMail(dgUploadList.CurrentRow.Cells["UploadederName"].Value.ToString(), "Accept", dgUploadList.CurrentRow.Cells["UploadedFile"].Value.ToString(), Ls);
            //        fnAddProjectInfo();
            //    }
            //    else
            //    {
            //        if (dgUploadList.CurrentRow.Cells["UploadStatus"].Value.ToString() == "False")
            //        {
            //            MessageBox.Show("No file uploaded in server to verify the document", "Error", 0, MessageBoxIcon.Error);
            //        }
            //        else if (dgUploadList.CurrentRow.Cells["VerifiedStatus"].Value.ToString() == "True")
            //        {
            //            MessageBox.Show("File already verified", "Information", 0, MessageBoxIcon.Exclamation);
            //        }
            //    }
            //}
        }
        ListBox Ls = new ListBox();
        public void fnAlertMail(string sUser, string sRemarks, string sDocName, ListBox sCC)
        {
            try
            {
                DataTable dtlogindetails = DAL.fnloginemail(sUser.Trim()).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                        if (sRemarks == "Accept")
                        {
                            oMsg.Subject = "Project document verified";
                            oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Project '" + cmbProjectCode.Text + " - " + lblprojname.Text + "' uploaded document '" + sDocName + "'  verified. <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        }
                        else  if (sRemarks == "Reject")
                        {
                            oMsg.Subject = "Project document not verified";
                            oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Project '" + cmbProjectCode.Text + " - " + lblprojname.Text + "' uploaded '" + sDocName + "' document is not a valid document. Update the valid document. <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        }
                        else if (sRemarks == "New")
                        {
                            oMsg.Subject = "Project document uploaded for verify";
                            oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Project '" + cmbProjectCode.Text + " - " + lblprojname.Text + "' document '" + sDocName + "' is uploaded to server. Verify the document. <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        }
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();
                        // Send.


                        if (sCC.Items.Count > 0)
                        {
                            Outlook.Recipient oRecip;
                            List<string> sCCRecipsList = new List<string>();
                            foreach (string tempTO in sCC.Items)
                            {
                                if (tempTO != null)
                                    sCCRecipsList.Add(tempTO);
                            }
                            foreach (string t in sCCRecipsList)
                            {
                                oRecip = (Outlook.Recipient)oRecips.Add(t);
                                oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                                oRecip.Resolve();
                            }
                            oMsg.Send();
                            oRecip = null;
                        }
                        else
                        {
                            // Send.
                            oMsg.Send();
                            // Clean up.
                            oRecips = null;
                        }


                        // oMsg.Send();
                        // Clean up.
                        //  oRecips = null;
                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void btnReviewDoc_Click(object sender, EventArgs e)
        {
            //if (dgUploadList.Rows.Count > 0)
            //{
            //    if ((dgUploadList.CurrentRow.Cells["UploadStatus"].Value.ToString() == "True")  && login.GetUserDetails[23] == "Accounts")
            //    {
            //        GlobalClass.iSuccess = DAL.fnAddProjectDocuments(3, cmbProjectCode.Text, dgUploadList.CurrentRow.Cells["UploadedFile"].Value.ToString(),
            //                                                             "", "", "", "0", "0", "");

            //        MessageBox.Show("Selected file verified to the server succeessfully", "Success", 0, MessageBoxIcon.Information);
                   
            //        fnAlertMail(dgUploadList.CurrentRow.Cells["UploadederName"].Value.ToString(), "Reject", dgUploadList.CurrentRow.Cells["UploadedFile"].Value.ToString(), Ls);
                  
            //        fnAddProjectInfo();
            //    }
            //    else
            //    {
            //        if (dgUploadList.CurrentRow.Cells["UploadStatus"].Value.ToString() == "False")
            //        {
            //            MessageBox.Show("No file to verify the document", "Error", 0, MessageBoxIcon.Error);
            //        }
            //        //else if (dgUploadList.CurrentRow.Cells["VerifiedStatus"].Value.ToString() == "True")
            //        //{
            //        //    MessageBox.Show("File already verified", "Information", 0, MessageBoxIcon.Exclamation);
            //        //}
            //    }
            //}
        }

        private void cmbProjectDocument_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cmbProjectDocument.SelectedItem.ToString() == "Project Documents")
            {
                cmbDocType.Items.Clear();
                cmbDocType.Items.Add("Purchase order without price");
                cmbDocType.Items.Add("Scope of supply");
                cmbDocType.Items.Add("Technical Specifications/Compliance Statement");
                cmbDocType.Items.Add("Actuator Performance Curve");
                cmbDocType.Items.Add("MOM with customer");
                cmbDocType.Items.Add("Concept Drawing");
                cmbDocType.Items.Add("MOCT MOM");
                cmbDocType.Items.Add("Activity Chart");
                cmbDocType.Items.Add("System Layout");
                cmbDocType.Items.Add("Site requirement");
                cmbDocType.Items.Add("DAP");
                cmbDocType.Items.Add("System Manual");
                cmbDocType.Items.Add("PDI/acceptance plan");
                cmbDocType.Items.Add("Acceptance plan at site");
                cmbDocType.Items.Add("Integration Check List");
                cmbDocType.Items.Add("Validation Report/Test Reports");
                cmbDocType.Items.Add("Machine Passport");
                cmbDocType.Items.Add("Packing list");
                cmbDocType.Items.Add("Dispatch/Delivery Proof");
                cmbDocType.Items.Add("Installation Report/certificate");                
            }
            else
            {
                cmbDocType.Items.Clear();
                cmbDocType.Items.Add("Purchase order with price");
                cmbDocType.Items.Add("Bank Guarantee format");
                cmbDocType.Items.Add("Performance Bank Guarantee format");
                cmbDocType.Items.Add("Security Deposit format");
                cmbDocType.Items.Add("LC");
                cmbDocType.Items.Add("Performance Invoice");
                cmbDocType.Items.Add("Invoice");
                cmbDocType.Items.Add("Bank Guarantee");
                cmbDocType.Items.Add("Performance Bank Guarantee");
                cmbDocType.Items.Add("Warranty Certificate");
                cmbDocType.Items.Add("Guarantee Certificate"); 
                cmbDocType.Items.Add("Country of origin certificate");
                cmbDocType.Items.Add("Payment Receipt");
            }
                    
        }
        private void cmbDocType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbProjectDocument.Text))
            {
                Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                string sProjName = lblprojname.Text;
                sProjName = illegalInFileName.Replace(sProjName, " ");

                if (dgUploadList.Rows.Count == 0)
                {
                    //\\inbas01\Data\ERP\Pub\
                   // string newPath = @"\\192.168.1.81\ERP_Project_Document\\" + cmbProjectCode.Text + "-" + sProjName;
                    string newPath = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\\" + cmbProjectCode.Text;

                    if (!Directory.Exists(newPath))
                    {
                        System.IO.Directory.CreateDirectory(newPath);

                        string newPath1 = newPath + "\\Finance Documents";
                        System.IO.Directory.CreateDirectory(newPath1);
                        newPath1 = newPath + "\\Project Documents";
                        System.IO.Directory.CreateDirectory(newPath1);
                    }
                }

                openFileDialog1.InitialDirectory = @"c:\";
                openFileDialog1.FileName = "Select File";
                openFileDialog1.Title = "Select files..";
                openFileDialog1.ShowDialog();
            }
            else
            {
                MessageBox.Show("Select or enter the document type", "Information", 0, MessageBoxIcon.Warning);
            }
        }

        private void dgUploadList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgUploadList.Rows.Count > 0)
            {
                if (dgUploadList.CurrentCell.OwningColumn.Name == "View")
                {
                    if (dgUploadList.CurrentRow.Cells["UploadStatus"].Value.ToString() == "True")
                    {
                        string sProjName = lblprojname.Text;
                        sProjName = illegalInFileName.Replace(sProjName, " ");
                        string FileOpen = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\" + cmbProjectCode.Text + "\\" + dgUploadList.CurrentRow.Cells["UploadedFile"].Value.ToString() + "\\" + dgUploadList.CurrentRow.Cells["UploadedFile2"].Value.ToString();

                      //  string FileOpen = @"\\192.168.1.81\ERP_Project_Document\" + cmbProjectCode.Text + "-" + sProjName + "\\" + dgUploadList.CurrentRow.Cells["UploadedFile"].Value.ToString() + "\\" + dgUploadList.CurrentRow.Cells["UploadedFile2"].Value.ToString();

                        if (File.Exists(FileOpen))
                        {
                            System.Diagnostics.Process.Start(FileOpen);
                        }
                        else
                        {
                            MessageBox.Show("Document is missing, Ask the authorised person to re upload the document", "Warning", 0, MessageBoxIcon.Warning);
                        }

                    }
                    else
                    {
                        if (dgUploadList.CurrentRow.Cells["UploadStatus"].Value.ToString() == "False")
                        {
                            MessageBox.Show("No document uploaded to view", "Information", 0, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
        }

        private void dgUploadList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (dgUploadList.Rows.Count > 0)
                {
                    if (dgUploadList.CurrentRow.Cells["UploadederName"].Value.ToString().ToLower() == login.GetUserDetails[2].ToLower())
                    {
                        DialogResult DR = MessageBox.Show("Do you want to delete selected file  '" + dgUploadList.CurrentRow.Cells["UploadedFile2"].Value.ToString() + "'", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (DR == DialogResult.Yes)
                        {
                            string sProjName = lblprojname.Text;
                            sProjName = illegalInFileName.Replace(sProjName, " ");

                            // \\inbas01\Data\ERP\Pub
                            string FileOpen = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\" + cmbProjectCode.Text + "\\" + dgUploadList.CurrentRow.Cells["UploadedFile"].Value.ToString() + "\\" + dgUploadList.CurrentRow.Cells["UploadedFile2"].Value.ToString();

                            GlobalClass.iSuccess = DAL.fnAddProjectDocuments(4, cmbProjectCode.Text, dgUploadList.CurrentRow.Cells["UploadedFile"].Value.ToString(),
                                                    login.GetUserDetails[2], login.GetUserDetails[23], dtpUploaddate.Text, "1", "0", dgUploadList.CurrentRow.Cells["UploadedFile2"].Value.ToString(),"");
                            if (File.Exists(FileOpen))
                            {
                                File.Delete(FileOpen);
                            }
                            MessageBox.Show("Selected file deleted from the server", "Information", 0, MessageBoxIcon.Information);
                            fnAddProjectInfo();
                        }
                    }
                    else
                    {
                        MessageBox.Show("You cannot delete this document, ask " + dgUploadList.CurrentRow.Cells["UploadederName"].Value.ToString() + " to delete", "Information", 0, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        private void dgUploadList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
