﻿namespace Erp_Project_With_Buttons.Project_Documents
{
    partial class frmProjectDocs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectDocs));
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblcustomername = new System.Windows.Forms.Label();
            this.lblprojname = new System.Windows.Forms.Label();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.cmbProjectCode = new System.Windows.Forms.ComboBox();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.llbDownloadProject = new System.Windows.Forms.LinkLabel();
            this.dgUploadList = new System.Windows.Forms.DataGridView();
            this.DocumentType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UploadedFile2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UploadStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UploadederName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UploadederDept = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UploadDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.View = new System.Windows.Forms.DataGridViewButtonColumn();
            this.UploadedFile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnVerifyDoc = new System.Windows.Forms.Button();
            this.btnDownloadProject = new System.Windows.Forms.Button();
            this.btnReviewDoc = new System.Windows.Forms.Button();
            this.cmbProjectDocument = new System.Windows.Forms.ComboBox();
            this.label60 = new System.Windows.Forms.Label();
            this.dtpUploaddate = new System.Windows.Forms.DateTimePicker();
            this.cmbDocType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgUploadList)).BeginInit();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(723, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(439, 43);
            this.panel3.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(71, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "BiSS Project Documents";
            // 
            // lblcustomername
            // 
            this.lblcustomername.AutoSize = true;
            this.lblcustomername.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomername.ForeColor = System.Drawing.Color.Black;
            this.lblcustomername.Location = new System.Drawing.Point(180, 80);
            this.lblcustomername.Name = "lblcustomername";
            this.lblcustomername.Size = new System.Drawing.Size(12, 18);
            this.lblcustomername.TabIndex = 144;
            this.lblcustomername.Text = ".";
            // 
            // lblprojname
            // 
            this.lblprojname.AutoSize = true;
            this.lblprojname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojname.ForeColor = System.Drawing.Color.Black;
            this.lblprojname.Location = new System.Drawing.Point(180, 49);
            this.lblprojname.Name = "lblprojname";
            this.lblprojname.Size = new System.Drawing.Size(12, 18);
            this.lblprojname.TabIndex = 143;
            this.lblprojname.Text = ".";
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblcustomer.Location = new System.Drawing.Point(99, 80);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(75, 18);
            this.lblcustomer.TabIndex = 142;
            this.lblcustomer.Text = "Customer :";
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblProjectCode.Location = new System.Drawing.Point(70, 12);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(104, 18);
            this.lblProjectCode.TabIndex = 139;
            this.lblProjectCode.Text = "Project Code * :";
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectCode.DropDownHeight = 130;
            this.cmbProjectCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectCode.DropDownWidth = 239;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectCode.FormattingEnabled = true;
            this.cmbProjectCode.IntegralHeight = false;
            this.cmbProjectCode.Location = new System.Drawing.Point(183, 12);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.Size = new System.Drawing.Size(376, 26);
            this.cmbProjectCode.TabIndex = 140;
            this.cmbProjectCode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectCode_SelectedIndexChanged);
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblProjectName.Location = new System.Drawing.Point(75, 49);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(99, 18);
            this.lblProjectName.TabIndex = 138;
            this.lblProjectName.Text = "Project Name :";
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectView.Location = new System.Drawing.Point(565, 15);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 26);
            this.btnProjectView.TabIndex = 141;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            this.btnProjectView.Click += new System.EventHandler(this.btnProjectView_Click);
            // 
            // llbDownloadProject
            // 
            this.llbDownloadProject.AutoSize = true;
            this.llbDownloadProject.BackColor = System.Drawing.Color.Transparent;
            this.llbDownloadProject.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbDownloadProject.ForeColor = System.Drawing.Color.Transparent;
            this.llbDownloadProject.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llbDownloadProject.LinkColor = System.Drawing.Color.RoyalBlue;
            this.llbDownloadProject.Location = new System.Drawing.Point(836, 106);
            this.llbDownloadProject.Name = "llbDownloadProject";
            this.llbDownloadProject.Size = new System.Drawing.Size(245, 23);
            this.llbDownloadProject.TabIndex = 150;
            this.llbDownloadProject.TabStop = true;
            this.llbDownloadProject.Text = "Download Project Documents";
            this.llbDownloadProject.Visible = false;
            this.llbDownloadProject.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbDownloadProject_LinkClicked);
            // 
            // dgUploadList
            // 
            this.dgUploadList.AllowUserToAddRows = false;
            this.dgUploadList.AllowUserToDeleteRows = false;
            this.dgUploadList.AllowUserToResizeRows = false;
            this.dgUploadList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgUploadList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgUploadList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgUploadList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgUploadList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgUploadList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DocumentType,
            this.UploadedFile2,
            this.UploadStatus,
            this.UploadederName,
            this.UploadederDept,
            this.UploadDate,
            this.View,
            this.UploadedFile});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgUploadList.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgUploadList.EnableHeadersVisualStyles = false;
            this.dgUploadList.Location = new System.Drawing.Point(3, 168);
            this.dgUploadList.MultiSelect = false;
            this.dgUploadList.Name = "dgUploadList";
            this.dgUploadList.RowHeadersVisible = false;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgUploadList.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgUploadList.Size = new System.Drawing.Size(1225, 471);
            this.dgUploadList.TabIndex = 154;
            this.dgUploadList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgUploadList_CellClick);
            this.dgUploadList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgUploadList_CellContentClick);
            this.dgUploadList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgUploadList_KeyUp);
            // 
            // DocumentType
            // 
            this.DocumentType.DataPropertyName = "DocumentType";
            this.DocumentType.HeaderText = "DocumentType";
            this.DocumentType.Name = "DocumentType";
            this.DocumentType.ReadOnly = true;
            this.DocumentType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DocumentType.Width = 119;
            // 
            // UploadedFile2
            // 
            this.UploadedFile2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.UploadedFile2.DataPropertyName = "Filename";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.UploadedFile2.DefaultCellStyle = dataGridViewCellStyle2;
            this.UploadedFile2.HeaderText = "File Name";
            this.UploadedFile2.Name = "UploadedFile2";
            this.UploadedFile2.ReadOnly = true;
            this.UploadedFile2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UploadedFile2.Width = 319;
            // 
            // UploadStatus
            // 
            this.UploadStatus.DataPropertyName = "UploadStatus";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.UploadStatus.DefaultCellStyle = dataGridViewCellStyle3;
            this.UploadStatus.HeaderText = "Uploaded Status";
            this.UploadStatus.Name = "UploadStatus";
            this.UploadStatus.ReadOnly = true;
            this.UploadStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UploadStatus.Width = 115;
            // 
            // UploadederName
            // 
            this.UploadederName.DataPropertyName = "UploaderName";
            this.UploadederName.HeaderText = "Uploaded By";
            this.UploadederName.Name = "UploadederName";
            this.UploadederName.ReadOnly = true;
            this.UploadederName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UploadederName.Width = 92;
            // 
            // UploadederDept
            // 
            this.UploadederDept.DataPropertyName = "UploaderDept";
            this.UploadederDept.HeaderText = "Department";
            this.UploadederDept.Name = "UploadederDept";
            this.UploadederDept.ReadOnly = true;
            this.UploadederDept.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UploadederDept.Width = 98;
            // 
            // UploadDate
            // 
            this.UploadDate.DataPropertyName = "UploadDate";
            this.UploadDate.HeaderText = "Upload Date";
            this.UploadDate.Name = "UploadDate";
            this.UploadDate.ReadOnly = true;
            this.UploadDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UploadDate.Width = 90;
            // 
            // View
            // 
            this.View.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.View.DefaultCellStyle = dataGridViewCellStyle4;
            this.View.HeaderText = "View";
            this.View.Name = "View";
            this.View.ReadOnly = true;
            this.View.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.View.Width = 114;
            // 
            // UploadedFile
            // 
            this.UploadedFile.DataPropertyName = "UploadedFile";
            this.UploadedFile.HeaderText = "UploadedFile";
            this.UploadedFile.Name = "UploadedFile";
            this.UploadedFile.ReadOnly = true;
            this.UploadedFile.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UploadedFile.Visible = false;
            this.UploadedFile.Width = 104;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // btnVerifyDoc
            // 
            this.btnVerifyDoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnVerifyDoc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerifyDoc.Location = new System.Drawing.Point(1172, 17);
            this.btnVerifyDoc.Name = "btnVerifyDoc";
            this.btnVerifyDoc.Size = new System.Drawing.Size(56, 41);
            this.btnVerifyDoc.TabIndex = 166;
            this.btnVerifyDoc.Text = "Verify Document";
            this.btnVerifyDoc.UseVisualStyleBackColor = false;
            this.btnVerifyDoc.Visible = false;
            this.btnVerifyDoc.Click += new System.EventHandler(this.btnVerifyDoc_Click);
            // 
            // btnDownloadProject
            // 
            this.btnDownloadProject.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnDownloadProject.FlatAppearance.BorderSize = 0;
            this.btnDownloadProject.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDownloadProject.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownloadProject.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_ftp_48;
            this.btnDownloadProject.Location = new System.Drawing.Point(919, 63);
            this.btnDownloadProject.Name = "btnDownloadProject";
            this.btnDownloadProject.Size = new System.Drawing.Size(73, 40);
            this.btnDownloadProject.TabIndex = 149;
            this.btnDownloadProject.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDownloadProject.UseVisualStyleBackColor = true;
            this.btnDownloadProject.Visible = false;
            this.btnDownloadProject.Click += new System.EventHandler(this.btnDownloadProject_Click);
            // 
            // btnReviewDoc
            // 
            this.btnReviewDoc.BackColor = System.Drawing.Color.Red;
            this.btnReviewDoc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReviewDoc.Location = new System.Drawing.Point(1176, 15);
            this.btnReviewDoc.Name = "btnReviewDoc";
            this.btnReviewDoc.Size = new System.Drawing.Size(52, 41);
            this.btnReviewDoc.TabIndex = 167;
            this.btnReviewDoc.Text = "Review Document";
            this.btnReviewDoc.UseVisualStyleBackColor = false;
            this.btnReviewDoc.Visible = false;
            this.btnReviewDoc.Click += new System.EventHandler(this.btnReviewDoc_Click);
            // 
            // cmbProjectDocument
            // 
            this.cmbProjectDocument.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbProjectDocument.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectDocument.Enabled = false;
            this.cmbProjectDocument.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectDocument.FormattingEnabled = true;
            this.cmbProjectDocument.Location = new System.Drawing.Point(180, 104);
            this.cmbProjectDocument.Name = "cmbProjectDocument";
            this.cmbProjectDocument.Size = new System.Drawing.Size(376, 26);
            this.cmbProjectDocument.TabIndex = 168;
            this.cmbProjectDocument.SelectedIndexChanged += new System.EventHandler(this.cmbProjectDocument_SelectedIndexChanged);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.Black;
            this.label60.Location = new System.Drawing.Point(-4, 106);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(178, 18);
            this.label60.TabIndex = 169;
            this.label60.Text = "Upload Project Document*:";
            // 
            // dtpUploaddate
            // 
            this.dtpUploaddate.CustomFormat = "";
            this.dtpUploaddate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpUploaddate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpUploaddate.Location = new System.Drawing.Point(1104, 109);
            this.dtpUploaddate.MaxDate = new System.DateTime(2028, 12, 31, 0, 0, 0, 0);
            this.dtpUploaddate.MinDate = new System.DateTime(2017, 1, 1, 0, 0, 0, 0);
            this.dtpUploaddate.Name = "dtpUploaddate";
            this.dtpUploaddate.Size = new System.Drawing.Size(124, 26);
            this.dtpUploaddate.TabIndex = 170;
            // 
            // cmbDocType
            // 
            this.cmbDocType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbDocType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDocType.Enabled = false;
            this.cmbDocType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDocType.FormattingEnabled = true;
            this.cmbDocType.Location = new System.Drawing.Point(180, 136);
            this.cmbDocType.Name = "cmbDocType";
            this.cmbDocType.Size = new System.Drawing.Size(376, 26);
            this.cmbDocType.TabIndex = 171;
            this.cmbDocType.SelectedIndexChanged += new System.EventHandler(this.cmbDocType_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(55, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 18);
            this.label2.TabIndex = 172;
            this.label2.Text = "Document Type*:";
            // 
            // frmProjectDocs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1240, 649);
            this.Controls.Add(this.cmbDocType);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpUploaddate);
            this.Controls.Add(this.cmbProjectDocument);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.btnReviewDoc);
            this.Controls.Add(this.btnVerifyDoc);
            this.Controls.Add(this.dgUploadList);
            this.Controls.Add(this.llbDownloadProject);
            this.Controls.Add(this.btnDownloadProject);
            this.Controls.Add(this.lblcustomername);
            this.Controls.Add(this.lblprojname);
            this.Controls.Add(this.lblcustomer);
            this.Controls.Add(this.lblProjectCode);
            this.Controls.Add(this.cmbProjectCode);
            this.Controls.Add(this.lblProjectName);
            this.Controls.Add(this.btnProjectView);
            this.Controls.Add(this.panel3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmProjectDocs";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Documents";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectDocs_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectDocs_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgUploadList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblcustomername;
        private System.Windows.Forms.Label lblprojname;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.ComboBox cmbProjectCode;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.LinkLabel llbDownloadProject;
        private System.Windows.Forms.Button btnDownloadProject;
        private System.Windows.Forms.DataGridView dgUploadList;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnVerifyDoc;
        private System.Windows.Forms.Button btnReviewDoc;
        private System.Windows.Forms.ComboBox cmbProjectDocument;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.DateTimePicker dtpUploaddate;
        private System.Windows.Forms.ComboBox cmbDocType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn DocumentType;
        private System.Windows.Forms.DataGridViewTextBoxColumn UploadedFile2;
        private System.Windows.Forms.DataGridViewTextBoxColumn UploadStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn UploadederName;
        private System.Windows.Forms.DataGridViewTextBoxColumn UploadederDept;
        private System.Windows.Forms.DataGridViewTextBoxColumn UploadDate;
        private System.Windows.Forms.DataGridViewButtonColumn View;
        private System.Windows.Forms.DataGridViewTextBoxColumn UploadedFile;
    }
}